  METAHASH = {
    :home => [38, 5, 22, 8],
  :TrainerVictory => "Victory!.ogg",
  :WildVictory => "Victory!.ogg",
  :TrainerBattle => "Battle- Trainer.ogg",
  :WildBattle => "Battle- Wild.ogg",
  :Surf => "Atmosphere- Surfing.ogg",
  :Bicycle => "Atmosphere- Rush.ogg",

  :player1 => {
    :tclass => :PkMnTRAINER_Male,
    # sprites,
    :walk => "BWCole",
    :run => "BWColeRun",
    :bike => "BWColeBike",
    :surf => "BWColeSurf",
    :dive => "BWColeSurf",
    :fishing => "BWColeFishing",
    :surffish => "fishing000surf",
    :ride => "vero_ride"
  },

  :player2 => {
    :tclass => :PkMnTRAINER_Female,
    # sprites,
    :walk => "BWElla",
    :run => "BWEllaRun",
    :bike => "BWEllaBike",
    :surf => "BWEllaSurfing",
    :dive => "BWEllaSurfing",
    :fishing => "BWEllaFishing",
    :surffish => "fishing001surf",
    :ride => "alice_ride"
  },

  :player3 => {},

  :player4 => {},

  :player5 => {
    :tclass => :PkMnTRAINER_Male2,
    # sprites,
    :walk => "boy2_walk",
    :run => "boy2_run",
    :bike => "boy2_bike",
    :surf => "boy2_surf",
    :dive => "boy2_dive",
    :fishing => "fishing004",
    :surffish => "fishing004surf",
    :ride => "kuro_ride"
  },

  :player6 => {
    :tclass => :PkMnTRAINER_Female2,
    # sprites,
    :walk => "girl2_walk",
    :run => "girl2_run",
    :bike => "girl2_bike",
    :surf => "girl2_surf",
    :dive => "girl2_dive",
    :fishing => "fishing005",
    :surffish => "fishing005surf",
    :ride => "lucia_ride"
  },

  :player7 => {},

  :player8 => {},

  :player9 => {
    :tclass => :PkMnTRAINER_NB,
    # sprites,
    :walk => "nb_walk",
    :run => "nb_run",
    :bike => "nb_bike",
    :surf => "nb_surf",
    :dive => "nb_dive",
    :fishing => "fishing006",
    :surffish => "fishing006surf",
    :ride => "ari_ride"
  },

  :player10 => {
    :tclass => :PkMnTRAINER_NB2,
    # sprites,
    :walk => "nb2_walk",
    :run => "nb2_run",
    :bike => "nb2_bike",
    :surf => "nb2_surf",
    :dive => "nb2_dive",
    :fishing => "fishing007",
    :surffish => "fishing007surf",
    :ride => "decibel_ride"
  },

  :player11 => {},

  :player12 => {},

  :player13 => {
    :tclass => :SIGMUND,
    # sprites,
    :walk => "trchar184",
    :run => "trchar184",
    :bike => "trchar184",
    :surf => "trchar184",
    :dive => "trchar184",
  },

  :player14 => {
    :tclass => :Taka2,
    # sprites,
    :walk => "trchar071",
    :run => "trchar071",
    :bike => "trchar071",
    :surf => "trchar071",
    :dive => "trchar071",
  },

  :player15 => {
    :tclass => :ZTAKA2,
    # sprites,
    :walk => "trchar071c",
    :run => "trchar071c",
    :bike => "trchar071c",
    :surf => "trchar071c",
    :dive => "trchar071c",
  },

  :player16 => {
    :tclass => :ZEL3,
    # sprites,
    :walk => "trchar070b",
    :run => "trchar070b",
    :bike => "trchar070b",
    :surf => "trchar070b",
    :dive => "trchar070b",
  },

  # -------------------------------
  1 => { #Soltree Town
    :WildVictoryME => "001-Victory01.mid",
    :MapPosition => [0, 13, 18],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :DiveMap => 310,
    :Bicycle => true,
    :BattleBack => "Town",
    :TrainerVictoryME => "004-Victory04.mid",
    :HealingSpot => [1, 8, 24],
    :ShowArea => true,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
    :SnapEdges => false,
  },

  # -------------------------------
  2 => {
    :MapPosition => [0, 13, 18],
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  3 => {
    :MapPosition => [0, 13, 18],
    :Bicycle => true,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  4 => {
    :MapPosition => [0, 13, 18],
    :Bicycle => false,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  5 => {
    :MapPosition => [0, 13, 18],
    :Bicycle => false,
    :HealingSpot => [6, 16, 9],
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  6 => {
    :MapPosition => [0, 13, 18],
    :Bicycle => false,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  7 => {
    :MapPosition => [0, 11, 18],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "Routes",
    :ShowArea => true,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  8 => {
    :SnapEdges => false,
    :MapPosition => [0, 10, 19],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "Town",
    :HealingSpot => [8, 27, 10],
    :ShowArea => true,
    :Outdoor => true,
  },

  # -------------------------------
  9 => {
    :MapPosition => [0, 10, 19],
    :Bicycle => false,
  },

  # -------------------------------
  10 => {
    :MapPosition => [0, 10, 19],
    :Bicycle => false,
  },

  # -------------------------------
  11 => {
    :MapPosition => [0, 10, 19],
    :Bicycle => false,
  },

  # -------------------------------
  12 => {
    :SnapEdges => false,
    :MapPosition => [0, 10, 19],
    :Bicycle => false,
  },

  # -------------------------------
  13 => {
    :SnapEdges => true,
    :MapPosition => [0, 8, 19],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "Mossy",
    :ShowArea => true,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  14 => {
    :SnapEdges => true,
    :MapPosition => [0, 8, 19],
    :Bicycle => true,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  15 => { #serpentine city
    :SnapEdges => false,
    :MapPosition => [0, 6, 19],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "City",
    :HealingSpot => [15, 45, 17],
    :ShowArea => true,
    :Outdoor => true,
  },

  # -------------------------------
  16 => { #Serpentine Gym
    :SnapEdges => false,
    :MapPosition => [0, 6, 19],
    :BattleBack => "Gym1",
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  17 => {
    :SnapEdges => false,
    :MapPosition => [0, 6, 19],
    :Bicycle => false,
  },

  # -------------------------------
  18 => {
    :SnapEdges => false,
    :MapPosition => [0, 6, 19],
  },

  # -------------------------------
  19 => {
    :SnapEdges => false,
    :MapPosition => [0, 6, 19],
  },

  # -------------------------------
  20 => {
    :SnapEdges => false,
    :MapPosition => [0, 6, 19],
  },

  # -------------------------------
  21 => {
    :SnapEdges => false,
    :MapPosition => [0, 6, 19],
  },

  # -------------------------------
  22 => {
    :SnapEdges => false,
    :MapPosition => [0, 6, 19],
  },

  # -------------------------------
  23 => {
    :SnapEdges => false,
    :MapPosition => [0, 6, 19],
  },

  # -------------------------------
  24 => {
    :SnapEdges => true,
    :MapPosition => [0, 6, 19],
  },

  # -------------------------------
  25 => { #dullfern forest
    :SnapEdges => true,
    :MapPosition => [0, 3, 19],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "Dullfern",
    :ShowArea => true,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  26 => { #Route 2
    :SnapEdges => true,
    :MapPosition => [0, 1, 18],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "Lake",
    :ShowArea => true,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  27 => {
    :MapPosition => [0, 1, 17],
    :Bicycle => true,
    :BattleBack => "City",
    :TrainerVictoryME => "004-Victory04.mid",
    :HealingSpot => [27, 32, 30],
    :ShowArea => true,
    :Weather => [:Rain,50],
    :Outdoor => true,
  },

  # -------------------------------
  28 => {
    :MapPosition => [0, 1, 17],
    :Bicycle => false,
  },

  # -------------------------------
  29 => {
    :SnapEdges => false,
    :MapPosition => [0, 1, 17],
    :Bicycle => false,
    :BattleBack => "CaveDarker",
    :HealingSpot => [29, 29, 30],
    :ShowArea => false,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  30 => {
    :MapPosition => [0, 1, 17],
    :Bicycle => false,
  },

  # -------------------------------
  31 => {
    :MapPosition => [0, 1, 17],
    :Bicycle => false,
  },

  # -------------------------------
  32 => {
    :MapPosition => [0, 1, 17],
    :Bicycle => false,
  },

  # -------------------------------
  33 => {
    :MapPosition => [0, 1, 17],
    :Bicycle => false,
  },

  # -------------------------------
  34 => {
    :MapPosition => [0, 1, 17],
    :Bicycle => false,
  },

  # -------------------------------
  35 => {
    :MapPosition => [0, 1, 17],
    :Bicycle => false,
  },

  # -------------------------------
  36 => {
    :MapPosition => [0, 1, 17],
    :Bicycle => false,
  },

  # -------------------------------
  37 => {
    :MapPosition => [0, 1, 17],
    :Bicycle => false,
  },

  # -------------------------------
  38 => {
    :MapPosition => [0, 1, 17],
    :Bicycle => false,
  },

  # -------------------------------
  39 => {
    :MapPosition => [0, 1, 17],
    :Bicycle => false,
    :Outdoor => false,
  },

  # -------------------------------
  40 => {
    :MapPosition => [0, 1, 17],
    :Bicycle => false,
    :Outdoor => false,
  },

  # -------------------------------
  41 => {
    :MapPosition => [0, 1, 17],
    :Bicycle => false,
    :Outdoor => false,
  },

  # -------------------------------
  42 => {
    :SnapEdges => true,
    :MapPosition => [0, 1, 17],
  },

  # -------------------------------
  43 => { #Blackleaf Woods
    :MapPosition => [0, 0, 17],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "Blackleaf",
    :ShowArea => true,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  44 => {
    :MapPosition => [0, 1, 15],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "Routes",
    :ShowArea => true,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  45 => {
    :SnapEdges => true,
    :MapPosition => [0, 1, 14],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "Rocky",
    :ShowArea => true,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  46 => {
    :MapPosition => [0, 1, 14],
    :Bicycle => true,
    :BattleBack => "Cave2",
    :ShowArea => true,
    :Outdoor => false,
  },

  # -------------------------------
  47 => {
    :MapPosition => [0, 1, 14],
    :Bicycle => true,
    :BattleBack => "Cave2",
    :HealingSpot => [47, 44, 19],
    :ShowArea => true,
    :Outdoor => false,
  },

  # -------------------------------
  48 => {
    :MapPosition => [0, 1, 14],
    :Bicycle => true,
    :BattleBack => "Cave2",
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  49 => {
    :MapPosition => [0, 1, 14],
    :Bicycle => true,
    :BattleBack => "Cave2",
  },

  # -------------------------------
  50 => {
    :DarkMap => true,
    :MapPosition => [0, 1, 14],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :DiveMap => 311,
    :Bicycle => true,
    :BattleBack => "Cave2",
    :ShowArea => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  51 => {
    :SnapEdges => true,
    :Dungeon => false,
    :DarkMap => false,
    :MapPosition => [0, 1, 14],
    :Bicycle => true,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  52 => {
    :SnapEdges => true,
    :Dungeon => false,
    :DarkMap => false,
    :MapPosition => [0, 1, 14],
    :Bicycle => true,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  53 => {
    :SnapEdges => false,
    :MapPosition => [0, 1, 11],
    :Bicycle => true,
    :BattleBack => "City",
    :HealingSpot => [53, 62, 56],
    :ShowArea => true,
    :Outdoor => true,
  },

  # -------------------------------
  54 => {
    :MapPosition => [0, 1, 11],
    :Bicycle => false,
  },

  # -------------------------------
  55 => {
    :MapPosition => [0, 1, 11],
    :BattleBack => "Gym3",
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  56 => {
    :MapPosition => [0, 1, 11],
  },

  # -------------------------------
  57 => {
    :SnapEdges => false,
    :MapPosition => [0, 1, 11],
    :Bicycle => false,
  },

  # -------------------------------
  58 => {
    :MapPosition => [0, 1, 11],
    :Bicycle => false,
    :BattleBack => "IndoorC",
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  59 => {
    :MapPosition => [0, 1, 11],
    :Bicycle => false,
    :BattleBack => "IndoorC",
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  60 => {
    :MapPosition => [0, 1, 11],
    :BattleBack => "IndoorC",
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  61 => {
    :MapPosition => [0, 1, 11],
    :Bicycle => false,
    :BattleBack => 5,
    :HealingSpot => [61, 29, 30],
    :ShowArea => true,
    :Outdoor => false,
  },

  # -------------------------------
  62 => {
    :MapPosition => [0, 1, 11],
  },

  # -------------------------------
  63 => {
    :MapPosition => [0, 1, 11],
    :Outdoor => false,
  },

  # -------------------------------
  64 => {
    :MapPosition => [0, 1, 11],
  },

  # -------------------------------
  65 => {
    :MapPosition => [0, 1, 11],
  },

  # -------------------------------
  66 => {
    :MapPosition => [0, 1, 11],
  },

  # -------------------------------
  67 => {
    :MapPosition => [0, 1, 11],
    :Bicycle => true,
  },

  # -------------------------------
  68 => {
    :SnapEdges => true,
    :MapPosition => [0, 1, 11],
    :Bicycle => true,
    :BattleBack => 8,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  69 => {
    :MapPosition => [0, 3, 11],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "Routes",
    :ShowArea => true,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  70 => {
    :SnapEdges => true,
    :WildVictoryME => "Victory - Wild Pokemon.mid",
    :MapPosition => [0, 3, 11],
    :Bicycle => true,
    :BattleBack => "IndoorGateway",
    :TrainerVictoryME => "Victory - Trainer.mid",
    :ShowArea => false,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  71 => {
    :MapPosition => [0, 3, 10],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :DiveMap => 312,
    :Bicycle => true,
    :BattleBack => "Routes",
    :ShowArea => true,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  72 => {
    :SnapEdges => true,
    :MapPosition => [0, 3, 10],
    :Bicycle => true,
    :BattleBack => 0,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  73 => {
    :MapPosition => [0, 3, 10],
    :BicycleAlways => true,
    :Bicycle => true,
    :BattleBack => "Cycling",
    :ShowArea => false,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  74 => {
    :SnapEdges => true,
    :MapPosition => [0, 3, 9],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "Path",
    :ShowArea => true,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  75 => {
    :MapPosition => [0, 3, 9],
    :Bicycle => false,
  },

  # -------------------------------
  76 => {
    :MapPosition => [0, 3, 9],
    :Bicycle => false,
  },

  # -------------------------------
  77 => {
    :MapPosition => [0, 3, 9],
    :Bicycle => false,
  },

  # -------------------------------
  78 => {
    :SnapEdges => true,
    :MapPosition => [0, 3, 9],
    :Bicycle => false,
    :BattleBack => "IndoorA",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => false,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  79 => {
    :SnapEdges => true,
    :MapPosition => [0, 6, 11],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "Desert",
    :ShowArea => true,
    :Weather => [:Sandstorm,50],
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  80 => {
    :SnapEdges => true,
    :MapPosition => [0, 6, 11],
    :Bicycle => true,
    :ShowArea => false,
  },

  # -------------------------------
  81 => {
    :SnapEdges => true,
    :MapPosition => [0, 6, 9],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "City",
    :HealingSpot => [81, 37, 39],
    :ShowArea => true,
    :Weather => [:Sandstorm,50],
    :Outdoor => true,
  },

  # -------------------------------
  82 => {
    :MapPosition => [0, 6, 5],
    :SafariMap => false,
    :HealingSpot => [11, 9, 8],
  },

  # -------------------------------
  83 => {
    :SnapEdges => true,
    :MapPosition => [0, 1, 18],
    :Bicycle => true,
    :BattleBack => 12,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  84 => {
    :MapPosition => [0, 6, 9],
    :Bicycle => false,
    :BattleBack => 5,
  },

  # -------------------------------
  85 => {
    :MapPosition => [0, 6, 9],
    :BattleBack => "Gym4",
    :Outdoor => false,
  },

  # -------------------------------
  86 => {
    :MapPosition => [0, 6, 9],
    :BattleBack => "Gym4",
  },

  # -------------------------------
  87 => {
    :SnapEdges => true,
    :MapPosition => [0, 3, 10],
    :Bicycle => true,
  },

  # -------------------------------
  88 => {
    :MapPosition => [0, 6, 9],
  },

  # -------------------------------
  89 => {
    :MapPosition => [0, 6, 9],
  },

  # -------------------------------
  90 => {
    :MapPosition => [0, 6, 9],
  },

  # -------------------------------
  91 => {
    :MapPosition => [0, 6, 9],
  },

  # -------------------------------
  92 => {
    :MapPosition => [0, 6, 9],
  },

  # -------------------------------
  93 => {
    :MapPosition => [0, 6, 9],
  },

  # -------------------------------
  94 => {
    :MapPosition => [0, 6, 9],
  },

  # -------------------------------
  95 => {
    :MapPosition => [0, 6, 9],
  },

  # -------------------------------
  96 => {
    :MapPosition => [0, 6, 11],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "Cave2",
  },

  # -------------------------------
  97 => {
    :MapPosition => [0, 6, 11],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :DiveMap => 313,
    :Bicycle => true,
    :BattleBack => "Cave2",
  },

  # -------------------------------
  98 => {
    :DarkMap => false,
    :MapPosition => [0, 0, 17],
    :BattleBack => "IndoorB",
  },

  # -------------------------------
  99 => {
    :SnapEdges => true,
    :MapPosition => [0, 6, 9],
    :Bicycle => true,
    :Outdoor => false,
  },

  # -------------------------------
  100 => {
    :MapPosition => [0, 3, 19],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :BattleBack => "TempleA",
  },

  # -------------------------------
  101 => {
    :MapPosition => [0, 1, 14],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :BattleBack => "TempleB",
  },

  # -------------------------------
  102 => {
    :SnapEdges => true,
    :MapPosition => [0, 6, 7],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "Fallrock",
    :ShowArea => true,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  103 => {
    :MapPosition => [0, 7, 6],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "Routes",
    :ShowArea => true,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  104 => {
    :MapPosition => [0, 9, 6],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "Beach",
    :HealingSpot => [104, 14, 14],
    :ShowArea => true,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  105 => {
    :MapPosition => [0, 9, 6],
    :Outdoor => false,
  },

  # -------------------------------
  106 => {
    :MapPosition => [0, 9, 6],
    :Outdoor => false,
  },

  # -------------------------------
  107 => {
    :MapPosition => [0, 9, 6],
    :Outdoor => false,
  },

  # -------------------------------
  108 => {
    :MapPosition => [0, 9, 6],
    :Outdoor => false,
  },

  # -------------------------------
  109 => {
    :MapPosition => [0, 9, 6],
    :Outdoor => false,
  },

  # -------------------------------
  110 => {
    :SnapEdges => true,
    :MapPosition => [0, 9, 6],
    :Bicycle => true,
    :BattleBack => "IndoorGateway",
    :Outdoor => false,
    :TrainerBattleBGM => "PSLLD_RivalBattle.mp3",
  },

  # -------------------------------
  111 => {
    :MapPosition => [0, 9, 6],
    :Bicycle => false,
    :Outdoor => false,
  },

  # -------------------------------
  112 => {
    :MapPosition => [0, 11, 6],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "Beach",
    :ShowArea => true,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  113 => {
    :MapPosition => [0, 12, 10],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "City",
    :HealingSpot => [113, 29, 30],
    :ShowArea => true,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  114 => {
    :MapPosition => [0, 12, 10],
  },

  # -------------------------------
  115 => {
    :MapPosition => [0, 12, 10],
  },

  # -------------------------------
  116 => {
    :MapPosition => [0, 12, 10],
  },

  # -------------------------------
  117 => {
    :MapPosition => [0, 12, 10],
  },

  # -------------------------------
  118 => {
    :MapPosition => [0, 12, 10],
  },

  # -------------------------------
  119 => {
    :MapPosition => [0, 12, 10],
    :Bicycle => false,
  },

  # -------------------------------
  120 => {
    :MapPosition => [0, 12, 11],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "RockyRoute",
    :ShowArea => true,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  121 => {
    :MapPosition => [0, 11, 12],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "RockyRoute",
    :ShowArea => true,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  122 => {
    :DarkMap => true,
    :MapPosition => [0, 12, 13],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "JewelMine",
    :ShowArea => true,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  123 => {
    :MapPosition => [0, 10, 12],
    :Bicycle => true,
    :BattleBack => "City",
    :HealingSpot => [123, 32, 39],
    :ShowArea => true,
    :Outdoor => true,
  },

  # -------------------------------
  124 => {
    :SnapEdges => false,
    :MapPosition => [0, 10, 12],
    :Bicycle => false,
  },

  # -------------------------------
  125 => {
    :SnapEdges => true,
    :MapPosition => [0, 10, 12],
    :Bicycle => false,
  },

  # -------------------------------
  126 => {
    :SnapEdges => true,
    :MapPosition => [0, 10, 12],
    :Bicycle => false,
  },

  # -------------------------------
  127 => {
    :SnapEdges => true,
    :MapPosition => [0, 10, 12],
    :Bicycle => false,
  },

  # -------------------------------
  128 => {
    :SnapEdges => true,
    :MapPosition => [0, 10, 12],
    :Bicycle => false,
  },

  # -------------------------------
  129 => {
    :SnapEdges => true,
    :MapPosition => [0, 10, 12],
    :Bicycle => false,
  },

  # -------------------------------
  130 => {
    :MapPosition => [0, 10, 12],
  },

  # -------------------------------
  131 => {
    :MapPosition => [0, 10, 12],
  },

  # -------------------------------
  132 => {
    :MapPosition => [0, 10, 12],
  },

  # -------------------------------
  133 => {
    :SnapEdges => true,
    :WildVictoryME => "001-Victory01.mid",
    :MapPosition => [0, 16, 2],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "Swamp",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => true,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  134 => {
    :SnapEdges => true,
    :MapPosition => [0, 9, 12],
    :Bicycle => false,
    :BattleBack => "Gym5",
    :ShowArea => false,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  135 => {
    :MapPosition => [0, 9, 11],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "MtHighpoint",
    :ShowArea => true,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  136 => {
    :MapPosition => [0, 12, 4],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :BattleBack => "Beach",
    :ShowArea => true,
    :Weather => [:Storm,100],
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  137 => {
    :MapPosition => [0, 12, 2],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "Beach",
    :ShowArea => true,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  138 => {
    :MapPosition => [0, 9, 2],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "Beach",
    :HealingSpot => [138, 35, 42],
    :ShowArea => true,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  139 => {
    :SnapEdges => false,
    :MapPosition => [0, 9, 2],
    :Bicycle => false,
    :Outdoor => false,
  },

  # -------------------------------
  140 => {
    :SnapEdges => true,
    :MapPosition => [0, 9, 2],
  },

  # -------------------------------
  141 => {
    :SnapEdges => true,
    :MapPosition => [0, 9, 2],
  },

  # -------------------------------
  142 => {
    :SnapEdges => true,
    :MapPosition => [0, 9, 2],
  },

  # -------------------------------
  143 => {
    :SnapEdges => true,
    :MapPosition => [0, 9, 2],
  },

  # -------------------------------
  144 => {
    :SnapEdges => true,
    :MapPosition => [0, 6, 7],
    :Bicycle => true,
  },

  # -------------------------------
  145 => {
    :SnapEdges => true,
    :MapPosition => [0, 9, 2],
    :Bicycle => false,
    :ShowArea => true,
  },

  # -------------------------------
  146 => {
    :SnapEdges => true,
    :MapPosition => [0, 8, 2],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :BattleBack => "Beach",
    :ShowArea => true,
    :Outdoor => true,
  },

  # -------------------------------
  147 => {
    :MapPosition => [0, 6, 7],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => false,
    :BattleBack => "Cave2",
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  148 => {
    :MapPosition => [0, 6, 7],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :DiveMap => 314,
    :Bicycle => false,
    :BattleBack => "Cave2",
    :ShowArea => false,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  149 => { #Serpentine Garden
    :MapPosition => [0, 6, 18],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "Flowers",
    #:Field => "Grassy",
    :ShowArea => true,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  150 => {
    :SnapEdges => true,
    :MapPosition => [0, 12, 10],
    :Bicycle => true,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  151 => {
    :SnapEdges => true,
    :MapPosition => [0, 11, 12],
    :Bicycle => true,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  152 => {
    :SnapEdges => true,
    :MapPosition => [0, 10, 2],
    :Bicycle => true,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  153 => {
    :SnapEdges => true,
  },

  # -------------------------------
  154 => {
    :SnapEdges => true,
    :Bicycle => true,
  },

  # -------------------------------
  155 => {
    :SnapEdges => true,
    :Bicycle => false,
  },

  # -------------------------------
  156 => {
    :SnapEdges => true,
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => false,
    :BattleBack => "Cave2",
    :ShowArea => false,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  157 => {
    :MapPosition => [0, 10, 11],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :BattleBack => "TempleC",
  },

  # -------------------------------
  158 => {
    :WildVictoryME => "001-Victory01.mid",
    :MapPosition => [0, 20, 2],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "Beach",
    :TrainerVictoryME => "Victory - Trainer.mid",
    :ShowArea => true,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  159 => {
    :WildVictoryME => "001-Victory01.mid",
    :MapPosition => [0, 21, 3],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :DiveMap => 266,
    :Bicycle => false,
    :BattleBack => "Reef",
    :TrainerVictoryME => "Victory - Trainer.mid",
    :ShowArea => true,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  160 => {
    :SnapEdges => true,
    :Bicycle => true,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  161 => {
    :SnapEdges => true,
    :WildVictoryME => "001-Victory01.mid",
    :MapPosition => [0, 16, 2],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => false,
    :BattleBack => "IndoorB",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => true,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  162 => {
    :WildVictoryME => "001-Victory01.mid",
    :MapPosition => [0, 22, 3],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => false,
    :BattleBack => "Beach",
    :TrainerVictoryME => "Victory - Trainer.mid",
    :ShowArea => true,
    :Weather => [:Storm,100],
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  163 => {
    :WildVictoryME => "001-Victory01.mid",
    :MapPosition => [0, 22, 5],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "Town",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => true,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  164 => {
    :MapPosition => [0, 22, 5],
    :Bicycle => false,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  165 => {
    :MapPosition => [0, 22, 5],
    :Bicycle => false,
    :BattleBack => "IndoorA",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => false,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  166 => {
    :MapPosition => [0, 22, 5],
    :Bicycle => false,
    :BattleBack => "IndoorA",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => false,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  167 => {
    :MapPosition => [0, 22, 5],
    :Bicycle => false,
    :BattleBack => "IndoorA",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => false,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  168 => {
    :MapPosition => [0, 22, 5],
    :Bicycle => false,
    :BattleBack => "IndoorA",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => false,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  169 => {
    :MapPosition => [0, 22, 5],
    :Bicycle => false,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  170 => {
    :MapPosition => [0, 22, 5],
    :Bicycle => false,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  171 => {
    :MapPosition => [0, 22, 5],
    :Bicycle => false,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  172 => {
    :MapPosition => [0, 22, 5],
    :Bicycle => false,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  173 => {
    :MapPosition => [0, 22, 5],
    :Bicycle => false,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  174 => {
    :MapPosition => [0, 22, 5],
    :Bicycle => false,
    :BattleBack => "IndoorA",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => false,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  175 => {
    :SnapEdges => false,
    :WildVictoryME => "001-Victory01.mid",
    :MapPosition => [0, 25, 16],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => false,
    :BattleBack => "CrystalCave",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => true,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  176 => {
    :SnapEdges => true,
    :WildVictoryME => "001-Victory01.mid",
    :MapPosition => [0, 22, 8],
    :SafariMap => true,
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "WildPlains",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => true,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  177 => {
    :SnapEdges => true,
    :WildVictoryME => "001-Victory01.mid",
    :MapPosition => [0, 25, 6],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "Lake",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => true,
    :Weather => [:Rain,50],
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  178 => {
    :WildVictoryME => "001-Victory01.mid",
    :MapPosition => [0, 28, 7],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "Town",
    :TrainerVictoryME => "004-Victory04.mid",
    :HealingSpot => [178, 9, 11],
    :ShowArea => true,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  179 => {
    :SnapEdges => false,
    :WildVictoryME => "001-Victory01.mid",
    :MapPosition => [0, 25, 16],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => false,
    :BattleBack => "CrystalCave",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => true,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  180 => {
    :MapPosition => [0, 29, 14],
    :Bicycle => false,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  181 => {
    :SnapEdges => true,
    :Bicycle => true,
    :Outdoor => false,
  },

  # -------------------------------
  182 => {
    :SnapEdges => true,
    :WildVictoryME => "001-Victory01.mid",
    :MapPosition => [0, 22, 8],
    :Bicycle => false,
    :BattleBack => "IndoorA",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => false,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  183 => {
    :SnapEdges => true,
    :MapPosition => [0, 25, 6],
    :Bicycle => true,
    :Outdoor => false,
  },

  # -------------------------------
  184 => {
    :SnapEdges => true,
    :DarkMap => false,
    :MapPosition => [0, 27, 19],
    :Bicycle => true,
    :BattleBack => "Gym2",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => false,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  185 => {
    :SnapEdges => false,
    :WildVictoryME => "001-Victory01.mid",
    :DarkMap => false,
    :MapPosition => [0, 29, 5],
    :SafariMap => false,
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => false,
    :BattleBack => "Beach",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => true,
    :Weather => [:Storm,50],
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  186 => {
    :SnapEdges => true,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  187 => {
    :SnapEdges => true,
    :DarkMap => false,
    :MapPosition => [0, 1, 17],
    :Bicycle => false,
    :BattleBack => "Gym2",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => false,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  188 => {
    :SnapEdges => false,
    :MapPosition => [0, 3, 10],
    :BicycleAlways => true,
    :Bicycle => true,
    :ShowArea => false,
    :Outdoor => true,
  },

  # -------------------------------
  189 => {
    :WildVictoryME => "001-Victory01.mid",
    :MapPosition => [0, 29, 2],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "Fallrock",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => true,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  190 => {
    :WildVictoryME => "001-Victory01.mid",
    :MapPosition => [0, 27, 2],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "City",
    :TrainerVictoryME => "004-Victory04.mid",
    :HealingSpot => [190, 26, 36],
    :ShowArea => true,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  191 => {
    :WildVictoryME => "001-Victory01.mid",
    :MapPosition => [0, 28, 9],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "Routes",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => true,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  192 => {
    :WildVictoryME => "001-Victory01.mid",
    :DarkMap => true,
    :MapPosition => [0, 28, 11],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "Whisper",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => true,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  193 => {
    :SnapEdges => false,
    :WildVictoryME => "001-Victory01.mid",
    :MapPosition => [0, 29, 2],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "Cave2",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => false,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  194 => {
    :SnapEdges => false,
    :WildVictoryME => "001-Victory01.mid",
    :MapPosition => [0, 25, 11],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "City",
    :TrainerVictoryME => "004-Victory04.mid",
    :HealingSpot => [194, 26, 37],
    :ShowArea => true,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  195 => {
    :WildVictoryME => "001-Victory01.mid",
    :MapPosition => [0, 23, 12],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "Routes",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => true,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  196 => {
    :SnapEdges => true,
    :WildVictoryME => "004-Victory04.mid",
    :MapPosition => [0, 21, 13],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :BattleBack => "Tropic",
    :TrainerVictoryME => "001-Victory01.mid",
    :ShowArea => true,
    :Weather => [:Rain,100],
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  197 => {
    :SnapEdges => true,
    :WildVictoryME => "004-Victory04.mid",
    :MapPosition => [0, 20, 12],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "Tropic",
    :TrainerVictoryME => "001-Victory01.mid",
    :ShowArea => true,
    :Weather => [:Rain,100],
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  198 => {
    :MapPosition => [0, 27, 2],
    :Bicycle => false,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  199 => {
    :MapPosition => [0, 25, 11],
    :Bicycle => false,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  200 => {
    :SnapEdges => true,
    :MapPosition => [0, 25, 11],
    :Bicycle => false,
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => true,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  201 => {
    :SnapEdges => false,
    :MapPosition => [0, 27, 2],
    :Bicycle => false,
    :BattleBack => "Castle",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => true,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  202 => {
    :MapPosition => [0, 27, 2],
    :Bicycle => false,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  203 => {
    :MapPosition => [0, 27, 2],
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  204 => {
    :SnapEdges => true,
    :MapPosition => [0, 27, 2],
    :Bicycle => false,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  205 => {
    :MapPosition => [0, 27, 2],
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  206 => {
    :MapPosition => [0, 27, 2],
    :Bicycle => false,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  207 => {
    :MapPosition => [0, 27, 2],
    :Bicycle => false,
    :ShowArea => true,
    :Outdoor => false,
  },

  # -------------------------------
  208 => {
    :MapPosition => [0, 25, 11],
    :Bicycle => false,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  209 => {
    :MapPosition => [0, 25, 11],
    :Bicycle => false,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  210 => {
    :MapPosition => [0, 25, 11],
    :Bicycle => false,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  211 => {
    :MapPosition => [0, 25, 11],
    :Bicycle => false,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  212 => {
    :MapPosition => [0, 25, 11],
    :Bicycle => false,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  213 => {
    :MapPosition => [0, 25, 11],
    :Bicycle => false,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  214 => {
    :MapPosition => [0, 22, 17],
    :Bicycle => true,
    :BattleBack => "SnowMountain",
    :ShowArea => true,
    :Weather => [:Snow,100],
    :Outdoor => true,
  },

  # -------------------------------
  215 => {
    :SnapEdges => true,
    :MapPosition => [0, 28, 7],
    :Bicycle => true,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  216 => {
    :SnapEdges => true,
    :MapPosition => [0, 21, 13],
    :Bicycle => true,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  217 => {
    :SnapEdges => false,
    :WildVictoryME => "001-Victory01.mid",
    :MapPosition => [0, 25, 16],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => false,
    :BattleBack => "CrystalCave",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => true,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  218 => {
    :SnapEdges => false,
    :WildVictoryME => "001-Victory01.mid",
    :MapPosition => [0, 25, 16],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => false,
    :BattleBack => "CrystalCave",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => false,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  219 => {
    :SnapEdges => true,
    :MapPosition => [0, 28, 11],
    :Bicycle => true,
    :BattleBack => "Whisper",
    :Outdoor => false,
  },

  # -------------------------------
  220 => {
    :MapPosition => [0, 25, 13],
    :Bicycle => true,
    :BattleBack => "SnowRoute",
    :ShowArea => true,
    :Outdoor => true,
  },

  # -------------------------------
  221 => {
    :MapPosition => [0, 26, 14],
    :Bicycle => true,
    :BattleBack => "SnowRoute",
    :ShowArea => true,
    :Weather => [:Snow,100],
    :Outdoor => true,
  },

  # -------------------------------
  222 => {
    :MapPosition => [0, 28, 14],
    :Bicycle => true,
    :BattleBack => "Town",
    :HealingSpot => [222, 16, 11],
    :ShowArea => true,
    :Outdoor => true,
  },

  # -------------------------------
  223 => {
    :WildVictoryME => "001-Victory01.mid",
    :MapPosition => [0, 22, 18],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "SnowMountain",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => true,
    :Weather => [:Snow,100],
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  224 => {
    :SnapEdges => true,
    :WildVictoryME => "001-Victory01.mid",
    :MapPosition => [0, 24, 19],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "Frosthail",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => true,
    :Weather => [:Snow,100],
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  225 => {
    :MapPosition => [0, 27, 19],
    :Bicycle => true,
    :BattleBack => "City",
    :HealingSpot => [225, 28, 30],
    :ShowArea => true,
    :Weather => [:Snow,100],
    :Outdoor => true,
  },

  # -------------------------------
  226 => {
    :WildVictoryME => "001-Victory01.mid",
    :MapPosition => [0, 29, 19],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => false,
    :BattleBack => "Icecaps",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => true,
    :Weather => [:Snow,100],
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  227 => {
    :SnapEdges => false,
    :WildVictoryME => "001-Victory01.mid",
    :MapPosition => [0, 5, 2],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :DiveMap => 331,
    :Bicycle => true,
    :BattleBack => "Isle",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => true,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  228 => {
    :SnapEdges => true,
    :MapPosition => [0, 1, 2],
    :Bicycle => true,
    :TrainerVictoryME => "004-Victory04.mid",
    :HealingSpot => [228, 39, 17],
    :ShowArea => true,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  232 => {
    :DarkMap => true,
    :MapPosition => [0, 1, 17],
    :Bicycle => false,
    :BattleBack => "CaveDarker",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => false,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  235 => {
    :WildVictoryME => "001-Victory01.mid",
    :MapPosition => [0, 22, 6],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "Routes",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => true,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  237 => {
    :MapPosition => [0, 29, 14],
    :Bicycle => false,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  238 => {
    :WildVictoryME => "001-Victory01.mid",
    :MapPosition => [0, 25, 7],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "Routes",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => true,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  239 => {
    :MapPosition => [0, 29, 14],
    :Bicycle => false,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  240 => {
    :MapPosition => [0, 29, 14],
    :Bicycle => false,
    :BattleBack => "IndoorA",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => false,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  260 => {
    :MapPosition => [0, 27, 19],
    :Bicycle => false,
    :BattleBack => "Gym7",
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  262 => {
    :WildVictoryME => "001-Victory01.mid",
    :DarkMap => true,
    :MapPosition => [0, 12, 13],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => false,
    :BattleBack => "JewelMine",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => false,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  264 => {
    :WildVictoryME => "001-Victory01.mid",
    :MapPosition => [0, 1, 10],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => false,
    :BattleBack => "City",
    :TrainerVictoryME => "004-Victory04.mid",
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  266 => {
    :SnapEdges => true,
    :WildVictoryME => "001-Victory01.mid",
    :MapPosition => [0, 21, 3],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => false,
    :BattleBack => "Underwater",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => false,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  267 => {
    :MapPosition => [0, 25, 11],
    :Bicycle => false,
    :BattleBack => "Gym6",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => false,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  268 => {
    :SnapEdges => true,
    :MapPosition => [0, 21, 3],
  },

  # -------------------------------
  269 => {
    :SnapEdges => true,
    :MapPosition => [0, 21, 3],
    :DiveMap => 268,
    :BattleBack => "Reef",
    :TrainerVictoryME => "004-Victory04.mid",
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  270 => {
    :MapPosition => [0, 29, 14],
    :Bicycle => true,
    :BattleBack => "Town",
    :HealingSpot => [222, 14, 11],
    :ShowArea => true,
    :Outdoor => true,
  },

  # -------------------------------
  271 => {
    :SnapEdges => true,
    :MapPosition => [0, 12, 10],
    :Bicycle => true,
    :Outdoor => false,
  },

  # -------------------------------
  272 => {
    :SnapEdges => true,
    :MapPosition => [0, 10, 12],
    :Bicycle => true,
    :Outdoor => false,
  },

  # -------------------------------
  273 => {
    :SnapEdges => false,
    :WildVictoryME => "001-Victory01.mid",
    :DarkMap => true,
    :MapPosition => [0, 5, 2],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "Cave2",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => false,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  274 => {
    :SnapEdges => true,
    :MapPosition => [0, 10, 19],
    :Bicycle => true,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  275 => {
    :SnapEdges => true,
    :Bicycle => true,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  276 => {
    :SnapEdges => true,
    :MapPosition => [0, 1, 17],
    :Bicycle => true,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  277 => {
    :MapPosition => [0, 28, 11],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :BattleBack => "TempleD",
  },

  # -------------------------------
  278 => {
    :MapPosition => [0, 21, 3],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :BattleBack => "TempleE",
  },

  # -------------------------------
  279 => {
    :MapPosition => [0, 1, 2],
    :Bicycle => false,
    :BattleBack => "League",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => false,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  280 => {
    :SnapEdges => false,
    :WildVictoryME => "001-Victory01.mid",
    :MapPosition => [0, 9, 2],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "Routes",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => true,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  283 => {
    :SnapEdges => true,
    :MapPosition => [0, 1, 2],
    :Bicycle => true,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  287 => {
    :SnapEdges => true,
    :MapPosition => [0, 22, 18],
    :Bicycle => true,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  288 => {
    :MapPosition => [0, 9, 2],
    :Bicycle => false,
    :BattleBack => "Gym8",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => false,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  289 => {
    :MapPosition => [0, 9, 2],
    :Bicycle => false,
    :BattleBack => "Gym8",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => false,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  290 => {
    :MapPosition => [0, 9, 2],
    :Bicycle => false,
    :BattleBack => "Gym8",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => false,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  291 => {
    :MapPosition => [0, 9, 2],
    :Bicycle => false,
    :BattleBack => "Gym8",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => false,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  292 => {
    :MapPosition => [0, 9, 2],
    :Bicycle => false,
    :BattleBack => "Gym8",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => false,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  293 => {
    :MapPosition => [0, 9, 2],
    :Bicycle => false,
    :BattleBack => "Gym8",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => false,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  294 => {
    :MapPosition => [0, 9, 2],
    :Bicycle => false,
    :BattleBack => "Gym8",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => false,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  295 => {
    :MapPosition => [0, 9, 2],
    :Bicycle => false,
    :BattleBack => "Gym8",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => false,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  296 => {
    :MapPosition => [0, 9, 2],
    :Bicycle => false,
    :BattleBack => "Gym8",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => false,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  297 => {
    :MapPosition => [0, 9, 2],
    :Bicycle => false,
    :BattleBack => "Gym8",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => false,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  298 => { #route 19
    :WildVictoryME => "001-Victory01.mid",
    :MapPosition => [0, 14, 18],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "Routes",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => true,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  299 => {
    :WildVictoryME => "001-Victory01.mid",
    :DarkMap => true,
    :MapPosition => [0, 20, 12],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "Cave2",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => true,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  300 => {
    :WildVictoryME => "001-Victory01.mid",
    :MapPosition => [0, 15, 14],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "Routes",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => true,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  301 => {
    :SnapEdges => true,
    :MapPosition => [0, 15, 14],
    :Bicycle => true,
    :ShowArea => false,
    :Outdoor => false,
  },

  # -------------------------------
  303 => {
    :WildVictoryME => "001-Victory01.mid",
    :MapPosition => [0, 1, 10],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => false,
    :BattleBack => "City",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => true,
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  305 => {
    :BattleBack => "Cave2",
  },

  # -------------------------------
  309 => {
    :DiveMap => 315,
    :BattleBack => "Cave2",
  },

  # -------------------------------
  316 => {
    :SnapEdges => true,
    :WildVictoryME => "001-Victory01.mid",
    :MapPosition => [0, 24, 19],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "Frosthail",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => true,
    :Weather => [:Snow,100],
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  318 => {
    :WildVictoryME => "001-Victory01.mid",
    :MapPosition => [0, 22, 18],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => true,
    :BattleBack => "SnowMountain",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => true,
    :Weather => [:Sunny,100],
    :Outdoor => true,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  324 => {
    :SnapEdges => false,
    :WildVictoryME => "001-Victory01.mid",
    :MapPosition => [0, 25, 16],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => false,
    :BattleBack => "CrystalCave",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => true,
    :Weather => [:Rain,100],
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  325 => {
    :SnapEdges => false,
    :WildVictoryME => "001-Victory01.mid",
    :MapPosition => [0, 25, 16],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => false,
    :BattleBack => "CrystalCave",
    :TrainerVictoryME => "004-Victory04.mid",
    :Weather => [:Rain,100],
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  326 => {
    :SnapEdges => false,
    :WildVictoryME => "001-Victory01.mid",
    :MapPosition => [0, 25, 16],
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => false,
    :BattleBack => "CrystalCave",
    :TrainerVictoryME => "004-Victory04.mid",
    :Weather => [:Rain,100],
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  # -------------------------------
  327 => {
    :MapPosition => [0, 25, 13],
    :Bicycle => true,
    :BattleBack => "SnowRoute",
    :ShowArea => true,
    :Outdoor => true,
  },

  # -------------------------------
  328 => {
    :MapPosition => [0, 26, 14],
    :Bicycle => true,
    :BattleBack => "SnowRoute",
    :ShowArea => true,
    :Outdoor => true,
  },

  # -------------------------------
  330 => {
    :BattleBack => "TempleC",
  },

  # Victory Isle (Underwater)
  331 => {
    :BattleBack => "Underwater",
  },

  334 => { #Route 19 Cave
    :SnapEdges => false,
    :WildVictoryME => "001-Victory01.mid",
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => false,
    :BattleBack => "Cave2",
    :TrainerVictoryME => "004-Victory04.mid",
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },
  
  335 => { #frigid tunnel
    :SnapEdges => false,
    :WildVictoryME => "001-Victory01.mid",
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => false,
    :BattleBack => "CrystalCave",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => true,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },

  336 => {
  :BattleBack => "TempleC",
  :Outdoor => false,
  :SnapEdges => false,
  },

  337 => { #Lost Tomb
    :SnapEdges => false,
    :WildVictoryME => "001-Victory01.mid",
    :WildBattleBGM => "PSLLD_WildBattle.mp3",
    :Bicycle => false,
    :BattleBack => "Cave2",
    :TrainerVictoryME => "004-Victory04.mid",
    :ShowArea => true,
    :Outdoor => false,
    :TrainerBattleBGM => "Vs_Trainer.mp3",
  },
}

