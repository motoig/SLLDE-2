TOWNMAP = {
  0 => {
    :name => "Rikoto",
    :filename => "map.png",
    :points => {
      [13, 18] => {
        :name => "Soltree Town",
        :poi => "Laboratory",
        :flyData => [1, 8, 24], # mapid, x, y
      },
      [12, 18] => {
        :name => "Route 1",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [11, 18] => {
        :name => "Route 1",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [10, 18] => {
        :name => "Route 1",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [10, 19] => {
        :name => "Mossy Town",
        :poi => "Keira's house",
        :flyData => [8, 26, 10], # mapid, x, y
      },
      [9, 19] => {
        :name => "Mossy Forest",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [8, 19] => {
        :name => "Mossy Forest",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [7, 19] => {
        :name => "Mossy Forest",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [6, 19] => {
        :name => "Serpentine City",
        :poi => "Serpentine Gym",
        :flyData => [15, 45, 17], # mapid, x, y
      },
      [6, 18] => {
        :name => "Serp. Garden",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [5, 19] => {
        :name => "Dullfern Forest",
        :poi => "Earth Temple",
        :flyData => [], # mapid, x, y
      },
      [4, 19] => {
        :name => "Dullfern Forest",
        :poi => "Earth Temple",
        :flyData => [], # mapid, x, y
      },
      [3, 19] => {
        :name => "Dullfern Forest",
        :poi => "Earth Temple",
        :flyData => [], # mapid, x, y
      },
      [2, 19] => {
        :name => "Dullfern Forest",
        :poi => "Earth Temple",
        :flyData => [], # mapid, x, y
      },
      [1, 19] => {
        :name => "Route 2",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [1, 18] => {
        :name => "Route 2",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [1, 17] => {
        :name => "Crestlight City",
        :poi => "Crestlight Gym",
        :flyData => [27, 32, 30], # mapid, x, y
      },
      [0, 17] => {
        :name => "Blackleaf Woods",
        :poi => "Haunted House",
        :flyData => [], # mapid, x, y
      },
      [1, 16] => {
        :name => "Route 3",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [1, 15] => {
        :name => "Route 3",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [1, 14] => {
        :name => "Thundrome Pass",
        :poi => "Volt Temple",
        :flyData => [], # mapid, x, y
      },
      [1, 13] => {
        :name => "Thundrome Pass",
        :poi => "Volt Temple",
        :flyData => [], # mapid, x, y
      },
      [1, 12] => {
        :name => "Thundrome Pass",
        :poi => "Volt Temple",
        :flyData => [], # mapid, x, y
      },
      [1, 11] => {
        :name => "Rustbolt City",
        :poi => "Rustbolt Gym",
        :flyData => [53, 62, 56], # mapid, x, y
      },
      [1, 10] => {
        :name => "Rustbolt Landfill",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [2, 11] => {
        :name => "Route 4",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [3, 11] => {
        :name => "Route 4",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [4, 11] => {
        :name => "Route 4",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [3, 10] => {
        :name => "Cycling Path",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [3, 9] => {
        :name => "Cycling Path",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [3, 8] => {
        :name => "Brushus Town",
        :poi => "Daycare Center",
        :flyData => [74, 16, 9], # mapid, x, y
      },
      [6, 11] => {
        :name => "Goldune Desert",
        :poi => "Goldune Cave",
        :flyData => [], # mapid, x, y
      },
      [5, 11] => {
        :name => "Goldune Desert",
        :poi => "Goldune Cave",
        :flyData => [], # mapid, x, y
      },
      [6, 10] => {
        :name => "Goldune Desert",
        :poi => "Goldune Cave",
        :flyData => [], # mapid, x, y
      },
      [6, 9] => {
        :name => "Goldune City",
        :poi => "Goldune Gym",
        :flyData => [81, 37, 39], # mapid, x, y
      },
      [6, 8] => {
        :name => "Fallrock Valley",
        :poi => "Fallrock Cave",
        :flyData => [], # mapid, x, y
      },
      [6, 7] => {
        :name => "Fallrock Valley",
        :poi => "Fallrock Cave",
        :flyData => [], # mapid, x, y
      },
      [6, 6] => {
        :name => "Route 5",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [7, 6] => {
        :name => "Route 5",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [8, 6] => {
        :name => "Route 5",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [9, 6] => {
        :name => "Orshore Town",
        :poi => "Burt's Balls",
        :flyData => [104, 14, 14], # mapid, x, y
      },
      [12, 10] => {
        :name => "Docking Port",
        :poi => "",
        :flyData => [113, 29, 30], # mapid, x, y
      },
      [9, 12] => {
        :name => "Highpoint City",
        :poi => "Highpoint Gym",
        :flyData => [123, 32, 39], # mapid, x, y
      },
      [9, 11] => {
        :name => "Mount Highpoint",
        :poi => "Core Temple",
        :flyData => [], # mapid, x, y
      },
      [9, 2] => {
        :name => "Waytide City",
        :poi => "Waytide Gym",
        :flyData => [138, 35, 42], # mapid, x, y
      },
      [1, 2] => {
        :name => "Rikoto League Village",
        :poi => "Pokémon League",
        :flyData => [228, 39, 17], # mapid, x, y
      },
      [16, 2] => {
        :name => "Goopool Swamp",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [22, 5] => {
        :name => "Coralite Town",
        :poi => "Lighthouse",
        :flyData => [163, 34, 31], # mapid, x, y
      },
      [28, 7] => {
        :name => "Sailport Town",
        :poi => "Sailing Museum",
        :flyData => [178, 8, 12], # mapid, x, y
      },
      [27, 2] => {
        :name => "Rassic City",
        :poi => "Rassic Castle",
        :flyData => [190, 26, 37], # mapid, x, y
      },
      [25, 11] => {
        :name => "Greenpine City",
        :poi => "Greenpine Gym",
        :flyData => [194, 27, 37], # mapid, x, y
      },
      [29, 14] => {
        :name => "Sario Town",
        :poi => "Dimension Gate",
        :flyData => [222, 16, 11], # mapid, x, y
      },
      [22, 16] => {
        :name => "Crystal Cave",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [27, 19] => {
        :name => "Subhail City",
        :poi => "Subhail Gym",
        :flyData => [225, 35, 30], # mapid, x, y
      },
      [29, 19] => {
        :name => "Subhail Icecaps",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [28, 19] => {
        :name => "Subhail Icecaps",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [24, 19] => {
        :name => "Frosthail Forest",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [25, 16] => {
        :name => "Crystal Cave",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [20, 13] => {
        :name => "Tropic Jungle",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [21, 13] => {
        :name => "Tropic Jungle",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [22, 13] => {
        :name => "Tropic Jungle",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [20, 12] => {
        :name => "Cascade Waterfall",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [25, 6] => {
        :name => "Lake Bliss",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [22, 8] => {
        :name => "Wild Plains",
        :poi => "Safari Zone",
        :flyData => [], # mapid, x, y
      },
      [29, 2] => {
        :name => "Ancient Pass",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [28, 11] => {
        :name => "Whisper Tunnel",
        :poi => "Wind Temple",
        :flyData => [], # mapid, x, y
      },
      [21, 3] => {
        :name => "Rainbow Reef",
        :poi => "Sea Temple",
        :flyData => [], # mapid, x, y
      },
      [5, 2] => {
        :name => "Victory Isle",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [12, 13] => {
        :name => "Jewel Mine",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [11, 6] => {
        :name => "Battle Bridge",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [10, 6] => {
        :name => "Battle Bridge",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [12, 6] => {
        :name => "Battle Bridge",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [12, 7] => {
        :name => "Battle Bridge",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [12, 8] => {
        :name => "Battle Bridge",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [12, 9] => {
        :name => "Battle Bridge",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [12, 11] => {
        :name => "Route 6",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [12, 12] => {
        :name => "Route 6",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [11, 12] => {
        :name => "Route 7",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [10, 12] => {
        :name => "Route 7",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [12, 5] => {
        :name => "Route 8",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [12, 4] => {
        :name => "Route 8",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [12, 3] => {
        :name => "Route 8",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [12, 2] => {
        :name => "Route 9",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [11, 2] => {
        :name => "Route 9",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [10, 2] => {
        :name => "Route 9",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [13, 2] => {
        :name => "Route 9",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [14, 2] => {
        :name => "Goopool Swamp",
        :poi => "Graveyard",
        :flyData => [], # mapid, x, y
      },
      [15, 2] => {
        :name => "Goopool Swamp",
        :poi => "Graveyard",
        :flyData => [], # mapid, x, y
      },
      [17, 2] => {
        :name => "Goopool Swamp",
        :poi => "Graveyard",
        :flyData => [], # mapid, x, y
      },
      [18, 2] => {
        :name => "Goopool Swamp",
        :poi => "Graveyard",
        :flyData => [], # mapid, x, y
      },
      [19, 2] => {
        :name => "Route 10 A",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [20, 2] => {
        :name => "Route 10 A",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [20, 3] => {
        :name => "Route 10 A",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [22, 3] => {
        :name => "Route 10 B",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [22, 4] => {
        :name => "Route 10 B",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [23, 7] => {
        :name => "Route 12",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [22, 6] => {
        :name => "Route 11",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [22, 7] => {
        :name => "Route 11",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [24, 7] => {
        :name => "Route 12",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [25, 7] => {
        :name => "Route 12",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [26, 7] => {
        :name => "Route 12",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [27, 7] => {
        :name => "Route 12",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [29, 4] => {
        :name => "Route 13",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [29, 5] => {
        :name => "Route 13",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [29, 6] => {
        :name => "Route 13",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [29, 7] => {
        :name => "Route 13",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [29, 3] => {
        :name => "Ancient Pass",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [28, 2] => {
        :name => "Ancient Pass",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [28, 8] => {
        :name => "Route 14",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [28, 9] => {
        :name => "Route 14",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [28, 10] => {
        :name => "Whisper Tunnel",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [27, 11] => {
        :name => "Whisper Tunnel",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [26, 11] => {
        :name => "Whisper Tunnel",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [24, 11] => {
        :name => "Route 15",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [23, 11] => {
        :name => "Route 15",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [23, 12] => {
        :name => "Route 15",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [23, 13] => {
        :name => "Route 15",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [25, 12] => {
        :name => "Route 16",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [25, 13] => {
        :name => "Route 16",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [25, 14] => {
        :name => "Route 16",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [25, 15] => {
        :name => "Route 16",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [24, 16] => {
        :name => "Crystal Cave",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [23, 16] => {
        :name => "Crystal Cave",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [26, 14] => {
        :name => "Route 17",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [27, 14] => {
        :name => "Route 17",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [28, 14] => {
        :name => "Route 17",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [22, 17] => {
        :name => "Snowpeak Village",
        :poi => "",
        :flyData => [214, 13, 30], # mapid, x, y
      },
      [22, 18] => {
        :name => "Route 18",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [22, 19] => {
        :name => "Frosthail Forest",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [23, 19] => {
        :name => "Frosthail Forest",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [25, 19] => {
        :name => "Frosthail Forest",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [26, 19] => {
        :name => "Frosthail Forest",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [1, 3] => {
        :name => "Victory Isle",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [1, 4] => {
        :name => "Victory Isle",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [2, 4] => {
        :name => "Victory Isle",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [3, 4] => {
        :name => "Victory Isle",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [4, 4] => {
        :name => "Victory Isle",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [4, 3] => {
        :name => "Victory Isle",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [4, 2] => {
        :name => "Victory Isle",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [6, 2] => {
        :name => "Victory Isle",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [6, 3] => {
        :name => "Victory Isle",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [7, 3] => {
        :name => "Victory Isle",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [7, 2] => {
        :name => "Victory Isle",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [8, 2] => {
        :name => "Victory Isle",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [14, 18] => {
        :name => "Route 19",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [15, 18] => {
        :name => "Route 19",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [15, 17] => {
        :name => "Route 21",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [15, 16] => {
        :name => "Route 21",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [15, 15] => {
        :name => "Route 21",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [15, 14] => {
        :name => "Route 20",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [14, 14] => {
        :name => "Route 20",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [16, 14] => {
        :name => "Route 20",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [13, 13] => {
        :name => "Jewel Mine",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [13, 14] => {
        :name => "Jewel Mine",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [17, 14] => {
        :name => "Tropic Cave",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [18, 14] => {
        :name => "Tropic Cave",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [18, 13] => {
        :name => "Tropic Cave",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [18, 12] => {
        :name => "Tropic Cave",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
      [19, 12] => {
        :name => "Tropic Cave",
        :poi => "",
        :flyData => [], # mapid, x, y
      },
    }
  },
}
