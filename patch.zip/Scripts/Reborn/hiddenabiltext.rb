  HIDDENABILHASH = {
   :MOUNTREE => {
      :badges => 5,
      :price => [[:BLUESHARD,20]]
    },
    :FLEAROE => {
      :badges => 5,
      :price => [[:BLUESHARD,20]]
    },
    :SALASLAM => {
      :badges => 6,
      :price => [[:BLUESHARD,30]]
    },
    :SNUFFUZZ => {
      :badges => 5,
      :price => [[:BLUESHARD,30]]
    },   
    :BUDSOAR => {
      :badges => 3,
      :price => [[:BLUESHARD,10]]
    },
    :WEASHOCK => {
      :badges => 6,
      :price => [[:BLUESHARD,20]]
    },
    :STICKUT => {
      :badges => 5,
      :price => [[:BLUESHARD,20]]
    },
    :AEROMA => {
      :badges => 5,
      :price => [[:BLUESHARD,40]]
    },
    :LAVENRINA => {
      :badges => 7,
      :price => [[:BLUESHARD,50]]
    },
    :LUNAPE => {
      :badges => 6,
      :price => [[:BLUESHARD,30]]
    },
    :DARTOAD => {
      :badges => 5,
      :price => [[:BLUESHARD,20]]
    },
    :DOVEHEART => {
      :badges => 5,
      :price => [[:BLUESHARD,40]]
    },
    :WIDOX => {
      :badges => 4,
      :price => [[:BLUESHARD,20]]
    },
    :GLOWING => {
      :badges => 4,
      :price => [[:BLUESHARD,20]]
    },
    :CRYSTOX => {
      :badges => 6,
      :price => [[:BLUESHARD,30]]
    },
    :CASSPRING => {
      :badges => 5,
      :price => [[:BLUESHARD,20]]
    },
    :CIRRIBUS => {
      :badges => 5,
      :price => [[:BLUESHARD,40]]
    },
    :PIXILILY => {
      :badges => 5,
      :price => [[:BLUESHARD,20]]
    },
    :SWELLEGANT => {
      :badges => 7,
      :price => [[:BLUESHARD,50]]
    },
    :ANGELIGHT => {
      :badges => 6,
      :price => [[:BLUESHARD,30]]
    },
    :RUBBUNNY => {
      :badges => 6,
      :price => [[:BLUESHARD,50]]
    },
    :SMAQUA => {
      :badges => 2,
      :price => [[:BLUESHARD,5]]
    },
    :MONSTRAP => {
      :badges => 6,
      :price => [[:BLUESHARD,20]]
    },
    :LOPHUG => {
      :badges => 3,
      :price => [[:BLUESHARD,20]]
    },
    :WEREHIDE => {
      :badges => 6,
      :price => [[:BLUESHARD,40]]
    },
    :TARATERROR => {
      :badges => 7,
      :price => [[:BLUESHARD,60]]
    },
    :GECKONE => {
      :badges => 5,
      :price => [[:BLUESHARD,30]]
    },
    :NATORON => {
      :badges => 5,
      :price => [[:BLUESHARD,20]]
    },
    :RUSHOT => {
      :badges => 6,
      :price => [[:BLUESHARD,60]]
    },
    :LEGENIX => {
      :badges => 7,
      :price => [[:BLUESHARD,50]]
    },
    :COBOLTA => {
      :badges => 5,
      :price => [[:BLUESHARD,20]]
    },
    :BUSHAIRY => {
      :badges => 5,
      :price => [[:BLUESHARD,20]]
    },
    :PLATYPLASH => {
      :badges => 5,
      :price => [[:BLUESHARD,20]]
    },
    :DINOPION => {
      :badges => 7,
      :price => [[:BLUESHARD,50]]
    },
    :FORMLING => {
      :badges => 7,
      :price => [[:BLUESHARD,100]]
    },
    :RAIZODON => {
      :badges => 7,
      :price => [[:BLUESHARD,40]]
    },
    :COUNTULA => {
      :badges => 5,
      :price => [[:BLUESHARD,40]]
    },
    :GOLOSSUS => {
      :badges => 5,
      :price => [[:BLUESHARD,20]]
    },
    :SIGNILEAF => {
      :badges => 3,
      :price => [[:BLUESHARD,10]]
    },
    :POOLDOG => {
      :badges => 5,
      :price => [[:BLUESHARD,15]]
    },
    :PSYFLOCK => {
      :badges => 5,
      :price => [[:BLUESHARD,50]]
    },
    :PHOXIVEN => {
      :badges => 5,
      :price => [[:BLUESHARD,20]]
    },
    :PARABOW => {
      :badges => 6,
      :price => [[:BLUESHARD,40]]
    },
    :HUMMZAP => {
      :badges => 5,
      :price => [[:BLUESHARD,30]]
    },
    :HORSHUSH => {
      :badges => 6,
      :price => [[:BLUESHARD,40]]
    },
    :WORMOLE => {
      :badges => 4,
      :price => [[:BLUESHARD,10]]
    },
    :SCORPINOVA => {
      :badges => 4,
      :price => [[:BLUESHARD,10]]
    },
    :CASSAND => {
      :badges => 5,
      :price => [[:BLUESHARD,40]]
    },
    :MONSTUNE => {
      :badges => 6,
      :price => [[:BLUESHARD,20]]
    },
    :PHAROBE => {
      :badges => 6,
      :price => [[:BLUESHARD,20]]
    },
    :ROOBEOP => {
      :badges => 6,
      :price => [[:BLUESHARD,30]]
    },
    :DODONT => {
      :badges => 5,
      :price => [[:BLUESHARD,10]]
    },
    :TAREXITE => {
      :badges => 5,
      :price => [[:BLUESHARD,30]]
    },
    :STEGASTEEL => {
      :badges => 7,
      :price => [[:BLUESHARD,40]]
    },
    :ATOMOTRIX => {
      :badges => 7,
      :price => [[:BLUESHARD,20]]
    },
    :JEWELTAL => {
      :badges => 5,
      :price => [[:BLUESHARD,30]]
    },
    :BULKER => {
      :badges => 7,
      :price => [[:BLUESHARD,30]]
    },
    :EXPLONADE => {
      :badges => 7,
      :price => [[:BLUESHARD,40]]
    },
    :DEERFERNO => {
      :badges => 7,
      :price => [[:BLUESHARD,40]]
    },
    :KAHULA => {
      :badges => 5,
      :price => [[:BLUESHARD,20]]
    },
    :KELPULA => {
      :badges => 6,
      :price => [[:BLUESHARD,50]]
    },
    :ECLIPSER => {
      :badges => 5,
      :price => [[:BLUESHARD,10]]
    },
    :FEVESTA => {
      :badges => 5,
      :price => [[:BLUESHARD,20]]
    },
    :MOOSTRIKE => {
      :badges => 5,
      :price => [[:BLUESHARD,10]]
    },
    :BILLAZE => {
      :badges => 5,
      :price => [[:BLUESHARD,30]]
    },
    :BLIMPOON => {
      :badges => 6,
      :price => [[:BLUESHARD,30]]
    },
    :MAGRIZZLY => {
      :badges => 6,
      :price => [[:BLUESHARD,30]]
    },
    :BARBVIRAL => {
      :badges => 5,
      :price => [[:BLUESHARD,30]]
    },
    :FYANT => {
      :badges => 5,
      :price => [[:BLUESHARD,10]]
    },
    :BLITZIBOOM => {
      :badges => 6,
      :price => [[:BLUESHARD,40]]
    },
    :VOLCADON => {
      :badges => 5,
      :price => [[:BLUESHARD,30]]
    },
    :PHANSHEET => {
      :badges => 7,
      :price => [[:BLUESHARD,50]]
    },
    :PSYTRIC => {
      :badges => 5,
      :price => [[:BLUESHARD,20]]
    },
    :BOULDOISE => {
      :badges => 5,
      :price => [[:BLUESHARD,20]]
    },
    :DOFLAP => {
      :badges => 6,
      :price => [[:BLUESHARD,50]]
    },
    :SHRIMPOON => {
      :badges => 6,
      :price => [[:BLUESHARD,30]]
    },
    :MARKRUSH => {
      :badges => 7,
      :price => [[:BLUESHARD,80]]
    },
    :KINIP => {
      :badges => 5,
      :price => [[:BLUESHARD,20]]
    },
    :GUPPISH => {
      :badges => 7,
      :price => [[:BLUESHARD,50]]
    },
    :EQWATER => {
      :badges => 5,
      :price => [[:BLUESHARD,20]]
    },
    :GLYDFIN => {
      :badges => 6,
      :price => [[:BLUESHARD,40]]
    },
    :SEAGIC => {
      :badges => 5,
      :price => [[:BLUESHARD,20]]
    },
    :ORCAIL => {
      :badges => 5,
      :price => [[:BLUESHARD,20]]
    },
    :JELLIKING => {
      :badges => 5,
      :price => [[:BLUESHARD,40]]
    },
    :JELLIQUEEN => {
      :badges => 5,
      :price => [[:BLUESHARD,30]]
    },
    :PARADISO => {
      :badges => 5,
      :price => [[:BLUESHARD,20]]
    },
    :TIDUDE => {
      :badges => 5,
      :price => [[:BLUESHARD,30]]
    },
    :ROCKSTER => {
      :badges => 5,
      :price => [[:BLUESHARD,30]]
    },
    :SNAPIKE => {
      :badges => 5,
      :price => [[:BLUESHARD,20]]
    },
    :ROTTOWEEN => {
      :badges => 6,
      :price => [[:BLUESHARD,30]]
    },
    :SWAMPHEAP => {
      :badges => 5,
      :price => [[:BLUESHARD,20]]
    },
    :TOXITOAD => {
      :badges => 6,
      :price => [[:BLUESHARD,30]]
    },
    :MOSLIQUO => {
      :badges => 6,
      :price => [[:BLUESHARD,30]]
    },
    :FUNGERM => {
      :badges => 5,
      :price => [[:BLUESHARD,30]]
    },
    :KAPPLASH => {
      :badges => 6,
      :price => [[:BLUESHARD,40]]
    },
    :TROLLGER => {
      :badges => 6,
      :price => [[:BLUESHARD,50]]
    },
    :SKELEDEEP => {
      :badges => 5,
      :price => [[:BLUESHARD,30]]
    },
    :SCROW => {
      :badges => 7,
      :price => [[:BLUESHARD,60]]
    },
    :GASLIT => {
      :badges => 5,
      :price => [[:BLUESHARD,30]]
    },
    :DOZAND => {
      :badges => 6,
      :price => [[:BLUESHARD,50]]
    },
    :BANSCREAM => {
      :badges => 5,
      :price => [[:BLUESHARD,30]]
    },
    :HYDROGON => {
      :badges => 6,
      :price => [[:BLUESHARD,50]]
    },
    :MERMARINE => {
      :badges => 5,
      :price => [[:BLUESHARD,30]]
    },
    :MERSIDON => {
      :badges => 5,
      :price => [[:BLUESHARD,30]]
    },
    :CORALTLE => {
      :badges => 5,
      :price => [[:BLUESHARD,30]]
    },
    :SPECSTONE => {
      :badges => 6,
      :price => [[:BLUESHARD,50]]
    },
    :GHOULLOW => {
      :badges => 6,
      :price => [[:BLUESHARD,40]]
    },
    :BAAWOOL => {
      :badges => 7,
      :price => [[:BLUESHARD,50]]
    },
    :BAABUSH => {
      :badges => 5,
      :price => [[:BLUESHARD,40]]
    },
    :BAABLAZE => {
      :badges => 5,
      :price => [[:BLUESHARD,30]]
    },
    :BAABBLE => {
      :badges => 5,
      :price => [[:BLUESHARD,30]]
    },
    :BAABREEZE => {
      :badges => 6,
      :price => [[:BLUESHARD,50]]
    },
    :BAABLOCK => {
      :badges => 5,
      :price => [[:BLUESHARD,40]]
    },
    :BAABLIZZ => {
      :badges => 5,
      :price => [[:BLUESHARD,30]]
    },
    :SPIRIX => {
      :badges => 5,
      :price => [[:BLUESHARD,20]]
    },
    :PUPETAL => {
      :badges => 5,
      :price => [[:BLUESHARD,30]]
    },
    :PUPYRO => {
      :badges => 7,
      :price => [[:BLUESHARD,50]]
    },
    :PUPLASH => {
      :badges => 6,
      :price => [[:BLUESHARD,40]]
    },
    :FELOVE => {
      :badges => 6,
      :price => [[:BLUESHARD,40]]
    },
    :YAKKLE => {
      :badges => 5,
      :price => [[:BLUESHARD,40]]
    },
    :LEONITE => {
      :badges => 7,
      :price => [[:BLUESHARD,50]]
    },
    :FLAPINKO => {
      :badges => 6,
      :price => [[:BLUESHARD,30]]
    },
    :ELESTOMP => {
      :badges => 6,
      :price => [[:BLUESHARD,40]]
    },
    :GIRAFLAME => {
      :badges => 6,
      :price => [[:BLUESHARD,40]]
    },
    :BULLSON => {
      :badges => 6,
      :price => [[:BLUESHARD,50]]
    },
    :ZEBRITE => {
      :badges => 5,
      :price => [[:BLUESHARD,20]]
    },
    :HIPPOTONE => {
      :badges => 5,
      :price => [[:BLUESHARD,20]]
    },
    :CHEETRIC => {
      :badges => 7,
      :price => [[:BLUESHARD,40]]
    },
    :METEROCK => {
      :badges => 5,
      :price => [[:BLUESHARD,30]]
    },
    :SYPHOON => {
      :badges => 7,
      :price => [[:BLUESHARD,60]]
    },
    :HYPNOSMOG => {
      :badges => 5,
      :price => [[:BLUESHARD,20]]
    },
    :NAWALE => {
      :badges => 5,
      :price => [[:BLUESHARD,30]]
    },
    :HUMBREECH => {
      :badges => 5,
      :price => [[:BLUESHARD,30]]
    },
    :LISQUID => {
      :badges => 7,
      :price => [[:BLUESHARD,50]]
    },
    :SILVICIOUS => {
      :badges => 6,
      :price => [[:BLUESHARD,30]]
    },
    :KONGRILLA => {
      :badges => 6,
      :price => [[:BLUESHARD,30]]
    },
    :WOODAWN => {
      :badges => 6,
      :price => [[:BLUESHARD,40]]
    },
    :AEROGON => {
      :badges => 6,
      :price => [[:BLUESHARD,50]]
    },
    :TIKITOKO => {
      :badges => 6,
      :price => [[:BLUESHARD,50]]
    },
    :CRYODRA => {
      :badges => 6,
      :price => [[:BLUESHARD,40]]
    },
    :BRACHIODON => {
      :badges => 5,
      :price => [[:BLUESHARD,30]]
    },
    :DRACOFLY => {
      :badges => 7,
      :price => [[:BLUESHARD,60]]
    },
    :TAPIBLAZE => {
      :badges => 5,
      :price => [[:BLUESHARD,40]]
    },
    :LAZLOTH => {
      :badges => 7,
      :price => [[:BLUESHARD,60]]
    },
    :MYSTABLET => {
      :badges => 5,
      :price => [[:BLUESHARD,20]]
    },
    :ARCTICHARE => {
      :badges => 6,
      :price => [[:BLUESHARD,50]]
    },
    :AVALDEER => {
      :badges => 5,
      :price => [[:BLUESHARD,20]]
    },
    :TUNDRILL => {
      :badges => 7,
      :price => [[:BLUESHARD,50]]
    },
    :HUSKOLD => {
      :badges => 6,
      :price => [[:BLUESHARD,40]]
    },
    :CRYSTIWING => {
      :badges => 7,
      :price => [[:BLUESHARD,60]]
    },
    :SNOWRONG => {
      :badges => 5,
      :price => [[:BLUESHARD,40]]
    },
    :AURORAI => {
      :badges => 6,
      :price => [[:BLUESHARD,50]]
    },
    :POLARPOW => {
      :badges => 5,
      :price => [[:BLUESHARD,10]]
    },
    :RINOTIC => {
      :badges => 7,
      :price => [[:BLUESHARD,80]]
    },
    :SEALBERG => {
      :badges => 5,
      :price => [[:BLUESHARD,30]]
    },
    :SASCRUSH => {
      :badges => 5,
      :price => [[:BLUESHARD,30]]
    },
    :BLIZZIBAT => {
      :badges => 6,
      :price => [[:BLUESHARD,40]]
    },
    :CARBONITRO => {
      :badges => 6,
      :price => [[:BLUESHARD,40]]
    },
    :GIGLOO => {
      :badges => 7,
      :price => [[:BLUESHARD,40]]
    },
    :PUFFPEAK => {
      :badges => 6,
      :price => [[:BLUESHARD,50]]
    },
    :PINGLADE => {
      :badges => 6,
      :price => [[:BLUESHARD,40]]
    },
    :MELOTWEET => {
      :badges => 6,
      :price => [[:BLUESHARD,50]]
    },
    :EELECT => {
      :badges => 5,
      :price => [[:BLUESHARD,30]]
    },
    :CHAMELECTRO => {
      :badges => 5,
      :price => [[:BLUESHARD,40]]
    },
    :COCOROCKO => {
      :badges => 5,
      :price => [[:BLUESHARD,20]]
    },
    :NEMBROSLUG => {
      :badges => 5,
      :price => [[:BLUESHARD,30]]
    },
    :FRUGON => {
      :badges => 7,
      :price => [[:BLUESHARD,100]]
    },
    :BLAZILISK => {
      :badges => 7,
      :price => [[:BLUESHARD,100]]
    },
    :BEAUTIFIN => {
      :badges => 7,
      :price => [[:BLUESHARD,100]]
    },
    :STRIKYON => {
      :badges => 7,
      :price => [[:BLUESHARD,100]]
    },
    :REPTILEON => {
      :badges => 6,
      :price => [[:BLUESHARD,50]]
    },
    :DAEOGON => {
      :badges => 6,
      :price => [[:BLUESHARD,60]]
    },
    :FLAREHARE => {
      :badges => 6,
      :price => [[:BLUESHARD,50]]
    },
    :SHRUBLADE => {
      :badges => 6,
      :price => [[:BLUESHARD,40]]
    },
    :SCARERIE => {
      :badges => 6,
      :price => [[:BLUESHARD,60]]
    },



  }