TTYPEHASH = {
    :PkMnTRAINER_Male => {
    :ID => 0,
    :title => "PkMn Trainer",
    :skill => 100,
    :moneymult => 100,
    :player => true,
  },

  :PkMnTRAINER_Female => {
    :ID => 1,
    :title => "PkMn Trainer",
    :skill => 100,
    :moneymult => 100,
    :player => true,
  },
  

  :RODNEY => {
    :ID => 8,
    :title => "Pokemon Trainer",
    :skill => 100,
    :moneymult => 5,
    :battleBGM => "Vs_Rival_Rodney.mp3",
    :sprite => "trainer008.png",
  },

  :PkMnTRAINER_Keira => {
    :ID => 7,
    :title => "Pokemon Trainer",
    :skill => 100,
    :moneymult => 5,
    :battleBGM => "Vs_Rival_Keira.mp3",
    :sprite => "trainer007.png",
  },

  
  :PkMnTRAINER_Rick => {
    :ID => 84,
    :title => "Pokemon Trainer",
    :skill => 100,
    :moneymult => 5,
    :battleBGM => "Vs_Rival_Rick.mp3",
    :sprite => "trainer084.png",
  },

    :BUGCATCHER_Male => {
    :ID => 4,
    :title => "Bug Catcher",
    :skill => 100,
    :moneymult => 5,
    :battleBGM => "Vs_Trainer.mp3",
    :sprite => "trainer004.png",
  },

  :LASS => {
    :ID => 2,
    :title => "Lass",
    :skill => 100,
    :moneymult => 5,
    :battleBGM => "Vs_Trainer.mp3",
    :sprite => "trainer002.png",
  },

  :BUGCATCHER_Female => {
    :ID => 5,
    :title => "Bug Catcher",
    :skill => 100,
    :moneymult => 5,
    :battleBGM => "Vs_Trainer.mp3",
    :sprite => "trainer005.png",
  },

  :SCHOOLKID_Male => {
    :ID => 9,
    :title => "School Kid",
    :skill => 100,
    :moneymult => 5,
    :battleBGM => "Vs_Trainer.mp3",
    :sprite => "trainer009.png",
  },

  :SCHOOLKID_Female => {
    :ID => 10,
    :title => "School Kid",
    :skill => 100,
    :moneymult => 5,
    :battleBGM => "Vs_Trainer.mp3",
    :sprite => "trainer010.png",
  },

  :TEACHER => {
    :ID => 11,
    :title => "Teacher",
    :skill => 100,
    :moneymult => 5,
    :battleBGM => "Vs_Trainer.mp3",
    :sprite => "trainer011.png",
  },

  :YOUNGSTER => {
    :ID => 3,
    :title => "Youngster",
    :skill => 100,
    :moneymult => 5,
    :battleBGM => "Vs_Trainer.mp3",
    :sprite => "trainer003.png",
  },

  :LEADER_Donna => {
    :ID => 15,
    :title => "Leader",
    :skill => 100,
    :moneymult => 5,
    :battleBGM => "Vs_Gym_Leader.mp3",
    :sprite => "trainer015.png",
  },

  :NURSE => {
    :ID => 33,
    :title => "Nurse",
    :skill => 100,
    :moneymult => 5,
    :battleBGM => "Vs_Trainer.mp3",
    :sprite => "trainer033.png",
  },

  :RUINMANIAC => {
    :ID => 42,
    :title => "Ruin Maniac",
    :skill => 100,
    :moneymult => 5,
    :battleBGM => "Vs_Trainer.mp3",
    :sprite => "trainer042.png",
  },

  :TWINS => {
    :ID => 23,
    :title => "Twins",
    :skill => 100,
    :moneymult => 5,
    :battleBGM => "Vs_Trainer.mp3",
    :sprite => "trainer023.png",
  },

  :PRESCHOOLER_Male => {
    :ID => 12,
    :title => "Preschooler",
    :skill => 100,
    :moneymult => 5,
    :battleBGM => "Vs_Trainer.mp3",
    :sprite => "trainer012.png",
  },

  :PRESCHOOLER_Female => {
    :ID => 13,
    :title => "Preschooler",
    :skill => 100,
    :moneymult => 5,
    :battleBGM => "Vs_Trainer.mp3",
    :sprite => "trainer013.png",
  },

  :TEAMLUNAR_Male => {
    :ID => 26,
    :title => "Team Lunar",
    :skill => 100,
    :moneymult => 5,
    :battleBGM => "Vs_Trainer.mp3",
    :sprite => "trainer026.png",
  },

  :TEAMLUNAR_Female => {
    :ID => 27,
    :title => "Team Lunar",
    :skill => 100,
    :moneymult => 5,
    :battleBGM => "Vs_Trainer.mp3",
    :sprite => "trainer027.png",
  },

  :LUNAROFFICIER_Scarlett => {
    :ID => 28,
    :title => "Lunar Commander",
    :skill => 100,
    :moneymult => 5,
    :battleBGM => "Vs_Solar_Lunar_Grunts.mp3",
    :sprite => "trainer028.png",
  },

  :LUNAROFFICIER_Marcus => {
    :ID => 29,
    :title => "Lunar Commander",
    :skill => 100,
    :moneymult => 5,
    :battleBGM => "Vs_Solar_Lunar_Grunts.mp3",
    :sprite => "trainer029.png",
  },

  :PkMnRANGER_Male => {
    :ID => 24,
    :title => "Pokemon Ranger",
    :skill => 100,
    :moneymult => 5,
    :battleBGM => "Vs_Trainer.mp3",
    :sprite => "trainer024.png",
  },

  :PkMnRANGER_Female => {
    :ID => 25,
    :title => "Pokemon Ranger",
    :skill => 100,
    :moneymult => 5,
    :battleBGM => "Vs_Trainer.mp3",
    :sprite => "trainer025.png",
  },

  :PARASOLLADY => {
    :ID => 32,
    :title => "Parasol Lady",
    :skill => 100,
    :moneymult => 5,
    :battleBGM => "Vs_Trainer.mp3",
    :sprite => "trainer032.png",
  },

  :PUNKGIRL => {
    :ID => 87,
    :title => "Punk Girl",
    :skill => 100,
    :moneymult => 5,
    :battleBGM => "Vs_Trainer.mp3",
    :sprite => "trainer087.png",
  },

  :BURGLAR => {
    :ID => 103,
    :title => "Burglar",
    :skill => 100,
    :moneymult => 5,
    :battleBGM => "Vs_Trainer.mp3",
    :sprite => "trainer103.png",
  },

  :HOMEDEFENSE => {
    :ID => 129,
    :title => "Home Defense System",
    :skill => 100,
    :moneymult => 5,
    :battleBGM => "Battle- Misc.ogg",
    :sprite => "trainer129.png",
  },

  :GUARDIANS => {
    :ID => 130,
    :title => "Ancient",
    :skill => 100,
    :moneymult => 5,
    :battleBGM => "Battle- Misc.ogg",
    :sprite => "trainer130.png",
  },

  :LEADER_Damon => {
    :ID => 16,
    :title => "Leader",
    :skill => 100,
    :moneymult => 5,
    :battleBGM => "Vs_Gym_Leader.mp3",
    :sprite => "trainer016.png",
  },

    :TEST => {
    :ID => 211,
    :title => "Umbral",
    :skill => 100,
    :moneymult => 14,
  }


}