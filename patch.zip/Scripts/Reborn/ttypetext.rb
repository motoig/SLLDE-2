TTYPEHASH = {
    :PkMnTRAINER_Male => {
    :ID => 0,
    :title => "PkMn Trainer",
    :skill => 100,
    :moneymult => 100,
    :player => true,
  },

  :PkMnTRAINER_Female => {
    :ID => 1,
    :title => "PkMn Trainer",
    :skill => 100,
    :moneymult => 100,
    :player => true,
  },
  

  :RODNEY => {
    :ID => 8,
    :title => "Pokemon Trainer",
    :skill => 100,
    :moneymult => 5,
    :battleBGM => "Vs_Rival_Rodney.mp3",
    :sprite => "trainer008.png",
  },

  :PkMnTRAINER_Keira => {
    :ID => 7,
    :title => "Pokemon Trainer",
    :skill => 100,
    :moneymult => 5,
    :battleBGM => "Vs_Rival_Keira.mp3",
    :sprite => "trainer007.png",
  },

    :BUGCATCHER_Male => {
    :ID => 4,
    :title => "Bug Catcher",
    :skill => 100,
    :moneymult => 5,
    :battleBGM => "Vs_Trainer.mp3",
    :sprite => "trainer004.png",
  },

  :LASS => {
    :ID => 2,
    :title => "Lass",
    :skill => 100,
    :moneymult => 5,
    :battleBGM => "Vs_Trainer.mp3",
    :sprite => "trainer002.png",
  },

  :BUGCATCHER_Female => {
    :ID => 5,
    :title => "Bug Catcher",
    :skill => 100,
    :moneymult => 5,
    :battleBGM => "Vs_Trainer.mp3",
    :sprite => "trainer005.png",
  },

  :SCHOOLKID_Male => {
    :ID => 9,
    :title => "School Kid",
    :skill => 100,
    :moneymult => 5,
    :battleBGM => "Vs_Trainer.mp3",
    :sprite => "trainer009.png",
  },

  :SCHOOLKID_Female => {
    :ID => 10,
    :title => "School Kid",
    :skill => 100,
    :moneymult => 5,
    :battleBGM => "Vs_Trainer.mp3",
    :sprite => "trainer010.png",
  },

  :TEACHER => {
    :ID => 11,
    :title => "Teacher",
    :skill => 100,
    :moneymult => 5,
    :battleBGM => "Vs_Trainer.mp3",
    :sprite => "trainer011.png",
  },

  :YOUNGSTER => {
    :ID => 3,
    :title => "Youngster",
    :skill => 100,
    :moneymult => 5,
    :battleBGM => "Vs_Trainer.mp3",
    :sprite => "trainer003.png",
  },

  :LEADER_Donna => {
    :ID => 15,
    :title => "Leader",
    :skill => 100,
    :moneymult => 5,
    :battleBGM => "Vs_Gym_Leader.mp3",
    :sprite => "trainer015.png",
  },

  :NURSE => {
    :ID => 33,
    :title => "Nurse",
    :skill => 100,
    :moneymult => 5,
    :battleBGM => "Vs_Trainer.mp3",
    :sprite => "trainer033.png",
  },

  :RUINMANIAC => {
    :ID => 42,
    :title => "Ruin Maniac",
    :skill => 100,
    :moneymult => 5,
    :battleBGM => "Vs_Trainer.mp3",
    :sprite => "trainer042.png",
  },





    :TEST => {
    :ID => 211,
    :title => "Umbral",
    :skill => 100,
    :moneymult => 14,
  }


}