FIELDEFFECTS = {
:INDOOR => {
	:name => "",
	:fieldMessage => [
		""
	],
	:graphic => ["Indoor","IndoorA","IndoorB","IndoorC","IndoorD","IndoorE","IndoorVenam","AxisHigh","NightmareSchool"],
	:secretPower => "TRIATTACK",
	:naturePower => :TRIATTACK,
	:mimicry => :NORMAL,	
	:damageMods => { #damage modifiers for specific moves, written as multipliers (e.g. 1.5 => [:TACKLE])
	},				# a damage mod of 0 denotes the move failing on this field
	:accuracyMods => { #accuracy chance for specific moves, written as percent chance to hit (e.g. 80 => [:TOXIC])
	},				# a accuracy mod of 0 denotes the move always hitting on this field
	:moveMessages => {	# the field message displayed when using a move (written as "message" => [move1,move2....] )
	},
	:typeMods => {	# secondary types applied to moves (written as "type" => [move1,move2,....])
	},
	:typeAddOns => { # secondary types applied to entire types (written as SecondaryTypeSymbol => [typesymbol1,typesymbol2,...])
	},
	:moveEffects => { # arbitrary commands that are evaled after a move executes but before fieldchanges are checked
	},	#evaled in "fieldEffectAfterMove" method in the battle class
	:typeBoosts => { # damage multipliers applied to all moves of a specific type (e.g. 1.3 => [:FIRE,:WATER])
	},
	:typeMessages => {	# field message shown when using a move of the denoted type ("message" => [type1,type2,....])
	},
	:typeCondition => {	# conditions for the type boost written as a string of conditions that are evaled later
	},	#evaled as a function on the move class
	:typeEffects => { # arbitrary commands attached to all moves of a type that are evaled after a move executes but before fieldchanges are checked
	},	#evaled in "fieldEffectAfterMove" method in the battle class
	:changeCondition => { # conditions for a field change written as a string of conditions that are evaled later
	},	#evaled as a function on the move class
	:fieldChange => {  # moves that change this field to a different field (Fieldsymbol => [move1,move2,....])
	},
	:dontChangeBackup => [],	#list of moves which store the current field as backup when changing the field
	:changeMessage => {	# message displayed when changing a field to a different one ("message" => [move1,move2,....])
	},
	:statusMods => [],	#list of non-damaging moves boosted by the field in different ways, for field highlighting
	:changeEffects => {#additional effects that happen when specific moves change a field (such as corrisive mist explosion)
	},	#evaled in "fieldEffectAfterMove" method in the battle class
	:seed => {		# the seed effects on this field
		:seedtype => nil,	# which seed is activated
		:effect => nil,		# which battler effect is being changed if any
		:duration => nil,	# duration of the extra effect
		:message => nil,	# message shown with the seeds boost
		:animation => nil,	# animation associated with the effect
		:stats => {			# statchanges caused by the seed
		},
	},
	:overlay => {		# effects of this field as an overlay instead of a full field #Rejuv
		:damageMods => { #damage modifiers for specific moves, written as multipliers (e.g. 1.5 => [:TACKLE])
		},				# a damage mod of 0 denotes the move failing on this field
		:typeMods => {	# secondary types applied to moves (written as "type" => [move1,move2,....])
		},
		:moveMessages => {	# the field message displayed when using a move (written as "message" => [move1,move2....] )
		},
		:typeBoosts => { # damage multipliers applied to all moves of a specific type (e.g. 1.3 => [:FIRE,:WATER])
		},
		:typeMessages => {	# field message shown when using a move of the denoted type ("message" => [type1,type2,....])
		},
		:typeCondition => {	# conditions for the type boost written as a string of conditions that are evaled later
		},	#evaled as a function on the move class
		:statusMods => [],	#list of non-damaging moves boosted by the field in different ways, for field highlighting
	},
},
:ELECTERRAIN => {
	:name => "Electric Terrain",
	:fieldMessage => [
		"The field is hyper-charged!",
	],
	:graphic => ["Electric","Gym3"],
	:secretPower => "SHOCKWAVE",
	:naturePower => :THUNDERBOLT,
	:mimicry => :ELECTRIC,
	:damageMods => {
		1.5 => [:EXPLOSION, :SELFDESTRUCT, :HURRICANE, :SURF, :SMACKDOWN, :MUDDYWATER, :THOUSANDARROWS],
		2.0 => [:MAGNETBOMB],
	},
	:accuracyMods => {
	},
	:moveMessages => {
		"The explosion became hyper-charged!" => [:EXPLOSION, :SELFDESTRUCT],
		"The attack became hyper-charged!" => [:HURRICANE, :SURF, :SMACKDOWN, :MUDDYWATER, :THOUSANDARROWS, :ELECTROSHOT],
		"The attack powered up!" => [:MAGNETBOMB],
	},
	:typeMods => {
		:ELECTRIC => [:EXPLOSION, :SELFDESTRUCT, :SMACKDOWN, :SURF, :MUDDYWATER, :HURRICANE, :THOUSANDARROWS, :HYDROVORTEX],
	},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:ELECTRIC],
	},
	:typeMessages => {
		"The Electric Terrain strengthened the attack!" => [:ELECTRIC],
	},
	:typeCondition => {
	},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
		:INDOOR => [:MUDSPORT, :TECTONICRAGE],
	},
	:dontChangeBackup => [:MUDSPORT],
	:changeMessage => {
		 "The hyper-charged terrain shorted out!" => [:MUDSPORT, :TECTONICRAGE],
	},
	:statusMods => [:CHARGE, :EERIEIMPULSE, :MAGNETRISE, :SPIKES, :ELECTRIFY, :ELECTROSHOT, :MAGNETICFLUX],
	:changeEffects => {},
	:seed => {
		:seedtype => :ELEMENTALSEED,
		:effect => :Charge,
		:duration => 2,
		:message => "{1} began charging power!",
		:animation => :CHARGE,
		:stats => {
			PBStats::SPEED => 1,
		},
	},
	:overlay => {
		:damageMods => {
			1.5 => [:HURRICANE, :SURF, :SMACKDOWN, :MUDDYWATER, :THOUSANDARROWS],
			2.0 => [:MAGNETBOMB],
		},
		:typeMods => {
			:ELECTRIC => [:EXPLOSION, :SELFDESTRUCT, :SMACKDOWN, :SURF, :MUDDYWATER, :HURRICANE, :THOUSANDARROWS],
		},
		:moveMessages => {
			"The attack became hyper-charged!" => [:HURRICANE, :SURF, :SMACKDOWN, :MUDDYWATER, :THOUSANDARROWS],
			"The attack powered up!" => [:MAGNETBOMB],
		},
		:typeBoosts => {
			1.5 => [:ELECTRIC],
		},
		:typeMessages => {
			"The Electric Terrain strengthened the attack!" => [:ELECTRIC],
		},
		:typeCondition => {
		},
		:statusMods => [:MAGNETRISE],
	},
},
:GRASSY => {
	:name => "Grassy Terrain",
	:fieldMessage => [
		"The field is in full bloom."
	],
	:graphic => ["Grassy","Flowers",],
	:secretPower => "SEEDBOMB",
	:naturePower => :ENERGYBALL,
	:mimicry => :GRASS,
	:damageMods => {
		1.5 => [:FAIRYWIND, :SILVERWIND, :OMINOUSWIND, :ICYWIND, :RAZORWIND, :GUST, :TWISTER, :GRASSKNOT, :GALESTRIKE, :TRAILBLAZE],
		0.5 => [:MUDDYWATER, :SURF, :EARTHQUAKE, :MAGNITUDE, :BULLDOZE],
	},
	:accuracyMods => {
		80 => [:GRASSWHISTLE],
	},
	:moveMessages => {
		"The wind picked up strength from the field!" => [:FAIRYWIND, :SILVERWIND, :OMINOUSWIND, :ICYWIND, :RAZORWIND, :GUST, :TWISTER, :GALESTRIKE],
		"The grass strengthened the attack!" => [:GRASSKNOT, :TRAILBLAZE],
		"The grass softened the attack..." => [:MUDDYWATER, :SURF, :EARTHQUAKE, :MAGNITUDE, :BULLDOZE],
	},
	:typeMods => {},
	:typeAddOns => {},
	:moveEffects => {
		"@battle.field.counter += 1" => [:SURF],
		"@battle.field.counter += 2" => [:MUDDYWATER],
	},
	:typeBoosts => {
		1.5 => [:GRASS, :FIRE],
	},
	:typeMessages => {
		"The Grassy Terrain strengthened the attack!" => [:GRASS],
		"The grass below caught flame!" => [:FIRE],
	},
	:typeCondition => {

	},
	:typeEffects => {},
	:changeCondition => {
		:SWAMP => "@battle.field.counter > 2",
	},
	:fieldChange => {
		:CORROSIVE => [:SLUDGEWAVE, :ACIDDOWNPOUR],
		:SWAMP => [:SURF, :MUDDYWATER],
	},
	:dontChangeBackup => [],
	:changeMessage => {
		 "The grassy terrain was corroded!" => [:SLUDGEWAVE, :ACIDDOWNPOUR],
		 "The grassy terrain became marshy!" => [:SURF, :MUDDYWATER],
	},
	:statusMods => [:COIL, :GROWTH, :FLORALHEALING, :SYNTHESIS, :WORRYSEED, :INGRAIN, :GRASSWHISTLE, :LEECHSEED, :COTTONSPORE, :TRAILBLAZE],
	:changeEffects => {},
	:seed => {
		:seedtype => :ELEMENTALSEED,
		:effect => :Ingrain,
		:duration => true,
		:message => "{1} planted its roots!",
		:animation => :INGRAIN,
		:stats => {
			PBStats::DEFENSE => 1,
		},
	},
	:overlay => {
		:damageMods => {
			1.5 => [:FAIRYWIND, :SILVERWIND, :OMINOUSWIND, :ICYWIND, :RAZORWIND, :GUST, :TWISTER],
		},
		:typeMods => {
		},
		:moveMessages => {
			"The wind picked up strength from the field!" => [:FAIRYWIND, :SILVERWIND, :OMINOUSWIND, :ICYWIND, :RAZORWIND, :GUST, :TWISTER],
		},
		:typeBoosts => {
			1.5 => [:GRASS],
		},
		:typeMessages => {
			"The Grassy Terrain strengthened the attack!" => [:GRASS],
		},
		:typeCondition => {
		},
		:statusMods => [],
	},
},
:MISTY => {
	:name => "Misty Terrain",
	:fieldMessage => [
		"Mist settles on the field."
	],
	:graphic => ["Misty"],
	:secretPower => "MISTBALL",
	:naturePower => :MISTBALL,
	:mimicry => :FAIRY,
	:damageMods => {
		1.5 => [:MYSTICALFIRE, :MAGICALLEAF, :DOOMDUMMY, :ICYWIND, :MISTBALL, :AURASPHERE, :STEAMERUPTION, :SILVERWIND, :MOONGEISTBEAM, :SMOG, :CLEARSMOG, :STRANGESTEAM, :SPRINGTIDESTORM, :MATCHAGOTCHA, :SCENTEDGEYSER, :GILDEDARROW, :GILDEDHELIX, :FROSTBREATH],
		0.5 => [:DARKPULSE, :SHADOWBALL, :NIGHTDAZE],
		0 => [:SELFDESTRUCT, :EXPLOSION, :MINDBLOWN],
	},
	:accuracyMods => {
		100 => [:SWEETKISS],
	},
	:moveMessages => {
		"The mist's energy strengthened the attack!" => [:GILDEDHELIX, :GILDEDARROW, :MYSTICALFIRE, :MAGICALLEAF, :DOOMDUMMY, :ICYWIND, :MISTBALL, :AURASPHERE, :STEAMERUPTION, :SILVERWIND, :MOONGEISTBEAM, :SMOG, :CLEARSMOG, :STRANGESTEAM, :SPRINGTIDESTORM, :MATCHAGOTCHA, :SCENTEDGEYSER, :FROSTBREATH],
		"The mist softened the attack..." => [:DARKPULSE, :SHADOWBALL, :NIGHTDAZE],
		"The damp mist prevented the explosion..." => [:SELFDESTRUCT, :EXPLOSION, :MINDBLOWN],
	},
	:typeMods => {},
	:typeAddOns => {},
	:moveEffects => {
		"@battle.field.counter += 1" => [:CLEARSMOG, :SMOG, :POISONGAS],
		"@battle.field.counter = 2" => [:ACIDDOWNPOUR],
	},
	:typeBoosts => {
		1.5 => [:FAIRY],
		0.5 => [:DRAGON],
	},
	:typeMessages => {
		"The Misty Terrain strengthened the attack!" => [:FAIRY],
		"The Misty Terrain weakened the attack!" => [:DRAGON],
	},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {
		:CORROSIVEMIST => "@battle.field.counter > 1",
	},
	:fieldChange => {
		:INDOOR => [:WHIRLWIND, :GUST, :RAZORWIND, :DEFOG, :HURRICANE, :TWISTER, :TAILWIND, :SUPERSONICSKYSTRIKE],
		:CORROSIVEMIST => [:CLEARSMOG, :SMOG, :POISONGAS, :ACIDDOWNPOUR]
	},
	:dontChangeBackup => [:CLEARSMOG, :SMOG, :POISONGAS, :ACIDDOWNPOUR],
	:changeMessage => {
		 "The mist was blown away!" => [:WHIRLWIND, :GUST, :RAZORWIND, :DEFOG, :HURRICANE, :TWISTER, :TAILWIND, :SUPERSONICSKYSTRIKE],
		 "The mist was corroded!" => [:CLEARSMOG, :SMOG, :POISONGAS, :ACIDDOWNPOUR],
	},
	:statusMods => [:COSMICPOWER, :AROMATICMIST, :SWEETSCENT, :WISH, :AQUARING],
	:changeEffects => {},
	:seed => {
		:seedtype => :ELEMENTALSEED,
		:effect => :Wish,
		:duration => 2,
		:message => "A wish was made for {1}!",
		:animation => :WISH,
		:stats => {
			PBStats::SPDEF => 1,
		},
	},
	:overlay => {
		:damageMods => {
			1.5 => [:GILDEDHELIX, :GILDEDARROW, :MYSTICALFIRE, :MAGICALLEAF, :ICYWIND, :MISTBALL, :AURASPHERE, :SILVERWIND, :MOONGEISTBEAM, :SMOG, :CLEARSMOG, :STRANGESTEAM],
		},
		:typeMods => {
		},
		:moveMessages => {
			"The mist's energy strengthened the attack!" => [:GILDEDHELIX, :GILDEDARROW, :MYSTICALFIRE, :MAGICALLEAF, :ICYWIND, :MISTBALL, :AURASPHERE, :SILVERWIND, :MOONGEISTBEAM, :SMOG, :CLEARSMOG, :STRANGESTEAM],
		},
		:typeBoosts => {
			1.5 => [:FAIRY],
		},
		:typeMessages => {
			"The Misty Terrain strengthened the attack!" => [:FAIRY],
		},
		:typeCondition => {
		},
		:statusMods => [],
	},
},
:DARKCRYSTALCAVERN => {
	:name => "Dark Crystal Cavern",
	:fieldMessage => [
		"The crystals shine pale as bones..."
	],
	:graphic => ["DarkCrystalCavern"],
	:secretPower => "DARKPULSE",
	:naturePower => :EERIESPELL,
	:mimicry => :DARK,
	:damageMods => {
		1.5 => [:EERIESPELL,:SKITTERSMACK,:FREEZINGGLARE,:SNARL,:DRAGONRUSH,:MYSTICALFIRE, :LUMINACRASH, :ELECTROCLAP, :FLOWERTRICK, :AURORABEAM, :SIGNALBEAM, :FLASHCANNON, :LUSTERPURGE, :DAZZLINGGLEAM, :MIRRORSHOT, :MIRRORBEAM, :TECHNOBLAST, :DOOMDUMMY, :POWERGEM, :MOONGEISTBEAM, :PHOTONGEYSER, :DIAMONDSTORM, :MENACINGMOONRAZEMAELSTROM, :BLACKHOLEECLIPSE, :RAZORTHREAD],
		1.2 => [:DARKPULSE, :NIGHTDAZE, :NIGHTSLASH, :SHADOWBALL, :SHADOWPUNCH, :SHADOWCLAW, :SHADOWSNEAK, :SHADOWFORCE, :SHADOWBONE, :HEXINGSLASH, :MENACINGMOONRAZEMAELSTROM],
		2.0 => [:PRISMATICLASER, :ASTONISH],
		0.5 => [:LIGHTTHATBURNSTHESKY],
	},
	:accuracyMods => {
		100 => [:DARKVOID],
	},
	:moveMessages => {
		"The darkness began to gather...!" => [:DARKPULSE, :NIGHTDAZE, :NIGHTSLASH],
		"The attack flew out from the darkness!" => [:ELECTROCLAP, :FLOWERTRICK, :DRAGONRUSH, :SKITTERSMACK],
		"The shadows strengthened the attack!" => [:SHADOWBALL, :SHADOWPUNCH, :SHADOWCLAW, :SHADOWSNEAK, :SHADOWFORCE, :SHADOWBONE, :HEXINGSLASH, :MENACINGMOONRAZEMAELSTROM],
		"The crystals' light strengthened the attack!" => [:AURORABEAM, :MYSTICALFIRE, :LUMINACRASH, :SIGNALBEAM, :FLASHCANNON, :LUSTERPURGE, :DAZZLINGGLEAM, :MIRRORSHOT, :MIRRORBEAM, :TECHNOBLAST, :DOOMDUMMY, :POWERGEM, :MOONGEISTBEAM, :PHOTONGEYSER, :DIAMONDSTORM],
		"The crystal split the attack!" => [:PRISMATICLASER],
		"The attack collected crystal shards!" => [:RAZORTHREAD],
		"The consuming darkness fed the attack!" => [:BLACKHOLEECLIPSE],
		"The menacing darkness strengthened the attack!" => [:SNARL,:ASTONISH,:FREEZINGGLARE,:EERIESPELL],
		"{1} couldn't consume much light..." => [:LIGHTTHATBURNSTHESKY],
	},
	:typeMods => {
		:DARK => [:RAZORTHREAD],
	},
	:typeAddOns => {
		:DARK => [:ROCK],
	},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:DARK,:GHOST,:ROCK],
	},
	:typeMessages => {
		"The darkness strengthened the attack!" => [:DARK, :GHOST],
		"The dark crystals strengthened the attack!" => [:ROCK],
	},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {
		:CRYSTALCAVERN => "suncheck",
		:CAVE => "@battle.field.counter > 1",
	},
	:fieldChange => {
		:CAVE => [:EARTHQUAKE, :BULLDOZE, :MAGNITUDE, :FISSURE, :TECTONICRAGE],
		:CRYSTALCAVERN => [:SUNNYDAY],
	},
	:dontChangeBackup => [:SUNNYDAY],
	:changeMessage => {
		 "The dark crystals were shattered!" => [:EARTHQUAKE, :BULLDOZE, :MAGNITUDE, :FISSURE, :TECTONICRAGE],
		 "The sun lit up the crystal cavern!" => [:SUNNYDAY],
	},
	:statusMods => [:FLASH, :DARKVOID, :MOONLIGHT, :AURORAVEIL, :LIGHTSCREEN,:REFLECT,:ARENITEWALL,:SCARYFACE,:MEANLOOK],
	:changeEffects => {},
	:seed => {
		:seedtype => :MAGICALSEED,
		:effect => :MagicCoat,
		:duration => true,
		:message => "{1} shrouded itself with Magic Coat!",
		:animation => :MAGICCOAT,
		:stats => {
			PBStats::SPDEF => 1,
		},
	},
},
:CHESS => {
	:name => "Chess Board",
	:fieldMessage => [
		"Opening variation set."
	],
	:graphic => ["Chess","Chess1"],
	:secretPower => "FEINT",
	:naturePower => :ANCIENTPOWER,
	:mimicry => :PSYCHIC,
	:damageMods => {
		1.5 => [:FEINT, :FEINTATTACK, :FAKEOUT, :SUCKERPUNCH, :FIRSTIMPRESSION, :SHADOWSNEAK, :SMARTSTRIKE, :STRENGTH, :ANCIENTPOWER, :PSYCHIC, :CONTINENTALCRUSH, :SECRETPOWER, :SHATTEREDPSYCHE, :FOULPLAY],
	},
	:accuracyMods => {},
	:moveMessages => {
		"En passant!" => [:FEINT, :FEINTATTACK, :FAKEOUT, :SUCKERPUNCH, :FIRSTIMPRESSION, :SHADOWSNEAK, :SMARTSTRIKE],
		"A deceptive tactic!" => [:FOULPLAY]
	},
	:typeMods => {
		:ROCK => [:STRENGTH, :ANCIENTPOWER, :PSYCHIC, :SECRETPOWER, :SHATTEREDPSYCHE],
	},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {},
	:typeMessages => {},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {},
	:dontChangeBackup => [],
	:changeMessage => {},
	:statusMods => [:CALMMIND, :NASTYPLOT, :TRICKROOM, :NORETREAT, :KINGSSHIELD, :OBSTRUCT],
	:changeEffects => {},
	:seed => {
		:seedtype => :SYNTHETICSEED,
		:effect => :MagicCoat,
		:duration => true,
		:message => "{1} shrouded itself with Magic Coat!",
		:animation => :MAGICCOAT,
		:stats => {
			PBStats::SPATK => 1,
			PBStats::ACCURACY => 1, # LAWDS - we calculating
		},
	},
},
:BIGTOP => {
	:name => "Big Top Arena",
	:fieldMessage => [
		"Now presenting...!"
	],
	:graphic => ["BigTop"],
	:secretPower => "DYNAMICPUNCH",
	:naturePower => :ACROBATICS,
	:mimicry => :FIGHTING,
	:damageMods => {
		1.5 => [:VINEWHIP, :POWERWHIP, :FIRELASH, :FIERYDANCE, :DEADLYPIROUETTE, :PETALDANCE, :REVELATIONDANCE, :FLY, :ACROBATICS, :FIRSTIMPRESSION, :DRUMBEATING, :AQUASTEP, :GILDEDARROW, :GILDEDHELIX],
		2.0 => [:PAYDAY],
	},
	:accuracyMods => {
		100 => [:SING],
	},
	:moveMessages => {
		"Back, foul beast!" => [:VINEWHIP, :POWERWHIP, :FIRELASH],
		"What grace!" => [:FIERYDANCE, :PETALDANCE, :REVELATIONDANCE, :AQUASTEP, :DEADLYPIROUETTE],
		"An extravagant aerial finish!" => [:FLY, :ACROBATICS],
		"And what an entrance it is!" => [:FIRSTIMPRESSION],
		"And a little extra for you, darling!" => [:PAYDAY],
		"Loud and clear!" => [:DRUMBEATING, :DRAGONCHEER],
		"Bullseye!" => [:GILDEDARROW,:GILDEDHELIX],
	},
	:typeMods => {},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {},
	:typeMessages => {},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {},
	:dontChangeBackup => [],
	:changeMessage => {},
	:statusMods => [:ENCORE, :DRAGONDANCE, :DRAGONCHEER, :QUIVERDANCE, :SWORDSDANCE, :FEATHERDANCE, :SING, :RAINDANCE, :BELLYDRUM, :SPOTLIGHT, :AQUABATICS, :CLANGOROUSSOUL],
	:changeEffects => {},
	:seed => {
		:seedtype => :SYNTHETICSEED,
		:effect => :HelpingHand,
		:duration => true,
		:message => "{1} accepts the crowd's help!",
		:animation => :HELPINGHAND,
		:stats => {
			PBStats::ATTACK => 1,
		},
	},
},
:VOLCANIC => {
	:name => "Volcanic Field",
	:fieldMessage => [
		"The field is molten!"
	],
	:graphic => ["Burning"],
	:secretPower => "FLAMETHROWER",
	:naturePower => :FLAMETHROWER,
	:mimicry => :FIRE,
	:damageMods => {
		2.0 => [:SMOG, :CLEARSMOG],
		1.5 => [:SMACKDOWN, :THOUSANDARROWS, :ROCKSLIDE, :FIRESPIN, :ROCKTHROW, :STONEEDGE],
		1.3 => [:SCALD],
		0 => [:HAIL],
	},
	:accuracyMods => {
		100 => [:WILLOWISP],
	},
	:moveMessages => {
		"The flames spread from the attack!" => [:SMOG, :CLEARSMOG, :FIRESPIN],
		"The opponent was knocked into the flames!" => [:SMACKDOWN, :THOUSANDARROWS, :ROCKSLIDE, :ROCKTHROW, :STONEEDGE],
		"The hail melted away." => [:HAIL],
		"The field super-heated the attack!" => [:SCALD],
	},
	:typeMods => {
		:FIRE => [:SMACKDOWN, :SMOG, :CLEARSMOG, :THOUSANDARROWS, :ROCKSLIDE, :ROCKTHROW, :STONEEDGE],
	},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:FIRE],
		0.7 => [:GRASS, :ICE],
	},
	:typeMessages => {
		"The blaze amplified the attack!" => [:FIRE],
		"The blaze softened the attack..." => [:GRASS, :ICE],
	},
	:typeCondition => {
	},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
		:CAVE => [:WHIRLWIND, :GUST, :RAZORWIND, :DEFOG, :HURRICANE, :TWISTER, :TAILWIND, :SUPERSONICSKYSTRIKE, :WATERSPORT, :SURF, :MUDDYWATER, :WATERSPOUT, :WATERPLEDGE, :SPARKLINGARIA, :SLUDGEWAVE, :SANDTOMB, :CONTINENTALCRUSH, :HYDROVORTEX, :OCEANICOPERETTA],
	},
	:dontChangeBackup => [],
	:changeMessage => {
		 "The grime snuffed out the flame!" => [:SLUDGEWAVE],
		 "The wind snuffed out the flame!" => [:WHIRLWIND, :GUST, :RAZORWIND, :DEFOG, :HURRICANE, :TWISTER, :TAILWIND, :SUPERSONICSKYSTRIKE],
		 "The water snuffed out the flame!" => [:WATERSPORT, :SURF, :MUDDYWATER, :WATERSPOUT, :WATERPLEDGE, :SPARKLINGARIA, :HYDROVORTEX, :OCEANICOPERETTA],
		 "The sand snuffed out the flame!" => [:SANDTOMB, :CONTINENTALCRUSH],
	},
	:statusMods => [:WILLOWISP, :SMOKESCREEN],
	:changeEffects => {},
	:seed => {
		:seedtype => :ELEMENTALSEED,
		:effect => :MultiTurnAttack,
		:duration => :FIRESPIN,
		:message => "{1} was trapped in the vortex!",
		:animation => :FIRESPIN,
		:stats => {
			PBStats::ATTACK => 1,
			PBStats::SPATK => 1,
			PBStats::SPEED => 1,
		},
	},
},
:SWAMP => {
	:name => "Swamp Field",
	:fieldMessage => [
		"The field is swamped."
	],
	:graphic => ["Swamp"],
	:secretPower => "MUDDYWATER",
	:naturePower => :MUDDYWATER,
	:mimicry => :WATER,
	:damageMods => {
		1.5 => [:MUDBOMB, :MUDSHOT, :MUDSLAP, :MUDBARRAGE, :MUDDYWATER, :SLUDGEWAVE, :GUNKSHOT, :BRINE, :SMACKDOWN, :THOUSANDARROWS, :HYDROVORTEX, :SAVAGESPINOUT],
		1.3 => [:PSYCHICHARVEST],
		0.7 => [:ACROBATICS, :FLYINGPRESS, :GALESTRIKE, :BRAVEBIRD],
		0.25 => [:EARTHQUAKE, :MAGNITUDE, :BULLDOZE],
		0 => [:SELFDESTRUCT, :EXPLOSION, :MINDBLOWN]
	},
	:accuracyMods => {
		100 => [:SLEEPPOWDER, :STUNSPORE, :POISONPOWDER],
	},
	:moveMessages => {
		"The murk strengthened the attack!" => [:MUDBOMB, :MUDSHOT, :MUDSLAP, :MUDBARRAGE, :MUDDYWATER, :SLUDGEWAVE, :GUNKSHOT, :BRINE, :SMACKDOWN, :THOUSANDARROWS, :HYDROVORTEX],
		"The attack waded through thick mud..." => [:ACROBATICS, :FLYINGPRESS, :GALESTRIKE, :BRAVEBIRD],
		"The attack dissipated in the soggy ground..." => [:EARTHQUAKE, :MAGNITUDE, :BULLDOZE],
		"The dampness prevents the explosion!" => [:SELFDESTRUCT, :EXPLOSION, :MINDBLOWN],
		"There are bugs EVERYWHERE!" => [:SAVAGESPINOUT],
		"Thick mangroves line the area!" => [:PSYCHICHARVEST],
	},
	:typeMods => {
		:WATER => [:SMACKDOWN, :THOUSANDARROWS],
	},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		1.3 => [:BUG,:WATER,:GRASS],
		0.8 => [:FIRE],
	},
	:typeMessages => {
		"Bugs are swarming everywhere!" => [:BUG],
		"The dampness strengthened the attack!" => [:WATER],
		"Thick mangroves line the area!" => [:GRASS],
		"The dampness weakened the flame..." => [:FIRE],
	},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {},
	:dontChangeBackup => [],
	:changeMessage => {},
	:statusMods => [:SLEEPPOWDER, :STUNSPORE, :POISONPOWDER, :AQUARING, :STRENGTHSAP, :LEECHSEED, :STRINGSHOT, :SPIDERWEB],
	:changeEffects => {},
	:seed => {
		:seedtype => :TELLURICSEED,
		:effect => nil,
		:duration => nil,
		:message => "{1}'s body became clear!",
		:animation => :ROCKPOLISH,
		:stats => {
			PBStats::DEFENSE => 1,
		},
	},
},
:RAINBOW => {
	:name => "Rainbow Field",
	:fieldMessage => [
		"What does it mean?"
	],
	:graphic => ["Rainbow"],
	:secretPower => "AURORABEAM",
	:naturePower => :AURORABEAM,
	:mimicry => :FAIRY,
	:damageMods => {
		1.5 => [:ACROBATICS, :FIERYDANCE, :DEADLYPIROUETTE, :GALESTRIKE, :BOUNCE, :FLY, :AQUASTEP, :SILVERWIND, :MYSTICALFIRE, :DRAGONPULSE, :SACREDFIRE, :FIREPLEDGE, :WATERPLEDGE, :GRASSPLEDGE, :AURORABEAM, :MIRRORBEAM, :JUDGMENT, :RELICSONG, :HIDDENPOWER, :SECRETPOWER, :WEATHERBALL, :MISTBALL, :HEARTSTAMP, :MOONBLAST, :ZENHEADBUTT, :SPARKLINGARIA, :FLEURCANNON, :PRISMATICLASER, :TWINKLETACKLE, :OCEANICOPERETTA, :SOLARBEAM, :SOLARBLADE, :DAZZLINGGLEAM, :HIDDENPOWERNOR, :HIDDENPOWERFIR, :HIDDENPOWERFIG, :HIDDENPOWERWAT, :HIDDENPOWERFLY, :HIDDENPOWERGRA, :HIDDENPOWERPOI, :HIDDENPOWERELE, :HIDDENPOWERGRO, :HIDDENPOWERPSY, :HIDDENPOWERROC, :HIDDENPOWERICE, :HIDDENPOWERBUG, :HIDDENPOWERDRA, :HIDDENPOWERGHO, :HIDDENPOWERDAR, :HIDDENPOWERSTE, :HIDDENPOWERFAI],
		0 => [:NIGHTMARE]
	},
	:accuracyMods => {},
	:moveMessages => {
		"The attack was rainbow-charged!" => [:SILVERWIND, :MYSTICALFIRE, :DRAGONPULSE, :SACREDFIRE, :FIREPLEDGE, :WATERPLEDGE, :GRASSPLEDGE, :AURORABEAM, :MIRRORBEAM, :JUDGMENT, :RELICSONG, :HIDDENPOWER, :SECRETPOWER, :WEATHERBALL, :MISTBALL, :HEARTSTAMP, :MOONBLAST, :ZENHEADBUTT, :SPARKLINGARIA, :FLEURCANNON, :PRISMATICLASER, :TWINKLETACKLE, :OCEANICOPERETTA, :SOLARBEAM, :SOLARBLADE, :DAZZLINGGLEAM, :HIDDENPOWERNOR, :HIDDENPOWERFIR, :HIDDENPOWERFIG, :HIDDENPOWERWAT, :HIDDENPOWERFLY, :HIDDENPOWERGRA, :HIDDENPOWERPOI, :HIDDENPOWERELE, :HIDDENPOWERGRO, :HIDDENPOWERPSY, :HIDDENPOWERROC, :HIDDENPOWERICE, :HIDDENPOWERBUG, :HIDDENPOWERDRA, :HIDDENPOWERGHO, :HIDDENPOWERDAR, :HIDDENPOWERSTE, :HIDDENPOWERFAI],
		"The attacker danced among the colors!" => [:AQUASTEP, :FIERYDANCE, :DEADLYPIROUETTE, :ACROBATICS, :GALESTRIKE, :SKYUPPERCUT, :BOUNCE, :FLY],
		"The rainbow ensures good dreams." => [:NIGHTMARE]
	},
	:typeMods => {},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:NORMAL],
		0.5 => [:GHOST,:DARK],
	},
	:typeMessages => {
		"The rainbow energized the attack!" => [:NORMAL],
		"The rainbow's light diminished the attack..." => [:DARK,:GHOST],
	},
	:typeCondition => {
		:NORMAL => "self.pbIsSpecial?(type)",
	},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
		:INDOOR => [:LIGHTTHATBURNSTHESKY],
	},
	:dontChangeBackup => [],
	:changeMessage => {
		 "The rainbow was consumed!" => [:LIGHTTHATBURNSTHESKY],
	},
	:statusMods => [:COSMICPOWER, :MEDITATE, :WISH, :LIFEDEW, :AURORAVEIL],
	:changeEffects => {},
	:seed => {
		:seedtype => :MAGICALSEED,
		:stats => {
			PBStats::ATTACK => 1,
			PBStats::SPATK => 1,
		},
	},
},
:CORROSIVE => {
	:name => "Corrosive Field",
	:fieldMessage => [
		"The field is corrupted!"
	],
	:graphic => ["Corrosive"],
	:secretPower => "ACID",
	:naturePower => :ACIDSPRAY,
	:mimicry => :POISON,
	:damageMods => {
		1.5 => [:SMACKDOWN, :MUDSLAP, :MUDSHOT, :MUDBOMB, :MUDDYWATER, :WHIRLPOOL, :THOUSANDARROWS, :APPLEACID],
		2 => [:ACID, :ACIDSPRAY, :GRASSKNOT, :SNAPTRAP],
	},
	:accuracyMods => {
		100 => [:POISONPOWDER, :SLEEPPOWDER, :STUNSPORE, :TOXIC, :GUNKSHOT],
	},
	:moveMessages => {
		"The impurities strengthened the attack!" => [:SMACKDOWN, :MUDSLAP, :MUDSHOT, :MUDBOMB, :MUDDYWATER, :HEADLONGRUSH, :WHIRLPOOL, :THOUSANDARROWS, :GRASSKNOT, :SNAPTRAP],
		"The corrosion strengthened the attack!" => [:APPLEACID, :ACID, :ACIDSPRAY],
	},
	:typeMods => {
		:POISON => [:SMACKDOWN, :MUDSLAP, :MUDSHOT, :MUDDYWATER, :WHIRLPOOL, :MUDBOMB, :THOUSANDARROWS, :APPLEACID],
	},
	:typeAddOns => {
		:POISON => [:GRASS],
	},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:GRASS],
	},
	:typeMessages => {
		"The pollution corrupted the attack!" => [:GRASS],
	},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
		:GRASSY => [:SEEDFLARE, :PURIFY],
	},
	:dontChangeBackup => [],
	:changeMessage => {
		 "The polluted field was purified!" => [:SEEDFLARE, :PURIFY],
	},
	:statusMods => [:ACIDARMOR, :POISONPOWDER, :SLEEPPOWDER, :STUNSPORE, :TOXIC, :GUNKSHOT, :VENOMDRENCH],
	:changeEffects => {},
	:seed => {
		:seedtype => :TELLURICSEED,
		:effect => :Protect,
		:duration => :BanefulBunker,
		:message => "The Telluric Seed shielded {1} against damage!",
		:animation => :BANEFULBUNKER,
		:stats => {
			PBStats::ATTACK => 1,
		},
	},
},
:CORROSIVEMIST => {
	:name => "Corrosive Mist Field",
	:fieldMessage => [
		"Corrosive mist settles on the field!"
	],
	:graphic => ["CorrosiveMist"],
	:secretPower => "ACIDSPRAY",
	:naturePower => :ACIDSPRAY,
	:mimicry => :POISON,
	:damageMods => {
		1.3 => [:HYDROPUMP,:MISTBALL, :APPLEACID,:ENERGYBALL,:APPLEACID,:ENERGYBALL],
		1.5 => [:ACIDSPRAY, :SMOG, :CLEARSMOG, :SPARKLINGARIA, :BUBBLE, :BUBBLEBEAM, :APPLEACID],
	},
	:accuracyMods => {
		100 => [:TOXIC],
	},
	:moveMessages => {
		"The poison strengthened the attack!" => [:HYDROPUMP,:MISTBALL,:BUBBLEBEAM,:ENERGYBALL],
		"The mist strengthened the attack!" => [:BUBBLEBEAM, :ACIDSPRAY, :BUBBLE, :SMOG, :CLEARSMOG, :SPARKLINGARIA, :APPLEACID,:HYDROPUMP],
	},
	:typeMods => {
		:POISON => [:BUBBLE, :BUBBLEBEAM, :ENERGYBALL, :SPARKLINGARIA, :APPLEACID, :HYDROPUMP, :MISTBALL],
	},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:POISON,:FAIRY],
		1.3 => [:FIRE,:FLYING],
	},
	:typeMessages => {
		"The toxic mist boosted the attack!" => [:POISON],
		"The heavy mist empowered the attack!" => [:FAIRY],
		"Searing mist was blown at the opponent!" => [:FLYING],
		"The toxic mist caught flame!" => [:FIRE],
	},
	:typeCondition => {
		:FLYING => "self.pbIsSpecial?(@type)",
	},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
		:MISTY => [:SEEDFLARE,:PURIFY],
		:CORROSIVE => [:GRAVITY],
	},
	:dontChangeBackup => [:GRAVITY],
	:changeMessage => {
		 "The polluted mist was purified!" => [:SEEDFLARE,:PURIFY],
		 "The toxic mist collected on the ground!" => [:GRAVITY],
	},
	:statusMods => [:ACIDARMOR, :SMOKESCREEN, :VENOMDRENCH, :TOXIC],
	:changeEffects => {
	},
	:seed => {
		:seedtype => :ELEMENTALSEED,
		:effect => 0,
		:duration => 0,
		:message => "{1} was badly poisoned!",
		:animation => nil,
		:stats => {
			PBStats::ATTACK => 1,
			PBStats::SPATK => 1,
			PBStats::SPEED => 1,
		},
	},
},
  :DESERT => {
    :name => "Desert Field",
    :fieldMessage => ["The field is rife with sand."],
    :graphic => ["Desert", "Desert2", "Desert3", "DesertNight", "DesertEve"],
    :secretPower => :SANDTOMB,
    :naturePower => :SANDTOMB,
    :mimicry => :GROUND,
    :burmyCloak => :SANDYCLOAK,
    :damageMods => {
      1.5 => [:NEEDLEARM, :PINMISSILE, :DIG, :SANDTOMB, :HEATWAVE, :THOUSANDWAVES, :BURNUP, :SEARINGSUNRAZESMASH,
              :SOLARBLADE, :SOLARBEAM, :SCALD, :STEAMERUPTION, :SANDSEARSTORM, :BONECLUB, :BONERUSH, :BONEMERANG, :SHADOWBONE, :SCORCHINGSANDS, :BUGBOMB, :DUSTYDASH],
      0 => [:SOAK, :AQUARING, :LIFEDEW],
    },
    :accuracyMods => {},
    :moveMessages => {
      "The desert strengthened the attack!" => [:DUSTYDASH, :NEEDLEARM, :PINMISSILE, :DIG, :SANDTOMB, :HEATWAVE, :THOUSANDWAVES, :BURNUP, :SEARINGSUNRAZESMASH, :SOLARBLADE, :SOLARBEAM, :SCALD, :STEAMERUPTION, :SANDSEARSTORM, :SCORCHINGSANDS, :BUGBOMB],
      "The lifeless desert strengthened the attack!" => [:BONECLUB, :BONERUSH, :BONEMERANG, :SHADOWBONE],
      "The desert is too dry..." => [:SOAK, :AQUARING, :LIFEDEW],
    },
    :typeMods => {},
    :typeAddOns => {},
    :moveEffects => {},
    :typeBoosts => {
      0.5 => [:WATER, :ELECTRIC],
    },
    :typeMessages => {
      "The desert softened the attack..." => [:WATER, :ELECTRIC],
    },
    :typeCondition => {
		:WATER => "!attacker.isAirborne? && self.move!=:SCALD && self.move!=:STEAMERUPTION",
    },
    :typeEffects => {},
    :changeCondition => {},
    :fieldChange => {},
    :dontChangeBackup => [],
    :changeMessage => {},
    :statusBuffs => [:SANDSTORM, :SUNNYDAY, :SANDATTACK, :SHOREUP, :ARENITEWALL],
    :statusNerfs => [:SOAK],
    :changeEffects => {},
    :seed => {
      :seedtype => :TELLURICSEED,
      :effect => :MultiTurnAttack,
      :duration => :SANDTOMB,
      :message => "{1} was trapped by Sand Tomb!",
      :animation => :SANDTOMB,
      :stats => {
        PBStats::DEFENSE => 1,
        PBStats::SPDEF => 1,
        PBStats::SPEED => 1,
      },
    },
  },
:ICY => {
	:name => "Icy Field",
	:fieldMessage => [
		"The field is covered in ice."
	],
	:graphic => ["Icy","CrystalCave"],
	:secretPower => "ICESHARD",
	:naturePower => :ICEBEAM,
	:mimicry => :ICE,
	:damageMods => {
		2.0 => [:CHILLINGWATER],
		1.5 => [:BITTERMALICE],
		0.5 => [:SCALD, :STEAMERUPTION, :HYDROSTEAM],
	},
	:accuracyMods => {},
	:moveMessages => {
		"The cold strengthened the attack!" => [:BITTERMALICE, :CHILLINGWATER],
		"The cold softened the attack..." => [:SCALD, :STEAMERUPTION, :HYDROSTEAM],
	},
	:typeMods => {},
	:typeAddOns => {
		:ICE => [:ROCK],
	},
	:moveEffects => {
		"@battle.iceSpikes" => [:EARTHQUAKE, :BULLDOZE, :MAGNITUDE, :FISSURE, :TECTONICRAGE],
	},
	:typeBoosts => {
		1.5 => [:ICE],
		0.5 => [:FIRE],
	},
	:typeMessages => {
		"The cold strengthened the attack!" => [:ICE],
		"The cold softened the attack..." => [:FIRE],
	},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {
	},
	:fieldChange => {
		:INDOOR => [:DIVE, :EARTHQUAKE, :BULLDOZE, :MAGNITUDE, :FISSURE, :TECTONICRAGE],
		:CAVE => [:HEATWAVE, :ERUPTION, :SEARINGSHOT, :FLAMEBURST, :LAVAPLUME, :FIREPLEDGE, :MINDBLOWN, :INCINERATE, :INFERNOOVERDRIVE, :MAGMADRIFT, :RAGINGFURY],
		:WATERSURFACE => [:SCALD, :STEAMERUPTION, :HYDROSTEAM],
		:MURKWATERSURFACE => [:THUNDERRAID],
		:FROZENDIMENSION => [:COLDTRUTH],
	},
	:dontChangeBackup => [],
	:changeMessage => {
		"The ice was broken from underneath!" => [:DIVE],
		"The quake broke up the ice and revealed the water beneath!" => [:EARTHQUAKE, :BULLDOZE, :MAGNITUDE, :FISSURE, :TECTONICRAGE],
		"The ice melted away!" => [:HEATWAVE, :ERUPTION, :SEARINGSHOT, :FLAMEBURST, :LAVAPLUME, :FIREPLEDGE, :MINDBLOWN, :INCINERATE, :INFERNOOVERDRIVE, :MAGMADRIFT, :RAGINGFURY],
		"The hot water melted the ice!" => [:SCALD, :STEAMERUPTION, :HYDROSTEAM],
		"The high-voltage assault shattered the ice and revealed the water beneath!" => [:THUNDERRAID],
		"The hateful chill corrupted the ice!" => [:COLDTRUTH],
	},
	:statusMods => [:HAIL, :AURORAVEIL, :CHILLYRECEPTION],
	:changeEffects => {},
	:seed => {
		:seedtype => :ELEMENTALSEED,
		:effect => 0,
		:duration => 0,
		:animation => nil,
		:stats => {
			PBStats::SPEED => 2,
		},
	},
},
:ROCKY => {
	:name => "Rocky Field",
	:fieldMessage => [
		"The field is littered with rocks."
	],
	:graphic => ["Rocky"],
	:secretPower => "ROCKTHROW",
	:naturePower => :ROCKSMASH,
	:mimicry => :ROCK,
	:damageMods => {
		1.5 => [:ROCKCLIMB, :STRENGTH, :MAGNITUDE, :EARTHQUAKE, :BULLDOZE, :ACCELEROCK, :HIGHHORSEPOWER, :STOMPINGTANTRUM],
		1.3 => [:XSCISSOR,:RAZORLEAF,:SLASH,:CUT,:STONEAXE,:SACREDSWORD,:NIGHTSLASH,:PSYCHOCUT,:SLASHANDBURN,:CEASELESSEDGE,:LEAFBLADE,:FURYCUTTER,:CROSSPOISON,:DREAMREAPER,:SOLARBLADE,:BEHEMOTHBLADE,:HEXINGSLASH,:BITTERBLADE,:AQUACUTTER,:RAZORSHELL,:KOWTOWCLEAVE,:PSYBLADE],
		2.0 => [:ROCKSMASH],
	},
	:accuracyMods => {
		100 => [:STONEEDGE, :ROCKSLIDE, :HEADSMASH]
	},
	:moveMessages => {
		"The rocks strengthened the attack!" => [:ROCKCLIMB, :STRENGTH, :MAGNITUDE, :EARTHQUAKE, :BULLDOZE, :ACCELEROCK],
		"The attack collected a surplus of rocks!!" => [:RAZORTHREAD],
		"The rough terrain strengthened the attack!" => [:HIGHHORSEPOWER, :STOMPINGTANTRUM],
		"The blade was sharpened on the rocks!" => [:RAZORSHELL,:RAZORLEAF,:XSCISSOR,:SLASH,:CUT,:STONEAXE,:SACREDSWORD,:NIGHTSLASH,:PSYCHOCUT,:SLASHANDBURN,:CEASELESSEDGE,:LEAFBLADE,:FURYCUTTER,:CROSSPOISON,:DREAMREAPER,:SOLARBLADE,:BEHEMOTHBLADE,:HEXINGSLASH,:BITTERBLADE,:AQUACUTTER,:KOWTOWCLEAVE,:PSYBLADE],
		"SMASH'D!" => [:ROCKSMASH],
	},
	:typeMods => {
		:ROCK => [:ROCKCLIMB, :EARTHQUAKE, :MAGNITUDE, :STRENGTH, :BULLDOZE],
	},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:ROCK],
	},
	:typeMessages => {
		"The field strengthened the attack!" => [:ROCK],
	},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {},
	:dontChangeBackup => [],
	:changeMessage => {},
	:statusMods => [:SANDSTORM, :ARENITEWALL, :STEALTHROCK],
	:changeEffects => {},
	:seed => {
		:seedtype => :TELLURICSEED,
		:effect => 0,
		:duration => 0,
		:message => "{1} was hurt by Stealth Rocks!",
		:animation => nil,
		:stats => {
			PBStats::DEFENSE => 1,
			PBStats::SPDEF => 1,
		},
	},
},
:FOREST => {
	:name => "Forest Field",
	:fieldMessage => [
		"The field is abound with trees."
	],
	:graphic => ["Forest","GoldForest","ForestCave","Dullfern"],
	:secretPower => "WOODHAMMER",
	:naturePower => :WOODHAMMER,
	:mimicry => :BUG,
	:damageMods => {
		0.5 => [:SURF, :MUDDYWATER],
		1.5 => [:GRAVAPPLE, :SYRUPBOMB, :ATTACKORDER, :TRAILBLAZE, :ELECTROWEB, :SLASH, :FURYCUTTER, :PSYCHOCUT, :BREAKINGSWIPE, :PSYCHICHARVEST],
		2.0 => [:CUT],
	},
	:accuracyMods => {},
	:moveMessages => {
		"The forest softened the attack..." => [:SURF, :MUDDYWATER],
		"They're coming out of the woodwork!" => [:ATTACKORDER],
		"The forest strengthened the attack!" => [:PSYCHICHARVEST],
		"Gossamer and arbor strengthened the attack!" => [:ELECTROWEB],
		"The apple did not fall far from the tree!" => [:GRAVAPPLE],
		"The ample sap strengthened the attack!" => [:SYRUPBOMB],
		"The attacker leapt out from the tall trees!" => [:TRAILBLAZE],
		"A tree slammed down!" => [:CUT, :SLASH, :FURYCUTTER, :PSYCHOCUT, :BREAKINGSWIPE],
	},
	:typeMods => {
		:GRASS => [:CUT, :SLASH, :FURYCUTTER, :PSYCHOCUT, :BREAKINGSWIPE],
	},
	:typeAddOns => {
	},
	:moveEffects => {
		"@battle.field.counter += 1" => [:SURF],
		"@battle.field.counter += 2" => [:MUDDYWATER],
	},
	:typeBoosts => {
		1.5 => [:BUG, :GRASS],
	},
	:typeMessages => {
		"The attack spread throughout the forest!" => [:BUG],
		"The forestry strengthened the attack!" => [:GRASS],
	},
	:typeCondition => {

	},
	:typeEffects => {},
	:changeCondition => {
		:SWAMP => "@battle.field.counter > 2",
	},
	:fieldChange => {
		:SWAMP => [:SURF, :MUDDYWATER],
	},
	:dontChangeBackup => [],
	:changeMessage => {
		"The forest became marshy!" => [:SURF, :MUDDYWATER],
	},
	:statusMods => [:STICKYWEB, :DEFENDORDER, :GROWTH, :STRENGTHSAP, :HEALORDER, :NATURESMADNESS, :FORESTSCURSE],
	:changeEffects => {},
	:seed => {
		:seedtype => :TELLURICSEED,
		:effect => :Protect,
		:duration => :SpikyShield,
		:message => "The Telluric Seed shielded {1} against damage!",
		:animation => :SPIKYSHIELD,
		:stats => {
			PBStats::ATTACK => 1,
		},
	},
},
:VOLCANICTOP => {
	:name => "Volcanic Top",
	:fieldMessage => [
		"The mountain top is super-heated!"
	],
	:graphic => ["Voltop"],
	:secretPower => "FLAMEBURST",
	:naturePower => :TARSHOT,
	:mimicry => :FIRE,
	:damageMods => {
		1.5 => [:ROCKCLIMB, :VITALTHROW, :CIRCLETHROW, :STORMTHROW, :OMINOUSWIND, :GALESTRIKE, :SILVERWIND, :RAZORWIND, :ICYWIND, :GUST, :TWISTER, :SMOG, :CLEARSMOG, :PRECIPICEBLADES, :THUNDER, :SCALD, :STEAMERUPTION, :HYDROSTEAM, :INFERNALPARADE, :THUNDERCLAP, :THUNDER, :RAZORTHREAD, :TORCHSONG, :HYPERVOICE],
		1.3 => [:ERUPTION, :HEATWAVE, :MAGMASTORM, :LAVAPLUME, :MAGMADRIFT],
		0.5 => [:SCENTEDGEYSER, :FLOWERTRICK],
		0 => [:HAIL]
	},
	:accuracyMods => {
		0 => [:THUNDER]
	},
	:moveMessages => {
		"{1} was thrown partway down the mountain!" => [:VITALTHROW, :CIRCLETHROW, :STORMTHROW],
		"The field super-heated the attack!" => [:SCALD, :STEAMERUPTION, :ICYWIND, :RAZORWIND, :GUST, :TWISTER, :SMOG, :CLEARSMOG, :PRECIPICEBLADES],
		"The thick mountain smoke strengthened the attack!" => [:OMINOUSWIND,:SILVERWIND],
		"The cold air formed a front with the heat!" => [:ICYWIND],
		"The field powers up the flaming attacks!" => [:ERUPTION, :HEATWAVE, :MAGMASTORM, :LAVAPLUME, :MAGMADRIFT, :INFERNALPARADE],
		"The volcanic air carried the song!" => [:TORCHSONG],
		"The attack resonated with the mountain's vibrations!" => [:HYPERVOICE],
		"The mountain powered up the attack!" => [:THUNDER, :THUNDERCLAP, :ROCKCLIMB],
		"The hot fumes choked out the attack..." => [:SCENTEDGEYSER],
		"The flowers couldn't bloom in the heat..." => [:FLOWERTRICK],
		"The hail melted away." => [:HAIL],
		"The wide open space powered up the attack!" => [:GALESTRIKE],
		"The attack collected igneous rocks!" => [:RAZORTHREAD],
	},
	:typeMods => {
		:FIRE => [:RAZORWIND, :ICYWIND, :GUST, :TWISTER, :SMOG, :CLEARSMOG, :PRECIPICEBLADES, :EXPLOSION, :SELFDESTRUCT, :DIG, :DIVE, :SEISMICTOSS, :MAGNETBOMB, :EGGBOMB, :RAZORTHREAD],
	},
	:typeAddOns => {
		:FIRE => [:ROCK],
	},
	:moveEffects => {
		"@battle.fieldAccuracyDrop" => [:SURF, :MUDDYWATER, :WATERPLEDGE, :WATERSPOUT, :SPARKLINGARIA, :OCEANICOPERETTA, :HYDROVORTEX, :HYDROPUMP, :WATERSPORT],
		"@battle.eruptionChecker" => [:BULLDOZE, :EARTHQUAKE, :MAGNITUDE, :ERUPTION, :PRECIPICEBLADES, :LAVAPLUME, :MAGMADRIFT, :EARTHPOWER, :FEVERPITCH],
	},
	:typeBoosts => {
		0.5 => [:ICE,:WATER],
		1.3 => [:FIRE,:FLYING,:ROCK],
	},
	:typeMessages => {
		"The extreme heat softened the attack..." => [:ICE, :WATER],
		"The attack was super-heated!" => [:FIRE],
		"The mountain strengthened the attack!!" => [:FLYING],
		"The igneous rocks strengthened the attack!" => [:ROCK],
	},
	:typeCondition => {
		:WATER => "self.pbIsSpecial?(@type) && self.move!=:SCALD && self.move!=:STEAMERUPTION && self.move!=:HYDROSTEAM",
		:ICE => "self.move!=:ICYWIND"
	},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
		:SKY => [:FLY, :BOUNCE, :HEAVENLYWING],
		:MOUNTAIN => [:BLIZZARD, :GLACIATE, :SUBZEROSLAMMER],
	},
	:dontChangeBackup => [],
	:changeMessage => {
		 "The battle was taken to the skies!" => [:FLY, :BOUNCE,:HEAVENLYWING],
		 "The field cooled off!" => [:BLIZZARD, :GLACIATE, :SUBZEROSLAMMER],
	},
	:statusMods => [:TAILWIND, :STEALTROCK, :SMOKESCREEN, :POISONGAS],
	:changeEffects => {},
	:seed => {
		:seedtype => :TELLURICSEED,
		:effect => :ShellTrap,
		:duration => true,
		:message => "{1} primed a trap!",
		:animation => :SHELLTRAP,
		:stats => {
			PBStats::DEFENSE => 1,
		},
	},
},
:FACTORY => {
	:name => "Factory Field",
	:fieldMessage => [
		"Machines whir in the background."
	],
	:graphic => ["Factory"],
	:secretPower => "MAGNETBOMB",
	:naturePower => :GEARGRIND,
	:mimicry => :STEEL,
	:damageMods => {
		1.5 => [:STEAMROLLER, :TECHNOBLAST, :ULTRAMEGADEATH],
		2.0 => [:FLASHCANNON, :GYROBALL, :MAGNETBOMB, :GEARGRIND, :DOUBLEIRONBASH],
	},
	:accuracyMods => {},
	:moveMessages => {
		"ATTACK SEQUENCE UPDATE." => [:STEAMROLLER, :TECHNOBLAST, :ULTRAMEGADEATH],
		"ATTACK SEQUENCE INITIATE." => [:FLASHCANNON, :GYROBALL, :MAGNETBOMB, :GEARGRIND, :DOUBLEIRONBASH],
		"The attack monopolized the factory's power supply!" => [:ELECTROSHOT],
	},
	:typeMods => {},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		1.2 => [:ELECTRIC],
	},
	:typeMessages => {
		"The attack took energy from the field!" => [:ELECTRIC],
	},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {
		:SHORTCIRCUIT => "!(self.move==:ULTRAMEGADEATH && self.pbIsSpecial?(@type))",
	},
	:fieldChange => {
		:SHORTCIRCUIT => [:AURAWHEEL, :DISCHARGE, :OVERDRIVE, :IONDELUGE, :GIGAVOLTHAVOC, :EARTHQUAKE, :BULLDOZE, :MAGNITUDE, :FISSURE, :TECTONICRAGE, :SELFDESTRUCT, :EXPLOSION, :LIGHTTHATBURNSTHESKY, :ULTRAMEGADEATH, :ELECTROSHOT],
	},
	:dontChangeBackup => [],
	:changeMessage => {
		 "The field was broken!" => [:EARTHQUAKE, :BULLDOZE, :MAGNITUDE, :FISSURE, :TECTONICRAGE, :SELFDESTRUCT, :EXPLOSION, :ULTRAMEGADEATH],
		 "All the light was consumed!" => [:LIGHTTHATBURNSTHESKY],
		 "The field shorted out!" => [:AURAWHEEL, :IONDELUGE, :GIGAVOLTHAVOC, :DISCHARGE, :OVERDRIVE],
		 "The field's energy was depleted!" => [:ELECTROSHOT],
	},
	:statusMods => [:AUTOTOMIZE, :IRONDEFENSE, :METALSOUND, :SHIFTGEAR, :MAGNETRISE, :GEARUP, :MAGNETRISE],
	:changeEffects => {},
	:seed => {
		:seedtype => :SYNTHETICSEED,
		:effect => :LaserFocus,
		:duration => 1,
		:message => "{1} is focused!",
		:animation => :LASERFOCUS,
		:stats => {
			PBStats::SPATK => 1,
		},
	},
},
:SHORTCIRCUIT => {
	:name => "Short-Circuit Field",
	:fieldMessage => [
		"Bzzt!"
	],
	:graphic => ["ShortCircuit"],
	:secretPower => "ELECTROBALL",
	:naturePower => :DISCHARGE,
	:mimicry => :ELECTRIC,
	:damageMods => {
		1.667 => [:STEELBEAM],
		1.5 => [:DAZZLINGGLEAM, :SURF, :MUDDYWATER, :MAGNETBOMB, :GYROBALL, :FLASHCANNON, :GEARGRIND, :HYDROVORTEX, :MAKEITRAIN, :ULTRAMEGADEATH],
		1.3 => [:DARKPULSE, :NIGHTDAZE, :NIGHTSLASH, :SHADOWBALL, :SHADOWPUNCH, :SHADOWCLAW, :SHADOWSNEAK, :SHADOWFORCE, :SHADOWBONE, :PHANTOMFORCE],
		0.5 => [:LIGHTTHATBURNSTHESKY],
	},
	:accuracyMods => {
		80 => [:ZAPCANNON],
	},
	:moveMessages => {
		"CHARGING UP!" => [:ULTRAMEGADEATH],
		"Blinding!" => [:DAZZLINGGLEAM, :FLASHCANNON],
		"The attack picked up electricity!" => [:SURF, :MUDDYWATER, :MAGNETBOMB, :GYROBALL, :GEARGRIND, :HYDROVORTEX],
		"The attack gathered stray electricity!" => [:ELECTROSHOT],
		"The darkness strengthened the attack!" => [:DARKPULSE, :NIGHTDAZE, :NIGHTSLASH, :SHADOWBALL, :SHADOWPUNCH, :SHADOWCLAW, :SHADOWSNEAK, :SHADOWFORCE, :SHADOWBONE, :PHANTOMFORCE],
		"{1} couldn't consume much light..." => [:LIGHTTHATBURNSTHESKY],
		"The gold coins conducted electricity!" => [:MAKEITRAIN],
	},
	:typeMods => {
		:ELECTRIC => [:SURF, :MUDDYWATER, :MAGNETBOMB, :GYROBALL, :FLASHCANNON, :GEARGRIND, :STEELBEAM, :MAKEITRAIN],
	},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {},
	:typeMessages => {},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
		:FACTORY => [:AURAWHEEL, :PARABOLICCHARGE, :WILDCHARGE, :CHARGEBEAM, :IONDELUGE, :ELECTROSHOT, :GIGAVOLTHAVOC, :DISCHARGE, :OVERDRIVE],
	},
	:dontChangeBackup => [],
	:changeMessage => {
		 "SYSTEM ONLINE." => [:AURAWHEEL, :PARABOLICCHARGE, :WILDCHARGE, :CHARGEBEAM, :IONDELUGE, :ELECTROSHOT, :GIGAVOLTHAVOC, :DISCHARGE, :OVERDRIVE],
	},
	:statusMods => [:FLASH, :METALSOUND, :MAGNETRISE, :ELECTROSHOT],
	:changeEffects => {},
	:seed => {
		:seedtype => :SYNTHETICSEED,
		:effect => :MagnetRise,
		:duration => 5,
		:message => "{1} levitated with electromagnetism!",
		:animation => :MAGNETRISE,
		:stats => {
			PBStats::SPDEF => 1,
		},
	},
},
:WASTELAND => {
	:name => "Wasteland",
	:fieldMessage => [
		"The waste is watching..."
	],
	:graphic => ["Wasteland"],
	:secretPower => "GUNKSHOT",
	:naturePower => :GUNKSHOT,
	:mimicry => :POISON,
	:damageMods => {
		1.5 => [:VINEWHIP, :POWERWHIP, :MUDSLAP, :MUDBOMB, :MUDSHOT],
		0.25 => [:EARTHQUAKE, :MAGNITUDE, :BULLDOZE],
		2.0 => [:SPITUP],
		1.2 => [:OCTAZOOKA, :SLUDGE, :GUNKSHOT, :SLUDGEWAVE, :SLUDGEBOMB],
	},
	:accuracyMods => {},
	:moveMessages => {
		"The waste did it for the vine!" => [:VINEWHIP, :POWERWHIP],
		"The waste was added to the attack!" => [:MUDSLAP, :MUDBOMB, :MUDSHOT],
		"Wibble-wibble wobble-wobb..." => [:EARTHQUAKE, :MAGNITUDE, :BULLDOZE],
		"BLEAAARGGGGH!" => [:SPITUP],
		"The waste joined the attack!" => [:OCTAZOOKA, :SLUDGE, :GUNKSHOT, :SLUDGEWAVE, :SLUDGEBOMB, :ACIDDOWNPOUR],
	},
	:typeMods => {
		:POISON => [:MUDBOMB, :MUDSLAP, :MUDSHOT],
	},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {},
	:typeMessages => {},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {},
	:dontChangeBackup => [],
	:changeMessage => {},
	:statusMods => [:SWALLOW, :STEALTHROCK, :SPIKES, :TOXICSPIKES, :STICKYWEB],
	:changeEffects => {},
	:seed => {
		:seedtype => :TELLURICSEED,
		:effect => 0,
		:duration => 0,
		:message => "",
		:animation => nil,
		:stats => {
			PBStats::ATTACK => 1,
			PBStats::SPATK => 1,
		},
	},
},
:ASHENBEACH => {
	:name => "Beach",
	:fieldMessage => [
		"Focus and relax to the sound of crashing waves..."
	],
	:graphic => ["Beach","BeachEve","BeachNight"],
	:secretPower => "MUDSHOT",
	:naturePower => :MEDITATE,
	:mimicry => :GROUND,
	:damageMods => {
		1.5 => [:ANCHORSHOT, :MUDBOMB, :HIDDENPOWER, :SCENTEDGEYSER, :BARBBARRAGE, :BRINE, :DELUGE, :SMELLINGSALTS, :CRABHAMMER, :RAZORSHELL, :SHELLSIDEARM, :SHELLTRAP, :SCORCHINGSANDS, :SANDSEARSTORM, :STRENGTH, :LANDSWRATH, :THOUSANDWAVES, :SURF, :MUDDYWATER, :WAVECRASH, :CLANGOROUSSOULBLAZE, :HIDDENPOWERNOR, :HIDDENPOWERFIR, :HIDDENPOWERFIG, :HIDDENPOWERWAT, :HIDDENPOWERFLY, :HIDDENPOWERGRA, :HIDDENPOWERPOI, :HIDDENPOWERELE, :HIDDENPOWERGRO, :HIDDENPOWERPSY, :HIDDENPOWERROC, :HIDDENPOWERICE, :HIDDENPOWERBUG, :HIDDENPOWERDRA, :HIDDENPOWERGHO, :HIDDENPOWERDAR, :HIDDENPOWERSTE, :HIDDENPOWERFAI],
		2.0 => [:MUDSLAP, :MUDSHOT, :SANDTOMB],
		1.3 => [:STOREDPOWER, :ZENHEADBUTT, :FOCUSBLAST, :SPIKECANNON, :AURASPHERE, :FOCUSPUNCH],
		1.2 => [:PSYCHIC],
		0.5 => [:RAGEFIST],
	},
	:accuracyMods => {
		90 => [:FOCUSBLAST],
	},
	:moveMessages => {
		"...And with pure focus!" => [:HIDDENPOWER, :STRENGTH, :CLANGOROUSSOULBLAZE, :HIDDENPOWERNOR, :HIDDENPOWERFIR, :HIDDENPOWERFIG, :HIDDENPOWERWAT, :HIDDENPOWERFLY, :HIDDENPOWERGRA, :HIDDENPOWERPOI, :HIDDENPOWERELE, :HIDDENPOWERGRO, :HIDDENPOWERPSY, :HIDDENPOWERROC, :HIDDENPOWERICE, :HIDDENPOWERBUG, :HIDDENPOWERDRA, :HIDDENPOWERGHO, :HIDDENPOWERDAR, :HIDDENPOWERSTE, :HIDDENPOWERFAI],
		"The sand strengthened the atttack!" => [:LANDSWRATH, :THOUSANDWAVES, :SANDTOMB, :SCORCHINGSANDS, :SANDSEARSTORM],
		"Surf's up!" => [:SURF, :MUDDYWATER, :WAVECRASH],
		"A shining shell on the beach!" => [:RAZORSHELL, :SHELLSIDEARM, :SHELLTRAP],
		"The barbs erupted from the teeming sea!" => [:SPIKECANNON, :BARBBARRAGE],
		"The salty sea strengthened the attack!" => [:BRINE, :SMELLINGSALTS, :SCENTEDGEYSER],
		"Time for crab!" => [:CRABHAMMER],
		"Sand mixed into the attack!" => [:MUDSLAP, :MUDSHOT, :MUDBOMB, :MUDBARRAGE],
		"...And with full focus...!" => [:STOREDPOWER, :ZENHEADBUTT, :FOCUSBLAST, :FOCUSPUNCH, :AURASPHERE],
		"...And with focus...!" => [:PSYCHIC],
		"Land ho!" => [:ANCHORSHOT],
		"The rage dissolved in the calming waves..." => [:RAGEFIST],
	},
	:typeMods => {
		:PSYCHIC => [:STRENGTH],
	},
	:typeAddOns => {},
	:moveEffects => {
		"@battle.fieldAccuracyDrop" => [:LEAFTORNADO,:FIRESPIN, :TWISTER, :RAZORWIND, :WHIRLPOOL],
	},
	:typeBoosts => {},
	:typeMessages => {},
	:typeCondition => {
		:FLYING => "self.pbIsSpecial?(type)",
	},
	:typeEffects => {
		:FLYING => "@battle.fieldAccuracyDrop",
	},
	:changeCondition => {},
	:fieldChange => {},
	:dontChangeBackup => [],
	:changeMessage => {},
	:statusMods => [:CALMMIND, :KINESIS, :MEDITATE, :SANDATTACK, :SANDSTORM, :PSYCHUP, :FOCUSENERGY, :SHOREUP, :ARENITEWALL, :SHELLSMASH, :SPARKLINGARIA],
	:changeEffects => {},
	:seed => {
		:seedtype => :TELLURICSEED,
		:effect => :FocusEnergy,
		:duration => 3,
		:message => "{1}'s Telluric Seed is getting it pumped!",
		:animation => :FOCUSENERGY,
		:stats => {
		},
	},
},
:WATERSURFACE => {
	:name => "Water Surface",
	:fieldMessage => [
		"The water's surface is calm."
	],
	:graphic => ["Water","Water3"],
	:secretPower => "AQUAJET",
	:naturePower => :WHIRLPOOL,
	:mimicry => :WATER,
	:damageMods => {
		1.5 => [:ORDERUP],
		1.2 => [:WHIRLPOOL, :SURF, :MUDDYWATER, :WHIRLPOOL, :DIVE, :SLUDGEWAVE, :OCTAZOOKA, :ORIGINPULSE, :HYDROVORTEX],
		0 => [:SPIKES, :TOXICSPIKES],
	},
	:accuracyMods => {},
	:moveMessages => {
		"The attack rode the current!" => [:WHIRLPOOL, :SURF, :MUDDYWATER, :WHIRLPOOL, :DIVE, :ORIGINPULSE, :HYDROVORTEX],
		"A delectable surplus of sushi!" => [:ORDERUP],
		"Poison spread through the water!" => [:SLUDGEWAVE],
		"...The spikes sank into the water and vanished!" => [:SPIKES, :TOXICSPIKES],
	},
	:typeMods => {},
	:typeAddOns => {},
	:moveEffects => {
		"@battle.field.counter += 1" => [:SLUDGEWAVE],
		"@battle.field.counter = 2" => [:ACIDDOWNPOUR],
	},
	:typeBoosts => {
		1.5 => [:WATER, :ELECTRIC],
		0.5 => [:FIRE],
		0 => [:GROUND],
	},
	:typeMessages => {
		"The water conducted the attack!" => [:ELECTRIC],
		"The water strengthened the attack!" => [:WATER],
		"The water deluged the attack..." => [:FIRE],
		"...But there was no solid ground to attack from!" => [:GROUND],
	},
	:typeCondition => {
	},
	:typeEffects => {},
	:changeCondition => {
		:MURKWATERSURFACE => "@battle.field.counter > 1",
	},
	:fieldChange => {
		:UNDERWATER => [:GRAVITY, :DIVE, :ANCHORSHOT, :GRAVAPPLE],
		:ICY => [:BLIZZARD, :GLACIATE, :SUBZEROSLAMMER],
		:MURKWATERSURFACE => [:SLUDGEWAVE, :ACIDDOWNPOUR],
	},
	:dontChangeBackup => [:BLIZZARD, :GLACIATE, :SUBZEROSLAMMER],
	:changeMessage => {
		 "The battle sank into the depths!" => [:GRAVITY, :GRAVAPPLE],
		 "The battle was pulled underwater!" => [:DIVE, :ANCHORSHOT],
		 "The water froze over!" => [:BLIZZARD, :GLACIATE, :SUBZEROSLAMMER],
		 "The water was polluted!" => [:SLUDGEWAVE, :ACIDDOWNPOUR],
	},
	:statusMods => [:SPLASH, :AQUARING, :LIFEDEW, :TAKEHEART],
	:changeEffects => {},
	:seed => {
		:seedtype => :ELEMENTALSEED,
		:effect => :AquaRing,
		:duration => true,
		:message => "{1} surrounded itself with a veil of water!",
		:animation => :AQUARING,
		:stats => {
			PBStats::SPDEF => 1,
		},
	},
},
:UNDERWATER => {
	:name => "Underwater",
	:fieldMessage => [
		"Blub blub..."
	],
	:graphic => ["Underwater"],
	:secretPower => "AQUATAIL",
	:naturePower => :WATERPULSE,
	:mimicry => :WATER,
	:damageMods => {
		1.5 => [:WATERPULSE, :ORDERUP, :EARTHPOWER],
		2.0 => [:ANCHORSHOT, :DRAGONDARTS, :SLUDGEWAVE, :ACIDDOWNPOUR],
		0 => [:SUNNYDAY, :HAIL, :SANDSTORM, :RAINDANCE, :SHADOWSKY, :TARSHOT],
	},
	:accuracyMods => {},
	:moveMessages => {
		"Jet-streamed!" => [:WATERPULSE],
		"From the depths!" => [:ANCHORSHOT, :DRAGONDARTS],
		"You're too deep to notice the weather!" => [:SUNNYDAY, :HAIL, :SANDSTORM, :RAINDANCE, :SHADOWSKY],
		"A delectable surplus of sushi!" => [:ORDERUP],
		"The tar washed off instantly!" => [:TARSHOT],
		"A hydrothermic vent erupted!" => [:EARTHPOWER],
	},
	:typeMods => {
		:WATER => [:DRAGONDARTS, :GRAVAPPLE],
	},
	:typeAddOns => {
		:WATER => [:GROUND],
	},
	:moveEffects => {
		"@battle.field.counter += 1" => [:SLUDGEWAVE],
		"@battle.field.counter = 2" => [:ACIDDOWNPOUR],
	},
	:typeBoosts => {
		1.5 => [:WATER],
		2.0 => [:ELECTRIC],
		0 => [:FIRE],
	},
	:typeMessages => {
		"The water strengthened the attack!" => [:WATER],
		"The water super-conducted the attack!" => [:ELECTRIC],
		"...But the attack was doused instantly!" => [:FIRE],
	},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {
		:MURKWATERSURFACE => "@battle.field.counter > 1",
	},
	:fieldChange => {
		:WATERSURFACE => [:DIVE, :SKYDROP, :FLY, :BOUNCE],
		:MURKWATERSURFACE => [:SLUDGEWAVE, :ACIDDOWNPOUR],
	},
	:dontChangeBackup => [],
	:changeMessage => {
		 "The battle resurfaced!" => [:DIVE, :SKYDROP, :FLY, :BOUNCE, :SHOREUP],
		 "The grime sank beneath the battlers!" => [:SLUDGEWAVE, :ACIDDOWNPOUR],
	},
	:statusMods => [:AQUARING, :TAKEHEART],
	:changeEffects => {
		"@battle.waterPollution" => [:SLUDGEWAVE, :ACIDDOWNPOUR],
	},
	:seed => {
		:seedtype => :ELEMENTALSEED,
		:effect => 0,
		:duration => 0,
		:message => "{1} transformed into the Water type!",
		:animation => :SOAK,
		:stats => {
			PBStats::SPEED => 1,
		},
	},
},
:CAVE => {
	:name => "Cave",
	:fieldMessage => [
		"The cave echoes dully..."
	],
	:graphic => ["Cave","Cave2"],
	:secretPower => "ROCKWRECKER",
	:naturePower => :ROCKTOMB,
	:mimicry => :ROCK,
	:damageMods => {
		1.5 => [:ROCKTOMB,:RAZORTHREAD],
		0 => [:SKYDROP],
	},
	:accuracyMods => {},
	:moveMessages => {
		"...Piled on!" => [:ROCKTOMB],
		"The attack collected scattered rocks!" => [:RAZORTHREAD],
	},
	:typeMods => {},
	:typeAddOns => {},
	:moveEffects => {
		"@battle.caveCollapse" => [:EARTHQUAKE, :BULLDOZE, :MAGNITUDE, :FISSURE, :TECTONICRAGE, :CONTINENTALCRUSH],
		"@battle.field.counter2 += 1" => [:DRAGONPULSE],
		"@battle.field.counter2 = 2" => [:DRACOMETEOR, :DEVASTATINGDRAKE],
		"@battle.field.counter3 += 1" => [:FEVERPITCH, :MAGMADRIFT, :ERUPTION, :LAVAPLUME, :HEATWAVE, :OVERHEAT, :FUSIONFLARE],
		"@battle.field.counter4 += 1" => [:GRAVITY],
	},
	:typeBoosts => {
		1.5 => [:ROCK],
		0.5 => [:FLYING],
	},
	:typeMessages => {
		"The cave choked out the air!" => [:FLYING],
		"The cavern strengthened the attack!" => [:ROCK],
	},
	:typeCondition => {
		:FLYING => "!self.contactMove?",
	},
	:typeEffects => {},
	:changeCondition => {
		:DRAGONSDEN => "@battle.field.counter2 > 1",
		:VOLCANIC => "@battle.field.counter3 > 1",
		:DEEPEARTH => "@battle.field.counter4 > 1",
	},
	:fieldChange => {
		:CRYSTALCAVERN => [:POWERGEM, :DIAMONDSTORM],
		:ICY => [:BLIZZARD, :SUBZEROSLAMMER],
		:CORRUPTED => [:SLUDGEWAVE, :ACIDDOWNPOUR],
		:VOLCANIC => [:FEVERPITCH, :MAGMADRIFT, :ERUPTION, :LAVAPLUME, :HEATWAVE, :OVERHEAT, :FUSIONFLARE],
		:DRAGONSDEN => [:DRAGONPULSE, :DRACOMETEOR, :DEVASTATINGDRAKE],
		:DEEPEARTH => [:GRAVITY],
	},
	:dontChangeBackup => [:BLIZZARD, :SUBZEROSLAMMER],
	:changeMessage => {
		"The cave was littered with crystals!" => [:POWERGEM, :DIAMONDSTORM],
		"The cavern froze over!" => [:BLIZZARD, :SUBZEROSLAMMER],
		"The cave was corrupted!" => [:SLUDGEWAVE, :ACIDDOWNPOUR],
		"The flame ignited the cave!" => [:FEVERPITCH, :MAGMADRIFT, :ERUPTION, :LAVAPLUME, :HEATWAVE, :OVERHEAT, :FUSIONFLARE],
		"The draconic energy mutated the field!" => [:DRAGONPULSE, :DRACOMETEOR, :DEVASTATINGDRAKE],
		"The battle was pulled deeper into the earth!" => [:GRAVITY],
	},
	:statusMods => [:STEALTHROCK],
	:changeEffects => {},
	:seed => {
		:seedtype => :TELLURICSEED,
		:effect => 0,
		:duration => 0,
		:message => "{1} was hurt by Stealth Rocks!",
		:animation => nil,
		:stats => {
			PBStats::DEFENSE => 2,
		},
	},
},
:GLITCH => {
	:name => "Glitch Field",
	:fieldMessage => [
		"1n!taliz3 .b//////attl3"
	],
	:graphic => ["Glitch","99"],
	:secretPower => "TECHNOBLAST",
	:naturePower => :METRONOME,
	:mimicry => :QMARKS,
	:damageMods => {
		1.3 => [:ULTRAMEGADEATH],
		0 => [:ROAR, :WHIRLWIND],
	},
	:accuracyMods => {
		90 => [:BLIZZARD],
	},
	:moveMessages => {
		"CHARGING UP!" => [:ULTRAMEGADEATH,:ELECTROSHOT],
		"ERROR! MOVE NOT FOUND!" => [:ROAR, :WHIRLWIND],
	},
	:typeMods => {},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		1.2 => [:PSYCHIC,:QMARKS],
	},
	:typeMessages => {
		".0P pl$ nerf!-//" => [:PSYCHIC],
		"ERR.$#^%$^&@ TYPE = nilx$$$$$$" => [:QMARKS]
	},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {},
	:dontChangeBackup => [],
	:changeMessage => {},
	:statusMods => [:METRONOME,:ELECTROSHOT],
	:changeEffects => {},
	:seed => {
		:seedtype => :SYNTHETICSEED,
		:effect => 0,
		:duration => 0,
		:message => "{1}.TYPE = (:QMARKS)",
		:animation => :AMNESIA,
		:stats => {
			PBStats::DEFENSE => 1,
		},
	},
},
:CRYSTALCAVERN => {
	:name => "Crystal Cavern",
	:fieldMessage => [
		"The cave is littered with crystals."
	],
	:graphic => ["CrystalCavern","AmethystCave","CaveAqua"],
	:secretPower => "POWERGEM",
	:naturePower => :POWERGEM,
	:mimicry => :DRAGON,
	:damageMods => {
		1.5 => [:AURORABEAM, :SIGNALBEAM, :FLASHCANNON, :DAZZLINGGLEAM, :MIRRORSHOT, :MIRRORBEAM, :TECHNOBLAST, :DOOMDUMMY, :MOONGEISTBEAM, :PHOTONGEYSER, :MENACINGMOONRAZEMAELSTROM,:TERASTARSTORM, :POWERGEM, :DIAMONDSTORM, :ANCIENTPOWER, :JUDGMENT, :ROCKTOMB, :STRENGTH, :ROCKCLIMB, :MULTIATTACK, :PRISMATICLASER, :LUSTERPURGE, :RAZORTHREAD, :HIDDENPOWER, :HIDDENPOWERNOR, :HIDDENPOWERFIR, :HIDDENPOWERFIG, :HIDDENPOWERWAT, :HIDDENPOWERFLY, :HIDDENPOWERGRA, :HIDDENPOWERPOI, :HIDDENPOWERELE, :HIDDENPOWERGRO, :HIDDENPOWERPSY, :HIDDENPOWERROC, :HIDDENPOWERICE, :HIDDENPOWERBUG, :HIDDENPOWERDRA, :HIDDENPOWERGHO, :HIDDENPOWERDAR, :HIDDENPOWERSTE, :HIDDENPOWERFAI],
		2.0 => [:ROCKSMASH],
	},
	:accuracyMods => {},
	:moveMessages => {
		"The Tera Energy strengthened the attack!" => [:TERASTARSTORM, :HIDDENPOWER, :HIDDENPOWERNOR, :HIDDENPOWERFIR, :HIDDENPOWERFIG, :HIDDENPOWERWAT, :HIDDENPOWERFLY, :HIDDENPOWERGRA, :HIDDENPOWERPOI, :HIDDENPOWERELE, :HIDDENPOWERGRO, :HIDDENPOWERPSY, :HIDDENPOWERROC, :HIDDENPOWERICE, :HIDDENPOWERBUG, :HIDDENPOWERDRA, :HIDDENPOWERGHO, :HIDDENPOWERDAR, :HIDDENPOWERSTE, :HIDDENPOWERFAI],
		"The crystals' light strengthened the attack!" => [:AURORABEAM, :SIGNALBEAM, :FLASHCANNON, :LUSTERPURGE, :DAZZLINGGLEAM, :MIRRORSHOT, :MIRRORBEAM, :TECHNOBLAST, :DOOMDUMMY, :MOONGEISTBEAM, :PHOTONGEYSER, :PRISMATICLASER, :MENACINGMOONRAZEMAELSTROM],
		"The crystals strengthened the attack!" => [:POWERGEM, :DIAMONDSTORM, :ANCIENTPOWER, :JUDGMENT, :ROCKSMASH, :ROCKTOMB, :STRENGTH, :ROCKCLIMB, :MULTIATTACK],
		"The attack collected crystal shards!" => [:RAZORTHREAD],
	},
	:typeMods => {},
	:typeAddOns => {},
	:moveEffects => {
		"@battle.field.counter += 1" => [:EARTHQUAKE, :BULLDOZE, :MAGNITUDE, :FISSURE],
		"@battle.field.counter = 2" => [:TECTONICRAGE],
	},
	:typeBoosts => {
		1.5 => [:ROCK, :DRAGON],
	},
	:typeMessages => {
		"The crystals charged the attack!" => [:ROCK],
		"The crystal energy strengthened the attack!" => [:DRAGON],
	},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {
		:CAVE => "@battle.field.counter > 1",
	},
	:fieldChange => {
		:CAVE => [:EARTHQUAKE, :BULLDOZE, :MAGNITUDE, :FISSURE, :TECTONICRAGE],
		:DARKCRYSTALCAVERN => [:DARKPULSE, :DARKVOID, :NIGHTDAZE, :LIGHTTHATBURNSTHESKY],
	},
	:dontChangeBackup => [:EARTHQUAKE, :BULLDOZE, :MAGNITUDE, :FISSURE, :TECTONICRAGE, :DARKPULSE, :DARKVOID, :NIGHTDAZE],
	:changeMessage => {
		 "The crystals were broken up!" => [:EARTHQUAKE, :BULLDOZE, :MAGNITUDE, :FISSURE, :TECTONICRAGE],
		 "The crystals' light was warped by the darkness!" => [:DARKPULSE, :DARKVOID, :NIGHTDAZE],
		 "The crystals' light was consumed!" => [:LIGHTTHATBURNSTHESKY],
	},
	:statusMods => [:ROCKPOLISH, :STEALTHROCK, :AURORAVEIL],
	:changeEffects => {},
	:seed => {
		:seedtype => :MAGICALSEED,
		:effect => :MagicCoat,
		:duration => true,
		:message => "{1} shrouded itself with Magic Coat!",
		:animation => :MAGICCOAT,
		:stats => {
			PBStats::SPATK => 1,
		},
	},
},
:MURKWATERSURFACE => {
	:name => "Murkwater Surface",
	:fieldMessage => [
		"The water is tainted..."
	],
	:graphic => ["MurkwaterSurface"],
	:secretPower => "SLUDGEBOMB",
	:naturePower => :SLUDGEWAVE,
	:mimicry => :POISON,
	:damageMods => {
		1.5 => [:MUDBOMB, :MUDSLAP, :MUDSHOT, :MUDBARRAGE, :SMACKDOWN, :ACID, :ACIDSPRAY, :BRINE, :THOUSANDWAVES, :APPLEACID],
		0 => [:SPIKES, :TOXICSPIKES],
	},
	:accuracyMods => {},
	:moveMessages => {
		"The toxic water strengthened the attack!" => [:MUDBOMB, :MUDSLAP, :MUDSHOT, :SMACKDOWN, :ACID, :ACIDSPRAY, :THOUSANDWAVES, :APPLEACID],
		"Stinging!" => [:BRINE],
		"...The spikes sank into the water and vanished!" => [:SPIKES, :TOXICSPIKES],
	},
	:typeMods => {
		:WATER => [:SLUDGEWAVE],
	},
	:typeAddOns => {
		:POISON => [:WATER],
	},
	:moveEffects => {
		"@battle.field.counter += 1" => [:PURIFY,:WHIRLPOOL],
	},
	:typeBoosts => {
		1.5 => [:WATER, :POISON, :ELECTRIC],
		0 => [:GROUND],
	},
	:typeMessages => {
		"The toxic water strengthened the attack!" => [:WATER, :POISON],
		"The toxic water conducted the attack!" => [:ELECTRIC],
		"...But there was no solid ground to attack from!" => [:GROUND],
	},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {
		:WATERSURFACE => "@battle.field.counter > 1"
	},
	:fieldChange => {
		:WATERSURFACE => [:WHIRLPOOL, :PURIFY],
		:ICY => [:BLIZZARD, :GLACIATE, :SUBZEROSLAMMER],
	},
	:dontChangeBackup => [:WHIRLPOOL, :PURIFY, :BLIZZARD, :GLACIATE, :SUBZEROSLAMMER],
	:changeMessage => {
		"The maelstrom flushed out the poison!" => [:WHIRLPOOL],
		"The attack cleared the waters!" => [:PURIFY],
		"The toxic water froze over!" => [:BLIZZARD, :GLACIATE, :SUBZEROSLAMMER],
	},
	:statusMods => [:ACIDARMOR, :TARSHOT, :VENOMDRENCH],
	:changeEffects => {},
	:seed => {
		:seedtype => :ELEMENTALSEED,
		:effect => :AquaRing,
		:duration => true,
		:message => "{1} surrounded itself with a veil of water!",
		:animation => :AQUARING,
		:stats => {
			PBStats::SPEED => 1,
		},
	},
},
:MOUNTAIN => {
	:name => "Mountain",
	:fieldMessage => [
		"High up!",
	],
	:graphic => ["Mountain"],
	:secretPower => "ROCKBLAST",
	:naturePower => :ROCKSLIDE,
	:mimicry => :ROCK,
	:damageMods => {
		1.5 => [:ROCKCLIMB, :VITALTHROW, :GALESTRIKE, :CIRCLETHROW, :STORMTHROW, :OMINOUSWIND, :ICYWIND, :SILVERWIND, :TWISTER, :RAZORWIND, :FAIRYWIND, :THUNDER, :ERUPTION, :AVALANCHE, :HYPERVOICE, :MOUNTAINGALE, :THUNDERCLAP, :RAZORTHREAD, :SANDSEARSTORM, :WILDBOLTSTORM, :BLEAKWINDSTORM, :SPRINGTIDESTORM, :HEATWAVE],
	},
	:accuracyMods => {
		0 => [:THUNDER]
	},
	:moveMessages => {
		"{1} was thrown partway down the mountain!" => [:VITALTHROW, :CIRCLETHROW, :STORMTHROW],
		"The wind strengthened the attack!" => [:OMINOUSWIND, :HEATWAVE, :ICYWIND, :SILVERWIND, :TWISTER, :RAZORWIND, :FAIRYWIND, :MOUNTAINGALE, :SANDSEARSTORM, :WILDBOLTSTORM, :BLEAKWINDSTORM, :SPRINGTIDESTORM],
		"The mountain strengthened the attack!" => [:THUNDER, :THUNDERCLAP, :ERUPTION, :AVALANCHE, :ROCKCLIMB],
		"Yodelayheehoo~" => [:HYPERVOICE],
		"The wide open space powered up the attack!" => [:GALESTRIKE],
		"The attack collected mountain rocks!" => [:RAZORTHREAD],
	},
	:typeMods => {},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:ROCK, :FLYING],
	},
	:typeMessages => {
		"The mountain strengthened the attack!" => [:ROCK],
		"The open air strengthened the attack!" => [:FLYING],
	},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
		:SNOWYMOUNTAIN => [:BLIZZARD, :GLACIATE, :SUBZEROSLAMMER, :MOUNTAINGALE],
		:SKY => [:FLY, :BOUNCE, :HEAVENLYWING],
		:VOLCANICTOP => [:LAVAPLUME, :MAGMADRIFT, :ERUPTION, :INFERNOOVERDRIVE],
	},
	:dontChangeBackup => [],
	:changeMessage => {
		"The mountain was covered in snow!" => [:BLIZZARD, :GLACIATE, :SUBZEROSLAMMER, :MOUNTAINGALE],
		"The battle was taken to the skies!" => [:FLY, :BOUNCE,:HEAVENLYWING],
		"The mountain erupted!" => [:LAVAPLUME, :MAGMADRIFT, :ERUPTION, :INFERNOOVERDRIVE],
	},
	:statusMods => [:TAILWIND, :SUNNYDAY],
	:changeEffects => {},
	:seed => {
		:seedtype => :TELLURICSEED,
		:effect => 0,
		:duration => 0,
		:message => "",
		:animation => nil,
		:stats => {
			PBStats::ATTACK => 2,
			PBStats::ACCURACY => -1,
		},
	},
},
:SNOWYMOUNTAIN => {
	:name => "Snowy Mountain",
	:fieldMessage => [
		"The snow glows white on the mountain..."
	],
	:graphic => ["SnowyMountain"],
	:secretPower => "ICEBALL",
	:naturePower => :AVALANCHE,
	:mimicry => :ICE,
	:damageMods => {
		1.5 => [:ROCKCLIMB, :VITALTHROW, :CIRCLETHROW, :GALESTRIKE, :STORMTHROW, :OMINOUSWIND, :SILVERWIND, :TWISTER, :RAZORWIND, :FAIRYWIND, :AVALANCHE, :POWDERSNOW, :HYPERVOICE, :GLACIATE, :MOUNTAINGALE, :BITTERMALICE, :THUNDER, :THUNDERCLAP, :RAZORTHREAD, :SANDSEARSTORM, :WILDBOLTSTORM, :BLEAKWINDSTORM, :SPRINGTIDESTORM],
		0.5 => [:SCALD, :STEAMERUPTION, :HYDROSTEAM],
		2.0 => [:ICYWIND,:CHILLINGWATER],
	},
	:accuracyMods => {
		0 => [:THUNDER]
	},
	:moveMessages => {
		"{1} was thrown partway down the mountain!" => [:VITALTHROW, :CIRCLETHROW, :STORMTHROW],
		"The mountain powered up the attack!" => [:THUNDER, :THUNDERCLAP, :ROCKCLIMB],
		"The wind strengthened the attack!" => [:OMINOUSWIND, :SILVERWIND, :TWISTER, :RAZORWIND, :FAIRYWIND, :MOUNTAINGALE, :SANDSEARSTORM, :WILDBOLTSTORM, :BLEAKWINDSTORM, :SPRINGTIDESTORM],
		"The snow strengthened the attack!" => [:AVALANCHE, :POWDERSNOW, :BITTERMALICE, :CHILLINGWATER],
		"The cold softened the attack..." => [:SCALD, :STEAMERUPTION, :HYDROSTEAM],
		"The frigid wind strengthened the attack!" => [:ICYWIND],
		"Yodelayheehoo~" => [:HYPERVOICE],
		"The wide open space powered up the attack!" => [:GALESTRIKE],
		"The attack collected icy rocks!" => [:RAZORTHREAD],
	},
	:typeMods => {
		:ICE => [:RAZORTHREAD],
	},
	:typeAddOns => {
		:ICE => [:ROCK],
	},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:ROCK, :ICE, :FLYING],
		0.5 => [:FIRE],
	},
	:typeMessages => {
		"The snowy mountain strengthened the attack!" => [:ROCK, :ICE],
		"The open air strengthened the attack!" => [:FLYING],
		"The cold softened the attack!" => [:FIRE],
	},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
		:MOUNTAIN => [:HEATWAVE, :SEARINGSHOT, :FLAMEBURST, :LAVAPLUME, :FIREPLEDGE, :MINDBLOWN, :INCINERATE, :INFERNOOVERDRIVE, :RAGINGFURY],
		:VOLCANICTOP => [:ERUPTION, :MAGMADRIFT],
		:SKY => [:FLY, :BOUNCE, :HEAVENLYWING],
	},
	:dontChangeBackup => [],
	:changeMessage => {
		"The snow melted away!" => [:HEATWAVE, :SEARINGSHOT, :FLAMEBURST, :LAVAPLUME, :FIREPLEDGE, :MINDBLOWN, :INCINERATE, :INFERNOOVERDRIVE, :RAGINGFURY],
		"The mountain erupted!" => [:ERUPTION, :MAGMADRIFT],
		"The battle was taken to the skies!" => [:FLY, :BOUNCE, :HEAVENLYWING],
	},
	:statusMods => [:TAILWIND, :SUNNYDAY, :HAIL, :CHILLYRECEPTION],
	:changeEffects => {},
	:seed => {
		:seedtype => :TELLURICSEED,
		:effect => 0,
		:duration => 0,
		:message => "",
		:animation => nil,
		:stats => {
			PBStats::SPATK => 2,
			PBStats::ACCURACY => -1,
		},
	},
},
:HOLY => {
	:name => "Blessed Field",
	:fieldMessage => [
		"The field is blessed!"
	],
	:graphic => ["Holy","Ruin2","Ruin3"],
	:secretPower => "DAZZLINGGLEAM",
	:naturePower => :JUDGMENT,
	:mimicry => :NORMAL,
	:damageMods => {
		1.3 => [:PSYSTRIKE, :AEROBLAST, :ORIGINPULSE, :DOOMDUMMY, :MISTBALL, :CRUSHGRIP, :LUSTERPURGE, :SECRETSWORD, :PSYCHOBOOST, :RELICSONG, :SPACIALREND, :HYPERSPACEHOLE, :ROAROFTIME, :LANDSWRATH, :PRECIPICEBLADES, :DRAGONASCENT, :MOONGEISTBEAM, :SUNSTEELSTRIKE, :PRISMATICLASER, :FLEURCANNON, :DIAMONDSTORM, :GENESISSUPERNOVA, :SEARINGSUNRAZESMASH, :MENACINGMOONRAZEMAELSTROM, :BEHEMOTHBLADE, :BEHEMOTHBASH, :ETERNABEAM, :DYNAMAXCANNON],
		1.5 => [:MULTIPULSE, :MYSTICALFIRE, :PUNISHMENT, :SCENTEDGEYSER, :MAGICALLEAF, :ANCIENTPOWER, :JUDGMENT, :SACREDFIRE, :ETHEREALTEMPEST, :EXTREMESPEED, :SACREDSWORD, :RETURN, :QUICKSILVERSPEAR],
		2.0 => [:SALTCURE],
	},
	:accuracyMods => {
		100 => [:QUICKSILVERSPEAR],
	},
	:moveMessages => {
		"Legendary power accelerated the attack!" => [:PSYSTRIKE, :AEROBLAST, :SACREDFIRE, :ORIGINPULSE, :DOOMDUMMY, :JUDGMENT, :MISTBALL, :CRUSHGRIP, :LUSTERPURGE, :SECRETSWORD, :PSYCHOBOOST, :RELICSONG, :SPACIALREND, :HYPERSPACEHOLE, :ROAROFTIME, :LANDSWRATH, :PRECIPICEBLADES, :DRAGONASCENT, :MOONGEISTBEAM, :SUNSTEELSTRIKE, :PRISMATICLASER, :FLEURCANNON, :DIAMONDSTORM, :GENESISSUPERNOVA, :SEARINGSUNRAZESMASH, :MENACINGMOONRAZEMAELSTROM, :BEHEMOTHBLADE, :BEHEMOTHBASH, :ETERNABEAM, :DYNAMAXCANNON, :MULTIPULSE],
		"The holy energy resonated with the attack!" => [:MULTIPULSE, :MYSTICALFIRE, :MAGICALLEAF, :ANCIENTPOWER, :SACREDSWORD, :RETURN, :QUICKSILVERSPEAR, :ETHEREALTEMPEST],
		"Godspeed!" => [:EXTREMESPEED],
		"The holy sanctuary empowered the attack!" => [:SALTCURE, :SCENTEDGEYSER],
		"Repent!" => [:PUNISHMENT]
	},
	:typeMods => {},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:FAIRY, :NORMAL],
		1.2 => [:PSYCHIC, :DRAGON],
		0.5 => [:GHOST, :DARK],
	},
	:typeMessages => {
		"The holy energy resonated with the attack!" => [:FAIRY, :NORMAL],
		"The legendary energy resonated with the attack!" => [:PSYCHIC, :DRAGON],
		"The attack was cleansed..." => [:GHOST, :DARK],
	},
	:typeCondition => {
		:FAIRY => "self.pbIsSpecial?(type)",
		:NORMAL => "self.pbIsSpecial?(type) && self.move!=:MULTIPULSE", # lawds exclude multipulse from the generic normal boost so we dont double boost the special variant
		:DARK => "self.pbIsSpecial?(type)",
	},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
		:INDOOR => [:LIGHTTHATBURNSTHESKY],
		:HAUNTED=> [:CURSE, :PHANTOMFORCE, :SPECTRALSCREAM, :SHADOWFORCE, :OMINOUSWIND, :TRICKORTREAT],
	},
	:dontChangeBackup => [],
	:changeMessage => {
		"Evil spirits gathered!" => [:CURSE, :PHANTOMFORCE, :SPECTRALSCREAM, :SHADOWFORCE, :OMINOUSWIND, :TRICKORTREAT],
		"The holy light was consumed!" => [:LIGHTTHATBURNSTHESKY],
	},
	:statusMods => [:LIFEDEW, :WISH, :MIRACLEEYE, :COSMICPOWER, :NATURESMADNESS],
	:changeEffects => {},
	:seed => {
		:seedtype => :MAGICALSEED,
		:effect => :MagicCoat,
		:duration => true,
		:message => "{1} shrouded itself with Magic Coat!",
		:animation => :MAGICCOAT,
		:stats => {
			PBStats::SPATK => 1,
		},
	},
},
:MIRROR => {
	:name => "Mirror Arena",
	:fieldMessage => [
		"Mirror, mirror, on the field,",
		"Who shall this fractured power wield?",
	],
	:graphic => ["Mirror"],
	:secretPower => "MIRRORSHOT",
	:naturePower => :MIRRORSHOT,
	:mimicry => :STEEL,
	:damageMods => {
		1.5 => [:AURORABEAM, :SIGNALBEAM, :FLASHCANNON, :LUSTERPURGE, :DAZZLINGGLEAM, :TECHNOBLAST, :DOOMDUMMY, :PRISMATICLASER, :PHOTONGEYSER, :LIGHTTHATBURNSTHESKY],
		2.0 => [:MIRRORSHOT],
	},
	:accuracyMods => {
		0 => [:AURORABEAM, :SIGNALBEAM, :FLASHCANNON, :LUSTERPURGE, :DAZZLINGGLEAM, :TECHNOBLAST, :DOOMDUMMY, :PRISMATICLASER, :PHOTONGEYSER, :LIGHTTHATBURNSTHESKY, :MIRRORSHOT],
	},
	:moveMessages => {
		"The reflected light was blinding!" => [:AURORABEAM, :SIGNALBEAM, :FLASHCANNON, :LUSTERPURGE, :DAZZLINGGLEAM, :TECHNOBLAST, :DOOMDUMMY, :PRISMATICLASER, :PHOTONGEYSER, :LIGHTTHATBURNSTHESKY],
		"The mirrors strengthened the attack!" => [:MIRRORSHOT],
	},
	:typeMods => {},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {},
	:typeMessages => {},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
		:INDOOR => [:EARTHQUAKE, :BULLDOZE, :MAGNITUDE, :FISSURE, :TECTONICRAGE, :BOOMBURST, :HYPERVOICE, :SELFDESTRUCT, :EXPLOSION],
	},
	:dontChangeBackup => [],
	:changeMessage => {
		"The mirror arena shattered!" => [:EARTHQUAKE, :BULLDOZE, :MAGNITUDE, :FISSURE, :TECTONICRAGE, :BOOMBURST, :HYPERVOICE, :SELFDESTRUCT, :EXPLOSION],
	},
	:statusMods => [:LIGHTSCREEN, :AURORAVEIL, :REFLECT, :MIRRORMOVE, :MIRRORCOAT, :DOUBLETEAM, :FLASH],
	:changeEffects => {
		"@battle.mirrorShatter" => [:EARTHQUAKE, :BULLDOZE, :MAGNITUDE, :FISSURE, :TECTONICRAGE, :BOOMBURST, :HYPERVOICE, :SELFDESTRUCT, :EXPLOSION],
	},
	:seed => {
		:seedtype => :SYNTHETICSEED,
		:effect => :MagicCoat,
		:duration => true,
		:message => "{1} shrouded itself with Magic Coat!",
		:animation => :MAGICCOAT,
		:stats => {
			PBStats::EVASION => 1,
		},
	},
},
:FAIRYTALE => {
	:name => "Fairy Tale Field",
	:fieldMessage => [
		"Once upon a time..."
	],
	:graphic => ["FairyTale"],
	:secretPower => "SLASH",
	:naturePower => :SECRETSWORD,
	:mimicry => :FAIRY,
	:damageMods => {
      	1.5 => [:SMARTSTRIKE, :MAGICALLEAF, :MYSTICALFIRE, :ANCIENTPOWER, :RELICSONG, :SPARKLINGARIA, :MOONGEISTBEAM, :FLEURCANNON, :BEHEMOTHBASH,
              :OCEANICOPERETTA, :MENACINGMOONRAZEMAELSTROM, :EERIESPELL, :ARMORCANNON, :AERIALACE, :AIRCUTTER, :AIRSLASH, :AQUACUTTER, :CEASELESSEDGE, :FURYCUTTER, :LEAFBLADE, :NIGHTSLASH,
			  :PSYCHOCUT, :RAZORSHELL, :SACREDSWORD, :SHADOWCLAW, :SOLARBLADE, :STONEAXE, :XSCISSOR, :BEHEMOTHBLADE, :BITTERBLADE, :CROSSPOISON, :CRUSHCLAW, :DIRECLAW, :KOWTOWCLEAVE,
			  :METALCLAW, :MIGHTYCLAVE, :POPULATIONBOMB, :PSYBLADE, :RAZORLEAF, :SECRETSWORD, :TACHYONCUTTER, :MISTBALL],
		2.0 => [:DRAININGKISS], 
	},
	:accuracyMods => {},
	:moveMessages => {
		"The blade cuts true!" => [:SMARTSTRIKE, :AERIALACE, :AIRCUTTER, :AIRSLASH, :AQUACUTTER, :CEASELESSEDGE, :FURYCUTTER, :LEAFBLADE, :NIGHTSLASH,
			  :PSYCHOCUT, :RAZORSHELL, :SACREDSWORD, :SHADOWCLAW, :SLASH, :SOLARBLADE, :STONEAXE, :XSCISSOR, :BEHEMOTHBLADE, :BITTERBLADE, :CROSSPOISON, :CRUSHCLAW, :CUT, :DIRECLAW, :KOWTOWCLEAVE,
			  :METALCLAW, :MIGHTYCLAVE, :POPULATIONBOMB, :PSYBLADE, :RAZORLEAF, :SECRETSWORD, :TACHYONCUTTER],
		"The magical energy strengthened the attack!" => [:SEEDFLARE, :MAGICALLEAF, :MYSTICALFIRE, :ANCIENTPOWER, :RELICSONG, :SPARKLINGARIA, :MOONGEISTBEAM, :BEHEMOTHBASH, :MISTBALL, :OCEANICOPERETTA, :MENACINGMOONRAZEMAELSTROM],
		"A pledge of noblest fealty!" => [:GRASSPLEDGE,:FIREPLEDGE,:WATERPLEDGE],
		"True love never hurt so badly!" => [:DRAININGKISS],
	},
	:typeMods => {},
	:typeAddOns => {
		:DRAGON => [:FIRE],
	},
	:moveEffects => {},
	:typeBoosts => {
		1.3 => [:FIRE],
		1.5 => [:STEEL, :FAIRY],
		2.0 => [:DRAGON],
	},
	:typeMessages => {
		"For ever after!" => [:FAIRY],
		"For justice!" => [:STEEL],
		"The foul beast's attack gained strength!" => [:DRAGON],
		"The draconic flames are intense!" => [:FIRE],
	},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {},
	:dontChangeBackup => [],
	:changeMessage => {},
	:statusMods => [:KINGSSHIELD, :CRAFTYSHIELD, :FLOWERSHIELD, :ACIDARMOR, :NOBLEROAR, :SWORDSDANCE, :WISH, :HEALINGWISH, :MIRACLEEYE, :FORESTSCURSE, :FLORALHEALING],
	:changeEffects => {},
	:seed => {
		:seedtype => :MAGICALSEED,
		:effect => :Protect,
		:duration => :KingsShield,
		:message => "The Magical Seed shielded {1} against damage!",
		:animation => :KINGSSHIELD,
		:stats => {
			PBStats::ATTACK => 1,
		},
	},
},
:DRAGONSDEN => {
	:name => "Dragon's Den",
	:fieldMessage => [
		"If you wish to slay a dragon..."
	],
	:graphic => ["DragonsDen"],
	:secretPower => "DRAGONPULSE",
	:naturePower => :DRAGONPULSE,
	:mimicry => :DRAGON,
	:damageMods => {
		1.5 => [:MEGAKICK, :MAGMASTORM, :LAVAPLUME, :STOMPINGTANTRUM, :EARTHPOWER, :MAKEITRAIN, :DIAMONDSTORM, :MATRIXSHOT, :SHELLTRAP, :MAGMADRIFT, :ROCKCLIMB, :STRENGTH],             
		2.0 => [:SMACKDOWN, :THOUSANDARROWS, :DRAGONASCENT, :PAYDAY, :MISTBALL, :LUSTERPURGE,],
		0 => [:GRASSYTERRAIN, :PSYCHICTERRAIN, :MISTYTERRAIN, :ELECTRICTERRAIN, :MIST, :HAIL],
	},
	:accuracyMods => {
		100 => [:DRAGONRUSH],
	},
	:moveMessages => {
		"Trial of the Dragon!!!" => [:MEGAKICK],
		"Wrath of the Dragon!!!" => [:STOMPINGTANTRUM],
		"The cheer resonated with draconic energy!" => [:DRAGONCHEER],
		"Unrivaled Power!" => [:STRENGTH, :ROCKCLIMB],
		"The lava strengthened the attack!" => [:MAGMASTORM, :LAVAPLUME, :EARTHPOWER, :SHELLTRAP, :MAGMADRIFT],
		"{1} was knocked into the lava!" => [:SMACKDOWN, :THOUSANDARROWS],
		"The draconic energy boosted the attack!" => [:DRAGONASCENT, :MISTBALL, :LUSTERPURGE],
		"Sparkling treasure!" => [:PAYDAY, :DIAMONDSTORM, :MATRIXSHOT,:MAKEITRAIN],
		"The draconic power blocked the terrain..." => [:GRASSYTERRAIN, :PSYCHICTERRAIN, :MISTYTERRAIN, :ELECTRICTERRAIN, :MIST],
		"The hail is melting in the heat..." => [:HAIL],
	},
	:typeMods => {
		:FIRE => [:SMACKDOWN, :THOUSANDARROWS, :STRENGTH, :ROCKCLIMB, :EARTHQUAKE],
	},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:DRAGON, :FIRE],
		1.3 => [:ROCK],
		0.5 => [:ICE, :WATER],
	},
	:typeMessages => {
		"The lava's heat boosted the flame!" => [:FIRE],
		"The draconic energy boosted the attack!" => [:DRAGON],
		"The lava's heat softened the attack..." => [:ICE, :WATER],
	},
	:typeCondition => {
		:WATER => "self.move!=:SCALD && self.move!=:STEAMERUPTION && self.move!=:HYDROSTEAM",
		:ICE => "attacker.ability!=:THERMALEXCHANGE",
	},
	:typeEffects => {},
	:changeCondition => {
		:CAVE => "@battle.field.counter > 1",
	},
	:fieldChange => {
		:CAVE => [:GLACIATE, :SUBZEROSLAMMER, :OCEANICOPERETTA, :HYDROVORTEX],
		:FAIRYTALE => [:MISTBALL],
	},
	:dontChangeBackup => [],
	:changeMessage => {
		 "The lava was frozen solid!" => [:GLACIATE, :SUBZEROSLAMMER],
		 "The lava solidified!" => [:OCEANICOPERETTA, :HYDROVORTEX],
		 "The mist-ical energy altered the surroundings!" => [:MISTBALL],
	},
	:statusMods => [:DRAGONDANCE, :NOBLEROAR, :COIL, :STEALTHROCK, :DRAGONCHEER],
	:changeEffects => {},
	:seed => {
		:seedtype => :ELEMENTALSEED,
		:effect => :FlashFire,
		:duration => true,
		:message => "{1} raised its Fire power!",
		:animation => nil,
		:stats => {
			PBStats::SPATK => 1,
		},
	},
},
:FLOWERGARDEN1 => {
	:name => "Flower Garden",
	:fieldMessage => [
		"Seeds line the field."
	],
	:graphic => ["FlowerGarden0"],
	:secretPower => "SWEETSCENT",
	:naturePower => :GROWTH,
	:mimicry => :GRASS,
	:damageMods => {
		1.5 => [:DREAMREAPER, :XSCISSOR, :FURYCUTTER, :NIGHTSLASH, :SACREDSWORD, :AIRSLASH, :AERIALACE, :BITTERBLADE, :AIRCUTTER, :RAZORLEAF, :SLASH, :CUT, :CROSSPOISON, :PSYCHOCUT, :RAZORSHELL, :BEHEMOTHBLADE, :CEASELESSEDGE, :STONEAXE, :AQUACUTTER, :HEXINGSLASH],
	},
	:accuracyMods => {},
	:moveMessages => {
		"The target was cut down to size!" => [:DREAMREAPER, :XSCISSOR, :FURYCUTTER, :NIGHTSLASH, :SACREDSWORD, :AIRSLASH, :BITTERBLADE, :AERIALACE, :AIRCUTTER, :RAZORLEAF, :SLASH, :CUT, :CROSSPOISON, :PSYCHOCUT, :RAZORSHELL, :BEHEMOTHBLADE, :CEASELESSEDGE, :STONEAXE, :AQUACUTTER, :HEXINGSLASH],
	},
	:typeMods => {},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {},
	:typeMessages => {},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
		:FLOWERGARDEN2 => [:GROWTH,:FLOWERSHIELD,:RAINDANCE,:SUNNYDAY,:ROTOTILLER,:INGRAIN,:GRASSYTERRAIN,:WATERSPORT,:BLOOMDOOM],
	},
	:dontChangeBackup => [:GROWTH,:FLOWERSHIELD,:RAINDANCE,:SUNNYDAY, :ROTOTILLER,:INGRAIN,:GRASSYTERRAIN,:WATERSPORT,:BLOOMDOOM],
	:changeMessage => {
		"The garden grew a little!" => [:GROWTH,:FLOWERSHIELD,:RAINDANCE,:SUNNYDAY, :ROTOTILLER,:INGRAIN,:GRASSYTERRAIN,:WATERSPORT,:BLOOMDOOM],
	},
	:statusMods => [:GROWTH, :ROTOTILLER, :RAINDANCE, :WATERSPORT, :SUNNYDAY, :FLOWERSHIELD, :SWEETSCENT, :INGRAIN, :FLORALHEALING],
	:changeEffects => {},
	:seed => {
		:seedtype => :SYNTHETICSEED,
		:effect => :Ingrain,
		:duration => true,
		:message => "{1} planted its roots!",
		:animation => :INGRAIN,
		:stats => {
			PBStats::SPDEF => 1,
		},
	},
},
:FLOWERGARDEN2 => {
	:name => "Flower Garden",
	:fieldMessage => [
		"Seeds line the field."
	],
	:graphic => ["FlowerGarden1"],
	:secretPower => "PETALBLIZZARD",
	:naturePower => :GROWTH,
	:mimicry => :GRASS,
	:damageMods => {
		1.5 => [:DREAMREAPER, :XSCISSOR, :FURYCUTTER, :NIGHTSLASH, :BITTERBLADE, :SACREDSWORD, :AIRSLASH, :AERIALACE, :AIRCUTTER, :RAZORLEAF, :SLASH, :CUT, :CROSSPOISON, :PSYCHOCUT, :RAZORSHELL, :BEHEMOTHBLADE, :CEASELESSEDGE, :STONEAXE, :AQUACUTTER, :HEXINGSLASH],
	},
	:accuracyMods => {},
	:moveMessages => {
		"The target was cut down to size!" => [:DREAMREAPER, :XSCISSOR, :FURYCUTTER, :BITTERBLADE, :NIGHTSLASH, :SACREDSWORD, :AIRSLASH, :AERIALACE, :AIRCUTTER, :RAZORLEAF, :SLASH, :CUT, :CROSSPOISON, :PSYCHOCUT, :RAZORSHELL, :BEHEMOTHBLADE, :CEASELESSEDGE, :STONEAXE, :AQUACUTTER, :HEXINGSLASH],
	},
	:typeMods => {},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		1.1 => [:GRASS],
	},
	:typeMessages => {
		"The garden's power boosted the attack!" => [:GRASS],
	},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
		:FLOWERGARDEN3 => [:GROWTH,:FLOWERSHIELD,:RAINDANCE,:SUNNYDAY,:ROTOTILLER,:INGRAIN,:GRASSYTERRAIN,:WATERSPORT,:BLOOMDOOM],
		:FLOWERGARDEN1 => [:CUT,:XSCISSOR,:ACIDDOWNPOUR],
	},
	:dontChangeBackup => [],
	:changeMessage => {
		"The garden was cut down a bit!" => [:CUT,:XSCISSOR],
		"The garden grew a little!" => [:GROWTH,:FLOWERSHIELD,:RAINDANCE,:SUNNYDAY,:ROTOTILLER,:INGRAIN,:GRASSYTERRAIN,:WATERSPORT,:BLOOMDOOM],
		"The acid melted the bloom!" => [:ACIDDOWNPOUR],
	},
	:statusMods => [:GROWTH, :ROTOTILLER, :RAINDANCE, :WATERSPORT, :SUNNYDAY, :FLOWERSHIELD, :SWEETSCENT, :INGRAIN, :FLORALHEALING],
	:changeEffects => {},
	:seed => {
		:seedtype => :SYNTHETICSEED,
		:effect => :Ingrain,
		:duration => true,
		:message => "{1} planted its roots!",
		:animation => :INGRAIN,
		:stats => {
			PBStats::SPDEF => 1,
		},
	},
},
:FLOWERGARDEN3 => {
	:name => "Flower Garden",
	:fieldMessage => [
		"Seeds line the field."
	],
	:graphic => ["FlowerGarden2"],
	:secretPower => "PETALBLIZZARD",
	:naturePower => :GROWTH,
	:mimicry => :GRASS,
	:damageMods => {
		1.5 => [:DREAMREAPER, :XSCISSOR, :FURYCUTTER, :NIGHTSLASH, :BITTERBLADE, :SACREDSWORD, :AIRSLASH, :AERIALACE, :AIRCUTTER, :RAZORLEAF, :SLASH, :CUT, :CROSSPOISON, :PSYCHOCUT, :RAZORSHELL, :BEHEMOTHBLADE, :CEASELESSEDGE, :STONEAXE, :AQUACUTTER, :HEXINGSLASH],
		1.2 => [:PETALBLIZZARD,:PETALDANCE,:FLEURCANNON],
	},
	:accuracyMods => {
		85 => [:SLEEPPOWDER, :STUNSPORE, :POISONPOWDER],
	},
	:moveMessages => {
		"The target was cut down to size!" => [:DREAMREAPER, :XSCISSOR, :FURYCUTTER, :BITTERBLADE, :NIGHTSLASH, :SACREDSWORD, :AIRSLASH, :AERIALACE, :AIRCUTTER, :RAZORLEAF, :SLASH, :CUT, :CROSSPOISON, :PSYCHOCUT, :RAZORSHELL, :BEHEMOTHBLADE, :CEASELESSEDGE, :STONEAXE, :AQUACUTTER, :HEXINGSLASH],
		"The fresh scent of flowers boosted the attack!" => [:PETALBLIZZARD,:PETALDANCE,:FLEURCANNON],
	},
	:typeMods => {},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:FIRE,:BUG],
		1.3 => [:GRASS],
	},
	:typeMessages => {
		"The budding flowers boosted the attack!" => [:GRASS],
		"The attack infested the garden!" => [:BUG],
		"The nearby flowers caught flame!" => [:FIRE],
	},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {
		:BURNING => "state.effects[:WaterSport] <= 0 && pbWeather != :RAINDANCE",
	},
	:fieldChange => {
		:FLOWERGARDEN4 => [:GROWTH,:FLOWERSHIELD,:RAINDANCE,:SUNNYDAY,:ROTOTILLER,:INGRAIN,:GRASSYTERRAIN,:WATERSPORT,:BLOOMDOOM],
		:FLOWERGARDEN2 => [:CUT,:XSCISSOR],
		:FLOWERGARDEN1 => [:ACIDDOWNPOUR,:HEATWAVE,:ERUPTION,:SEARINGSHOT,:FLAMEBURST,:LAVAPLUME,:FIREPLEDGE,:MINDBLOWN,:INFERNOOVERDRIVE],
	},
	:dontChangeBackup => [],
	:changeMessage => {
		"The garden caught fire!" => [:HEATWAVE,:ERUPTION,:SEARINGSHOT,:FLAMEBURST,:LAVAPLUME,:FIREPLEDGE,:MINDBLOWN,:INFERNOOVERDRIVE],
		"The garden was cut down a bit!" => [:CUT,:XSCISSOR],
		"The garden grew a little!" => [:GROWTH,:FLOWERSHIELD,:RAINDANCE,:SUNNYDAY,:ROTOTILLER,:INGRAIN,:GRASSYTERRAIN,:WATERSPORT,:BLOOMDOOM],
		"The acid melted the bloom!" => [:ACIDDOWNPOUR],
	},
	:statusMods => [:GROWTH, :ROTOTILLER, :RAINDANCE, :WATERSPORT, :SUNNYDAY, :FLOWERSHIELD, :SWEETSCENT, :INGRAIN, :FLORALHEALING],
	:changeEffects => {},
	:seed => {
		:seedtype => :SYNTHETICSEED,
		:effect => :Ingrain,
		:duration => true,
		:message => "{1} planted its roots!",
		:animation => :INGRAIN,
		:stats => {
			PBStats::SPDEF => 1,
		},
	},
},
:FLOWERGARDEN4 => {
	:name => "Flower Garden",
	:fieldMessage => [
		"Seeds line the field."
	],
	:graphic => ["FlowerGarden3"],
	:secretPower => "PETALBLIZZARD",
	:naturePower => :GROWTH,
	:mimicry => :GRASS,
	:damageMods => {
		1.5 => [:CUT,:PETALBLIZZARD,:PETALDANCE,:FLEURCANNON,:DREAMREAPER, :XSCISSOR, :FURYCUTTER, :NIGHTSLASH, :BITTERBLADE, :SACREDSWORD, :AIRSLASH, :AERIALACE, :AIRCUTTER, :RAZORLEAF, :SLASH, :CROSSPOISON, :PSYCHOCUT, :RAZORSHELL, :BEHEMOTHBLADE, :CEASELESSEDGE, :STONEAXE, :AQUACUTTER, :HEXINGSLASH],
	},
	:accuracyMods => {
		85 => [:SLEEPPOWDER, :STUNSPORE, :POISONPOWDER],
	},
	:moveMessages => {
		"The target was cut down to size!" => [:DREAMREAPER, :XSCISSOR, :FURYCUTTER, :BITTERBLADE, :NIGHTSLASH, :SACREDSWORD, :AIRSLASH, :AERIALACE, :AIRCUTTER, :RAZORLEAF, :SLASH, :CUT, :CROSSPOISON, :PSYCHOCUT, :RAZORSHELL, :BEHEMOTHBLADE, :CEASELESSEDGE, :STONEAXE, :AQUACUTTER, :HEXINGSLASH],
		"The vibrant aroma scent of flowers boosted the attack!" => [:PETALBLIZZARD,:PETALDANCE,:FLEURCANNON],
	},
	:typeMods => {},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		2.0 => [:BUG],
		1.5 => [:FIRE,:GRASS],
	},
	:typeMessages => {
		"The blooming flowers boosted the attack!" => [:GRASS],
		"The attack infested the flowers!" => [:BUG],
		"The nearby flowers caught flame!" => [:FIRE],
	},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {
		:BURNING => "state.effects[:WaterSport] <= 0 && pbWeather != :RAINDANCE",
	},
	:fieldChange => {
		:FLOWERGARDEN5 => [:GROWTH,:FLOWERSHIELD,:RAINDANCE,:SUNNYDAY,:ROTOTILLER,:INGRAIN,:GRASSYTERRAIN,:WATERSPORT,:BLOOMDOOM],
		:FLOWERGARDEN3 => [:CUT,:XSCISSOR],
		:FLOWERGARDEN1 => [:ACIDDOWNPOUR],
		:FLOWERGARDEN2 => [:HEATWAVE,:ERUPTION,:SEARINGSHOT,:FLAMEBURST,:LAVAPLUME,:FIREPLEDGE,:MINDBLOWN,:INFERNOOVERDRIVE],
	},
	:dontChangeBackup => [],
	:changeMessage => {
		"The garden caught fire!" => [:HEATWAVE,:ERUPTION,:SEARINGSHOT,:FLAMEBURST,:LAVAPLUME,:FIREPLEDGE,:MINDBLOWN,:INFERNOOVERDRIVE],
		"The garden was cut down a bit!" => [:CUT,:XSCISSOR],
		"The garden grew a little!" => [:GROWTH,:FLOWERSHIELD,:RAINDANCE,:SUNNYDAY,:ROTOTILLER,:INGRAIN,:GRASSYTERRAIN,:WATERSPORT,:BLOOMDOOM],
		"The acid melted the bloom!" => [:ACIDDOWNPOUR],
	},
	:statusMods => [:GROWTH, :ROTOTILLER, :RAINDANCE, :WATERSPORT, :SUNNYDAY, :FLOWERSHIELD, :SWEETSCENT, :INGRAIN, :FLORALHEALING],
	:changeEffects => {},
	:seed => {
		:seedtype => :SYNTHETICSEED,
		:effect => :Ingrain,
		:duration => true,
		:message => "{1} planted its roots!",
		:animation => :INGRAIN,
		:stats => {
			PBStats::SPDEF => 1,
		},
	},
},
:FLOWERGARDEN5 => {
	:name => "Flower Garden",
	:fieldMessage => [
		"Seeds line the field."
	],
	:graphic => ["FlowerGarden4"],
	:secretPower => "PETALDANCE",
	:naturePower => :PETALBLIZZARD,
	:mimicry => :GRASS,
	:damageMods => {
		1.5 => [:CUT,:PETALBLIZZARD,:PETALDANCE,:FLEURCANNON,:XSCISSOR, :FURYCUTTER, :NIGHTSLASH, :SACREDSWORD, :AIRSLASH, :BITTERBLADE, :AERIALACE, :AIRCUTTER, :RAZORLEAF, :SLASH, :CROSSPOISON, :PSYCHOCUT, :RAZORSHELL, :BEHEMOTHBLADE, :CEASELESSEDGE, :STONEAXE, :AQUACUTTER, :HEXINGSLASH],
	},
	:accuracyMods => {
		85 => [:SLEEPPOWDER, :STUNSPORE, :POISONPOWDER],
	},
	:moveMessages => {
		"The target was cut down to size!" => [:XSCISSOR, :FURYCUTTER, :NIGHTSLASH, :BITTERBLADE, :SACREDSWORD, :AIRSLASH, :AERIALACE, :AIRCUTTER, :RAZORLEAF, :SLASH, :CUT, :CROSSPOISON, :PSYCHOCUT, :RAZORSHELL, :BEHEMOTHBLADE, :CEASELESSEDGE, :STONEAXE, :AQUACUTTER, :HEXINGSLASH],
		"The vibrant aroma scent of flowers boosted the attack!" => [:PETALBLIZZARD,:PETALDANCE,:FLEURCANNON],
	},
	:typeMods => {},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		2.0 => [:GRASS,:BUG],
		1.5 => [:FIRE],
	},
	:typeMessages => {
		"The thriving flowers boosted the attack!" => [:GRASS],
		"The attack infested the flowers!" => [:BUG],
		"The nearby flowers caught flame!" => [:FIRE],
	},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {
		:BURNING => "state.effects[:WaterSport] <= 0 && pbWeather != :RAINDANCE",
	},
	:fieldChange => {
		:FLOWERGARDEN4 => [:CUT,:XSCISSOR],
		:FLOWERGARDEN1 => [:ACIDDOWNPOUR],
		:FLOWERGARDEN3 => [:HEATWAVE,:ERUPTION,:SEARINGSHOT,:FLAMEBURST,:LAVAPLUME,:FIREPLEDGE,:MINDBLOWN,:INFERNOOVERDRIVE],
	},
	:dontChangeBackup => [],
	:changeMessage => {
		"The garden caught fire!" => [:HEATWAVE,:ERUPTION,:SEARINGSHOT,:FLAMEBURST,:LAVAPLUME,:FIREPLEDGE,:MINDBLOWN,:INFERNOOVERDRIVE],
		"The garden was cut down a bit!" => [:CUT,:XSCISSOR],
		"The acid melted the bloom!" => [:ACIDDOWNPOUR],
	},
	:statusMods => [:GROWTH, :ROTOTILLER, :RAINDANCE, :WATERSPORT, :SUNNYDAY, :FLOWERSHIELD, :SWEETSCENT, :INGRAIN, :FLORALHEALING],
	:changeEffects => {},
	:seed => {
		:seedtype => :SYNTHETICSEED,
		:effect => :Ingrain,
		:duration => true,
		:message => "{1} planted its roots!",
		:animation => :INGRAIN,
		:stats => {
			PBStats::SPDEF => 1,
		},
	},
},
:STARLIGHT => {
	:name => "Starlight Arena",
	:fieldMessage => [
		"Starlight fills the battlefield."
	],
	:graphic => ["Starlight","Starlight1"],
	:secretPower => "SWIFT",
	:naturePower => :MOONBLAST,
	:mimicry => :DARK,
	:damageMods => {
		1.5 => [:QUICKSILVERSPEAR, :AURORABEAM, :SIGNALBEAM, :FLASHCANNON, :LUSTERPURGE, :LUMINACRASH, :DAZZLINGGLEAM, :MIRRORSHOT, :MIRRORBEAM, :TECHNOBLAST, :SOLARBEAM, :PHOTONGEYSER, :MOONBLAST, :PRISMATICLASER, :DREAMREAPER, :NIGHTSLASH, :NIGHTDAZE],
		2.0 => [:DOOMDUMMY, :DRACOMETEOR, :COMETPUNCH, :SPACIALREND, :METEORMASH, :SWIFT, :HYPERSPACEHOLE, :HYPERSPACEFURY, :WEATHERBALL, :MOONGEISTBEAM, :SUNSTEELSTRIKE, :METEORASSAULT, :BLACKHOLEECLIPSE, :SEARINGSUNRAZESMASH, :MENACINGMOONRAZEMAELSTROM, :LIGHTTHATBURNSTHESKY],
	},
	:accuracyMods => {
	},
	:moveMessages => {
		"Starlight surged through the attack!" => [:AURORABEAM, :LUMINACRASH, :SIGNALBEAM, :FLASHCANNON, :LUSTERPURGE, :DAZZLINGGLEAM, :MIRRORSHOT, :MIRRORBEAM, :TECHNOBLAST, :SOLARBEAM, :PHOTONGEYSER, :PRISMATICLASER, :LIGHTTHATBURNSTHESKY],
		"Lunar energy surged through the attack!" => [:MOONBLAST, :NIGHTSLASH, :DREAMREAPER, :NIGHTDAZE, :QUICKSILVERSPEAR],
		"The astral energy boosted the attack!" => [:DRACOMETEOR, :METEORMASH, :COMETPUNCH, :SPACIALREND, :WEATHERBALL, :SWIFT, :HYPERSPACEFURY, :MOONGEISTBEAM, :SUNSTEELSTRIKE, :METEORASSAULT, :BLACKHOLEECLIPSE, :SEARINGSUNRAZESMASH, :MENACINGMOONRAZEMAELSTROM],
		"The astral vortex accelerated the attack!" => [:HYPERSPACEHOLE],
		"A star came crashing down!" => [:DOOMDUMMY],
	},
	:typeMods => {
		:FIRE => [:DOOMDUMMY],
	},
	:typeAddOns => {
		:FAIRY => [:DARK],
	},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:DARK, :PSYCHIC],
		1.3 => [:FAIRY],
	},
	:typeMessages => {
		"Starlight supercharged the attack!" => [:FAIRY],
		"The night sky boosted the attack!" => [:DARK],
		"The astral energy boosted the attack!" => [:PSYCHIC],
	},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
		:INDOOR => [:LIGHTTHATBURNSTHESKY],
	},
	:dontChangeBackup => [],
	:changeMessage => {
		 "The cosmic light was consumed!" => [:LIGHTTHATBURNSTHESKY],
	},
	:statusMods => [:AURORAVEIL, :COSMICPOWER, :FLASH, :WISH, :HEALINGWISH, :LUNARDANCE, :MOONLIGHT, :TRICKROOM, :MAGICROOM, :WONDERROOM, :LUNARBLESSING],
	:changeEffects => {},
	:seed => {
		:seedtype => :MAGICALSEED,
		:effect => :Wish,
		:duration => 2,
		#:message => "A wish was made for {1}!",
		#:animation => :WISH,
		:stats => {
			PBStats::SPATK => 1,
		},
	},
},
:NEWWORLD => {
	:name => "New World",
	:fieldMessage => [
		"The world is unformed!",
	],
	:graphic => ["NewWorld","WorldOfNightmares"],
	:secretPower => "ROAROFTIME",
	:naturePower => :SPACIALREND,
	:mimicry => :DARK,
	:damageMods => {
		1.5 => [:SANDSEARSTORM,:BLEAKWINDSTORM,:WILDBOLTSTORM,:SPRINGTIDESTORM,:PSYBLADE,:WEATHERBALL,:HYDROSTEAM,:UNLEASHEDPOWER,:BLINDINGSPEED,:GALESTRIKE,:SOLARBEAM,:SOLARBLADE,:AURORABEAM, :SIGNALBEAM, :FLASHCANNON, :DAZZLINGGLEAM, :MIRRORSHOT, :MIRRORBEAM, :GILDEDHELIX, :PHOTONGEYSER, :PSYSTRIKE, :AEROBLAST, :SACREDFIRE, :MISTBALL, :LUSTERPURGE, :ORIGINPULSE, :PRECIPICEBLADES, :DRAGONASCENT, :PSYCHOBOOST, :ROAROFTIME, :MAGMASTORM, :CRUSHGRIP, :JUDGMENT, :SEEDFLARE, :SHADOWFORCE, :SEARINGSHOT, :VCREATE, :SECRETSWORD, :SACREDSWORD, :RELICSONG, :FUSIONBOLT, :FUSIONFLARE, :ICEBURN, :FREEZESHOCK, :BOLTSTRIKE, :BLUEFLARE, :TECHNOBLAST, :OBLIVIONWING, :LANDSWRATH, :THOUSANDARROWS, :THOUSANDWAVES, :DIAMONDSTORM, :STEAMERUPTION, :COREENFORCER, :FLEURCANNON, :PRISMATICLASER, :SUNSTEELSTRIKE, :SPECTRALTHIEF, :MOONGEISTBEAM, :MULTIATTACK, :MINDBLOWN, :PLASMAFISTS, :EARTHPOWER, :POWERGEM, :ERUPTION, :CONTINENTALCRUSH, :GENESISSUPERNOVA, :SOULSTEALING7STARSTRIKE, :SEARINGSUNRAZESMASH, :MENACINGMOONRAZEMAELSTROM, :THUNDERCAGE, :DRAGONENERGY, :DREAMREAPER],
		2.0 => [:DOOMDUMMY,:VACUUMWAVE, :LUMINACRASH, :DRACOMETEOR, :METEORMASH, :MOONBLAST, :COMETPUNCH, :SWIFT, :HYPERSPACEHOLE, :SPACIALREND, :HYPERSPACEFURY, :ANCIENTPOWER, :FUTUREDUMMY, :BLACKHOLEECLIPSE, :LIGHTTHATBURNSTHESKY],
		0.25 => [:EARTHQUAKE, :MAGNITUDE, :BULLDOZE],
		0 => [:HAIL, :SUNNYDAY, :SANDSTORM, :RAINDANCE, :SHADOWSKY, :GRASSYTERRAIN, :PSYCHICTERRAIN, :MISTYTERRAIN, :ELECTRICTERRAIN, :MIST, :FISSURE],
	},
	:accuracyMods => {
		100 => [:DARKVOID],
	},
	:moveMessages => {
		"The light shone through the infinite darkness!" => [:SOLARBEAM,:SOLARBLADE,:WEATHERBALL,:AURORABEAM, :SIGNALBEAM, :FLASHCANNON, :DAZZLINGGLEAM, :MIRRORSHOT, :MIRRORBEAM, :PHOTONGEYSER, :LIGHTTHATBURNSTHESKY],
		"The ethereal energy strengthened the attack!" => [:PSYBLADE,:SANDSEARSTORM,:BLEAKWINDSTORM,:WILDBOLTSTORM,:SPRINGTIDESTORM,:HYDROSTEAM,:GILDEDHELIX, :PSYSTRIKE, :AEROBLAST, :SACREDFIRE, :MISTBALL, :LUSTERPURGE, :ORIGINPULSE, :PRECIPICEBLADES, :DRAGONASCENT, :PSYCHOBOOST, :ROAROFTIME, :MAGMASTORM, :CRUSHGRIP, :JUDGMENT, :SEEDFLARE, :SHADOWFORCE, :SEARINGSHOT, :VCREATE, :SECRETSWORD, :SACREDSWORD, :RELICSONG, :FUSIONBOLT, :FUSIONFLARE, :GLACIATE, :ICEBURN, :FREEZESHOCK, :BOLTSTRIKE, :BLUEFLARE, :TECHNOBLAST, :OBLIVIONWING, :LANDSWRATH, :THOUSANDARROWS, :THOUSANDWAVES, :DIAMONDSTORM, :STEAMERUPTION, :COREENFORCER, :FLEURCANNON, :PRISMATICLASER, :SUNSTEELSTRIKE, :SPECTRALTHIEF, :MOONGEISTBEAM, :MULTIATTACK, :MINDBLOWN, :PLASMAFISTS, :GENESISSUPERNOVA, :SOULSTEALING7STARSTRIKE, :SEARINGSUNRAZESMASH, :THUNDERCAGE, :DRAGONENERGY, :MENACINGMOONRAZEMAELSTROM],
		"The germinal matter amassed in the attack!" => [:EARTHPOWER, :POWERGEM, :ERUPTION, :CONTINENTALCRUSH],
		"The astral energy boosted the attack!" => [:VACUUMWAVE, :LUMINACRASH, :DRACOMETEOR, :METEORMASH, :MOONBLAST, :COMETPUNCH, :SWIFT, :HYPERSPACEHOLE, :SPACIALREND, :HYPERSPACEFURY, :ANCIENTPOWER, :FUTUREDUMMY],
		"A star came crashing down on {1}!" => [:DOOMDUMMY],
		"{1} was swallowed up by the void!" => [:BLACKHOLEECLIPSE],
		"The unformed land diffused the attack..." => [:EARTHQUAKE, :MAGNITUDE, :BULLDOZE, :FISSURE],
		"The terrain had no solid ground to attach..." => [:GRASSYTERRAIN, :PSYCHICTERRAIN, :MISTYTERRAIN, :ELECTRICTERRAIN, :MIST],
		"The weather drifted off into space..." => [:HAIL, :SUNNYDAY, :SANDSTORM, :RAINDANCE, :SHADOWSKY],
		"Infinite potential strengthened the attack!" => [:GALESTRIKE,:UNLEASHEDPOWER,:BLINDINGSPEED],
		"Dream a dream so terrible!" => [:DREAMREAPER]
	},
	:typeMods => {
		:FIRE => [:DOOMDUMMY],
	},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:DARK,:SHADOW,:PSYCHIC],
	},
	:typeMessages => {
		"Infinity boosted the attack!" => [:DARK],
		"The cosmos boosted the attack!" => [:PSYCHIC],
		"Limitless energy boosted the attack!" => [:SHADOW],
	},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
		:STARLIGHT => [:GRAVITY, :GEOMANCY],
	},
	:dontChangeBackup => [:GRAVITY],
	:changeMessage => {
		 "The world's matter reformed!" => [:GRAVITY],
		 "The world was regenerated!" => [:GEOMANCY],
	},
	:statusMods => [:DARKVOID, :HEARTSWAP, :TRICKROOM, :MAGICROOM, :WONDERROOM, :COSMICPOWER, :FLASH, :MOONLIGHT, :NATURESMADNESS, :LUNARBLESSING],
	:changeEffects => {},
	:seed => {
		:seedtype => :MAGICALSEED,
		:effect => :HyperBeam,
		:duration => 1,
		:message => "{1} must recharge!",
		:animation => nil,
		:stats => {
			PBStats::ATTACK => 1,
			PBStats::DEFENSE => 1,
			PBStats::SPEED => 1,
			PBStats::SPATK => 1,
			PBStats::SPDEF => 1,
		},
	},
},
:INVERSE => {
	:name => "Inverse Field",
	:fieldMessage => [
		"!trats elttaB"
	],
	:graphic => ["Inverse"],
	:secretPower => "CONFUSION",
	:naturePower => :WONDERROOM,
	:mimicry => :NORMAL,
	:damageMods => {
	},
	:accuracyMods => {},
	:moveMessages => {
	},
	:typeMods => {},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {},
	:typeMessages => {},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
	},
	:dontChangeBackup => [],
	:changeMessage => {
	},
	:statusMods => [],
	:changeEffects => {},
	:seed => {
		:seedtype => :MAGICALSEED,
		:effect => :HyperBeam,
		:duration => 1,
		:message => "{1}'s type matchups were normalized! Its Normal moves powered up!",
		:animation => :SHARPEN,
		:stats => {
			PBStats::DEFENSE => 1,
		},
	},
},
:PSYTERRAIN => {
	:name => "Psychic Terrain",
	:fieldMessage => [
		"The field became mysterious!"
	],
	:graphic => ["Psychic","Psychic_2"],
	:secretPower => "PSYCHIC",
	:naturePower => :PSYCHIC,
	:mimicry => :PSYCHIC,
	:damageMods => {
		1.5 => [:HEADBUTT,:IRONHEAD,:VCREATE,:ZENHEADBUTT,:HEADSMASH,:HEADCHARGE,:SKULLBASH, :SECRETPOWER, :SCENTEDGEYSER, :HIDDENPOWER, :HEX, :MAGICALLEAF, :MYSTICALFIRE, :MOONBLAST, :AURASPHERE, :FOCUSBLAST, :MINDBLOWN, :HIDDENPOWERNOR, :HIDDENPOWERFIR, :HIDDENPOWERFIG, :HIDDENPOWERWAT, :HIDDENPOWERFLY, :HIDDENPOWERGRA, :HIDDENPOWERPOI, :HIDDENPOWERELE, :HIDDENPOWERGRO, :HIDDENPOWERPSY, :HIDDENPOWERROC, :HIDDENPOWERICE, :HIDDENPOWERBUG, :HIDDENPOWERDRA, :HIDDENPOWERGHO, :HIDDENPOWERDAR, :HIDDENPOWERSTE, :HIDDENPOWERFAI],
	},
	:accuracyMods => {
	},
	:moveMessages => {
		"The psychic energy strengthened the attack!" => [:SECRETPOWER, :SCENTEDGEYSER, :HIDDENPOWER, :FOCUSBLAST, :AURASPHERE, :HEX, :MAGICALLEAF, :MYSTICALFIRE, :MOONBLAST, :AURASPHERE, :FOCUSBLAST, :MINDBLOWN, :HIDDENPOWERNOR, :HIDDENPOWERFIR, :HIDDENPOWERFIG, :HIDDENPOWERWAT, :HIDDENPOWERFLY, :HIDDENPOWERGRA, :HIDDENPOWERPOI, :HIDDENPOWERELE, :HIDDENPOWERGRO, :HIDDENPOWERPSY, :HIDDENPOWERROC, :HIDDENPOWERICE, :HIDDENPOWERBUG, :HIDDENPOWERDRA, :HIDDENPOWERGHO, :HIDDENPOWERDAR, :HIDDENPOWERSTE, :HIDDENPOWERFAI],
		"Your mind runneth over!" => [:HEADBUTT,:IRONHEAD,:VCREATE,:ZENHEADBUTT,:HEADSMASH,:HEADCHARGE,:SKULLBASH],
	},
	:typeMods => {
	},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:PSYCHIC],
	},
	:typeMessages => {
		"The Psychic Terrain strengthened the attack!" => [:PSYCHIC],
	},
	:typeCondition => {
	},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
	},
	:dontChangeBackup => [],
	:changeMessage => {
	},
	:statusMods => [:COSMICPOWER, :KINESIS, :MEDITATE, :NASTYPLOT, :PSYCHUP, :MINDREADER, :MIRACLEEYE, :TELEKINESIS, :GRAVITY, :MAGICROOM, :TRICKROOM, :WONDERROOM],
	:changeEffects => {},
	:seed => {
		:seedtype => :MAGICALSEED,
		:effect => 0,
		:duration => 0,
		:message => "{1} became confused!",
		:animation => nil,
		:stats => {
			PBStats::SPATK => 2,
		},
	},
	:overlay => {
		:damageMods => {
			1.5 => [:SECRETPOWER, :MYSTICALFIRE,:MAGICALLEAF,:AURASPHERE,:FOCUSBLAST,:HEX,:MOONBLAST,:MINDBLOWN],
		},
		:typeMods => {
		},
		:moveMessages => {
			"The psychic energy strengthened the attack!" => [:SECRETPOWER, :MYSTICALFIRE,:MAGICALLEAF,:AURASPHERE,:HEX,:MOONBLAST,:MINDBLOWN],
		},
		:typeBoosts => {
			1.5 => [:PSYCHIC],
		},
		:typeMessages => {
			"The Psychic Terrain strengthened the attack!" => [:PSYCHIC],
		},
		:typeCondition => {	
		},
		:statusMods => [],
	},
},
:DIMENSIONAL => {
	:name => "Dimensional Field",
	:fieldMessage => [
		"Darkness radiates."
	],
	:graphic => ["Dimensional","Dimensional1","AelitaRift","DimensionalGard"],
	:secretPower => "DARKPULSE",
	:naturePower => :DARKPULSE,
	:mimicry => :DARK,
	:damageMods => {
		1.5 => [:HYPERSPACEFURY, :HYPERSPACEHOLE, :SPACIALREND, :ROAROFTIME, :ETERNABEAM, :DYNAMAXCANNON, :TEMPERFLARE, :SHADOWFORCE, :OUTRAGE, :THRASH, :STOMPINGTANTRUM, :LASHOUT, :FREEZINGGLARE, :FIREYWRATH, :RAGINGFURY, :BITTERBLADE],
		1.2 => [:DARKPULSE, :NIGHTDAZE, :RAGEFIST],
		0 => [:HAIL, :SUNNYDAY, :SANDSTORM, :RAINDANCE, :TEATIME, :LUCKYCHANT],
	},
	:accuracyMods => {
		0 => [:DARKVOID, :DARKPULSE, :NIGHTDAZE],
	},
	:moveMessages => {
		"The attack has been corrupted." => [:HYPERSPACEFURY, :HYPERSPACEHOLE, :SPACIALREND, :ROAROFTIME, :ETERNABEAM, :DYNAMAXCANNON, :SHADOWFORCE, :DARKPULSE, :NIGHTDAZE],
		"The rage continues." => [:OUTRAGE, :THRASH, :STOMPINGTANTRUM, :LASHOUT, :FREEZINGGLARE, :TEMPERFLARE, :FIREYWRATH, :RAGINGFURY, :RAGEFIST],
		"The dimension powered up the attack!" => [:BITTERBLADE],
		"But it failed." => [:TEATIME, :LUCKYCHANT],
		"The dark dimension swallowed the sand." => [:SANDSTORM],
		"The dark dimension swallowed the rain." => [:RAINDANCE],
		"The dark dimension swallowed the hail." => [:HAIL],
		"The sunlight cannot pierce the darkness." => [:SUNNYDAY],
	},
	:typeMods => {
	},
	:typeAddOns => {
	},
	:moveEffects => {
		"@battle.field.counter += 1" => [:BLIZZARD, :SHEERCOLD, :ICEBURN, :FREEZESHOCK, :GLACIATE],
	},
	:typeBoosts => {
		1.5 => [:DARK, :SHADOW],
		1.2 => [:GHOST],
		0.5 => [:FAIRY],
	},
	:typeMessages => {
		"Darkness gathers..." => [:DARK],
		"The shadow is strengthened..." => [:SHADOW],
		"The evil aura powered up the attack..." => [:GHOST],
		"The evil aura depleted the attack!" => [:FAIRY],
	},
	:typeCondition => {
		:FAIRY => "attacker.ability != :EXECUTION",
	},
	:typeEffects => {},
	:changeCondition => {
		:FROZENDIMENSION => "@battle.field.counter > 1 || self.move==:COLDTRUTH",
	},
	:fieldChange => {
		:FROZENDIMENSION => [:BLIZZARD, :SHEERCOLD, :ICEBURN, :FREEZESHOCK, :GLACIATE, :COLDTRUTH],
		:INFERNAL => [:PRECIPICEBLADES],
		:INDOOR => [:PURIFY, :SEEDFLARE],
	},
	:dontChangeBackup => [],
	:changeMessage => {
		 "The dimension froze up!" => [:BLIZZARD, :SHEERCOLD, :ICEBURN, :FREEZESHOCK, :GLACIATE, :COLDTRUTH],
		 "The field went up in flames!" => [:PRECIPICEBLADES],
		 "The dimension was purified!" => [:PURIFY, :SEEDFLARE],
	},
	:statusMods => [:OBSTRUCT, :QUASH, :EMBARGO, :HEALBLOCK, :DARKVOID],
	:changeEffects => {},
	:seed => {
		:seedtype => :MAGICALSEED,
		:effect => nil,
		:duration => nil,
		:message => "",
		:animation => :TRICKROOM,
		:stats => {
			PBStats::DEFENSE => 1,
			PBStats::SPEED => -1,
		},
	},
},
# lawds mod 7/6/2024 - changed around some of the modifiers
:FROZENDIMENSION => {
	:name => "Frozen Dimensional Field",
	:fieldMessage => [
		"Hate and anger radiates."
	],
	:graphic => ["Angie"],
	:secretPower => "ICEBEAM",
	:naturePower => :ICEBEAM,
	:mimicry => :ICE,
	:damageMods => {
		2.0 => [:CHILLINGWATER],
		1.5 => [:RAGINGFURY,:THRASH,:OUTRAGE,:STOMPINGTANTRUM,:RAGE,:LASHOUT,:FREEZINGGLARE,:FIERYWRATH,:TEMPERFLARE,:ROAROFTIME, :SURF, :MUDDYWATER, :WATERPULSE, :HYDROPUMP, :BITTERMALICE],
		1.2 => [:NIGHTSLASH, :DARKPULSE, :HYPERSPACEFURY, :HYPERSPACEHOLE, :RAGEFIST],
		0 => [:MAGICROOM, :WONDERROOM, :TRICKROOM, :GRAVITY, :COURTCHANGE, :TEATIME, :ELECTRICTERRAIN, :GRASSYTERRAIN, :PSYCHICTERRAIN, :MISTYTERRAIN],
	},
	:accuracyMods => {
		100 => [:DARKVOID],
	},
	:moveMessages => {
		"The rage continues." => [:RAGINGFURY,:THRASH,:OUTRAGE,:STOMPINGTANTRUM,:RAGE,:LASHOUT,:TEMPERFLARE,:FREEZINGGLARE,:FIERYWRATH,:ROAROFTIME,:RAGEFIST],
		"The dimension powered up the attack!" => [:BITTERBLADE],
		"The ice warped the attack." => [:SURF, :MUDDYWATER, :WATERPULSE, :HYDROPUMP, :NIGHTSLASH, :DARKPULSE, :HYPERSPACEFURY, :HYPERSPACEHOLE,:RAGEFIST,:CHILLINGWATER,:BITTERMALICE],
		"The frozen dimension remains unchanged." => [:MAGICROOM, :WONDERROOM, :TRICKROOM, :GRAVITY, :COURTCHANGE, :ELECTRICTERRAIN, :GRASSYTERRAIN, :PSYCHICTERRAIN, :MISTYTERRAIN],
		"But it failed." => [:TEATIME],
	},
	:typeMods => {
		:ICE => [:SURF, :MUDDYWATER, :WATERPULSE, :HYDROPUMP, :NIGHTSLASH, :DARKPULSE,:RAGEFIST],
	},
	:typeAddOns => {
	},
	:moveEffects => {
		"@battle.field.counter += 1" => [:HEATWAVE, :ERUPTION, :SEARINGSHOT, :FLAMEBURST, :LAVAPLUME, :FIREPLEDGE, :MINDBLOWN, :INCINERATE, :INFERNOOVERDRIVE, :RAGINGFURY]
	},
	:typeBoosts => {
		1.5 => [:ICE, :DARK],
		0.7 => [:FIRE],
	},
	:typeMessages => {
		"Darkness gathers..." => [:DARK],
		"The dimension mutated the ice!" => [:ICE],
		"The dimension smothered the flame..." => [:FIRE],
	},
	:typeCondition => {
	},
	:typeEffects => {},
	:changeCondition => { # Lawds Mod - needs two uses of an applicable Fire move to change the field to Dimensional
		:DIMENSIONAL => "@battle.field.counter > 1",
	},
	:fieldChange => {
		:DIMENSIONAL => [:HEATWAVE, :ERUPTION, :SEARINGSHOT, :LAVAPLUME, :FIREPLEDGE, :MINDBLOWN, :INCINERATE, :INFERNOOVERDRIVE, :RAGINGFURY, :TEMPERFLARE],
		:ICY => [:PURIFY],
	},
	:dontChangeBackup => [],
	:changeMessage => {
		 "The dimension thawed away!" => [:HEATWAVE, :ERUPTION, :SEARINGSHOT, :FLAMEBURST, :LAVAPLUME, :FIREPLEDGE, :MINDBLOWN, :INCINERATE, :INFERNOOVERDRIVE, :RAGINGFURY],
		 "The dimension was purified!" => [:PURIFY],
	},
	:statusMods => [:PARTINGSHOT, :AURORAVEIL, :DARKVOID],
	:changeEffects => {},
	:seed => {
		:seedtype => :ELEMENTALSEED,
		:effect => :Torment,
		:duration => true,
		:message => "{1} is subjected to torment!",
		:animation => :TORMENT,
		:stats => {
			PBStats::SPEED => 2,
		},
	},
},
:HAUNTED => {
	:name => "Haunted Field",
	:fieldMessage => [
		"The field is haunted!"
	],
	:graphic => ["Haunted","Haunted2","Haunted3"],
	:secretPower => "SHADOWCLAW",
	:naturePower => :PHANTOMFORCE,
	:mimicry => :GHOST,
	:damageMods => {
		1.5 => [:FLAMEBURST, :INFERNO, :TORCHSONG, :FLAMECHARGE, :FIRESPIN, :BONECLUB, :BONERUSH, :BONEMERANG, :ASTONISH, :SPIRITBREAK],
		1.2 => [:SHADOWBONE],
		2 => [:TIKITORCH],
	},
	:accuracyMods => {},
	:moveMessages => {
		"Will-o'-wisps joined the attack!" => [:FLAMEBURST, :INFERNO, :FLAMECHARGE, :FIRESPIN],
		"The haunting tune chills you to the bone!" => [:TORCHSONG],
		"Spooky scary skeletons!" => [:BONECLUB, :BONERUSH, :BONEMERANG, :SHADOWBONE],
		"Soul-crushing!" => [:SPIRITBREAK],
		"Boo!" => [:ASTONISH],
		"Haunted ritual...!" => [:TIKITORCH],
	},
	:typeMods => {
		:GHOST => [:FLAMEBURST, :INFERNO, :FLAMECHARGE, :FIRESPIN],
	},
	:typeAddOns => {
	},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:GHOST],
	},
	:typeMessages => {
		"The evil aura powered up the attack!" => [:GHOST],
	},
	:typeCondition => {
	},
	:typeEffects => {},
	:changeCondition => {
	},
	:fieldChange => {
		:HOLY => [:JUDGEMENT, :ORIGINPULSE, :SACREDFIRE, :PURIFY, :MULTIPULSE],
	},
	:dontChangeBackup => [],
	:changeMessage => {
		 "The evil spirits have been exorcised!" => [:JUDGEMENT, :ORIGINPULSE, :PURIFY, :SACREDFIRE, :MULTIPULSE],
	},
	:statusMods => [:NIGHTMARE, :SPITE, :CURSE, :DESTINYBOND, :MEANLOOK, :SCARYFACE, :MAGICPOWDER, :WILLOWISP],
	:changeEffects => {},
	:seed => {
		:seedtype => :MAGICALSEED,
		:effect => :nil,
		:duration => nil,
		:message => "",
		:animation => nil,
		:stats => {
			PBStats::SPDEF => 1,
			PBStats::DEFENSE => 1,
		},
	},
},
:CORRUPTED => {
	:name => "Corrupted Cave",
	:fieldMessage => [
		"Corruption seeps from every crevice!"
	],
	:graphic => ["Corrupted"],
	:secretPower => "POISONJAB",
	:naturePower => :GUNKSHOT,
	:mimicry => :POISON,
	:damageMods => {
		1.5 => [:SEEDFLARE, :APPLEACID],
		0.5 => [:SCENTEDGEYSER],
	},
	:accuracyMods => {
	},
	:moveMessages => {
		"The move absorbed the filth!" => [:SEEDFLARE],
	},
	:typeMods => {
		:POISON => [:ROCKSLIDE, :SMACKDOWN, :STONEEDGE, :ROCKTOMB, :DIAMONDSTORM],
		:ROCK => [:SLUDGEWAVE, :GUNKSHOT],
	},
	:typeAddOns => {
	},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:POISON],
		1.2 => [:ROCK, :GRASS],
		0.5 => [:FAIRY, :FLYING],
	},
	:typeMessages => {
		"The chemicals strengthened the attack." => [:POISON],
		"The corruption morphed the attack!" => [:ROCK, :GRASS],
		"The corruption weakened the attack." => [:FAIRY],
		"The noxious fumes choked out the attack..." => [:SCENTEDGEYSER],
		"The cave choked out the air!" => [:FLYING],
	},
	:typeCondition => {
		:FLYING => "!self.contactMove?",
	},
	:typeEffects => {},
	:changeCondition => {
	},
	:fieldChange => {
		:CAVE => [:SOLARBEAM, :SOLARBLADE, :PURIFY, :SEEDFLARE],
		:VOLCANIC => [:HEATWAVE, :ERUPTION, :LAVAPLUME, :BLASTBURN, :INFERNOOVERDRIVE],
	},
	:dontChangeBackup => [],
	:changeMessage => {
		 "The cave was purified!" => [:SOLARBEAM, :SOLARBLADE, :PURIFY, :SEEDFLARE],
	},
	:statusMods => [:NIGHTMARE, :SPITE, :CURSE, :DESTINYBOND, :MEANLOOK, :SCARYFACE, :MAGICPOWDER, :HYPNOSIS, :WILLOWISP],
	:changeEffects => {
		"@battle.mistExplosion" => [:HEATWAVE, :ERUPTION, :LAVAPLUME, :BLASTBURN, :INFERNOOVERDRIVE],
	},
	:seed => {
		:seedtype => :SYNTHETICSEED,
		:effect => nil,
		:duration => nil,
		:message => "",
		:animation => nil,
		:stats => {
			PBStats::DEFENSE => 2,
		},
	},
},
:BEWITCHED => {
	:name => "Bewitched Woods",
	:fieldMessage => [
		"Everlasting glow and glamour!"
	],
	:graphic => ["Blackleaf","Darchlight"],
	:secretPower => "NEEDLEARM",
	:naturePower => :DAZZLINGGLEAM,
	:mimicry => :FAIRY,
	:damageMods => {
		1.5 => [:HEX, :MYSTICALFIRE, :SPIRITBREAK, :ELECTROCLAP, :MATCHAGOTCHA],
		1.4 => [:ICEBEAM, :HYPERBEAM, :SIGNALBEAM, :AURORABEAM, :CHARGEBEAM, :PSYBEAM, :FLASHCANNON, :MIRRORBEAM, :MAGICALLEAF, :BUBBLEBEAM, :PSYCHICHARVEST],
		1.2 => [:DARKPULSE, :NIGHTDAZE, :MOONBLAST],
	},
	:accuracyMods => {
		85 => [:SLEEPPOWDER, :POISONPOWDER, :STUNSPORE, :GRASSWHISTLE],
	},
	:moveMessages => {
		"Magic aura amplified the attack!" => [:HEX, :MYSTICALFIRE, :SPIRITBREAK, :ICEBEAM, :HYPERBEAM, :SIGNALBEAM, :AURORABEAM, :CHARGEBEAM, :PSYBEAM, :FLASHCANNON, :MIRRORBEAM, :MAGICALLEAF, :BUBBLEBEAM],
		"Flourish!" => [:PSYCHICHARVEST],
		"The forest is cursed with nightfall!" => [:DARKPULSE, :NIGHTDAZE, :MOONBLAST],
		"The attack burst out from the enchanted trees!" => [:ELECTROCLAP],
		"A dangerous fae's feast!" => [:MATCHAGOTCHA],
	},
	:typeMods => {
	},
	:typeAddOns => {
	},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:FAIRY, :GRASS],
		1.3 => [:DARK],
	},
	:typeMessages => {
		"The fairy aura amplified the attack's power!" => [:FAIRY],
		"Flourish!" => [:GRASS],
		"The dark aura amplified the attack's power!" => [:DARK],
	},
	:typeCondition => {
	},
	:typeEffects => {},
	:changeCondition => {
	},
	:fieldChange => {
		:FOREST => [:PURIFY],
	},
	:dontChangeBackup => [],
	:changeMessage => {
		 "The evil spirits have been exorcised!" => [:PURIFY],
	},
	:statusMods => [:STRENGTHSAP, :FORESTSCURSE, :MAGICPOWDER, :MOONLIGHT, :SLEEPPOWDER, :POISONPOWDER, :STUNSPORE, :GRASSWHISTLE],
	:changeEffects => {},
	:seed => {
		:seedtype => :MAGICALSEED,
		:effect => :Ingrain,
		:duration => true,
		:message => "{1} planted its roots.",
		:animation => :INGRAIN,
		:stats => {
			PBStats::SPDEF => 1,
		},
	},
},
:SKY => {
	:name => "Sky Field",
	:fieldMessage => [
		"The sky is filled with clouds."
	],
	:graphic => ["GoldenArena"],
	:secretPower => "WINGATTACK",
	:naturePower => :TAILWIND,
	:mimicry => :FLYING,
	:damageMods => {
		1.5 => [:ICYWIND, :SILVERWIND, :GALESTRIKE, :OMINOUSWIND, :FAIRYWIND, :AEROBLAST, :FLYINGPRESS, :SKYUPPERCUT, :CRUSHCLAW, :THUNDERSHOCK, :THUNDERBOLT, :STEELWING, :DRAGONDARTS, :GRAVAPPLE, :DRAGONASCENT, :THUNDER, :TWISTER, :RAZORWIND, :DIVE, :ESPERWING, :BLEAKWINDSTORM],
		1.3 => [:SPRINGTIDESTORM, :WILDBOLTSTORM, :SANDSEARSTORM],
		0 => [:EARTHQUAKE, :MAGNITUDE, :BULLDOZE, :DIG, :ROTOTILLER, :SPIKES, :TOXICSPIKES, :STICKYWEB]
	},
	:accuracyMods => {
		0 => [:HURRICANE]
	},
	:moveMessages => {
		"The open skies strengthened the attack!" => [:ICYWIND, :GALESTRIKE, :SILVERWIND, :OMINOUSWIND, :FAIRYWIND, :AEROBLAST, :FLYINGPRESS, :SKYUPPERCUT, :THUNDERSHOCK, :THUNDERBOLT, :THUNDER, :STEELWING, :DRAGONDARTS, :GRAVAPPLE, :DRAGONASCENT, :THUNDER, :TWISTER, :RAZORWIND, :DIVE, :ESPERWING, :SPRINGTIDESTORM, :WILDBOLTSTORM, :SANDSEARSTORM, :BLEAKWINDSTORM],
		"The talons glint in the open skies!" => [:CRUSHCLAW],
		"But there is no solid ground!" => [:EARTHQUAKE, :MAGNITUDE, :BULLDOZE, :DIG, :ROTOTILLER, :SPIKES, :TOXICSPIKES, :STICKYWEB]
	},
	:typeMods => {
		:FLYING => [:DIVE, :TWISTER],
	},
	:typeAddOns => {
	},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:FLYING],
	},
	:typeMessages => {
		"The open air strengthened the attack!" => [:FLYING],
	},
	:typeCondition => {
		:FLYING => "!(opponent.ability == :WINDRIDER && self.pbIsSpecial?(type) && opponent.pbOwnSide.effects[:Tailwind] != 0)",
	},
	:typeEffects => {},
	:changeCondition => {
	},
	:fieldChange => {
		:MOUNTAIN => [:GRAVITY, :INGRAIN, :THOUSANDARROWS, :SMACKDOWN, :GRAVAPPLE],
	},
	:dontChangeBackup => [],
	:changeMessage => {
		 "The battle has been brought down to the mountains!" => [:GRAVITY, :INGRAIN, :THOUSANDARROWS, :SMACKDOWN, :GRAVAPPLE],
	},
	:statusMods => [:MIRRORMOVE, :TAILWIND, :SUNNYDAY, :HAIL, :SANDSTORM, :RAINDANCE, :CHILLYRECEPTION],
	:changeEffects => {},
	:seed => {
		:seedtype => :ELEMENTALSEED,
		:effect => 0,
		:duration => 0,
		:message => "{1} began to ride the winds!",
		:animation => "Sky Attack charging",
		:stats => {
			PBStats::SPDEF => 1,
		},
	},
},
:COLOSSEUM => {
	:name => "Colosseum",
	:fieldMessage => [
		"All eyes are on the combatants!"
	],
	:graphic => ["Colosseum"],
	:secretPower => "POWERUPPUNCH",
	:naturePower => :BEATUP,
	:mimicry => :STEEL,
	:damageMods => {
		2.0 => [:BEATUP, :BOSSORDERS, :FELLSTINGER, :PAYDAY, :REVERSAL, :PURSUIT],
		1.5 => [:STORNTHROW, :SACREDSWORD, :KECLEONBLAST, :SECRETSWORD, :SUBMISSION, :GALESTRIKE, :METEORASSAULT, :MAKEITRAIN, :SMARTSTRIKE, :SMACKDOWN, :BRUTALSWING, :BARBEDWEB, :ELECTROWEB, :VINEWHIP, :PSYCHOCUT, :NIGHTSLASH, :BONEMERANG, :FIRSTIMPRESSION, :BONERUSH, :BONECLUB, :LEAFBLADE, :PAYBACK, :PUNISHMENT, :METEORMASH, :BULLETPUNCH, :CLANGINGSCALES, :STEAMROLLER],
		1.2 => [:WOODHAMMER, :DRAGONHAMMER, :POWERWHIP, :SPIRITSHACKLE, :DRILLRUN, :DRILLPECK, :ICEHAMMER, :ICICLESPEAR, :ANCHORSHOT, :CRABHAMMER, :SHADOWBONE, :FIRELASH, :SUCKERPUNCH, :THROATCHOP],
		0 => [:BATONPASS, :ENCORE, :WHIRLWIND],
	},
	:accuracyMods => {
	},
	:moveMessages => {
		"The fighters rallied together!" => [:BEATUP, :BOSSORDERS],
		"The coup de grâce!" => [:FELLSTINGER],
		"The audience hurled coins down!" => [:PAYDAY, :MAKEITRAIN],
		"There is no escape!" => [:PURSUIT],
		"Battle cry!" => [:DRAGONCHEER],
		"For Honor!" => [:REVERSAL, :SACREDSWORD, :SECRETSWORD, :SUBMISSION, :METEORASSAULT, :SMARTSTRIKE, :SMACKDOWN, :BRUTALSWING, :STORMTHROW, :GALESTRIKE],
		"For Glory!" => [:ELECTROWEB, :KECLEONBLAST, :BARBEDWEB, :VINEWHIP, :PSYCHOCUT, :NIGHTSLASH, :BONEMERANG, :FIRSTIMPRESSION, :BONERUSH, :BONECLUB, :LEAFBLADE, :PAYBACK, :PUNISHMENT, :METEORMASH, :BULLETPUNCH, :CLANGINGSCALES, :STEAMROLLER, :WOODHAMMER, :DRAGONHAMMER, :POWERWHIP, :SPIRITSHACKLE, :DRILLRUN, :DRILLPECK, :ICEHAMMER, :ICICLESPEAR, :ANCHORSHOT, :CRABHAMMER, :SHADOWBONE, :FIRELASH, :SUCKERPUNCH, :THROATCHOP],
		"There can be no retreat!" => [:BATONPASS],
		"{1} stands their ground in the arena!!" => [:WHIRLWIND],
		"The audience demands fighting, not repetition!" => [:ENCORE],
	},
	:typeMods => {
	},
	:typeAddOns => {
	},
	:moveEffects => {},
	:typeBoosts => {},
	:typeMessages => {},
	:typeCondition => {
	},
	:typeEffects => {},
	:changeCondition => {
	},
	:fieldChange => {
	},
	:dontChangeBackup => [],
	:changeMessage => {
	},
	:statusMods => [:SWORDSDANCE, :KINGSSHIELD, :HOWL, :NORETREAT, :ROAR, :SWAGGER, :DRAGONCHEER, :FLATTER],
	:changeEffects => {},
	:seed => {
		:seedtype => :SYNTHETICSEED,
		:effect => :Taunt,
		:duration => 4,
		:message => "{1} feels taunted!",
		:animation => :TAUNT,
		:stats => {
			PBStats::ATTACK => 2,
		},
	},
},
:INFERNAL => {
	:name => "Infernal Field",
	:fieldMessage => [
		"Damnation invites you..."
	],
	:graphic => ["Infernal"],
	:secretPower => "INFERNO",
	:naturePower => :PUNISHMENT,
	:mimicry => :FIRE,
	:damageMods => {
		2.0 => [:SMOG, :DREAMEATER],
		1.5 => [:RAGINGBULL,:BLASTBURN,:EARTHPOWER,:INFERNOOVERDRIVE,:PRECIPICEBLADES,:INFERNO,:RAGINGFURY,:INFERNALPARADE,:SPIRITSHACKLE,:LASHOUT,:TEMPERFLARE,:RAGEFIST,:STOMPINGTANTRUM],
		0  => [:RAINDANCE, :HAIL],
	},
	:accuracyMods => {
		0 => [:WILLOWISP, :DARKVOID],
	},
	:moveMessages => {
		"Hellish suffering!" => [:LASHOUT, :SMOG, :DREAMEATER, :RAGEFIST, :STOMPINGTANTRUM, :TEMPERFLARE,:RAGINGBULL],
		"Abandon hope!" => [:SPIRITSHACKLE, :PUNISHMENT],
		"Infernal flames strengthened the attack!" => [:BLASTBURN, :EARTHPOWER, :INFERNOOVERDRIVE, :PRECIPICEBLADES, :INFERNO, :RAGINGFURY, :INFERNALPARADE],
		"The hail melted away." => [:HAIL],
		"The rain evaporated." => [:RAINDANCE],
	},
	:typeMods => {
		:DARK => [:SPIRITBREAK, :AURASPHERE],
	},
	:typeAddOns => {
		:FIRE => [:GROUND, :ROCK],
	},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:FIRE, :DARK, :SHADOW],
		0.7 => [:FAIRY],
	},
	:typeMessages => {
		"The infernal flames strengthened the attack!" => [:FIRE],
		"Overwhelming malevolence strengthened the attack!" => [:DARK,:SHADOW],
		"The hellfire burnt out the attack!" => [:FAIRY],
	},
	:typeCondition => {
		:FAIRY => "self.pbIsSpecial?(@type)",
	},
	:typeEffects => {},
	:changeCondition => {
	},
	:fieldChange => {
		:DIMENSIONAL => [:GLACIATE],
		:VOLCANICTOP => [:JUDGEMENT, :ORIGINPULSE, :PURIFY],
	},
	:dontChangeBackup => [],
	:changeMessage => {
		 "The hellish landscape was doused of its fire!" => [:GLACIATE],
		 "The hellish landscape was purified!" => [:JUDGEMENT, :ORIGINPULSE, :PURIFY],
	},
	:statusMods => [:WILLOWISP, :DARKVOID, :TORMENT, :NIGHTMARE, :STEALTHROCK, :TORCHSONG, :NASTYPLOT],
	:changeEffects => {},
	:seed => {
		:seedtype => :ELEMENTALSEED,
		:effect => nil,
		:duration => nil,
		:message => "{1} can't escape the hellfire!",
		:animation => :MEANLOOK,
		:stats => {
			PBStats::DEFENSE => 1,
			PBStats::SPEED => 1,
		},
	},
},
:CONCERT1 => {
	:name => "Concert Venue",
	:fieldMessage => [
		"Let's get HYPED!"
	],
	:graphic => ["Concert1"],
	:secretPower => "BOOMBURST",
	:naturePower => :HYPERVOICE,
	:mimicry => :NORMAL,
	:damageMods => {
		1.5 => [:ACID,:APPLEACID,:ACIDSPRAY,:DRUMBEATING,:ELECTROCLAP,:FAKEOUT,:FLING,:ROLLOUT,:FIRSTIMPRESSION,:DRAGONTAIL,:CIRCLETHROW,:RAGE,:THRASH,:FRUSTRATION,:OUTRAGE,:STOMPINGTANTRUM,:RAGEFIST],
	},
	:accuracyMods => {
		100 => [:SING],
	},
	:moveMessages => {
		"Face melting!" => [:ACID,:ACIDSPRAY,:APPLEACID],
		"Rock and roll!" => [:ROLLOUT],
		"An amazing drum solo!" => [:DRUMBEATING],
		"Shining lights!" => [:ELECTROCLAP],
		"What an opening act!" => [:FIRSTIMPRESSION,:FAKEOUT],
		"MOSHPIT!!!" => [:DRAGONTAIL,:CIRCLETHROW],
		"The outraged audience is rioting!" => [:RAGE,:THRASH,:FRUSTRATION,:OUTRAGE,:STOMPINGTANTRUM,:RAGEFIST],
		"Mic drop!" => [:FLING],
	},
	:typeMods => {
	},
	:typeAddOns => {
	},
	:moveEffects => {},
	:typeBoosts => {
	},
	:typeMessages => {
	},
	:typeCondition => {
	},
	:typeEffects => {},
	:changeCondition => {
	},
	:fieldChange => {
		:CONCERT2 => [:WORKUP,:DRAGONCHEER,:ROLLOUT,:FIRSTIMPRESSION,:ELECTROCLAP,:DRUMBEATING,:REVELATIONDANCE,:FIERYDANCE,:PETALDANCE,:DRAGONDANCE,:QUIVERDANCE,:AQUABATICS,:SWORDSDANCE,:FEATHERDANCE,:SWAGGER,:BOOMBURST,:BUGBUZZ,:CHATTER,:CLANGINGSCALES,:CLANGOROUSSOUL,:CLANGOROUSSOULBLAZE,:DISARMINGVOICE,:ECHOEDVOICE,:GROWL,:HOWL,:HYPERVOICE,:METALSOUND,:NOBLEROAR,:OVERDRIVE,:PARTINGSHOT,:RELICSONG,:ROAR,:ROUND,:SCREECH,:SHADOWPANIC,:SING,:SNARL,:SPARKLINGARIA,:SUPERSONIC,:UPROAR,:FEVERPITCH,:SPECTRALSCREAM],
		:CONCERT3 => [:LASERFOCUS,:LUCKYCHANT,:FOCUSENERGY,:SPOTLIGHT,:FOLLOWME],
		:CONCERT4 => [:SELFDESTRUCT,:EXPLOSION],
	},
	:dontChangeBackup => [],
	:changeMessage => {
		"The stunning dance makes the audience go wild!" => [:REVELATIONDANCE,:FIERYDANCE,:PETALDANCE,:DRAGONDANCE,:QUIVERDANCE,:AQUABATICS,:SWORDSDANCE,:FEATHERDANCE],
		"The song is getting the audience hyped!" => [:BOOMBURST,:BUGBUZZ,:CHATTER,:CLANGINGSCALES,:CLANGOROUSSOUL,:CLANGOROUSSOULBLAZE,:DISARMINGVOICE,:ECHOEDVOICE,:GROWL,:HOWL,:HYPERVOICE,:METALSOUND,:NOBLEROAR,:OVERDRIVE,:PARTINGSHOT,:RELICSONG,:ROAR,:ROUND,:SCREECH,:SHADOWPANIC,:SING,:SNARL,:SPARKLINGARIA,:SUPERSONIC,:UPROAR,:FEVERPITCH,:SPECTRALSCREAM],
		"The crowd is getting hyped!" => [:DRUMBEATING,:FIRSTIMPRESSION,:WORKUP,:ROLLOUT,:SWAGGER,:ELECTROCLAP,:DRAGONCHEER],
		"The ruthless diss got the crowd's attention!" => [:PARTINGSHOT],
		"The audience's full attention is on the stage!" => [:LASERFOCUS,:LUCKYCHANT,:FOCUSENERGY,:SPOTLIGHT,:FOLLOWME],
		"The audience cheers for the explosive finish!!" => [:SELFDESTRUCT,:EXPLOSION],
	},
	:statusMods => [:ACIDARMOR,:WORKUP,:HOWL,:PARTINGSHOT,:METALSOUND,:DRAGONCHEER,:SCREECH,:GROWL,:CLANGOROUSSOUL,:SING,:ROAR,:ENCORE],
	:changeEffects => {
		"@battle.concertNoise" => [:LASERFOCUS,:LUCKYCHANT,:FOCUSENERGY,:SPOTLIGHT,:FOLLOWME,:SELFDESTRUCT,:EXPLOSION]
	},
	:seed => {
		:seedtype => :SYNTHETICSEED,
		:effect => :HelpingHand,
		:duration => true,
		:message => "{1} accepts the crowd's help!",
		:animation => :HELPINGHAND,
		:stats => {
			PBStats::SPATK => 1,
		},
	},
},
:CONCERT2 => {
	:name => "Concert Venue",
	:fieldMessage => [
		"Let's get HYPED!"
	],
	:graphic => ["Concert2"],
	:secretPower => "BOOMBURST",
	:naturePower => :HYPERVOICE,
	:mimicry => :NORMAL,
	:damageMods => {
		1.5 => [:ACID,:APPLEACID,:ACIDSPRAY,:DRUMBEATING,:FAKEOUT,:FLING,:ELECTROCLAP,:ROLLOUT,:RAGEFIST,:FIRSTIMPRESSION,:DRAGONTAIL,:CIRCLETHROW,:RAGE,:THRASH,:FRUSTRATION,:OUTRAGE,:STOMPINGTANTRUM],
	},
	:accuracyMods => {
		100 => [:SING],
	},
	:moveMessages => {
		"Face melting!" => [:ACID,:ACIDSPRAY,:APPLEACID],
		"Rock and roll!" => [:ROLLOUT],
		"An amazing drum solo!" => [:DRUMBEATING],
		"Shining lights!" => [:ELECTROCLAP],
		"What an opening act!" => [:FIRSTIMPRESSION,:FAKEOUT],
		"MOSHPIT!!!" => [:DRAGONTAIL,:CIRCLETHROW],
		"The outraged audience is rioting!" => [:RAGE,:THRASH,:FRUSTRATION,:OUTRAGE,:STOMPINGTANTRUM,:RAGEFIST],
		"Mic drop!" => [:FLING],
	},
	:typeMods => {
	},
	:typeAddOns => {
	},
	:moveEffects => {},
	:typeBoosts => {
	},
	:typeMessages => {
	},
	:typeCondition => {
	},
	:typeEffects => {},
	:changeCondition => {
		:CONCERT1 => "!attacker.missAcc || (basemove.move != :SHEERCOLD && basemove.move != :COLDTRUTH)",
	},
	:fieldChange => {
		:CONCERT1 => [:THROATCHOP,:SHEERCOLD,:CHILLYRECEPTION,:COLDTRUTH,:EMBARGO,:QUASH,:SLACKOFF,:YAWN,:PLAYNICE,:BABYDOLLEYES,:TICKLE,:RAGEFIST],
		:CONCERT3 => [:WORKUP,:ROLLOUT,:FIRSTIMPRESSION,:DRUMBEATING,:ELECTROCLAP,:REVELATIONDANCE,:DRAGONCHEER,:FIERYDANCE,:PETALDANCE,:DRAGONDANCE,:QUIVERDANCE,:AQUABATICS,:SWORDSDANCE,:FEATHERDANCE,:SWAGGER,:BOOMBURST,:BUGBUZZ,:CHATTER,:CLANGINGSCALES,:CLANGOROUSSOUL,:CLANGOROUSSOULBLAZE,:DISARMINGVOICE,:ECHOEDVOICE,:GROWL,:HOWL,:HYPERVOICE,:METALSOUND,:NOBLEROAR,:OVERDRIVE,:PARTINGSHOT,:RELICSONG,:ROAR,:ROUND,:SCREECH,:SHADOWPANIC,:SING,:SNARL,:SPARKLINGARIA,:SUPERSONIC,:UPROAR,:FEVERPITCH,:SPECTRALSCREAM],
		:CONCERT4 => [:LASERFOCUS,:LUCKYCHANT,:FOCUSENERGY,:SPOTLIGHT,:FOLLOWME,:SELFDESTRUCT,:EXPLOSION],
	},
	:dontChangeBackup => [],
	:changeMessage => {
		"The freezing cold drives the audience away..." => [:SHEERCOLD],
		"Tough crowd, huh?" => [:CHILLYRECEPTION],
		"'Bitter cold AND preaching? I am out of here!'" => [:COLDTRUTH],
		"The lead singer's voice fails..." => [:THROATCHOP],
		"The bar is closed and the crowd does NOT like it..." => [:EMBARGO],
		"The crowd is booing, they want action!" => [:QUASH,:SLACKOFF,:YAWN],
		"The audience is not a fan of this friendly touchy-feely stuff..." => [:PLAYNICE,:BABYDOLLEYES,:TICKLE],
		"Way to kill the vibe, psycho..." => [:RAGEFIST],
		"The stunning dance makes the audience go wild!" => [:REVELATIONDANCE,:FIERYDANCE,:PETALDANCE,:DRAGONDANCE,:QUIVERDANCE,:AQUABATICS,:SWORDSDANCE,:FEATHERDANCE],
		"The song is getting the audience hyped!" => [:BOOMBURST,:BUGBUZZ,:CHATTER,:CLANGINGSCALES,:CLANGOROUSSOUL,:CLANGOROUSSOULBLAZE,:DISARMINGVOICE,:ECHOEDVOICE,:GROWL,:HOWL,:HYPERVOICE,:METALSOUND,:NOBLEROAR,:OVERDRIVE,:PARTINGSHOT,:RELICSONG,:ROAR,:ROUND,:SCREECH,:SHADOWPANIC,:SING,:SNARL,:SPARKLINGARIA,:SUPERSONIC,:UPROAR,:FEVERPITCH,:SPECTRALSCREAM],
		"The crowd is getting hyped!" => [:DRUMBEATING,:FIRSTIMPRESSION,:DRAGONCHEER,:WORKUP,:ROLLOUT,:SWAGGER,:ELECTROCLAP],
		"The ruthless diss got the crowd's attention!" => [:PARTINGSHOT],
		"The audience's full attention is on the stage!" => [:LASERFOCUS,:LUCKYCHANT,:FOCUSENERGY,:SPOTLIGHT,:FOLLOWME],
		"The audience cheers for the explosive finish!!" => [:SELFDESTRUCT,:EXPLOSION],
	},
	:statusMods => [:ACIDARMOR,:WORKUP,:HOWL,:PARTINGSHOT,:METALSOUND,:SCREECH,:GROWL,:DRAGONCHEER,:CLANGOROUSSOUL,:SING,:ROAR,:ENCORE],
	:changeEffects => {
		"@battle.concertNoise" => [:WORKUP,:ROLLOUT,:FIRSTIMPRESSION,:DRUMBEATING,:REVELATIONDANCE,:FIERYDANCE,:PETALDANCE,:DRAGONDANCE,:QUIVERDANCE,:AQUABATICS,:SWORDSDANCE,:FEATHERDANCE,:SWAGGER,:LASERFOCUS,:LUCKYCHANT,:FOCUSENERGY,:SPOTLIGHT,:FOLLOWME,:BOOMBURST,:BUGBUZZ,:CHATTER,:CLANGINGSCALES,:CLANGOROUSSOUL,:CLANGOROUSSOULBLAZE,:DISARMINGVOICE,:ECHOEDVOICE,:GROWL,:HOWL,:HYPERVOICE,:METALSOUND,:NOBLEROAR,:OVERDRIVE,:PARTINGSHOT,:RELICSONG,:ROAR,:ROUND,:SCREECH,:SHADOWPANIC,:SING,:SNARL,:SPARKLINGARIA,:SUPERSONIC,:UPROAR,:FEVERPITCH,:SPECTRALSCREAM,:SELFDESTRUCT,:EXPLOSION]
	},
	:seed => {
		:seedtype => :SYNTHETICSEED,
		:effect => :HelpingHand,
		:duration => true,
		:message => "{1} accepts the crowd's help!",
		:animation => :HELPINGHAND,
		:stats => {
			PBStats::SPATK => 1,
		},
	},
},
:CONCERT3 => {
	:name => "Concert Venue",
	:fieldMessage => [
		"Let's get HYPED!"
	],
	:graphic => ["Concert3"],
	:secretPower => "BOOMBURST",
	:naturePower => :HYPERVOICE,
	:mimicry => :NORMAL,
	:damageMods => {
		1.5 => [:ACID,:APPLEACID,:ACIDSPRAY,:DRUMBEATING,:FLING,:FAKEOUT,:ROLLOUT,:FIRSTIMPRESSION,:ELECTROCLAP,:DRAGONTAIL,:CIRCLETHROW],
	},
	:accuracyMods => {
		100 => [:SING],
	},
	:moveMessages => {
		"Face melting!" => [:ACID,:ACIDSPRAY,:APPLEACID],
		"Rock and roll!" => [:ROLLOUT],
		"An amazing drum solo!" => [:DRUMBEATING],
		"What an opening act!" => [:FIRSTIMPRESSION,:FAKEOUT],
		"Shining lights!" => [:ELECTROCLAP],
		"MOSHPIT!!!" => [:DRAGONTAIL,:CIRCLETHROW],
		"Mic drop!" => [:FLING],
	},
	:typeMods => {
	},
	:typeAddOns => {
	},
	:moveEffects => {},
	:typeBoosts => {
	},
	:typeMessages => {
	},
	:typeCondition => {
	},
	:typeEffects => {},
	:changeCondition => {
		:CONCERT1 => "!attacker.missAcc",
	},
	:fieldChange => {
		:CONCERT1 => [:SHEERCOLD,:COLDTRUTH],
		:CONCERT2 => [:THROATCHOP,:EMBARGO,:QUASH,:SLACKOFF,:YAWN,:PLAYNICE,:BABYDOLLEYES,:TICKLE,:RAGEFIST],
		:CONCERT4 => [:WORKUP,:ROLLOUT,:FIRSTIMPRESSION,:DRUMBEATING,:ELECTROCLAP,:DRAGONCHEER,:REVELATIONDANCE,:FIERYDANCE,:PETALDANCE,:DRAGONDANCE,:QUIVERDANCE,:AQUABATICS,:SWORDSDANCE,:FEATHERDANCE,:SWAGGER,:LASERFOCUS,:LUCKYCHANT,:FOCUSENERGY,:SPOTLIGHT,:FOLLOWME,:BOOMBURST,:BUGBUZZ,:CHATTER,:CLANGINGSCALES,:CLANGOROUSSOUL,:CLANGOROUSSOULBLAZE,:DISARMINGVOICE,:ECHOEDVOICE,:GROWL,:HOWL,:HYPERVOICE,:METALSOUND,:NOBLEROAR,:OVERDRIVE,:PARTINGSHOT,:RELICSONG,:ROAR,:ROUND,:SCREECH,:SHADOWPANIC,:SING,:SNARL,:SPARKLINGARIA,:SUPERSONIC,:UPROAR,:FEVERPITCH,:SPECTRALSCREAM,:SELFDESTRUCT,:EXPLOSION],
	},
	:dontChangeBackup => [],
	:changeMessage => {
		"The freezing cold drives the audience away..." => [:SHEERCOLD],
		"'Bitter cold AND preaching? I am out of here!'" => [:COLDTRUTH],
		"The lead singer's voice fails..." => [:THROATCHOP],
		"The bar is closed and the crowd does NOT like it..." => [:EMBARGO],
		"The crowd is booing, they want action!" => [:QUASH,:SLACKOFF,:YAWN],
		"The audience is not a fan of this friendly touchy-feely stuff..." => [:PLAYNICE,:BABYDOLLEYES,:TICKLE],
		"Way to kill the vibe, psycho..." => [:RAGEFIST],
		"The ruthless diss got the crowd's attention!" => [:PARTINGSHOT],
		"The stunning dance makes the audience go wild!" => [:REVELATIONDANCE,:FIERYDANCE,:PETALDANCE,:DRAGONDANCE,:QUIVERDANCE,:AQUABATICS,:SWORDSDANCE,:FEATHERDANCE],
		"The song is getting the audience hyped!" => [:BOOMBURST,:BUGBUZZ,:CHATTER,:CLANGINGSCALES,:CLANGOROUSSOUL,:CLANGOROUSSOULBLAZE,:DISARMINGVOICE,:ECHOEDVOICE,:GROWL,:HOWL,:HYPERVOICE,:METALSOUND,:NOBLEROAR,:OVERDRIVE,:PARTINGSHOT,:RELICSONG,:ROAR,:ROUND,:SCREECH,:SHADOWPANIC,:SING,:SNARL,:SPARKLINGARIA,:SUPERSONIC,:UPROAR,:FEVERPITCH,:SPECTRALSCREAM],
		"The crowd is getting hyped!" => [:DRUMBEATING,:FIRSTIMPRESSION,:DRAGONCHEER,:WORKUP,:ROLLOUT,:SWAGGER,:ELECTROCLAP],
		"The audience's full attention is on the stage!" => [:LASERFOCUS,:LUCKYCHANT,:FOCUSENERGY,:SPOTLIGHT,:FOLLOWME],
		"The audience cheers for the explosive finish!!" => [:SELFDESTRUCT,:EXPLOSION],
	},
	:statusMods => [:ACIDARMOR,:WORKUP,:HOWL,:PARTINGSHOT,:METALSOUND,:SCREECH,:GROWL,:CLANGOROUSSOUL,:DRAGONCHEER,:SING,:ROAR,:ENCORE],
	:changeEffects => {
		"@battle.concertNoise" => [:WORKUP,:ROLLOUT,:FIRSTIMPRESSION,:DRUMBEATING,:REVELATIONDANCE,:FIERYDANCE,:PETALDANCE,:DRAGONDANCE,:QUIVERDANCE,:AQUABATICS,:SWORDSDANCE,:FEATHERDANCE,:SWAGGER,:LASERFOCUS,:LUCKYCHANT,:FOCUSENERGY,:SPOTLIGHT,:FOLLOWME,:BOOMBURST,:BUGBUZZ,:CHATTER,:CLANGINGSCALES,:CLANGOROUSSOUL,:CLANGOROUSSOULBLAZE,:DISARMINGVOICE,:ECHOEDVOICE,:GROWL,:HOWL,:HYPERVOICE,:METALSOUND,:NOBLEROAR,:OVERDRIVE,:PARTINGSHOT,:RELICSONG,:ROAR,:ROUND,:SCREECH,:SHADOWPANIC,:SING,:SNARL,:SPARKLINGARIA,:SUPERSONIC,:UPROAR,:FEVERPITCH,:SPECTRALSCREAM,:SELFDESTRUCT,:EXPLOSION]
	},
	:seed => {
		:seedtype => :SYNTHETICSEED,
		:effect => :HelpingHand,
		:duration => true,
		:message => "{1} accepts the crowd's help!",
		:animation => :HELPINGHAND,
		:stats => {
			PBStats::SPATK => 1,
		},
	},
},
:CONCERT4 => {
	:name => "Concert Venue",
	:fieldMessage => [
		"Let's get HYPED!"
	],
	:graphic => ["Concert4"],
	:secretPower => "BOOMBURST",
	:naturePower => :HYPERVOICE,
	:mimicry => :NORMAL,
	:damageMods => {
		1.5 => [:ACID,:APPLEACID,:ACIDSPRAY,:DRUMBEATING,:FLING,:ELECTROCLAP,:FAKEOUT,:ROLLOUT,:FIRSTIMPRESSION,:DRAGONTAIL,:CIRCLETHROW],
	},
	:accuracyMods => {
		100 => [:SING],
	},
	:moveMessages => {
		"Face melting!" => [:ACID,:ACIDSPRAY,:APPLEACID],
		"Rock and roll!" => [:ROLLOUT],
		"An amazing drum solo!" => [:DRUMBEATING],
		"Shining lights!" => [:ELECTROCLAP],
		"What an opening act!" => [:FIRSTIMPRESSION,:FAKEOUT],
		"MOSHPIT!!!" => [:DRAGONTAIL,:CIRCLETHROW],
		"Mic drop!" => [:FLING],
	},
	:typeMods => {
	},
	:typeAddOns => {
	},
	:moveEffects => {},
	:typeBoosts => {
	},
	:typeMessages => {
	},
	:typeCondition => {
	},
	:typeEffects => {},
	:changeCondition => {
		:CONCERT1 => "!attacker.missAcc",
	},
	:fieldChange => {
		:CONCERT1 => [:SHEERCOLD,:COLDTRUTH],
		:CONCERT3 => [:THROATCHOP,:EMBARGO,:QUASH,:SLACKOFF,:YAWN,:PLAYNICE,:BABYDOLLEYES,:TICKLE,:RAGEFIST],
	},
	:dontChangeBackup => [],
	:changeMessage => {
		"The freezing cold drives the audience away..." => [:SHEERCOLD],
		"'Bitter cold AND preaching? I am out of here!'" => [:COLDTRUTH],
		"The lead singer's voice fails..." => [:THROATCHOP],
		"The bar is closed and the crowd does NOT like it..." => [:EMBARGO],
		"The crowd is booing, they want action!" => [:QUASH,:SLACKOFF,:YAWN],
		"The audience is not a fan of this friendly touchy-feely stuff..." => [:PLAYNICE,:BABYDOLLEYES,:TICKLE],
		"Way to kill the vibe, psycho..." => [:RAGEFIST],
	},
	:statusMods => [:ACIDARMOR,:WORKUP,:HOWL,:PARTINGSHOT,:DRAGONCHEER,:METALSOUND,:SCREECH,:GROWL,:CLANGOROUSSOUL,:SING,:ROAR,:ENCORE],
	:changeEffects => {},
	:seed => {
		:seedtype => :SYNTHETICSEED,
		:effect => :HelpingHand,
		:duration => true,
		:message => "{1} accepts the crowd's help!",
		:animation => :HELPINGHAND,
		:stats => {
			PBStats::SPATK => 1,
		},
	},
},
:DEEPEARTH => {
	:name => "Deep Earth",
	:fieldMessage => [
		"The core is pulling you in...",
	],
	:graphic => ["DeepEarth","Zeight","Zeight2","Zeight3","Zeight4"],
	:secretPower => "HEAVYSLAM",
	:naturePower => :GRAVITY,
	:mimicry => :GROUND,
	:damageMods => {
		2.0 => [:LANDSWRATH, :PRECIPICEBLADES, :MAGNETBOMB, :TECTONICRAGE, :CRUSHGRIP, :SMACKDOWN, :COREENFORCER],
		1.5 => [:HEAVYSLAM,	:HEATCRASH, :BODYSLAM, :EGGBOMB, :ULTRAMEGADEATH, :STOMP, :DRAGONRUSH, :STEAMROLLER, :GRAVAPPLE, :ANCIENTPOWER, :FLING, :GRASSKNOT, :LOWKICK, :SPACIALREND, :STORMTHROW, :STONEAXE, :CIRCLETHROW, :VITALTHROW, :BODYPRESS, :SUBMISSION, :ICEHAMMER, :HAMMERARM, :CRABHAMMER, :ICICLECRASH, :THOUSANDARROWS, :THOUSANDWAVES],
	},
	:accuracyMods => {
	},
	:moveMessages => {
		"The attack came crashing down!" => [:HEAVYSLAM, :ULTRAMEGADEATH, :HEATCRASH, :BODYSLAM, :STOMP, :DRAGONRUSH, :STEAMROLLER, :GRAVAPPLE, :BODYPRESS, :ICICLECRASH, :FLING, :EGGBOMB],
		"Enjoy the trip!" => [:GRASSKNOT, :LOWKICK],
		"The attacker threw their whole weight into it!" => [:ICEHAMMER, :HAMMERARM, :CRABHAMMER, :STONEAXE],
		"Slammed into the ground!" => [:STORMTHROW, :CIRCLETHROW, :VITALTHROW, :SUBMISSION, :SMACKDOWN],
		"CRUSHED!" => [:CRUSHGRIP],
		"The magnetic field is strengthened!" => [:MAGNETBOMB],
		"The power of the earth is utterly overwhelming!"  => [:THOUSANDARROWS, :THOUSANDWAVES, :LANDSWRATH, :PRECIPICEBLADES, :TECTONICRAGE],
		"The power of ages gone by..." => [:ANCIENTPOWER],
		"The power of the core obliterates all!" => [:COREENFORCER],
		"The intense gravity is ruptured!" => [:SPACIALREND],
	},
	:typeMods => {},
	:typeAddOns => {
	},
	:moveEffects => {},
	:typeBoosts => {
		1.3 => [:ROCK, :PSYCHIC],
		1.5 => [:GROUND],
	},
	:typeMessages => {
		"The core's magical forces are immense!" => [:PSYCHIC],
		"The earth empowered the attack!" => [:ROCK, :GROUND],
	},
	:typeCondition => {
		:GROUND => "!opponent.hasType?(:GROUND)",
	},
	:typeEffects => {},
	:changeCondition => {
	},
	:fieldChange => {
	},
	:dontChangeBackup => [],
	:changeMessage => {
	},
	:statusMods => [:AUTOTOMIZE, :GEOMANCY, :ROTOTILLER, :MAGNETFLUX, :EERIEIMPULSE, :MAGNETRISE, :GRAVITY, :TOPSYTURVY, :SEISMICTOSS, :PSYWAVE],
	:changeEffects => {},
	:seed => {
		:seedtype => :TELLURICSEED,
		:effect => nil,
		:duration => nil,
		:message => "{1}'s weight increased!",
		:animation => :QUASH,
		:stats => {
			PBStats::DEFENSE => 1,
		}
	},
},
:BACKALLEY => {
	:name => "Backalley",
	:fieldMessage => [
		"Shifty eyes are all around..."
	],
	:graphic => ["CityNight"],
	:secretPower => "SMOG",
	:naturePower => :BEATUP,
	:mimicry => :STEEL,
	:damageMods => {
		1.5 => [:ICICLESPEAR,:BARBBARRAGE, :SPIKECANNON,:STEAMROLLER, :SPINOUT, :FLOWERTRICK, :BITTERBLADE, :NERVEPINCH, :SMOG, :BEATUP, :BOSSORDERS, :PAYDAY, :KOWTOWCLEAVE, :INFESTATION, :SPECTRALTHIEF, :FIRSTIMPRESSION, :TECHNOBLAST, :SHADOWSNEAK, :LUNGE, :PURSUIT,
			:XSCISSOR, :FURYCUTTER, :NIGHTSLASH, :SACREDSWORD, :AIRSLASH, :AERIALACE, :AIRCUTTER, :LEAFBLADE, :RAZORLEAF, :SLASH, :CUT, :CROSSPOISON, :PSYCHOCUT, :RAZORSHELL, :SOLARBLADE, :BEHEMOTHBLADE, :CEASELESSEDGE, :STONEAXE, :AQUACUTTER, :SLASHANDBURN, :HEXINGSLASH, :POPULATIONBOMB,
			:HORNATTACK, :FURYATTACK, :POISONSTING, :TWINEEDLE, :PINMISSILE, :PECK, :DRILLPECK, :MEGAHORN, :POISONJAB, :NEEDLEARM, :PLUCK, :DRILLRUN, :HORNLEECH, :FELLSTINGER, :SMARTSTRIKE, :BRANCHPOKE, :FALSESURRENDER, :GLACIALLANCE, :GILDEDARROW, :GILDEDHELIX, :QUICKSILVERSPEAR],
		1.2 => [:RAGEFIST],
	},
	:accuracyMods => {
		0 => [:SMOG, :POISONGAS],
	},
	:moveMessages => {
		"The power of science is amazing!" => [:TECHNOBLAST],
		"A crowd is gathering!" => [:BEATUP],
		"The city smog is suffocating!" => [:SMOG],
		"Careful on the street!" => [:STEAMROLLER,:SPINOUT],
		"Gotta make ends meet somehow..." => [:PAYDAY, :SPECTRALTHIEF, :SHADOWSNEAK, :FLOWERTRICK],
		"A frightening first impression!" => [:FIRSTIMPRESSION],
		"A knife glints in the dark!" => [:POPULATIONBOMB, :XSCISSOR, :FURYCUTTER, :BITTERBLADE, :NIGHTSLASH, :SACREDSWORD, :AIRSLASH, :AERIALACE, :AIRCUTTER, :KOWTOWCLEAVE, :LEAFBLADE, :RAZORLEAF, :SLASH, :CUT, :CROSSPOISON, :PSYCHOCUT, :RAZORSHELL, :SOLARBLADE, :BEHEMOTHBLADE, :CEASELESSEDGE, :STONEAXE, :AQUACUTTER, :SLASHANDBURN, :HEXINGSLASH],
		"Better watch your back..." => [:ICICLESPEAR,:BARBBARRAGE, :SPIKECANNON, :HORNATTACK, :FURYATTACK, :POISONSTING, :TWINEEDLE, :PINMISSILE, :PECK, :DRILLPECK, :MEGAHORN, :POISONJAB, :NEEDLEARM, :PLUCK, :DRILLRUN, :HORNLEECH, :FELLSTINGER, :SMARTSTRIKE, :BRANCHPOKE, :FALSESURRENDER, :GLACIALLANCE, :GILDEDARROW, :GILDEDHELIX, :QUICKSILVERSPEAR],
		"No witnesses, see!" => [:BOSSORDERS],
		"The assailant lurched forward!" => [:PURSUIT, :LUNGE],
		"Urban rage!" => [:RAGEFIST],
		"Bad touch!" => [:NERVEPINCH],
		"The attack drew from the city's power plants!" => [:ELECTROSHOT],
	},
	:typeMods => {
		:DARK => [:FIRSTIMPRESSION],
	},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:DARK],
		1.3 => [:POISON, :BUG, :STEEL],
		0.5 => [:FAIRY],
	},
	:typeMessages => {
		"Street rules!" => [:DARK],
		"The right tool for the job!" => [:STEEL],
		"In the cracks and the walls!" => [:BUG],
		"All kinds of pollution strengthened the attack!" => [:POISON],
		"This is no place for fairytales..." => [:FAIRY],
	},
	:typeCondition => {
		:DARK => "self.pbIsPhysical?(@type)",
	},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
		:CITY => [:UPROAR,:HYPERVOICE,:ECHOEDVOICE,:BOOMBURST],
	},
	:dontChangeBackup => [],
	:changeMessage => {
		"Cops! Everyone scatter!" => [:UPROAR,:HYPERVOICE,:ECHOEDVOICE,:BOOMBURST],
	},
	:statusMods => [:SMOKESCREEN, :NASTYPLOT, :PARTINGSHOT, :FAKETEARS, :POISONGAS, :SMOG, :TRICK, :SWITCHEROO, :CORROSIVEGAS, :SNATCH, :ELECTROSHOT],
	:changeEffects => {},
	:seed => {
		:seedtype => :SYNTHETICSEED,
		:effect => 0,
		:duration => 0,
		:message => "",
		:animation => nil,
		:stats => {
			PBStats::ATTACK => 1,
			PBStats::ACCURACY => 1,
		},
	},
},
:CITY => {
	:name => "City",
	:fieldMessage => [
		"The streets are busy..."
	],
	:graphic => ["GDCCentralSquare","City","GearenNew","GDCDreamDistrict","GDCDistrictOfHope","GDCJudicialDistrict","GDCScholarDistrict"],
	:secretPower => "SMOG",
	:naturePower => :SMOG,
	:mimicry => :NORMAL,
	:damageMods => {
		1.5 => [:STEAMROLLER, :SMOG, :BEATUP, :PAYDAY, :FIRSTIMPRESSION, :TECHNOBLAST, :SPINOUT],
		1.2 => [:RAGEFIST],
	},
	:accuracyMods => {
		0 => [:SMOG, :POISONGAS],
	},
	:moveMessages => {
		"The power of science is amazing!" => [:TECHNOBLAST],
		"A crowd is gathering!" => [:BEATUP],
		"The city smog is suffocating!" => [:SMOG],
		"Careful on the street!" => [:STEAMROLLER,:SPINOUT],
		"Working 9 to 5 for this!" => [:PAYDAY],
		"An overwhelming first impression!" => [:FIRSTIMPRESSION],
		"Urban rage!" => [:RAGEFIST],
		"The attack drew from the city's power plants!" => [:ELECTROSHOT],
	},
	:typeMods => {
	},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:NORMAL],
		1.3 => [:POISON, :BUG, :STEEL],
		0.7 => [:FAIRY],
	},
	:typeMessages => {
		"The hustle and bustle of the city!" => [:NORMAL],
		"The power of science is amazing!" => [:STEEL],
		"In the cracks and the walls!" => [:BUG],
		"All kinds of pollution strengthened the attack!" => [:POISON],
		"This is no place for fairytales..." => [:FAIRY],
	},
	:typeCondition => {
		:NORMAL => "self.pbIsPhysical?(@type)",
	},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
		:BACKALLEY => [:THIEF,:COVET,:PURSUIT,:BOSSORDERS],
	},
	:dontChangeBackup => [],
	:changeMessage => {
		"The criminal ran into a backalley!" => [:THIEF,:COVET,:PURSUIT],
		"Let's bring 'em onto our turf..." => [:BOSSORDERS],
	},
	:statusMods => [:SMOKESCREEN, :AUTOTOMIZE, :SHIFTGEAR, :POISONGAS, :SMOG, :RECYCLE, :CORROSIVEGAS, :ELECTROSHOT],
	:changeEffects => {},
	:seed => {
		:seedtype => :SYNTHETICSEED,
		:effect => 0,
		:duration => 0,
		:message => "",
		:animation => nil,
		:stats => {
			PBStats::ATTACK => 1,
			PBStats::ACCURACY => 1,
		},
	},
},
:ROSEGARDEN => {
	:name => "Rose Garden",
	:fieldMessage => [
		"Every rose has its thorn..."
	],
	:graphic => ["Gym1"],
	:secretPower => "POISONJAB",
	:naturePower => :LEAFTORNADO,
	:mimicry => :POISON,
	:damageMods => {
		1.5 => [:NEEDLEARM, :SPIKECANNON],
		1.3 => [:HORNATTACK, :FURYATTACK, :POISONSTING, :TWINEEDLE, :PINMISSILE,
    			:PECK, :DRILLPECK, :MEGAHORN, :POISONJAB, :NEEDLEARM, :PLUCK,
    			:DRILLRUN, :HORNLEECH, :FELLSTINGER, :SMARTSTRIKE, :BRANCHPOKE,
    			:FALSESURRENDER, :GLACIALLANCE, :GILDEDARROW, :GILDEDHELIX, :QUICKSILVERSPEAR],
		1.2 => [:VINEWHIP,:RAZORLEAF,:POWERWHIP,:FLOWERTRICK,:FRENZYPLANT,:LEAFBLADE,:MAGICALLEAF,:LEAFTORNADO,:LEAFDARTS],
	},
	:moveMessages => {
		"Deadly thorns pierce the target!" => [:NEEDLEARM],
		"The attack is imbued with thorns!" => [:VINEWHIP,:RAZORLEAF,:POWERWHIP,:FLOWERTRICK,:FRENZYPLANT,:LEAFBLADE,:MAGICALLEAF,:LEAFTORNADO],
		"Stabbed by a sharpened thorn!" => [:HORNATTACK, :FURYATTACK, :POISONSTING, :TWINEEDLE, :PINMISSILE,
    										:PECK, :DRILLPECK, :MEGAHORN, :POISONJAB, :NEEDLEARM, :PLUCK,
    										:DRILLRUN, :HORNLEECH, :FELLSTINGER, :SMARTSTRIKE, :BRANCHPOKE,
    										:FALSESURRENDER, :GLACIALLANCE, :GILDEDARROW, :GILDEDHELIX, :QUICKSILVERSPEAR],
	},
	:typeAddOns => {
	},
	:typeMods => {
		:POISON => [:VINEWHIP,:RAZORLEAF,:POWERWHIP,:FLOWERTRICK,:FRENZYPLANT,:LEAFBLADE,:MAGICALLEAF,:LEAFTORNADO,:LEAFDARTS],
	},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:POISON],
		1.3 => [:GRASS],
	},
	:typeMessages => {
		"The attack is strengthened by the surrounding thorns!" => [:POISON],
		"The attack is boosted by the garden!" => [:GRASS],
	},
	:typeEffects => {},
	:changeCondition => {},
	:dontChangeBackup => [],
	:statusMods => [:GROWTH, :FLOWERSHIELD, :INGRAIN],
	:changeEffects => {},
	:seed => {
		:seedtype => :SYNTHETICSEED,
		:effect => :Ingrain,
		:duration => true,
		:message => "{1} planted its roots.",
		:animation => :INGRAIN,
		:stats => {
			PBStats::SPDEF => 1,
		},
	},
},
:MIDNIGHT => {
	:name => "Midnight Field",
	:fieldMessage => [
		"The sky is pitch black."
	],
	:graphic => ["CaveDarker"],
	:secretPower => "NIGHTSLASH",
	:naturePower => :DARKPULSE,
	:mimicry => :DARK,
	:damageMods => {
		1.5 => [:DARKMATTER, :POWERGEM, :LUSTERPURGE, :AURORABEAM, :SIGNALBEAM,
    			:FLASHCANNON, :MIRRORSHOT, :DAZZLINGGLEAM, :MOONBLAST,
    			:LIGHTBURST, :LIGHTNINGSTRIKE,:FIREWORKS, :SWIFT],
		1.3 => [:PHANTOMGRIP,:SHADOWCLAW,:SNARL],
	},
	:moveMessages => {
		"Darker than dark." => [:DARKMATTER],
		"Blinding in the darkness!" => [:POWERGEM, :LUSTERPURGE, :AURORABEAM, :SIGNALBEAM,
    								:FLASHCANNON, :MIRRORSHOT, :DAZZLINGGLEAM, :MOONBLAST,
    								:LIGHTBURST, :LIGHTNINGSTRIKE,:FIREWORKS, :SWIFT],
		"Terrifying in the darkness..." => [:PHANTOMGRIP,:SHADOWCLAW,:SNARL],
	},
	:typeAddOns => {
	},
	:typeMods => {
	},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:DARK],
	},
	:typeMessages => {
		"Darkness envelops the attack." => [:DARK],
	},
	:typeEffects => {},
	:changeCondition => {},
	:dontChangeBackup => [],
	:statusMods => [:NASTYPLOT, :HONECLAWS, :SPOTLIGHT, :MOONLIGHT, :SCARYFACE],
	:changeEffects => {},
	:seed => {
		:seedtype => :TELLURICSEED,
		:effect => nil,
		:duration => nil,
		:message => "{1} shines with a brilliant light!",
		:animation => nil,
		:stats => {
			PBStats::ATTACK => 1,
		},
	},
	:overlay => {
		:damageMods => {
			1.3 => [:POWERGEM, :LUSTERPURGE, :AURORABEAM, :SIGNALBEAM,
					:FLASHCANNON, :MIRRORSHOT, :DAZZLINGGLEAM, :MOONBLAST,
					:LIGHTBURST, :LIGHTNINGSTRIKE,:FIREWORKS, :SWIFT,:PHANTOMGRIP,:SHADOWCLAW,:SNARL],
		},
		:typeMods => {
		},
		:moveMessages => {
		"Blinding in the darkness!" => [:POWERGEM, :LUSTERPURGE, :AURORABEAM, :SIGNALBEAM,
    									:FLASHCANNON, :MIRRORSHOT, :DAZZLINGGLEAM, :MOONBLAST,
    									:LIGHTBURST, :LIGHTNINGSTRIKE,:FIREWORKS, :SWIFT],
		"Terrifying in the darkness..." => [:PHANTOMGRIP,:SHADOWCLAW,:SNARL],
		},
		:typeBoosts => {
			1.3 => [:DARK],
		},
		:typeMessages => {
			"Darkness envelops the attack." => [:DARK],
		},
		:typeCondition => {
		},
		:statusMods => [:HONECLAWS,:SCARYFACE],
	},
},
:OASIS => {
	:name => "Oasis",
	:fieldMessage => [
		"A humid respite from the hot desert..."
	],
	:graphic => ["Gym4"],
	:secretPower => "SANDTOMB",
	:naturePower => :INFESTATION,
	:mimicry => :GROUND,
	:damageMods => {
		1.5 => [:SCALD, :DIG, :DUSTYDASH, :SCORCHINGSANDS],
		2 => [:SANDTOMB, :MUDSLAP, :INFESTATION],
	},
	:moveMessages => {
		"The desert strengthened the attack!" => [:SCALD, :SANDTOMB, :MUDSLAP, :DIG, :DUSTYDASH, :SCORCHINGSANDS],
		"A swarm attacks!" => [:INFESTATION],
	},
	:typeAddOns => {
	},
	:typeMods => {
	},
	:moveEffects => {},
	:typeBoosts => {
		1.3 => [:BUG, :GRASS, :WATER],
	},
	:typeMessages => {
		"The attack is strengthened by flourishing life!" => [:BUG, :GRASS],
		"The water strengthened the attack!" => [:WATER],
	},
	:typeCondition => {
		:WATER => "!opponent.hasType?(:GROUND)",
	},
	:typeEffects => {},
	:changeCondition => {},
	:dontChangeBackup => [],
	:statusMods => [:GROWTH, :ROTOTILLER, :COIL],
	:changeEffects => {},
	:seed => {
		:seedtype => :ELEMENTALSEED,
		:duration => true,
		:message => "{1} gained Water-type resistances!",
		:animation => :SOAK,
		:stats => {
			PBStats::SPDEF => 1,
		},
	},
},
}