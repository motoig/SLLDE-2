class PokeBattle_AI
	def chooseAction
		for index in 0...@aimondata.length #for every battler
			next if @aimondata[index].nil?
			next if @battle.pbOwnedByPlayer?(index) && !@battle.controlPlayer
			battler = @battle.battlers[index]
			next if battler.hp == 0 || !@battle.pbCanShowCommands?(index)
			next if @battle.choices[battler.index][0] != 0
			@mondata = @aimondata[index]
			#make move-targets coupled list bc that works way easier ?
			@mondata.scorearray.map! {|scorelist| scorelist.map! {|score| score < 0 ? -1 : score}}
			#make list of moves, targets, and scores, # structured [moveindex, [target(s)], score, isZmove?]
			chooseablemoves = findChoosableMoves(battler,@mondata)


			chooseablemoves = chooseablemoves.find_all {|arrays| arrays[:score] >= 0}
			#dealing with mon that can't even choose fight menu
			if !@battle.pbCanShowCommands?(battler.index)
				@battle.pbAutoChooseMove(battler.index)
				next
			end

			if chooseablemoves.length !=0
				maxmovescore = chooseablemoves.max {|a1,a2| a1[:score]<=>a2[:score]}[:score] rescue 0
			else
				maxmovescore = 0
			end
			#chooses the action that the AI pokemon will perform
			#SWITCH
			if @mondata.shouldswitchscore > maxmovescore && @mondata.switchscore.max > 100 #arbitrary
				if battler.index==3 && @battle.choices[1][0]==2 && @battle.choices[1][1] == @mondata.switchscore.index(@mondata.switchscore.max)
					if @mondata.switchscore.max(2)[1] > 100 && shouldHardSwitch?(battler,@mondata.switchscore.index(@mondata.switchscore.max(2)[1]))
						indexhighestscore = @mondata.switchscore.index(@mondata.switchscore.max(2)[1])
						PBDebug.log(sprintf("Switching to %s",getMonName(@battle.pbParty(battler.index)[indexhighestscore].species))) if $INTERNAL
						$ai_log_data[battler.index].chosen_action = sprintf("Switching to %s",getMonName(@battle.pbParty(battler.index)[indexhighestscore].species))
						@battle.pbRegisterSwitch(battler.index,indexhighestscore)
						next
					end
				elsif shouldHardSwitch?(battler,@mondata.switchscore.index(@mondata.switchscore.max))
					indexhighestscore = @mondata.switchscore.index(@mondata.switchscore.max)
					PBDebug.log(sprintf("Switching to %s",getMonName(@battle.pbParty(battler.index)[indexhighestscore].species))) if $INTERNAL
					$ai_log_data[battler.index].chosen_action = sprintf("Switching to %s",getMonName(@battle.pbParty(battler.index)[indexhighestscore].species))
					@battle.pbRegisterSwitch(battler.index,indexhighestscore)
					next
				end
			end

			#USE ITEM
			if !@mondata.itemscore.empty? && @mondata.itemscore.values.max > maxmovescore
				item = @mondata.itemscore.key(@mondata.itemscore.values.max)
				#check if quantity of item the battler has is 1 and if previous battler hasn't also tried to use this item
				if battler.index==3 && @battle.choices[1][0]==3 && @battle.choices[1][1]==item
					items=@battle.pbGetOwnerItems(battler.index)
					if items.count {|element| element==item} > 1
						@battle.pbRegisterItem(battler.index,item)
						$ai_log_data[battler.index].chosen_action = sprintf("Using Item %s", getItemName(item))
						next
					end
				else
					@battle.pbRegisterItem(battler.index,item)
					$ai_log_data[battler.index].chosen_action = sprintf("Using Item %s", getItemName(item))
					next
				end
			end

			if !@battle.pbCanShowCommands?(battler.index) || (0..3).none? {|number| @battle.pbCanChooseMove?(battler.index,number,false)}
				@battle.pbAutoChooseMove(battler.index)
				next
			end
			#MEGA+BURST
			if @aimondata[index].shouldMegaOrUltraBurst
				@battle.pbRegisterMegaEvolution(index) if @battle.pbCanMegaEvolve?(index)
				@battle.pbRegisterUltraBurst(index) if @battle.pbCanUltraBurst?(index)
			end

			#MOVE
			canusemovelist = []
			for moveindex in 0...battler.moves.length
				canusemovelist.push(moveindex) if @battle.pbCanChooseMove?(battler.index,moveindex,false)
			end
			if chooseablemoves.length==0 && canusemovelist.length > 0
				@battle.pbRegisterMove(battler.index,canusemovelist[rand(canusemovelist.length)],false)
				@battle.pbRegisterTarget(battler.index,battler.pbOppositeOpposing.index) if @battle.doublebattle
				$ai_log_data[battler.index].chosen_action = "Random Move bc only bad decisions"
				next
			elsif chooseablemoves.length==0
				@battle.pbAutoChooseMove(battler.index)
			end
			# Minmax choices depending on AI
			if  @mondata.skill>=MEDIUMSKILL
				threshold=(@mondata.skill>=BESTSKILL) ? 1.5 : (@mondata.skill>=HIGHSKILL) ? 2 : 3
				newscore=(@mondata.skill>=BESTSKILL) ? 5 : (@mondata.skill>=HIGHSKILL) ? 10 : 15
				for scoreindex in 0...chooseablemoves.length
					chooseablemoves[scoreindex][:score] = chooseablemoves[scoreindex][:score] > newscore && chooseablemoves[scoreindex][:score]*threshold<maxmovescore ? newscore : chooseablemoves[scoreindex][:score]
				end
			end

			#Log the move scores in debuglog
			if $INTERNAL
				x="[#{battler.pbThis}: "
				j=0
				for i in 0...4
					next if battler.moves[i].nil?
					x+=", " if j>0
					movelistscore = [@mondata.scorearray[0][i], @mondata.scorearray[1][i], @mondata.scorearray[2][i], @mondata.scorearray[3][i]]
					x+=battler.moves[i].name+"="+movelistscore.to_s
					j+=1
				end
				x+="]"
				PBDebug.log(x)
				$stdout.print(x); $stdout.print("\n")
			end

			preferredMoves = []
			for i in chooseablemoves
				if  (i[:score] >= (maxmovescore* 0.95))
					#preferredMoves.push(i)
					preferredMoves.push(i) if i[:score]==maxmovescore # Doubly prefer the best move
				end
			end
			
			chosen=preferredMoves[0]
			if chosen[:zmove]
				PBDebug.log("[Prefer "+battler.zmoves[chosen[:moveindex]].name+"]") if $INTERNAL
				$ai_log_data[battler.index].chosen_action = "[Prefer "+battler.zmoves[chosen[:moveindex]].name+"]"
			else
				PBDebug.log("[Prefer "+battler.moves[chosen[:moveindex]].name+"]") if $INTERNAL
				$ai_log_data[battler.index].chosen_action = "[Prefer "+battler.moves[chosen[:moveindex]].name+"]"
			end
			@battle.pbRegisterZMove(battler.index) if chosen[:zmove]==true #if chosen move is a z-move
			@battle.pbRegisterMove(battler.index,chosen[:moveindex],false)
			@battle.pbRegisterTarget(battler.index,chosen[:target][0]) if @battle.doublebattle
		end
	end
end