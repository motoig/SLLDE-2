# convert_townmap.rb
# Usage: ruby convert_townmap.rb townmap.txt townmap.rb

require "pp"

input_file  = ARGV[0] || "townmap.txt"
output_file = ARGV[1] || "townmap.rb"

maps = {}
current_id = nil
current_name = nil
current_filename = nil
current_points = {}

File.readlines(input_file, chomp: true).each do |line|
  line.strip!
  next if line.empty? || line.start_with?("#")

  if line =~ /^\[(\d+)\]$/
    # Save previous block if present
    if current_id
      maps[current_id] = {
        :name     => current_name,
        :filename => current_filename,
        :points   => current_points
      }
    end
    # Start new block
    current_id = $1.to_i
    current_name = nil
    current_filename = nil
    current_points = {}
  elsif line =~ /^Name=(.+)$/
    current_name = $1.strip
  elsif line =~ /^Filename=(.+)$/
    current_filename = $1.strip
  elsif line =~ /^Point=(.+)$/
    data = $1.split(",").map(&:strip)
    x, y = data[0].to_i, data[1].to_i
    name = data[2] || ""
    poi  = data[3] || ""
    fly  = data[4..6].compact.map(&:to_i)

    # flyData is [] if no numbers present
    fly_data = fly.empty? ? [] : fly

    current_points[[x, y]] = {
      :name     => name,
      :poi      => poi,
      :flyData  => fly_data
    }
  end
end

# Save last block
if current_id
  maps[current_id] = {
    :name     => current_name,
    :filename => current_filename,
    :points   => current_points
  }
end

File.open(output_file, "w") do |f|
  f.puts "TOWNMAP = {"
  maps.each do |id, data|
    f.puts "  #{id} => {"
    f.puts "    :name => #{data[:name].inspect},"
    f.puts "    :filename => #{data[:filename].inspect},"
    f.puts "    :points => {"
    data[:points].each do |coords, pdata|
      f.puts "      #{coords.inspect} => {"
      f.puts "        :name => #{pdata[:name].inspect},"
      f.puts "        :poi => #{pdata[:poi].inspect},"
      f.puts "        :flyData => #{pdata[:flyData].inspect}, # mapid, x, y"
      f.puts "      },"
    end
    f.puts "    }"
    f.puts "  },"
  end
  f.puts "}"
end

puts "Conversion complete! Wrote #{output_file}"