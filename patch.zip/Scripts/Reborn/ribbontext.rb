RIBBONHASH = {
:FIRSTGYM => {
    :id => "FIRSTGYM",
    :name => "First Gym Victor",
    :desc => "Awarded for beating Donna in Serpentine City.",
  },
:SECONDGYM => {
    :id => "SECONDGYM",
    :name => "Second Gym Victor",
    :desc => "Awarded for beating Damon in Crestlight City.",
  },
:THIRDGYM => {
    :id => "THIRDGYM",
    :name => "Third Gym Victor",
    :desc => "Awarded for beating Electra in Rustbolt City.",
  },
:FOURTHGYM => {
    :id => "FOURTHGYM",
    :name => "Fourth Gym Victor",
    :desc => "Awarded for beating Dustin in Goldune City.",
  },
:FIFTHGYM => {
    :id => "FIFTHGYM",
    :name => "Fifth Gym Victor",
    :desc => "Awarded for beating Amber in Highpoint City.",
  },
:SIXTHGYM => {
    :id => "SIXTHGYM",
    :name => "Sixth Gym Victor",
    :desc => "Awarded for beating Bailley in Greenpine City.",
  },
:SEVENTHGYM => {
    :id => "SEVENTHGYM",
    :name => "Seventh Gym Victor",
    :desc => "Awarded for beating Alice in Subnail City.",
  },
:EIGHTHGYM => {
    :id => "EIGHTH",
    :name => "Eighth Gym Victor",
    :desc => "Awarded for beating Wade in Waytide City.",
  },
:SUPERCOMPUTER => {
    :id => "SUPERCOMPUTER",
    :name => "Supercomputer",
    :desc => "Moves ignore immunities, cannot miss, and do not cause self recoil or stat drops.",
  },
:WELLTRIMMED => {
    :id => "WELLTRIMMED",
    :name => "Well-Trimmed",
    :desc => "Grants resistance to user's Hidden Power type. Sp. Atk scales off of Sp. Def.",
  },
:SNOWDRIFT => {
    :id => "SNOWDRIFT",
    :name => "Snowdrift",
    :desc => "Grants the effects of Hail for itself and the whole field.",
  },
:SCENTSPREADER => {
    :id => "SCENTSPREADER",
    :name => "Scent-Spreader",
    :desc => "Change type and Poison moves depending on what Incense it holds.",
  },
:HASTYESCAPE => {
    :id => "HASTYESCAPE",
    :name => "Hasty Escape",
    :desc => "The move in the first moveslot functions as a pivot move.",
  },

}