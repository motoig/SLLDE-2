  MAPCONNECTIONSHASH = {
  162 => { # Route 10 B
    :connections => [
      [162, "West", 0, 159, "East", 21] # to Rainbow Reef
    ],
  },

  158 => { # Route 10 A
    :connections => [
      [158, "East", 0, 159, "West", 0] # to Rainbow Reef
    ],
  },

  163 => { # Coralite Town
    :connections => [
      [163, "North", 0, 162, "South", 18] # to Route 10 B
    ],
  },

  73 => { # Cycling Path
    :connections => [
      [73, "South", 0, 188, "North", 0] # to Cycling Path
    ],
  },

  195 => { # Route 15
    :connections => [
      [195, "East", 0, 194, "West", 12] # to Greenpine City
    ],
  },

  221 => { # Route 17
    :connections => [
      [221, "West", 0, 220, "East", 37] # to Route 16
    ],
  },

  222 => { # Sario Town
    :connections => [
      [222, "West", 1, 221, "East", 0] # to Route 17
    ],
  },

  69 => { # Route 4
    :connections => [
      [69, "North", 20, 71, "South", 0] # to Cycling Path
    ],
  },

  226 => { # Subhail Icecaps
    :connections => [
      [226, "West", 10, 225, "East", 0] # to Subhail City
    ],
  },

  136 => { # Route 8
    :connections => [
      [136, "North", 0, 137, "South", 52] # to Route 9
    ],
  },

  282 => { # Addition
    :connections => [
      [282, "West", 8, 104, "East", 0] # to Orshore Town
    ],
  },

  112 => { # Battle Bridge
    :connections => [
      [112, "West", 0, 104, "East", 7] # to Orshore Town
    ],
  },

  103 => { # Route 5
    :connections => [
      [103, "East", 0, 104, "West", 9] # to Orshore Town
    ],
  },

  112 => { # Battle Bridge
    :connections => [
      [112, "North", 0, 282, "South", 0] # to Addition
    ],
  },

  113 => { # Docking Port
    :connections => [
      [113, "North", 0, 112, "South", 53] # to Battle Bridge
    ],
  },

  136 => { # Route 8
    :connections => [
      [136, "South", 0, 112, "North", 57] # to Battle Bridge
    ],
  },

  120 => { # Route 6
    :connections => [
      [120, "West", 35, 121, "East", 0] # to Route 7
    ],
  },

  135 => { # Mount Highpoint
    :connections => [
      [135, "South", 21, 123, "North", 0] # to Highpoint City
    ],
  },

  238 => { # Route 12
    :connections => [
      [238, "North", 0, 265, "South", 0] # to Addition
    ],
  },

  235 => { # Route 11
    :connections => [
      [235, "East", 8, 265, "West", 0] # to Addition
    ],
  },

  178 => { # Sailport Town
    :connections => [
      [178, "West", 6, 238, "East", 0] # to Route 12
    ],
  },

  235 => { # Route 11
    :connections => [
      [235, "East", 23, 238, "West", 0] # to Route 12
    ],
  },

  185 => { # Route 13
    :connections => [
      [185, "North", 0, 189, "South", 20] # to Ancient Pass
    ],
  },

  185 => { # Route 13
    :connections => [
      [185, "South", 0, 178, "North", 15] # to Sailport Town
    ],
  },

  223 => { # Route 18
    :connections => [
      [223, "North", 0, 214, "South", 1] # to Snowpeak Village
    ],
  },

  15 => { # Serpentine City
    :connections => [
      [15, "North", 10, 149, "South", 0] # to Serpentine Garden
    ],
  },

  298 => { # Route 19
    :connections => [
      [298, "North", 62, 280, "South", 0] # to Route 21
    ],
  },

  298 => { # Route 19
    :connections => [
      [298, "West", 1, 1, "East", 0] # to Soltree Town
    ],
  },

  7 => { # Route 1
    :connections => [
      [7, "East", 0, 1, "West", 0] # to Soltree Town
    ],
  },

  8 => { # Mossy Town
    :connections => [
      [8, "East", 0, 1, "West", 40] # to Soltree Town
    ],
  },

  8 => { # Mossy Town
    :connections => [
      [8, "North", 7, 7, "South", 0] # to Route 1
    ],
  },

  227 => { # Victory Isle
    :connections => [
      [227, "East", 17, 138, "West", 0] # to Waytide City
    ],
  },

  306 => { # Addition
    :connections => [
      [306, "East", 0, 227, "West", 60] # to Victory Isle
    ],
  },

  53 => { # Rustbolt City
    :connections => [
      [53, "North", 47, 303, "South", 0], # to Rustbolt Landfill
      [53, "West", 14, 304, "East", 0] # to Addition
    ],
  },

  318 => { # Route 18
    :connections => [
      [318, "North", 0, 319, "South", 1] # to Snowpeak Village
    ],
  },

  328 => { # Route 17
    :connections => [
      [328, "West", 0, 327, "East", 37] # to Route 16
    ],
  },

  270 => { # Sario Town Showdown
    :connections => [
      [270, "West", 1, 328, "East", 0] # to Route 17
    ],
  },
  }
