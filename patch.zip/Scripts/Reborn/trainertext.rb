TEAMARRAY = [
  {
    :teamid => ["Kathinka", :﻿ACETRAINER_Female,1, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BLIZZIBAT,
        :level => 56,
        :item => :EJECTBUTTON,
        :ability => "",
        :nature => :TIMID,
        :moves => [:BOOMBURST, :ENERGYBALL, :ICESHARD, :AURORAVEIL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ROCKSTER,
        :level => 59,
        :item => :RINDOBERRY,
        :ability => "",
        :nature => :BRAVE,
        :moves => [:JETPUNCH, :DIAMONDCLAW, :ICEPUNCH, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Kathinka", :ACETRAINER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :TIKITOKO,
        :level => 59,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :TIMID,
        :moves => [:GRASSKNOT, :GRASSKNOT, :GRASSKNOT, :GRASSKNOT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Uma", :ACETRAINER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :MELOTWEET,
        :level => 60,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BOULDOISE,
        :level => 60,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :COCOROCKO,
        :level => 60,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Daphne", :ACETRAINER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :FAYEGON,
        :level => 47,
        :item => :LEFTOVERS,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:DRAGONDANCE, :EARTHQUAKE, :DRAGONCLAW, :PLAYROUGH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Fortesa", :ACETRAINER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PUPYRO,
        :level => 50,
        :item => :HEATROCK,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:SOLARCLAW, :PLAYROUGH, :WILLOWISP, :EARTHPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LAVENRINA,
        :level => 50,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:ENERGYBALL, :MOONBLAST, :DUSTYDASH, :GROWTH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SIGNILEAF,
        :level => 50,
        :item => :OCCABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:ENERGYBALL, :THUNDERBOLT, :SUNNYDAY, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FLAPINKO,
        :level => 50,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:WEATHERBALL, :HYPERVOICE, :SQUALLBLOW, :SCALD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DARTOAD,
        :level => 50,
        :item => :LIFEORB,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:LEAFDARTS, :GUNKSHOT, :ENERGYBALL, :SCALD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Gesine", :ACETRAINER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :WINGON,
        :level => 45,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:ROCKCLIMB, :DRAGONCLAW, :RAZORBLADE, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FYANT,
        :level => 45,
        :item => :COBABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:BUGBUZZ, :FLAMETHROWER, :GIGADRAIN, :EARTHPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Marin", :ACETRAINER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :FINFLIX,
        :level => 37,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MERKID,
        :level => 37,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Erin", :ACETRAINER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :HIPPOTONE,
        :level => 45,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GROILLA,
        :level => 45,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Polly", :ACETRAINER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PSYFLOCK,
        :level => 42,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:PSYSHOCK, :SQUALLBLOW, :ICYWIND, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GIRAFLAME,
        :level => 42,
        :item => :CHARCOAL,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HEATWAVE, :HYPERVOICE, :ENERGYBALL, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CRYSCOON,
        :level => 42,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:BLIZZARD, :BUGBUZZ, :DAZZLINGGLEAM, :ELECTROWEB],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Mats", :ACETRAINER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ATOMOTRIX,
        :level => 62,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :JEWELTAL,
        :level => 62,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BULKER,
        :level => 62,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Ford", :ACETRAINER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BRACHIO,
        :level => 50,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :BRAVE,
        :moves => [:EARTHPOWER, :ENERGYBALL, :AQUATAIL, :IRONTAIL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ECOBUZZ,
        :level => 50,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SUNNYDAY, :SOLARBEAM, :THUNDERBOLT, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SPONY,
        :level => 50,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:SEEDBOMB, :EARTHQUAKE, :JUMPKICK, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rylie", :ACETRAINER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ROOBEOP,
        :level => 42,
        :item => :COBABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:EARTHQUAKE, :DRAINPUNCH, :THUNDERPUNCH, :ICEPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PLATYPLASH,
        :level => 42,
        :item => :RINDOBERRY,
        :ability => "",
        :nature => :BRAVE,
        :moves => [:AQUATAIL, :EARTHPOWER, :ICEPUNCH, :STONEEDGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GRIZZLER,
        :level => 42,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:FIREPUNCH, :DRAINPUNCH, :THUNDERPUNCH, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Louie", :ACETRAINER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :MERKID,
        :level => 37,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FINFLIX,
        :level => 37,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Fynn", :ACETRAINER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :TAPIBLAZE,
        :level => 45,
        :item => :AIRBALLOON,
        :ability => "",
        :nature => :MODEST,
        :moves => [:HEATWAVE, :SLUDGEBOMB, :EARTHPOWER, :GIGADRAIN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ELESTOMP,
        :level => 45,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:EARTHQUAKE, :ROCKSLIDE, :PHANTOMGRIP, :GUNKSHOT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Zachary", :ACETRAINER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :TIKITOKO,
        :level => 49,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:LEAFSTORM, :OVERHEAT, :EARTHPOWER, :THUNDERBOLT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Kalle", :ACETRAINER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :CHAMELECTRO,
        :level => 60,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :HYDROGON,
        :level => 60,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TAPIBLAZE,
        :level => 60,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Dario", :ACETRAINER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :STRIKON,
        :level => 46,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:AIRSLASH, :THUNDERBOLT, :HEATWAVE, :VACUUMWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DROOT,
        :level => 46,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:BULLETSEED, :DRAGONCLAW, :EARTHQUAKE, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PINKMEE,
        :level => 46,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:HYDROPUMP, :ICEBEAM, :PSYCHIC, :RECOVER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FAYELY,
        :level => 46,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:DRAGONCLAW, :PLAYROUGH, :DRAGONDANCE, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SERPYRO,
        :level => 46,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :TIMID,
        :moves => [:FLAMETHROWER, :SLUDGEBOMB, :EARTHPOWER, :DUSTYDASH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Irina", :ACETRAINER_Snow_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :AVALDEER,
        :level => 54,
        :item => :ICEGEM,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:GLACIERCRASH, :DOUBLEEDGE, :JUMPKICK, :PLAYROUGH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ISEALCLE,
        :level => 54,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:MEGALOFANG, :ICICLECRASH, :CRUNCH, :AQUAJET],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BLIMPOON,
        :level => 54,
        :item => :OCCABERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:FLASHCANNON, :SQUALLBLOW, :HEATWAVE, :AIRCANNON],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Yara", :ACETRAINER_Snow_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BLIZZIBAT,
        :level => 55,
        :item => :ENIGMABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HYPERVOICE, :SLUDGEWAVE, :ENERGYBALL, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Michonne", :ACETRAINER_Snow_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :AVALDEER,
        :level => 52,
        :item => :NORMALGEM,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:DOUBLEEDGE, :ICICLECRASH, :PLAYROUGH, :MEGAHORN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BUDSOAR,
        :level => 52,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HYPERVOICE, :HEATWAVE, :FLASHCANNON, :SQUALLBLOW],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :HUSKOLD,
        :level => 52,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:GLACIERCRASH, :PLAYROUGH, :CRACKLESLAM, :IRONTAIL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Sasha", :ACETRAINER_Snow_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :CRYSCOON,
        :level => 48,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PUFFPEAK,
        :level => 48,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SUBEARO,
        :level => 48,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Glenn", :ACETRAINER_Snow_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :AVALDEER,
        :level => 47,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PINGLETT,
        :level => 47,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SNOWRONG,
        :level => 47,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Tyreese", :ACETRAINER_Snow_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :HUSKPUP,
        :level => 54,
        :item => :LIGHTCLAY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:AURORAVEIL, :ICICLECRASH, :CRUNCH, :THUNDERFANG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MOOFORK,
        :level => 54,
        :item => :NORMALGEM,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:DOUBLEEDGE, :GLACIERCRASH, :PLAYROUGH, :WILDCHARGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SNOWLOW,
        :level => 54,
        :item => :LIFEORB,
        :ability => "",
        :nature => :MODEST,
        :moves => [:BLIZZARD, :SHADOWBALL, :FREEZEDRY, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CRYSILLA,
        :level => 54,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:BLIZZARD, :BUGBUZZ, :ELECTROWEB, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Raheem", :ACETRAINER_Snow_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :NAWALE,
        :level => 55,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:RAINDANCE, :GLACIERCRASH, :LIQUIDATION, :SACREDSWORD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Roberto", :ACETRAINER_Snow_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :RINOTIC,
        :level => 54,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GIGLOO,
        :level => 54,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Cathy", :AROMALADY, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PIXILILY,
        :level => 42,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BUSHUP,
        :level => 42,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LAVENRINA,
        :level => 42,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Fabrice", :AROMALADY, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BUSHAIRY,
        :level => 31,
        :item => :OCCABERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:GIGADRAIN, :HIDDENPOWER, :SYNTHESIS, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LAVENRINA,
        :level => 31,
        :item => :COBABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:MOONBLAST, :ENERGYBALL, :DUSTYDASH, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Shirley", :AROMALADY, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ECOBUZZ,
        :level => 23,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:SUNNYDAY, :GIGADRAIN, :LIGHTNINGSTRIKE, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SPONY,
        :level => 23,
        :item => :OCCABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:DOUBLEKICK, :SEEDBOMB, :BULLDOZE, :ZENHEADBUTT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :WOODBEAK,
        :level => 23,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:BULLETSEED, :PLUCK, :DRILLRUN, :STEELWING],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Elliot", :AROMALADY, 0],
    :defeat => "",
    :mons => [
      {
        :species => :HORSHUSH,
        :level => 21,
        :item => :LEFTOVERS,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:RAZORLEAF, :DOUBLEKICK, :SYNTHESIS, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Shirley", :AROMALADY,1, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ECOBUZZ,
        :level => 36,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :HORSHUSH,
        :level => 36,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :KAHULA,
        :level => 36,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Abigail", :BACKPACKER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :TIKITIK,
        :level => 49,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SOLARBEAM, :FLAMETHROWER, :EARTHPOWER, :THUNDERBOLT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PHOXIVEN,
        :level => 49,
        :item => :LIFEORB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HYPERVOICE, :MYSTICALFIRE, :ICEBEAM, :THUNDERBOLT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :HIPPOTONE,
        :level => 49,
        :item => :RINDOBERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:EARTHQUAKE, :MEGALOFANG, :ICEFANG, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Kimberly", :BACKPACKER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BLITZIGLOW,
        :level => 45,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :TIMID,
        :moves => [:FLAMETHROWER, :THUNDERBOLT, :ENERGYBALL, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :COUNTULA,
        :level => 45,
        :item => :FLYINGGEM,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:ACROBATICS, :CRUNCH, :ZENHEADBUTT, :DRAININGKISS],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GOLEMO,
        :level => 45,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:STONEEDGE, :DRAINPUNCH, :EARTHQUAKE, :THUNDERPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Sora", :BACKPACKER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SANDSTER,
        :level => 27,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:DARKPULSE, :EARTHPOWER, :HEATWAVE, :SHADOWBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MOOSTONE,
        :level => 27,
        :item => :CHOPLEBERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:TAKEDOWN, :ROCKSLIDE, :BULLDOZE, :ZENHEADBUTT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Trudie", :BACKPACKER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :IRIMP,
        :level => 30,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:FLASHCANNON, :SQUALLBLOW, :SIGNALBEAM, :ICYWIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ATOMOTRIX,
        :level => 30,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:FLASHCANNON, :DISCHARGE, :EARTHPOWER, :FREEZEDRY],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DINOMITE,
        :level => 30,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:DRAINPUNCH, :ROCKSLIDE, :ICEPUNCH, :IRONTAIL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rosita", :BACKPACKER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :AURORAI,
        :level => 51,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:THUNDERBOLT, :ICEBEAM, :ENERGYBALL, :DUSTYDASH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DEERFERNO,
        :level => 51,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:BLAZEKICK, :TAKEDOWN, :JUMPKICK, :CRUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CHAMELECTRO,
        :level => 51,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:THUNDERBOLT, :FLAMETHROWER, :SLUDGEBOMB, :FLASHCANNON],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Diana", :BACKPACKER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BOULDOX,
        :level => 26,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:ROCKSLIDE, :CROSSPOISON, :IRONHEAD, :PINMISSILE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GOLEMO,
        :level => 26,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:ROCKSLIDE, :BRICKBREAK, :WILDCHARGE, :ICEPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Kara", :BACKPACKER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BARBVIRAL,
        :level => 33,
        :item => :LEFTOVERS,
        :ability => "",
        :nature => :CAREFUL,
        :moves => [:TOXIC, :SPIKYSHIELD, :DRILLRUN, :IRONDEFENSE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Stella", :BACKPACKER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PURRYO,
        :level => 35,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :TIMID,
        :moves => [:EARTHPOWER, :FLAMETHROWER, :CRACKLESLAM, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BLITZIGLOW,
        :level => 35,
        :item => :CHARTIBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:FLAMETHROWER, :ENERGYBALL, :THUNDERBOLT, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :REXITE,
        :level => 35,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:ROCKSLIDE, :HEATCRASH, :THUNDERFANG, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Pamela", :BACKPACKER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :GWORM,
        :level => 21,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Nora", :BACKPACKER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :TERRAZ,
        :level => 20,
        :item => "",
        :ability => "",
        :nature => :TIMID,
        :moves => [:PARABOLICCHARGE, :AIRCUTTER, :MIRRORSHOT, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :NIMBLOW,
        :level => 20,
        :item => "",
        :ability => "",
        :nature => :MODEST,
        :moves => [:WATERPULSE, :LIGHTNINGSTRIKE, :GUST, :TWISTER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DOVEHEART,
        :level => 21,
        :item => "",
        :ability => "",
        :nature => :TIMID,
        :moves => [:AIRCUTTER, :DRAININGKISS, :CHARM, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Jenson", :BACKPACKER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SCORPINOVA,
        :level => 26,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:DRILLRUN, :HEATWAVE, :ROCKSLIDE, :GIGADRAIN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Jayden", :BACKPACKER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :LAZLOTH,
        :level => 50,
        :item => :LEFTOVERS,
        :ability => "",
        :nature => :BRAVE,
        :moves => [:GLACIERCRASH, :CRACKLESLAM, :EARTHQUAKE, :RETURN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Arne", :BACKPACKER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :MOOSTRIKE,
        :level => 42,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GRENATRIC,
        :level => 42,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Eugene", :BACKPACKER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SNOWRONG,
        :level => 52,
        :item => :LIFEORB,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:BLIZZARD, :PHANTOMGRIP, :FREEZEDRY, :GRASSKNOT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :AURORAI,
        :level => 52,
        :item => :OCCABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:ICEBEAM, :THUNDERBOLT, :THUNDERWAVE, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :HUMMZAP,
        :level => 52,
        :item => :CHARTIBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:THUNDERBOLT, :AIRSLASH, :HEATWAVE, :FLASHCANNON],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :JEWELTAL,
        :level => 52,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:BUGBUZZ, :GEODECANNON, :FREEZEDRY, :FLASHCANNON],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Scott", :BACKPACKER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BUSHAIRY,
        :level => 21,
        :item => :LEFTOVERS,
        :ability => "",
        :nature => :MODEST,
        :moves => [:INGRAIN, :LEECHSEED, :GIGADRAIN, :PROTECT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Thane", :BACKPACKER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :DYNABALL,
        :level => 30,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:FLAMECHARGE, :IRONHEAD, :WILDCHARGE, :BULLDOZE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :HUMMZAP,
        :level => 30,
        :item => :CHARTIBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:DRILLPECK, :VOLTSWITCH, :SIGNALBEAM, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :JELLITIC,
        :level => 30,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:SCALD, :FREEZEDRY, :THUNDERWAVE, :SIGNALBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Stewy", :BACKPACKER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :DEERASH,
        :level => 35,
        :item => :LIFEORB,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:TAKEDOWN, :FLAREBLITZ, :JUMPKICK, :WILDCHARGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ECOBUZZ,
        :level => 35,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :TIMID,
        :moves => [:GIGADRAIN, :THUNDERBOLT, :WEATHERBALL, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FIZIRE,
        :level => 35,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:FLAMETHROWER, :POWERGEM, :SCALD, :EARTHPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Xavier", :BACKPACKER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SCORLIT,
        :level => 26,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:DRILLRUN, :ROCKSLIDE, :FLAMEWHEEL, :POISONJAB],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SANDSTER,
        :level => 26,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:DARKPULSE, :EARTHPOWER, :HEATWAVE, :SHADOWBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Cameron", :BACKPACKER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BILLAZE,
        :level => 33,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :MODEST,
        :moves => [:HEATWAVE, :EARTHPOWER, :ZENHEADBUTT, :WILDCHARGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :COBOLTA,
        :level => 33,
        :item => :AIRBALLOON,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SLUDGEWAVE, :THUNDERBOLT, :ENERGYBALL, :AQUATAIL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FINNDRA,
        :level => 33,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:SCALD, :DRAGONPULSE, :ICEBEAM, :FREEZEDRY],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Nancy", :BATTLEGIRL, 0],
    :defeat => "",
    :mons => [
      {
        :species => :GROILLUM,
        :level => 30,
        :item => :COBABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:SEEDBOMB, :SKYUPPERCUT, :THUNDERPUNCH, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GRIZZLER,
        :level => 30,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:FIREPUNCH, :BRICKBREAK, :THUNDERPUNCH, :SHADOWCLAW],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Malia", :BATTLEGIRL, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ROOBEOP,
        :level => 61,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MAGRIZZLY,
        :level => 61,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Lucy", :BATTLEGIRL, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SHRIMPOON,
        :level => 35,
        :item => :LEFTOVERS,
        :ability => "",
        :nature => :MODEST,
        :moves => [:SCALD, :HEATWAVE, :EARTHPOWER, :AQUAJET],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SCORPINOVA,
        :level => 35,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :QUIET,
        :moves => [:STOMPINGTANTRUM, :LAVAPLUME, :GIGADRAIN, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Maggie", :BIRDKEEPER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :FLAPINKO,
        :level => 51,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HYPERVOICE, :HEATWAVE, :DAZZLINGGLEAM, :HURRICANE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PUFFPEAK,
        :level => 51,
        :item => :CHARTIBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:ICEBEAM, :AIRSLASH, :THUNDERBOLT, :FLASHCANNON],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DOVEHEART,
        :level => 51,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:MOONBLAST, :SQUALLBLOW, :HEATWAVE, :AIRCANNON],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Noemi", :BIRDKEEPER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PUFFPEAK,
        :level => 60,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PSYFLOCK,
        :level => 60,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FLAPINKO,
        :level => 60,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Anneli", :BIRDKEEPER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :AEROMA,
        :level => 49,
        :item => :YACHEBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:GIGADRAIN, :SQUALLBLOW, :CALMMIND, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PARABOW,
        :level => 49,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:GALERUSH, :DOUBLEHIT, :HEATWAVE, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SWELLEGANT,
        :level => 49,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HURRICANE, :HYDROPUMP, :DAZZLINGGLEAM, :HEATWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Avory", :BIRDKEEPER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :DODONT,
        :level => 30,
        :item => :YACHEBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:DOUBLEEDGE, :BULLDOZE, :ROCKSLIDE, :GALERUSH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :AEROMA,
        :level => 30,
        :item => :CHARTIBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:AIRSLASH, :ENERGYBALL, :DAZZLINGGLEAM, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PEAFAN,
        :level => 30,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:TRIATTACK, :AIRSLASH, :HEATWAVE, :CHARGEBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Laurent", :BIRDKEEPER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PUFFPEAK,
        :level => 54,
        :item => :LIFEORB,
        :ability => "",
        :nature => :MODEST,
        :moves => [:HURRICANE, :BLIZZARD, :THUNDERBOLT, :FLASHCANNON],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TERRAVOLT,
        :level => 54,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:THUNDERBOLT, :SQUALLBLOW, :HEATWAVE, :FLASHCANNON],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Joshua", :BIRDKEEPER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PARABOW,
        :level => 60,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :WOODAWN,
        :level => 60,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DODONT,
        :level => 60,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Jeff", :BIRDKEEPER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PARABOW,
        :level => 34,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:CRUSHCLAW, :WINGATTACK, :SCREECH, :STEELWING],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SWELLEGANT,
        :level => 34,
        :item => :CHARTIBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SCALD, :AIRSLASH, :DAZZLINGGLEAM, :ICYWIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Dwight", :BIRDKEEPER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BLIMPOON,
        :level => 53,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :MODEST,
        :moves => [:FLASHCANNON, :SQUALLBLOW, :HEATWAVE, :VACUUMWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Jackie", :BLACKBELT, 0],
    :defeat => "",
    :mons => [
      {
        :species => :GRIZZLER,
        :level => 35,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:DRAINPUNCH, :FIREPUNCH, :THUNDERPUNCH, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Malte", :BLACKBELT, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BULKER,
        :level => 61,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :KONGRILLA,
        :level => 61,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Corbin", :BLACKBELT, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BULLSON,
        :level => 29,
        :item => :KEEBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:BODYPRESS, :TAKEDOWN, :CRUNCH, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Karrie", :BUGCATCHER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :WIDOX,
        :level => 28,
        :item => :POWERHERB,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:XSCISSOR, :POISONJAB, :DIG, :RAZORBLADE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PIXILILY,
        :level => 28,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SIGNALBEAM, :DAZZLINGGLEAM, :GIGADRAIN, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :JEWELTAL,
        :level => 28,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :TIMID,
        :moves => [:POWERGEM, :SIGNALBEAM, :ENERGYBALL, :FREEZEDRY],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Tabetha", :BUGCATCHER_Female, 0],
    :defeat => "My ultimate strategy failed...",
    :mons => [
      {
        :species => :SANDUGG,
        :level => 16,
        :item => :LEFTOVERS,
        :ability => :SANDSTREAM,
        :nature => :CALM,
        :moves => [:SHOREUP, :PROTECT, :TOXIC, :INFESTATION],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 0, 252, 0, 252, 0],
        :statmults => [1.3,1,1.1,1,1.1,1]
      },
    ]
  },
  {
    :teamid => ["Jolanta", :BUGCATCHER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BUGRAY,
        :level => 49,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:GALERUSH, :PINMISSILE, :FELLSTINGER, :KNOCKOFF],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ELECRITTER,
        :level => 49,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :TIMID,
        :moves => [:THUNDERBOLT, :ENERGYBALL, :DAZZLINGGLEAM, :DUSTYDASH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BUDCHEEP,
        :level => 49,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HYPERVOICE, :SQUALLBLOW, :HEATWAVE, :AIRCANNON],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Christina", :BUGCATCHER_Female, 0],
    :defeat => "Oh!",
    :mons => [
      {
        :species => :TARATERROR,
        :level => 21,
        :item => :TELLURICSEED,
        :ability => :INTIMIDATE,
        :nature => :JOLLY,
        :moves => [:BITE,:BUGBITE,:BULLDOZE,:SHADOWCLAW],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
    ]
  },
  {
    :teamid => ["Luna", :BUGCATCHER_Female, 0],
    :defeat => "I've lost?",
    :mons => [
      {
        :species => :GLOCOON,
        :level => 19,
        :item => :MAGICALSEED,
        :ability => :MOTORDRIVE,
        :nature => :MODEST,
        :moves => [:SIGNALBEAM,:SHOCKWAVE,:ICYWIND,:HIDDENPOWERGRA],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0],
        :statMults => [1.5,1,1.3,1,1.1,1]
      },
    ]
  },
  {
    :teamid => ["Michele", :BUGCATCHER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SKRABBLE,
        :level => 10,
        :item => :ROCKGEM,
        :ability => :CLEARBODY,
        :nature => :ADAMANT,
        :moves => [:SMACKDOWN, :BUGBITE, :HONECLAWS, :COVET],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Lola", :BUGCATCHER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :FYANT,
        :level => 28,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Trixy", :BUGCATCHER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SPIDOX,
        :level => 9,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Lillian", :BUGCATCHER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SHRIMPET,
        :level => 10,
        :item => :WACANBERRY,
        :ability => :HEATPROOF,
        :nature => :MODEST,
        :moves => [:EMBER, :MEGADRAIN, :WATERGUN, :STRUGGLEBUG],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
      {
        :species => :SLUGGAH,
        :level => 10,
        :item => :BERRYJUICE,
        :ability => :CLEARBODY,
        :nature => :MODEST,
        :moves => [:ACIDSPRAY, :STRUGGLEBUG, :HEADBUTT, :HIDDENPOWERGRO],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Lana", :BUGCATCHER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :WIDOX,
        :level => 38,
        :item => :POWERHERB,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:POISONJAB, :XSCISSOR, :RAZORBLADE, :DIG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TARATERROR,
        :level => 38,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:CRUNCH, :XSCISSOR, :EARTHQUAKE, :DUALCHOP],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Arthur", :BUGCATCHER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BUGRAY,
        :level => 49,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:STICKYWEB, :ACROBATICS, :XSCISSOR, :FELLSTINGER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BUGRAY,
        :level => 49,
        :item => :FLYINGGEM,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:ACROBATICS, :PINMISSILE, :POISONJAB, :STEELWING],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BUGRAY,
        :level => 49,
        :item => :FLYINGGEM,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:ACROBATICS, :PINMISSILE, :POISONJAB, :STEELWING],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DRACOFLY,
        :level => 49,
        :item => :LIFEORB,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:DRAGONRUSH, :FELLSTINGER, :PINMISSILE, :WILDCHARGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Paul", :BUGCATCHER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :STICKIT,
        :level => 8,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :JUMPLE,
        :level => 8,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SLUGGAH,
        :level => 9,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Martin", :BUGCATCHER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :WORMUNE,
        :level => 26,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:COIL, :ROCKSLIDE, :UTURN, :DRILLRUN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Riccardo", :BUGCATCHER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :WORMOLE,
        :level => 53,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:EARTHQUAKE, :XSCISSOR, :STONEEDGE, :IRONTAIL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ROTTOWEEN,
        :level => 53,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:PHANTOMGRIP, :XSCISSOR, :SEEDBOMB, :BULLDOZE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FYANT,
        :level => 53,
        :item => :LIFEORB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:FLAMETHROWER, :ENERGYBALL, :BUGBUZZ, :EARTHPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Travis", :BUGCATCHER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :DARCULA,
        :level => 13,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Alan", :BUGCATCHER_Male, 0],
    :defeat => "Waaah...",
    :mons => [
      {
        :species => :GWORM,
        :level => 14,
        :item => :TELLURICSEED,
        :ability => :SANDRUSH,
        :nature => :JOLLY,
        :moves => [:SANDSTORM,:BUGBITE,:BULLDOZE,:SMACKDOWN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :SKRABBLE,
        :level => 14,
        :item => :ORANBERRY,
        :ability => :CLEARBODY,
        :nature => :JOLLY,
        :moves => [:FURYCUTTER,:ROLLOUT,:ROCKPOLISH,:THIEF],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :AQLARVA,
        :level => 14,
        :item => :FOCUSSASH,
        :ability => :HYDRATION,
        :nature => :TIMID,
        :moves => [:STRUGGLEBUG,:BUBBLEBEAM,:ELECTROWEB,:ROUND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
    ]
  },
  {
    :teamid => ["Sean", :BUGCATCHER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :STICKIT,
        :level => 6,
        :ability => :SWARM,
        :nature => :QUIRKY,
        :moves => [:SCRATCH, :HARDEN, :RAZORLEAF, :STRUGGLEBUG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 0]
      },
      {
        :species => :SHRIMPET,
        :level => 7,
        :ability => :HEATPROOF,
        :nature => :QUIRKY,
        :moves => [:AQUAJET, :STRUGGLEBUG, :BUBBLE, :SCREECH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Craig", :BUGCATCHER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :WIDOX,
        :level => 38,
        :item => :POWERHERB,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:POISONJAB, :XSCISSOR, :RAZORBLADE, :DIG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TARATERROR,
        :level => 38,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:CRUNCH, :XSCISSOR, :EARTHQUAKE, :DUALCHOP],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Sean", :BUGCATCHER_Male,1, 0],
    :defeat => "",
    :mons => [
      {
        :species => :STICKUT,
        :level => 36,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :WORMUNE,
        :level => 36,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FYANT,
        :level => 36,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Joe", :BUGCATCHER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :FYANT,
        :level => 34,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:BUGBUZZ, :FLAMETHROWER, :GIGADRAIN, :SLUDGEBOMB],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Orson", :BUGCATCHER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :JEWELTAL,
        :level => 27,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:BUGBUZZ, :ENERGYBALL, :POWERGEM, :FREEZEDRY],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :WORMUNE,
        :level => 27,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:DRILLRUN, :UTURN, :ROCKSLIDE, :IRONHEAD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Jeronimo", :BUGCATCHER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BUGRAY,
        :level => 49,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:GALERUSH, :PINMISSILE, :FELLSTINGER, :KNOCKOFF],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ELECRITTER,
        :level => 49,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :TIMID,
        :moves => [:THUNDERBOLT, :ENERGYBALL, :DAZZLINGGLEAM, :DUSTYDASH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BUDCHEEP,
        :level => 49,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HYPERVOICE, :SQUALLBLOW, :HEATWAVE, :AIRCANNON],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Gaspard", :BURGLAR, 0],
    :defeat => "",
    :mons => [
      {
        :species => :CRYSTOX,
        :level => 63,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PHANSHEET,
        :level => 63,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Billy", :BURGLAR, 0],
    :defeat => "Oof...",
    :mons => [
      {
        :species => :VAMBAT,
        :level => 18,
        :item => :BERRYJUICE,
        :ability => :BLOODTHIRST,
        :nature => :JOLLY,
        :moves => [:WINGATTACK, :BITE, :UTURN, :STEELWING],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 52, 0, 0, 252]
      },
      {
        :species => :PINKMEE,
        :level => 18,
        :ability => :ANTICIPATION,
        :nature => :MODEST,
        :moves => [:BUBBLEBEAM, :PSYBEAM, :SIGNALBEAM, :DRAININGKISS],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
      {
        :species => :LAVENBELLE,
        :level => 18,
        :item => :OCCABERRY,
        :ability => :CHLOROPHYLL,
        :nature => :MODEST,
        :moves => [:MEGADRAIN, :LIGHTBURST, :SUNNYDAY, :HIDDENPOWERROC],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
      {
        :species => :SLUGGAH,
        :level => 18,
        :item => :MAGICALSEED,
        :ability => :GOOEY,
        :nature => :MODEST,
        :moves => [:MEGADRAIN, :SIGNALBEAM, :ACIDSPRAY, :HIDDENPOWERGRO],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
      {
        :species => :BUNNIC,
        :level => 18,
        :item => :KEBIABERRY,
        :ability => :THICKFAT,
        :nature => :JOLLY,
        :moves => [:TRICKSHOT, :STOMP, :THIEF, :ICYWIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :WIDOX,
        :level => 19,
        :item => :LIFEORB,
        :ability => :SWARM,
        :nature => :JOLLY,
        :moves => [:BUGBITE, :POISONFANG, :BITE, :SWORDSDANCE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
    ]
  },
  {
    :teamid => ["Atomotro", :HOMEDEFENSE, 0],
    :defeat => "DEFENSES... DEPLETED.",
    :trainereffect => {
        :buffactivation => :Limited,
        :effectmode => :Party,
        0 => {
          :message => "EMERGENCY DEFENSE ACTIVATED...",
          :fieldChange => [:CORROSIVEMIST, "Poisonous gas floods the room!",0]
        }
      },
    :mons => [
      {
        :species => :DYNABALL,
        :level => 20,
        :item => :AIRBALLOON,
        :ability => :AFTERMATH,
        :nature => :JOLLY,
        :moves => [:FLAMEWHEEL, :MAGNETBOMB, :ROCKTOMB, :FACADE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 52, 0, 0, 252]
      },
      {
        :species => :JELLITOTF,
        :level => 20,
        :item => :BERRYJUICE,
        :ability => :CLEARBODY,
        :nature => :MODEST,
        :moves => [:ACIDSPRAY, :SHOCKWAVE, :BRINE, :ROUND],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
      {
        :species => :AQLARVA,
        :level => 20,
        :item => :ELEMENTALSEED,
        :ability => :SWARM,
        :nature => :MODEST,
        :moves => [:BUBBLEBEAM, :STRUGGLEBUG, :HIDDENPOWERELE, :GIGADRAIN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :LAVENBELLE,
        :level => 21,
        :item => :OCCABERRY,
        :ability => :AROMAVEIL,
        :nature => :MODEST,
        :moves => [:MAGICALLEAF, :LIGHTBURST, :NATUREPOWER, :HIDDENPOWERGRO],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
      {
        :species => :PHOXY,
        :level => 20,
        :item => :FOCUSSASH,
        :ability => :PIXILATE,
        :nature => :TIMID,
        :moves => [:ROUND, :WATERPULSE, :SHOCKWAVE, :HIDDENPOWERFIR],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :ATOMOTRO,
        :level => 22,
        :item => :OCCABERRY,
        :ability => :LEVITATE,
        :nature => :TIMID,
        :moves => [:HIDDENPOWERWAT, :LIGHTNINGSTRIKE, :FLASHCANNON, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
    ]
  },
  {
    :teamid => ["Guardians", :GUARDIANS, 0],
    :defeat => "....",
    :mons => [
      {
        :species => :ROLLIE,
        :level => 20,
        :item => :SITRUSBERRY,
        :ability => :TECHNICIAN,
        :nature => :BRAVE,
        :moves => [:BONECLUB, :SMACKDOWN, :SHADOWBALL, :FACADE],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 52, 0, 0, 0]
      },
      {
        :species => :CASPEEK,
        :level => 20,
        :item => :LIECHIBERRY,
        :ability => :SIMPLE,
        :nature => :ADAMANT,
        :moves => [:SWORDSDANCE, :SHADOWSNEAK, :FURYSWIPES, :NIGHTSHADE],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
      {
        :species => :TIKIKI,
        :level => 20,
        :item => :MAGICALSEED,
        :ability => :RATTLED,
        :nature => :TIMID,
        :moves => [:TIKITORCH, :FIRESPIN, :HIDDENPOWERWAT, :ROUND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :SKREECH,
        :level => 20,
        :item => :ROCKYHELMET,
        :ability => :CURSEDBODY,
        :nature => :TIMID,
        :moves => [:HEX, :NIGHTSHADE, :SHOCKWAVE, :ROUND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :GOLKID,
        :level => 20,
        :item => :EVIOLITE,
        :ability => :IRONFIST,
        :nature => :ADAMANT,
        :moves => [:DRAINPUNCH, :BULLDOZE, :MEGAPUNCH, :COMETPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
      {
        :species => :WRAPHRO,
        :level => 21,
        :item => :LEFTOVERS,
        :ability => :PURIFYINGSALT,
        :nature => :IMPISH,
        :moves => [:NIGHTSHADE, :MOONLIGHT, :TOXIC, :WRAP],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Jamie", :BURGLAR, 0],
    :defeat => "",
    :mons => [
      {
        :species => :VENNAP,
        :level => 12,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Dolf", :BURGLAR, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ATOMOTRIX,
        :level => 63,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PHAROBE,
        :level => 63,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Lips", :BURGLAR, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SNAPIKE,
        :level => 63,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TAPIBLAZE,
        :level => 63,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ELESTOMP,
        :level => 63,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CHAMELECTRO,
        :level => 63,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Dias", :WORKER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ECLIPSER,
        :level => 62,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :METEROCK,
        :level => 62,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :COUNTULA,
        :level => 62,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Diamante", :WORKER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :CRYSTOX,
        :level => 63,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LEONITE,
        :level => 63,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Dillion", :WORKER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :GOLOSSUS,
        :level => 63,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SYPHOON,
        :level => 63,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Jett", :WORKER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :LEONITE,
        :level => 62,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :METEROCK,
        :level => 62,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ECLIPSER,
        :level => 62,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Jerod", :WORKER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SYPHOON,
        :level => 62,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LEONITE,
        :level => 62,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CRYSTOX,
        :level => 62,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Lizzy", :CASTELLAN_Lizzy, 0],
    :defeat => "",
    :mons => [
      {
        :species => :FINNDRA,
        :level => 47,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HYDROPUMP, :DRAGONPULSE, :SLACKOFF, :IRONTAIL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DRACOFLY,
        :level => 47,
        :item => :CHARTIBERRY,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:DRAGONRUSH, :PINMISSILE, :DRACOMETEOR, :POISONJAB],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :AEROGON,
        :level => 47,
        :item => :YACHEBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:GALERUSH, :DRAGONRUSH, :EARTHQUAKE, :SUPERPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CRYODRA,
        :level => 47,
        :item => :CHOPLEBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:ICEBEAM, :DRAGONPULSE, :ROOST, :FREEZEDRY],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DINOPION,
        :level => 47,
        :item => :COBABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:STONEEDGE, :CLOSECOMBAT, :DRAGONRUSH, :IRONTAIL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :RAIZODON,
        :level => 48,
        :item => :RAIZODONITE,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:CRACKLESLAM, :DRAGONRUSH, :EARTHQUAKE, :DRAGONDANCE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Jessica", :CLERK_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :MOONKY,
        :level => 22,
        :item => "",
        :ability => "",
        :nature => :TIMID,
        :moves => [:PSYBEAM, :LIGHTBURST, :BRICKBREAK, :UTURN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :WEASHOCK,
        :level => 22,
        :item => "",
        :ability => "",
        :nature => :TIMID,
        :moves => [:ELECTROBALL, :THUNDERWAVE, :HIDDENPOWER, :FLAMEBURST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SNUFFUZZ,
        :level => 22,
        :item => "",
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:HYPERFANG, :ROLLOUT, :DEFENSECURL, :BITE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Lex", :CLERK_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :IGLOW,
        :level => 22,
        :item => :CHOPLEBERRY,
        :ability => "",
        :nature => :BRAVE,
        :moves => [:ROCKTOMB, :ICYWIND, :BARRAGE, :BULLDOZE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BOULDOX,
        :level => 22,
        :item => :AIRBALLOON,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:CROSSPOISON, :ROCKSLIDE, :BULLDOZE, :PINMISSILE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ECLIPO,
        :level => 22,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:ANCIENTPOWER, :EXTRASENSORY, :INCINERATE, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GOLEMO,
        :level => 22,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:ROCKPOLISH, :DRAINPUNCH, :ROCKTOMB, :BULLDOZE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :JEWELTAL,
        :level => 23,
        :item => :WHITEHERB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:BUGBOMB, :ANCIENTPOWER, :ENERGYBALL, :SHELLSMASH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Sebastian", :CLERK_Male2, 0],
    :defeat => "",
    :mons => [
      {
        :species => :UGLING,
        :level => 17,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Lassie", :COWGIRL, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BULLSON,
        :level => 44,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:DOUBLEEDGE, :BODYPRESS, :EARTHQUAKE, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GIRAFLAME,
        :level => 44,
        :item => :FLAMEPLATE,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HEATWAVE, :FLAMECHARGE, :ENERGYBALL, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ZEBRITE,
        :level => 44,
        :item => :LIFEORB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:PSYCHIC, :DAZZLINGGLEAM, :ENERGYBALL, :THUNDERBOLT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Irina", :COWGIRL, 0],
    :defeat => "",
    :mons => [
      {
        :species => :HORSHUSH,
        :level => 40,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Bridgett", :CYCLIST_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PEAFAN,
        :level => 25,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :TIMID,
        :moves => [:AIRCUTTER, :HYPERVOICE, :DAZZLINGGLEAM, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ORITURE,
        :level => 25,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:BULLDOZE, :ROCKSLIDE, :IRONHEAD, :ZENHEADBUTT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Poppy", :CYCLIST_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :HORSHUSH,
        :level => 25,
        :item => :OCCABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:SEEDBOMB, :DOUBLEKICK, :BULLDOZE, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LAVENBELLE,
        :level => 25,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :TIMID,
        :moves => [:GIGADRAIN, :DAZZLINGGLEAM, :DUSTYDASH, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Lance", :CYCLIST_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :DRACUBAT,
        :level => 25,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:WINGATTACK, :CRUNCH, :SHADOWCLAW, :REVERSAL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :COSMET,
        :level => 25,
        :item => :ROCKGEM,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:ROCKSLIDE, :WILDCHARGE, :IRONHEAD, :UTURN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Alberto", :CYCLIST_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :WEASHOCK,
        :level => 25,
        :item => :LIFEORB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:NASTYPLOT, :THUNDERBOLT, :ENERGYBALL, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Jason", :DANCER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :CHAMELEC,
        :level => 21,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:LIGHTNINGSTRIKE, :ANCIENTPOWER, :SLUDGEBOMB, :INCINERATE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TERRAZ,
        :level => 21,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:LIGHTNINGSTRIKE, :AIRCUTTER, :MIRRORSHOT, :THUNDERWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ATOMIX,
        :level => 22,
        :item => :OCCABERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:MIRRORSHOT, :LIGHTNINGSTRIKE, :DAZZLINGGLEAM, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Kevin", :DANCER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SIGNILEAF,
        :level => 22,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:SUNNYDAY, :GIGADRAIN, :LIGHTNINGSTRIKE, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Duncan", :DOCTOR, 0],
    :defeat => "",
    :mons => [
      {
        :species => :WRAPHRO,
        :level => 21,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Monty", :DOCTOR, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SNOWRONG,
        :level => 49,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BLIZZIBAT,
        :level => 49,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Freddie", :DOCTOR, 0],
    :defeat => "",
    :mons => [
      {
        :species => :LAZLOTH,
        :level => 45,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :WOODBEAK,
        :level => 45,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Perry", :DOCTOR, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SNAZAP,
        :level => 16,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Conrad", :DOCTOR, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SLIBLOO,
        :level => 33,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :AQLARVA,
        :level => 33,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Harnish", :FISHERMAN, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SKELEDEEP,
        :level => 39,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:AQUAJET, :SHADOWSNEAK, :AQUATAIL, :CRUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Seamus", :FISHERMAN, 0],
    :defeat => "",
    :mons => [
      {
        :species => :JELLIKING,
        :level => 51,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Harry", :FISHERMAN, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SHRIMPOON,
        :level => 36,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Finnian", :FISHERMAN, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ANGELISH,
        :level => 34,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :KINIP,
        :level => 34,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ANGELISH,
        :level => 34,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Caeleb", :FISHERMAN, 0],
    :defeat => "",
    :mons => [
      {
        :species => :NAWALE,
        :level => 56,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LISQUID,
        :level => 56,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Clancy", :FISHERMAN, 0],
    :defeat => "",
    :mons => [
      {
        :species => :POOLDOG,
        :level => 47,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:MEGALOFANG, :AQUAJET, :GLACIERCRASH, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SWELLEGANT,
        :level => 47,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:AIRSLASH, :SURF, :DAZZLINGGLEAM, :ROOST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :YAKKLE,
        :level => 47,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:DOUBLEEDGE, :LIQUIDATION, :SUPERPOWER, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Howie", :FISHERMAN, 0],
    :defeat => "",
    :mons => [
      {
        :species => :NAWALE,
        :level => 49,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :NAWALE,
        :level => 49,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Gerard", :FISHERMAN,1, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ANGELIGHT,
        :level => 36,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SMAQUA,
        :level => 36,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SHRIMPOON,
        :level => 36,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Leon", :FISHERMAN, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SHRIMPOON,
        :level => 62,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SILVICIOUS,
        :level => 62,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :EELECT,
        :level => 62,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Xavier", :FISHERMAN, 0],
    :defeat => "",
    :mons => [
      {
        :species => :MOSLIQUO,
        :level => 40,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:SIPHONBITE, :LIQUIDATION, :ACROBATICS, :PSYCHOCUT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grant", :FISHERMAN, 0],
    :defeat => "",
    :mons => [
      {
        :species => :JELLIKING,
        :level => 42,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:REST, :SURF, :ICEBEAM, :GIGADRAIN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Fridolin", :FISHERMAN, 0],
    :defeat => "",
    :mons => [
      {
        :species => :CRYODRA,
        :level => 61,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :KINIP,
        :level => 61,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Radoslaw", :FISHERMAN, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SWELLEGANT,
        :level => 61,
        :item => :CLEARAMULET,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SCALD, :REST, :HURRICANE, :CALMMIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Pirmin", :FISHERMAN, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SMAQUA,
        :level => 44,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ANGELIGHT,
        :level => 44,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Malte", :FISHERMAN, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SQUIDART,
        :level => 41,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SQUIDART,
        :level => 41,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Gerard", :FISHERMAN, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ANGELISH,
        :level => 15,
        :item => :RINDOBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:WATERPULSE, :DRAININGKISS, :AQUAJET, :ICYWIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Tony", :FISHERMAN, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PLATYPLAT,
        :level => 15,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ANGLING,
        :level => 15,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Quentin", :FISHERMAN, 0],
    :defeat => "",
    :mons => [
      {
        :species => :NAWALE,
        :level => 61,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :EQWATER,
        :level => 61,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Sienna", :GARDENER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :MOSSNAIL,
        :level => 45,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :WOODAWN,
        :level => 45,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Larissa", :GARDENER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BUSHAIRY,
        :level => 47,
        :item => :POWERHERB,
        :ability => "",
        :nature => :BRAVE,
        :moves => [:SOLARBEAM, :EARTHQUAKE, :SYNTHESIS, :CRACKLESLAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LAVENRINA,
        :level => 47,
        :item => :KEBIABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:MOONBLAST, :GIGADRAIN, :GROWTH, :SLEEPPOWDER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ECOBUZZ,
        :level => 47,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SUNNYDAY, :SOLARBEAM, :THUNDERBOLT, :WEATHERBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Walda", :GARDENER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :KELPULA,
        :level => 50,
        :item => :COBABERRY,
        :ability => "",
        :nature => :BRAVE,
        :moves => [:POWERWHIP, :LIQUIDATION, :ICEBEAM, :XSCISSOR],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BUSHAIRY,
        :level => 50,
        :item => :OCCABERRY,
        :ability => "",
        :nature => :BRAVE,
        :moves => [:EARTHQUAKE, :GIGADRAIN, :LEECHSEED, :SYNTHESIS],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :AEROMA,
        :level => 50,
        :item => :YACHEBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:ENERGYBALL, :SQUALLBLOW, :DAZZLINGGLEAM, :CALMMIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :KAHULA,
        :level => 50,
        :item => :KEBIABERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:HYDROPUMP, :GIGADRAIN, :ICEBEAM, :SYNTHESIS],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Lilly", :GARDENER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :KAHULA,
        :level => 62,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GLOWING,
        :level => 62,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BUSHAIRY,
        :level => 62,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Haidee", :GARDENER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :WOODAWN,
        :level => 50,
        :item => :YACHEBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:BULLETSEED, :PINMISSILE, :BRAVEBIRD, :DRILLRUN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GROILLUM,
        :level => 50,
        :item => :COBABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:WOODHAMMER, :DRAINPUNCH, :THUNDERPUNCH, :LEAFDARTS],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TIKITIK,
        :level => 50,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :TIMID,
        :moves => [:FLAMETHROWER, :SOLARBEAM, :THUNDERBOLT, :EARTHPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :EQWATER,
        :level => 50,
        :item => :KEBIABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SCALD, :GIGADRAIN, :ICEBEAM, :VACUUMWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Harrison", :GARDENER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :MOSSNAIL,
        :level => 49,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:BUGBUZZ, :GEODECANNON, :EARTHPOWER, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DRAGOON,
        :level => 49,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :BRAVE,
        :moves => [:GIGADRAIN, :DRAGONPULSE, :EARTHQUAKE, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PUPETAL,
        :level => 49,
        :item => :KEBIABERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:ENERGYBALL, :MOONBLAST, :DUSTYDASH, :THUNDERWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Foster", :GARDENER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SWAMPHEAP,
        :level => 52,
        :item => :LEFTOVERS,
        :ability => "",
        :nature => :BRAVE,
        :moves => [:LEECHSEED, :WHIRLPOOL, :TOXIC, :PROTECT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Leroy", :GARDENER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :AEROMA,
        :level => 47,
        :item => :POWERHERB,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:SOLARBEAM, :SKYATTACK, :ROOST, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GROILLUM,
        :level => 47,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:DRAINPUNCH, :WOODHAMMER, :THUNDERPUNCH, :MACHPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :COCOROCKO,
        :level => 47,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:STONEEDGE, :BULLETSEED, :EARTHQUAKE, :DRAINPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Garwin", :GARDENER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :STICKUT,
        :level => 50,
        :item => :COBABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:XSCISSOR, :HORNLEECH, :STONEEDGE, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MONSTRAP,
        :level => 50,
        :item => :TANGABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:SEEDBOMB, :CRUNCH, :EARTHQUAKE, :GUNKSHOT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GROILLUM,
        :level => 50,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:DRAINPUNCH, :WOODHAMMER, :THUNDERPUNCH, :MACHPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Didier", :GENTLEMAN, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SLITHEAT,
        :level => 46,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :TIMID,
        :moves => [:FLAMETHROWER, :SLUDGEBOMB, :EARTHPOWER, :DRAGONPULSE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DRAGOON,
        :level => 46,
        :item => :YACHEBERRY,
        :ability => "",
        :nature => :BRAVE,
        :moves => [:GIGADRAIN, :DRAGONPULSE, :EARTHQUAKE, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :VALURE,
        :level => 46,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:RIPPLEWAVE, :PSYCHIC, :ICEBEAM, :RECOVER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Brooke", :GENTLEMAN, 0],
    :defeat => "",
    :mons => [
      {
        :species => :RUSHOT,
        :level => 32,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:CRACKLESLAM, :HEATWAVE, :DAZZLINGGLEAM, :GALERUSH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :KELPULA,
        :level => 32,
        :item => :COBABERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:PETALBLIZZARD, :AQUASLAM, :BRICKBREAK, :KNOCKOFF],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :METEROCK,
        :level => 32,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:CRACKLESLAM, :GALERUSH, :ROCKSLIDE, :IRONHEAD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Athelstan", :GENTLEMAN, 0],
    :defeat => "",
    :mons => [
      {
        :species => :HUSKOLD,
        :level => 51,
        :item => :LIFEORB,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:ICICLECRASH, :PLAYROUGH, :WILDCHARGE, :IRONTAIL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SUBEARO,
        :level => 51,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:ICICLECRASH, :DRAINPUNCH, :THUNDERPUNCH, :STONEEDGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BILLAZE,
        :level => 51,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:FLAREBLITZ, :EARTHQUAKE, :WILDCHARGE, :DUSTYDASH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GECKONE,
        :level => 51,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:PSYCHIC, :ICEBEAM, :THUNDERBOLT, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Ashley", :GUITARIST_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :STRIKLOUD,
        :level => 22,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :TIMID,
        :moves => [:AIRSLASH, :LIGHTNINGSTRIKE, :ANCIENTPOWER, :CHARGEBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Kendra", :GUITARIST_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ATOMOTRO,
        :level => 22,
        :item => :OCCABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:FLASHCANNON, :DISCHARGE, :DAZZLINGGLEAM, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Lenny", :GUITARIST_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ZUPPY,
        :level => 22,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :TIMID,
        :moves => [:LIGHTNINGSTRIKE, :FLAMEBURST, :SIGNALBEAM, :DUSTYDASH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SNAZAP,
        :level => 22,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:LIGHTNINGSTRIKE, :SLUDGEBOMB, :ENERGYBALL, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ECOBUZZ,
        :level => 23,
        :item => :OCCABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:GIGADRAIN, :LIGHTNINGSTRIKE, :SIGNALBEAM, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Ronald", :HARLEQUIN, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PARAFUL,
        :level => 24,
        :item => :WHITEHERB,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:FURYSWIPES, :WINGATTACK, :STEELWING, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Chandler", :HIKER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ECLIPO,
        :level => 30,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:PSYSHOCK, :POWERGEM, :INCINERATE, :SHADOWBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :IGLOW,
        :level => 30,
        :item => :CHOPLEBERRY,
        :ability => "",
        :nature => :BRAVE,
        :moves => [:ICICLESPEAR, :ROCKBLAST, :BULLDOZE, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GOLEMO,
        :level => 30,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:DRAINPUNCH, :ROCKSLIDE, :ICEPUNCH, :THUNDERPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Silas", :HIKER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ECLIPSER,
        :level => 31,
        :item => :LUMBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:OVERHEAT, :POWERGEM, :RECOVER, :PSYSHOCK],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Jerome", :HIKER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :TORTAROCK,
        :level => 27,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:ROCKSLIDE, :BULLDOZE, :CRUNCH, :ZENHEADBUTT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CORALUSH,
        :level => 27,
        :item => :RINDOBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:POWERGEM, :SCALD, :ICEBEAM, :GIGADRAIN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Kyle", :HIKER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BOULDOISE,
        :level => 27,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:ROCKSLIDE, :EARTHQUAKE, :ROCKPOLISH, :ZENHEADBUTT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Gordon", :HIKER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ORITURE,
        :level => 26,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:DRILLRUN, :ROCKSLIDE, :XSCISSOR, :ZENHEADBUTT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ROOBEO,
        :level => 26,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:JUMPKICK, :ROCKSLIDE, :DRAINPUNCH, :BULLDOZE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Forrest", :HIKER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :GOLOSSUS,
        :level => 37,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:STONEEDGE, :HAMMERARM, :EARTHQUAKE, :ICEPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TAREXITE,
        :level => 37,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:DRAGONDANCE, :STONEEDGE, :FLAREBLITZ, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BULLSON,
        :level => 37,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:BODYPRESS, :RETURN, :ZENHEADBUTT, :GLACIERCRASH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TARATERROR,
        :level => 37,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:CRUNCH, :XSCISSOR, :THUNDERFANG, :ICEFANG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CRYSTOX,
        :level => 37,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:STONEEDGE, :POISONJAB, :EARTHQUAKE, :SUPERPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LOPHUG,
        :level => 39,
        :item => :LOPHUGNITE,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:DRAINPUNCH, :PLAYROUGH, :ICEPUNCH, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Joris", :HIKER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :GOLOSSUS,
        :level => 61,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :JEWELTAL,
        :level => 61,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Herbert", :HIKER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :DOZAND,
        :level => 34,
        :item => :LEFTOVERS,
        :ability => "",
        :nature => :IMPISH,
        :moves => [:INFESTATION, :PROTECT, :STEALTHROCK, :HYPNOSIS],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Nolan", :HIKER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :HOTTOP,
        :level => 30,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :HOTTOP,
        :level => 30,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :HOTTOP,
        :level => 30,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["BRAVESTAR", :BIKER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BULKER,
        :level => 37,
        :item => :BULKERITE,
        :ability => "",
        :nature => :BRAVE,
        :moves => [:DRAINPUNCH, :CRACKLESLAM, :BULKUP, :IRONHEAD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Benjen", :HIKER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :IGGLE,
        :level => 46,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :IGLOW,
        :level => 48,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CARBONITRO,
        :level => 50,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["David", :HIKER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :RAIZODON,
        :level => 28,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:THUNDERPUNCH, :FIREPUNCH, :ICEPUNCH, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Frederik", :HIKER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :MOOSTRIKE,
        :level => 61,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :NATORON,
        :level => 61,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Kyle", :HIKER,1, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ORITURE,
        :level => 36,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MONSTUNE,
        :level => 36,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MOOSTRIKE,
        :level => 36,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Abraham", :HIKER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :METEROCK,
        :level => 52,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:STONEEDGE, :CRACKLESLAM, :GLACIERCRASH, :SWORDSDANCE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Finley", :HIKER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :COSMET,
        :level => 42,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GOLEMO,
        :level => 42,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Luke", :HIKER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :MOOSTONE,
        :level => 33,
        :item => :CHOPLEBERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:TAKEDOWN, :ROCKSLIDE, :BULLDOZE, :IRONHEAD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GOLEMO,
        :level => 33,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:HAMMERARM, :ROCKSLIDE, :BULLDOZE, :MEGAPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :IGLOW,
        :level => 33,
        :item => :CHOPLEBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:ICICLESPEAR, :ROCKBLAST, :BULLDOZE, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Leon", :HIKER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :CRYSCOON,
        :level => 53,
        :item => :MENTALHERB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:STICKYWEB, :ICEBEAM, :BUGBUZZ, :FLASHCANNON],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LEONITE,
        :level => 53,
        :item => :LIFEORB,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:THUNDERFANG, :ICEFANG, :CRUNCH, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BAABLOCK,
        :level => 53,
        :item => :CHOPLEBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:DOUBLEEDGE, :STONEEDGE, :EARTHQUAKE, :WILDCHARGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Cade", :HIKER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :CRYSTOX,
        :level => 47,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:EARTHQUAKE, :POISONJAB, :STONEEDGE, :PINMISSILE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LEONITE,
        :level => 47,
        :item => :RINDOBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:ROCKSLIDE, :DRILLRUN, :ICEFANG, :THUNDERFANG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FIZIRE,
        :level => 47,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:HEATWAVE, :POWERGEM, :EARTHPOWER, :SCALD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Jason", :HIKER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :GOLKID,
        :level => 20,
        :item => "",
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:ROCKTOMB, :BULLDOZE, :ROCKSMASH, :COMETPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TORON,
        :level => 20,
        :item => "",
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:BULLDOZE, :TAKEDOWN, :ROCKTOMB, :HORNATTACK],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :IGGLE,
        :level => 21,
        :item => "",
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:ICYWIND, :SMACKDOWN, :BARRAGE, :GYROBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Shawn", :HIKER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :GOLKID,
        :level => 19,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:ROCKTOMB, :BRICKBREAK, :BULLDOZE, :FACADE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BOULDOX,
        :level => 19,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:CROSSPOISON, :ROCKTOMB, :BULLDOZE, :FACADE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TORON,
        :level => 19,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:BULLDOZE, :ROCKTOMB, :WILDCHARGE, :TAKEDOWN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Logan", :HIKER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :GOLOSSUS,
        :level => 46,
        :item => :LUMBERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:DRAINPUNCH, :STONEEDGE, :EARTHQUAKE, :ICEPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Reece", :HIKER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BOULDOISE,
        :level => 48,
        :item => :RINDOBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:STONEEDGE, :EARTHQUAKE, :SHELLSMASH, :ZENHEADBUTT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MOOSTRIKE,
        :level => 48,
        :item => :CHOPLEBERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:DOUBLEEDGE, :IRONHEAD, :ROCKSLIDE, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :HIPPOTONE,
        :level => 48,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:EARTHQUAKE, :MEGALOFANG, :ROCKSLIDE, :ICEFANG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Eddard", :HIKER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :CRYSTOX,
        :level => 54,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:ROCKSLIDE, :POISONJAB, :IRONHEAD, :SUPERPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :VOLCADON,
        :level => 54,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:HEATWAVE, :POWERGEM, :EARTHPOWER, :DRAGONPULSE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :COCOROCKO,
        :level => 54,
        :item => :YACHEBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:ROCKSLIDE, :WOODHAMMER, :DRAINPUNCH, :THUNDERPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Julius", :HIKER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :MOLICE,
        :level => 52,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:RAZORBLADE, :GLACIERCRASH, :ICESHARD, :BRICKBREAK],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :IGGLE,
        :level => 52,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :BRAVE,
        :moves => [:ICICLESPEAR, :ROCKBLAST, :ICESHARD, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PINGLETT,
        :level => 52,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:HYPERVOICE, :HYDROPUMP, :CRACKLESLAM, :KNOCKOFF],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Gustav", :HIKER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :CRYSTOX,
        :level => 34,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:ROCKPOLISH, :STONEEDGE, :EARTHQUAKE, :POISONJAB],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Hartmuth", :JANITOR, 0],
    :defeat => "",
    :mons => [
      {
        :species => :STOTOX,
        :level => 16,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :STOTOX,
        :level => 16,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Mattheo", :JANITOR, 0],
    :defeat => "",
    :mons => [
      {
        :species => :FEVA,
        :level => 17,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Paris", :LADY, 0],
    :defeat => "",
    :mons => [
      {
        :species => :DOVEHEART,
        :level => 23,
        :item => :CHARTIBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:DAZZLINGGLEAM, :AIRSLASH, :HIDDENPOWER, :ICYWIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LOPHUG,
        :level => 23,
        :item => :KEBIABERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:HIDDENPOWER, :DAZZLINGGLEAM, :ICYWIND, :GRASSKNOT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Carol", :LADY, 0],
    :defeat => "",
    :mons => [
      {
        :species => :LOPHUG,
        :level => 32,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HYPERVOICE, :ICEBEAM, :THUNDERBOLT, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PIXILILY,
        :level => 32,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:BUGBUZZ, :DAZZLINGGLEAM, :GIGADRAIN, :ICYWIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
    {
    :teamid => ["Jessebelle", :LASS, 0],
    :defeat => "No!",
    :mons => [
      {
        :species => :GWORM,
        :level => 10,
        :item => :TELLURICSEED,
        :ability => :SANDRUSH,
        :nature => :TIMID,
        :moves => [:MUDSHOT, :BUGBITE, :HIDDENPOWERROC, :FACADE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252],
        :statmults => [1,1.1,1,1.1,1,1]
      },
    ]
  },
  {
    :teamid => ["Vinal", :LASS, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SPONY,
        :level => 12,
        :item => :SYNTHETICSEED,
        :ability => :LEAFGUARD,
        :nature => :JOLLY,
        :moves => [:RAZORLEAF, :BULLDOZE, :DOUBLEKICK, :SMACKDOWN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
    ]
  },
  {
    :teamid => ["Andrea", :LASS, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SWELLEGANT,
        :level => 31,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:AIRSLASH, :SCALD, :HEATWAVE, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :AEROMA,
        :level => 31,
        :item => :BIGROOT,
        :ability => "",
        :nature => :TIMID,
        :moves => [:GIGADRAIN, :AIRSLASH, :ROOST, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Raina", :BACKPACKER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :HYPNOSMOG,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:SLUDGEBOMB, :DREAMEATER, :INFESTATION, :SPORE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FLAPINKO,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:HYPERVOICE, :HURRICANE, :CALMMIND, :ROOST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :NAWALE,
        :level => 65,
        :item => :NAWALITE,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:AQUATAIL, :RETURN, :DRILLRUN, :ICESHARD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Missy", :LASS, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PHOXIVEN,
        :level => 22,
        :item => :KEBIABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:DRAININGKISS, :WATERPULSE, :SHOCKWAVE, :ICYWIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Heather", :LASS, 0],
    :defeat => "",
    :mons => [
      {
        :species => :CORALUSH,
        :level => 41,
        :item => :RINDOBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:POWERGEM, :SURF, :ENERGYBALL, :DUSTYDASH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MERMARINE,
        :level => 41,
        :item => :KEBIABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:MOONBLAST, :SURF, :ICEBEAM, :MOONLIGHT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Krista", :LASS, 0],
    :defeat => "",
    :mons => [
      {
        :species => :LOPHUG,
        :level => 43,
        :item => :LOPHUGNITE,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:DRAINPUNCH, :PLAYROUGH, :SOFTBOILED, :ICEPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Cloe", :LASS, 0],
    :defeat => "",
    :mons => [
      {
        :species => :JELLINIP,
        :level => 30,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:SLUDGEBOMB, :SCALD, :ICEBEAM, :SHOCKWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CORALUSH,
        :level => 30,
        :item => :RINDOBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:POWERGEM, :SCALD, :EARTHPOWER, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SEALUG,
        :level => 30,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:SCALD, :SLUDGEBOMB, :SIGNALBEAM, :GIGADRAIN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Lindsey", :LASS, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ELECRITTER,
        :level => 8,
        :ability => :QUICKFEET,
        :nature => :NAIVE,
        :moves => [:THUNDERSHOCK,:TAILWHIP,:POUND,:CHARGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :CHEEPIP,
        :level => 8,
        :ability => :LEAFGUARD,
        :nature => :ADAMANT,
        :moves => [:RAZORLEAF,:PECK,:GROWL,:ABSORB],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Cloe", :LASS,1, 0],
    :defeat => "",
    :mons => [
      {
        :species => :DEERASH,
        :level => 37,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ECLIPSER,
        :level => 37,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Sady", :LASS, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PIXWEE,
        :level => 12,
        :gender => "F",
        :item => :ELEMENTALSEED,
        :ability => :MAGICGUARD,
        :nature => :TIMID,
        :moves => [:QUIVERDANCE,:SILVERWIND,:LIGHTBURST,:HIDDENPOWERGRO],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252],
        :statmults => [1.5,1,1.1,1.2,1.1,1]
      },
    ]
  },
  {
    :teamid => ["Alice", :LEADER_Alice, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SASCRUSH,
        :level => 55,
        :item => :CHOPLEBERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:CRUNCH, :FROSTCLAW, :CLOSECOMBAT, :STONEEDGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :AURORAI,
        :level => 55,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:AURORAVEIL, :BLIZZARD, :THUNDERBOLT, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CARBONITRO,
        :level => 56,
        :item => :CHARTIBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HEATWAVE, :BLIZZARD, :FREEZEDRY, :EARTHPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CRYSTIWING,
        :level => 56,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:BLIZZARD, :BUGBUZZ, :FLASHCANNON, :AURORAVEIL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CRYODRA,
        :level => 56,
        :item => :CRYODRAITE,
        :ability => "",
        :nature => :TIMID,
        :moves => [:BLIZZARD, :DRAGONPULSE, :FLASHCANNON, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :POLARPOW,
        :level => 57,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:CLOSECOMBAT, :FROSTCLAW, :THUNDERPUNCH, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Alice", :LEADER_Alice,1, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SASCRUSH,
        :level => 55,
        :item => :CHOPLEBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:BEATUP, :FROSTCLAW, :SUPERPOWER, :IRONHEAD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :AURORAI,
        :level => 55,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:AURORAVEIL, :BLIZZARD, :THUNDERBOLT, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :RINOTIC,
        :level => 55,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:GLACIERCRASH, :EARTHQUAKE, :CRACKLESLAM, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SNOWRONG,
        :level => 55,
        :item => :COLBURBERRY,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:PHANTOMGRIP, :FROSTCLAW, :FREEZEDRY, :FOULPLAY],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TUNDRILL,
        :level => 55,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:RAZORBLADE, :FROSTCLAW, :ICESHARD, :DRILLRUN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GIGLOO,
        :level => 55,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :QUIET,
        :moves => [:ICESHARD, :FROSTBREATH, :ROCKBLAST, :VACUUMWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SEALBERG,
        :level => 55,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:ICEFANG, :MEGALOFANG, :ZENHEADBUTT, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BLIZZIBAT,
        :level => 55,
        :item => :LIGHTCLAY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:AURORAVEIL, :SLUDGEBOMB, :BLIZZARD, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CARBONITRO,
        :level => 56,
        :item => :CHARTIBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HEATWAVE, :BLIZZARD, :FREEZEDRY, :EARTHPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CRYSTIWING,
        :level => 56,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:BLIZZARD, :BUGBUZZ, :FLASHCANNON, :TAILWIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :POLARPOW,
        :level => 57,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:DRAINPUNCH, :FROSTCLAW, :THUNDERPUNCH, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CRYODRA,
        :level => 57,
        :item => :CRYODRAITE,
        :ability => "",
        :nature => :TIMID,
        :moves => [:BLIZZARD, :DRAGONPULSE, :FLASHCANNON, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Alice", :LEADER_Alice,1, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SNOWRONG,
        :level => 75,
        :item => :COLBURBERRY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:BLIZZARD, :SHADOWBALL, :WILLOWISP, :STEALTHROCK],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :HUSKOLD,
        :level => 75,
        :item => :LIFEORB,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:GLACIERCRASH, :CRUNCH, :CRACKLESLAM, :PLAYROUGH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PINGLADE,
        :level => 75,
        :item => :ICEGEM,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:RETURN, :WATERFALL, :AQUAJET, :CRACKLESLAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GIGLOO,
        :level => 75,
        :item => :CHOICEBAND,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:AVALANCHE, :STONEEDGE, :EARTHQUAKE, :SUPERPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CRYSTIWING,
        :level => 75,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:ICEBEAM, :BUGBUZZ, :FLASHCANNON, :QUIVERDANCE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :POLARPOW,
        :level => 75,
        :item => :SALACBERRY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:GLACIERCRASH, :SUPERPOWER, :KNOCKOFF, :SWORDSDANCE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Amber", :LEADER_Amber, 0],
    :defeat => "",
    :mons => [
      {
        :species => :TAPIBLAZE,
        :level => 36,
        :item => :AIRBALLOON,
        :ability => "",
        :nature => :MODEST,
        :moves => [:MESMERSMOKE, :HEATWAVE, :GIGADRAIN, :EARTHPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FLEAROE,
        :level => 36,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HEATWAVE, :EARTHPOWER, :FAKEOUT, :SOLARBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GASLIT,
        :level => 36,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HEATWAVE, :SHADOWBALL, :ENERGYBALL, :EARTHPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PUPYRO,
        :level => 36,
        :item => :CHARTIBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:SOLARCLAW, :PLAYROUGH, :EARTHPOWER, :SUNNYDAY],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BILLAZE,
        :level => 36,
        :item => :BILLAZENITE,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:HEATCRASH, :RAZORBLADE, :ROCKSLIDE, :TRAILBLAZE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MAGRIZZLY,
        :level => 37,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:DRAINPUNCH, :THUNDERPUNCH, :ROCKSLIDE, :SOLARCLAW],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Amber", :LEADER_Amber,1, 0],
    :defeat => "",
    :mons => [
      {
        :species => :GASLIT,
        :level => 75,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FLAMETHROWER, :HEX, :WILLOWISP, :GRUDGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SHRIMPOON,
        :level => 75,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:SCALD, :LAVAPLUME, :EARTHPOWER, :AQUAJET],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BLITZIBOOM,
        :level => 75,
        :item => :CHOICESPECS,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FIREWORKS, :THUNDERBOLT, :FIREBLAST, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TIKITOKO,
        :level => 75,
        :item => :LIFEORB,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:SOLARBEAM, :FIERYDANCE, :WILLOWISP, :HEX],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LEGENIX,
        :level => 75,
        :item => :HEATROCK,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:LAVAPLUME, :SQUALLBLOW, :ROOST, :SUNNYDAY],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MAGRIZZLY,
        :level => 75,
        :item => :LANSATBERRY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FLAREBLITZ, :DRAINPUNCH, :ROCKSLIDE, :BULKUP],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Bailey", :LEADER_Bailey, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SCROW,
        :level => 51,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:PHANTOMGRIP, :LEAFBLADE, :STONEEDGE, :XSCISSOR],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :KONGRILLA,
        :level => 51,
        :item => :COBABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:DRAINPUNCH, :ICEPUNCH, :MACHPUNCH, :WOODHAMMER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PARADISO,
        :level => 51,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:WEATHERBALL, :ENERGYBALL, :ICEBEAM, :TRAILBLAZE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :HORSHUSH,
        :level => 52,
        :item => :COBABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:FLOWERTRICK, :HIGHHORSEPOWER, :ROCKSLIDE, :SUPERPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MOUNTREE,
        :level => 52,
        :item => :MOUNTREENITE,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:HEADSMASH, :WOODHAMMER, :HIGHHORSEPOWER, :LEAFDARTS],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FRUGON,
        :level => 53,
        :item => :LUMBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:POWERWHIP, :DRAGONDANCE, :NATURESFORCE, :HIGHHORSEPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Bailey", :LEADER_Bailey,1, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BUSHAIRY,
        :level => 75,
        :item => :LIGHTCLAY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:GIGADRAIN, :BODYSLAM, :REFLECT, :LEECHSEED],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :COCOROCKO,
        :level => 75,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:SEEDBOMB, :STONEEDGE, :KNOCKOFF, :POWERUPPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BRACHIODON,
        :level => 75,
        :item => :LEFTOVERS,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:GEOSPHERE, :GIGADRAIN, :GRASSYTERRAIN, :SYNTHESIS],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :WOODAWN,
        :level => 75,
        :item => :CHOICESCARF,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:BULLETSEED, :BRAVEBIRD, :ROCKBLAST, :DRILLRUN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SCROW,
        :level => 75,
        :item => :REDCARD,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:LEAFBLADE, :PHANTOMGRIP, :SUCKERPUNCH, :DESTINYBOND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :KONGRILLA,
        :level => 75,
        :item => :COBABERRY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:WOODHAMMER, :HAMMERARM, :THUNDERPUNCH, :BULKUP],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Damon", :LEADER_Damon, 0],
    :defeat => "The sun always rises eventually...",
    :mons => [
      {
        :species => :APEIN,
        :level => 20,
        :item => :TELLURICSEED,
        :ability => :DEFIANT,
        :nature => :JOLLY,
        :moves => [:BEATUP, :DRAINPUNCH, :HEADBUTT, :ROCKTOMB],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :GLOCOON,
        :level => 20,
        :item => :EVIOLITE,
        :ability => :ILLUMINATE,
        :nature => :MODEST,
        :shiny => true,
        :moves => [:SIGNALBEAM, :LIGHTNINGSTRIKE, :HIDDENPOWERWAT, :LIGHTBURST],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
      {
        :species => :SYRILL,
        :level => 20,
        :item => :FOCUSSASH,
        :ability => :INSOMNIA,
        :nature => :TIMID,
        :moves => [:NASTYPLOT, :HEX, :AIRSLASH, :HIDDENPOWERFIG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :SNOOZEE,
        :level => 20,
        :item => :CLEARAMULET,
        :ability => :ANTICIPATION,
        :nature => :BOLD,
        :moves => [:HEX, :LIGHTBURST, :MOONLIGHT, :CALMMIND],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 0, 252, 0, 0, 0]
      },
      {
        :species => :DRACUBAT,
        :level => 21,
        :item => :CHARTIBERRY,
        :ability => :BLOODTHIRST,
        :nature => :JOLLY,
        :moves => [:DIG, :WINGATTACK, :BITE, :STEELWING],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :WEREHIDE,
        :level => 22,
        :item => :ROSELIBERRY,
        :ability => :INSOMNIA,
        :nature => :ADAMANT,
        :moves => [:BITE, :FIREFANG, :ICEFANG, :POISONFANG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
    ]
  },
  {
    :teamid => ["Damon", :LEADER_Damon,1, 0],
    :defeat => "",
    :mons => [
      {
        :species => :TARATERROR,
        :level => 75,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:CRUNCH, :XSCISSOR, :STICKYWEB, :DESTINYBOND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LISQUID,
        :level => 75,
        :item => :TOXICORB,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:SCALD, :KNOCKOFF, :DISABLE, :PROTECT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :COUNTULA,
        :level => 75,
        :item => :ROSELIBERRY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:GALERUSH, :TAILWIND, :SUPERFANG, :UTURN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TROLLGER,
        :level => 75,
        :item => :LIFEORB,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:SUCKERPUNCH, :PLAYROUGH, :FIREPUNCH, :THUNDERPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MONSTRAP,
        :level => 75,
        :item => :TANGABERRY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:POWERWHIP, :SUCKERPUNCH, :EARTHQUAKE, :POISONJAB],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :WEREHIDE,
        :level => 75,
        :item => :LUMBERRY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:CRUNCH, :PLAYROUGH, :PURSUIT, :REVERSAL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Donna", :LEADER_Donna, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SLIBLOO,
        :level => 11,
        :item => :ROCKYHELMET,
        :ability => :LIQUIDOOZE,
        :nature => :TIMID,
        :moves => [:MEGADRAIN, :ACIDSPRAY, :STRUGGLEBUG, :ACIDARMOR],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 0, 116, 0, 0, 136]
      },
      {
        :species => :BARBALL,
        :level => 11,
        :item => :BLACKSLUDGE,
        :ability => :IRONBARBS,
        :nature => :CAREFUL,
        :moves => [:TOXIC, :SPIKYSHIELD, :POISONSTING, :INFESTATION],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 0, 0, 0, 252, 0]
      },
      {
        :species => :SNAZAP,
        :level => 11,
        :ability => :UNNERVE,
        :nature => :TIMID,
        :moves => [:ACID, :THUNDERSHOCK, :HIDDENPOWERGRA, :SUPERFANG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :TADART,
        :level => 11,
        :item => :COBABERRY,
        :ability => :LEAFGUARD,
        :nature => :TIMID,
        :moves => [:LEAFTORNADO, :ACID, :WATERPULSE, :SNARL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :POIPOLE,
        :level => 11,
        :item => :FOCUSSASH,
        :ability => :SEMIAQUATIC,
        :nature => :TIMID,
        :moves => [:ACID, :WATERPULSE, :FAKEOUT, :MUDBOMB],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :TOXIDON,
        :level => 12,
        :item => :SYNTHETICSEED,
        :ability => :POISONPOINT,
        :nature => :ADAMANT,
        :moves => [:POISONTAIL, :SANDTOMB, :FIREFANG, :PINMISSILE],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Donna", :LEADER_Donna,1, 0],
    :defeat => "",
    :mons => [
      {
        :species => :CRYSTOX,
        :level => 75,
        :item => :CUSTAPBERRY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:STONEEDGE, :TOXICSPIKES, :SPIKES, :EXPLOSION],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FUNGERM,
        :level => 75,
        :item => :BLACKSLUDGE,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:SULFURICSPRAY, :SPORE, :INFESTATION, :RECOVER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DARTOAD,
        :level => 75,
        :item => :DAMPROCK,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:GIGADRAIN, :VENOSHOCK, :TOXIC, :RAINDANCE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :KINIP,
        :level => 75,
        :item => :ROCKYHELMET,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:SCALD, :BIDE, :RECOVER, :SPIKYSHIELD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BLIZZIBAT,
        :level => 75,
        :item => :EXPERTBELT,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:ICEBEAM, :SULFURICSPRAY, :GIGADRAIN, :SHADOWBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FEVESTA,
        :level => 75,
        :item => :RINGTARGET,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:DARKPULSE, :SLUDGEWAVE, :TRICK, :TEETERDANCE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Dustin", :LEADER_Dustin, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SANDUGG,
        :level => 28,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :CALM,
        :moves => [:PROTECT, :INFESTATION, :STEALTHROCK, :SPIKES],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MONSTUNE,
        :level => 28,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:DUSTYDASH, :DARKPULSE, :HIDDENPOWER, :HEATWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DOZAND,
        :level => 28,
        :item => :LEFTOVERS,
        :ability => "",
        :nature => :BRAVE,
        :moves => [:ICEPUNCH, :FIREPUNCH, :PHANTOMGRIP, :EARTHPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ORITURE,
        :level => 28,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:DRILLRUN, :ROCKSLIDE, :ZENHEADBUTT, :ICEFANG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :METEROCK,
        :level => 28,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:GALERUSH, :CRACKLESLAM, :ROCKSLIDE, :IRONHEAD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :WORMOLE,
        :level => 29,
        :item => :OCCABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:COIL, :XSCISSOR, :DRILLRUN, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Dustin", :LEADER_Dustin,1, 0],
    :defeat => "",
    :mons => [
      {
        :species => :DOZAND,
        :level => 75,
        :item => :APICOTBERRY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:EARTHQUAKE, :NIGHTMARE, :REST, :SLEEPTALK],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ROOBEOP,
        :level => 75,
        :item => :MUSCLEBAND,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:HIGHJUMPKICK, :EARTHQUAKE, :BOUNCE, :ICEPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CASSAND,
        :level => 75,
        :item => :CHESTOBERRY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:INFESTATION, :TOXIC, :SPIKYSHIELD, :REST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :RAIZODON,
        :level => 75,
        :item => :LIFEORB,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:EARTHQUAKE, :CRACKLESLAM, :FIREBLAST, :ICEBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SNAPIKE,
        :level => 75,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:EARTHQUAKE, :GUNKSHOT, :DRAINPUNCH, :STONEEDGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MONSTUNE,
        :level => 75,
        :item => :LEFTOVERS,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:EARTHPOWER, :DARKPULSE, :HEATWAVE, :NASTYPLOT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Electra", :LEADER_Electra, 0],
    :defeat => "",
    :mons => [
      {
        :species => :HUMMZAP,
        :level => 23,
        :item => :CHARTIBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:DISCHARGE, :AIRSLASH, :HIDDENPOWER, :DRILLRUN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :STEGRON,
        :level => 23,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:GEODECANNON, :FLASHCANNON, :SIGNALBEAM, :THUNDERBOLT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :COBOLTA,
        :level => 23,
        :item => :AIRBALLOON,
        :ability => "",
        :nature => :TIMID,
        :moves => [:DISCHARGE, :SULFURICSPRAY, :HIDDENPOWER, :SIGNALBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SHARKO,
        :level => 23,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:CRACKLESLAM, :MEGALOFANG, :CRUNCH, :ICEFANG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GLOWING,
        :level => 23,
        :item => :OCCABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SIGNALBEAM, :HIDDENPOWER, :LIGHTNINGSTRIKE, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :RUSHOT,
        :level => 24,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:CRACKLESLAM, :ICEFANG, :HEATWAVE, :IRONTAIL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Electra", :LEADER_Electra,1, 0],
    :defeat => "",
    :mons => [
      {
        :species => :EELECT,
        :level => 75,
        :item => :LEFTOVERS,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:MEGALOFANG, :CRACKLESLAM, :COIL, :DRAGONDANCE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TERRAVOLT,
        :level => 75,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:VOLTSWITCH, :AIRSLASH, :PARABOLICCHARGE, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ATOMOTRIX,
        :level => 75,
        :item => :WISEGLASSES,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:DISCHARGE, :FLASHCANNON, :ENERGYBALL, :FOCUSBLAST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SIGNILEAF,
        :level => 75,
        :item => :OCCABERRY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:DISCHARGE, :SOLARBEAM, :MORNINGSUN, :SUNNYDAY],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CHEETRIC,
        :level => 75,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:DARKPULSE, :ELECTROBALL, :THUNDERWAVE, :VOLTSWITCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :RUSHOT,
        :level => 75,
        :item => :ELECTRICGEM,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:ELECTROBALL, :EXTREMESPEED, :HEATWAVE, :GALERUSH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Misty", :LEADER_Misty, 0],
    :defeat => "",
    :mons => [
      {
        :species => :POOLDOG,
        :level => 37,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:MEGALOFANG, :AQUAJET, :GLACIERCRASH, :WILDCHARGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :KELPULA,
        :level => 37,
        :item => :COBABERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:AQUATAIL, :LEAFBLADE, :ICEBEAM, :BRICKBREAK],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :VALURE,
        :level => 37,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:SURF, :PSYCHIC, :SIGNALBEAM, :GIGADRAIN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CORALUSH,
        :level => 37,
        :item => :RINDOBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:POWERGEM, :SURF, :ICEBEAM, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :KAPPLASH,
        :level => 37,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:RIPPLEWAVE, :PSYSHOCK, :SIGNALBEAM, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DOFLAP,
        :level => 38,
        :item => :LIFEORB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HYDROPUMP, :ICEBEAM, :SIGNALBEAM, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Misty", :LEADER_Misty,1, 0],
    :defeat => "",
    :mons => [
      {
        :species => :KAPPLASH,
        :level => 41,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:RIPPLEWAVE, :PSYSHOCK, :ICEBEAM, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :POOLDOG,
        :level => 41,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:MEGALOFANG, :AQUAJET, :ICEFANG, :WILDCHARGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :KELPULA,
        :level => 41,
        :item => :COBABERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:AQUATAIL, :LEAFBLADE, :ICEBEAM, :BRICKBREAK],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :VALURE,
        :level => 41,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:RIPPLEWAVE, :PSYCHIC, :ICEBEAM, :GIGADRAIN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CORALUSH,
        :level => 41,
        :item => :RINDOBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:POWERGEM, :MUDDYWATER, :ICEBEAM, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DOFLAP,
        :level => 42,
        :item => :LIFEORB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HYDROPUMP, :ICEBEAM, :SIGNALBEAM, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Wade", :LEADER_Wade, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SILVICIOUS,
        :level => 60,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:WAVECRASH, :HEADSMASH, :IRONTAIL, :CRACKLESLAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SALASLAM,
        :level => 61,
        :item => :LIFEORB,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:GUNKSHOT, :AQUAJET, :LIQUIDATION, :ICEPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MARKRUSH,
        :level => 60,
        :item => :COVERTCLOAK,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:WAVECRASH, :VOLTTACKLE, :IRONTAIL, :ICEFANG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BEAUTIFIN,
        :level => 60,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :BOLD,
        :moves => [:SCALEBASH, :BODYPRESS, :PSYCHIC, :GIGADRAIN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SMAQUA,
        :level => 62,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:DRAINPUNCH, :AQUATAIL, :MACHPUNCH, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rodney", :Rodney,500, 0],
    :defeat => "",
    :mons => [
      {
        :species => :FEVESTA,
        :level => 60,
        :item => :AIRBALLOON,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:BEATUP, :SLUDGEWAVE, :HIDDENPOWER, :THUNDERWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DRACOFLY,
        :level => 60,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:MEGAHORN, :DRAGONRUSH, :IRONTAIL, :FACADE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BAABREEZE,
        :level => 60,
        :item => :POWERHERB,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:SKYATTACK, :DIG, :TAILWIND, :NATUREPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TERRAVOLT,
        :level => 60,
        :item => :LIGHTCLAY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:LIGHTSCREEN, :REFLECT, :THUNDER, :SQUALLBLOW],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BULKER,
        :level => 61,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:DRAINPUNCH, :ICEPUNCH, :THUNDERPUNCH, :IRONHEAD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Wade", :LEADER_Wade,1, 0],
    :defeat => "",
    :mons => [
      {
        :species => :KAPPLASH,
        :level => 75,
        :item => :EJECTBUTTON,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:HYDROPUMP, :PSYSHOCK, :SHADOWBALL, :DISABLE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :JELLIKING,
        :level => 75,
        :item => :LEFTOVERS,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:WATERSPOUT, :RIPPLEWAVE, :ICEBEAM, :REST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PARADISO,
        :level => 75,
        :item => :LUMBERRY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:RIPPLEWAVE, :GIGADRAIN, :YAWN, :SAFEGUARD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MERSIDON,
        :level => 75,
        :item => :RINDOBERRY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:THUNDER, :RIPPLEWAVE, :ICEBEAM, :RAINDANCE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CORALTLE,
        :level => 75,
        :item => :WHITEHERB,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:POWERGEM, :WATERSPOUT, :RECOVER, :SHELLSMASH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TIDUDE,
        :level => 75,
        :item => :LIFEORB,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:RIPPLEWAVE, :FOCUSBLAST, :KNOCKOFF, :AQUAJET],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Beacon", :LIGHTHOUSEKEEPER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :DODONT,
        :level => 43,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:EARTHQUAKE, :BRAVEBIRD, :ROCKSLIDE, :BRICKBREAK],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CIRRIBUS,
        :level => 43,
        :item => :CIRRIBUSITE,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SQUALLBLOW, :THUNDERBOLT, :DISCHARGE, :HEATWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SYPHOON,
        :level => 43,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:TAILWIND, :SHADOWBALL, :AEROBLAST, :WILLOWISP],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :COUNTULA,
        :level => 43,
        :item => :FLYINGGEM,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:ACROBATICS, :GIGADRAIN, :POISONJAB, :CRUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MELOTWEET,
        :level => 43,
        :item => :LIFEORB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:DAZZLINGGLEAM, :HEATWAVE, :PSYCHIC, :TAILWIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BLIMPOON,
        :level => 44,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SQUALLBLOW, :FLASHCANNON, :HEATWAVE, :AIRCANNON],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Marcus", :LUNAROFFICIER_Marcus,1, 0],
    :defeat => "",
    :mons => [
      {
        :species => :GHOULLOW,
        :level => 48,
        :item => :KASIBBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:HYPNOSIS, :SLACKOFF, :SHADOWBALL, :MOONBLAST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SPIRIX,
        :level => 48,
        :item => :COLBURBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HYPERVOICE, :SHADOWBALL, :DAZZLINGGLEAM, :NASTYPLOT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TARATERROR,
        :level => 48,
        :item => :OCCABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:PURSUIT, :PINMISSILE, :CRUNCH, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SPECSTONE,
        :level => 48,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:GEODECANNON, :SHADOWBALL, :EARTHPOWER, :SIGNALBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :COUNTULA,
        :level => 48,
        :item => :FLYINGGEM,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:ACROBATICS, :CRUNCH, :FOCUSBLAST, :ICEBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SKELEDEEP,
        :level => 49,
        :item => :SKELEDEEPITE,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:LIQUIDATION, :AQUAJET, :PHANTOMGRIP, :ICEFANG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Marcus", :LUNAROFFICIER_Marcus, 0],
    :defeat => "",
    :mons => [
      {
        :species => :GRAVOLE,
        :level => 30,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:POWERGEM, :SHADOWBALL, :PSYCHIC, :EARTHPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TARATERROR,
        :level => 30,
        :item => :COBABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:XSCISSOR, :CRUNCH, :RAZORBLADE, :ELECTROWEB],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SNOOZEE,
        :level => 30,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :BRAVE,
        :moves => [:HYPNOSIS, :NIGHTSHADE, :DAZZLINGGLEAM, :PHANTOMGRIP],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SKELEDEEP,
        :level => 30,
        :item => :COLBURBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:AQUAJET, :MEGALOFANG, :ICEFANG, :SHADOWCLAW],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DARTOAD,
        :level => 30,
        :item => :OCCABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SLUDGEBOMB, :GIGADRAIN, :SCALD, :ICYWIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :COUNTULA,
        :level => 31,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:NIGHTSLASH, :GALERUSH, :GIGADRAIN, :ZENHEADBUTT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Scarlett", :LUNAROFFICIER_Scarlett, 0],
    :defeat => "Drat!",
    :mons => [
      {
        :species => :SKREECH,
        :level => 14,
        :item => :WISEGLASSES,
        :ability => :ANTICIPATION,
        :nature => :TIMID,
        :moves => [:ECHOEDVOICE, :SNARL, :OMINOUSWIND, :HIDDENPOWERGRO],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :SURFIDE,
        :level => 14,
        :item => :RINDOBERRY,
        :ability => :COMPETITIVE,
        :nature => :TIMID,
        :moves => [:WATERPULSE, :ICYWIND, :VACUUMWAVE, :ROUND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :TAPIRE,
        :level => 14,
        :item => :PETAYABERRY,
        :ability => :GLUTTONY,
        :nature => :MODEST,
        :moves => [:FLAMEBURST, :SLUDGE, :BULLDOZE, :SLACKOFF],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
      {
        :species => :SQUIDART,
        :level => 15,
        :item => :FOCUSSASH,
        :ability => :DARKAURA,
        :nature => :TIMID,
        :moves => [:AQUAJET, :DARKMATTER, :WATERPULSE, :ICYWIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
    ]
  },
  {
    :teamid => ["Scarlett", :LUNAROFFICIER_Scarlett,1, 0],
    :defeat => "",
    :mons => [
      {
        :species => :FUNGERM,
        :level => 39,
        :item => :LIGHTCLAY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SULFURICSPRAY, :LIGHTSCREEN, :REFLECT, :TOXICSPIKES],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :HUSKOLD,
        :level => 39,
        :item => :LIFEORB,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:ICICLECRASH, :ICESHARD, :WILDCHARGE, :IRONTAIL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SWAMPHEAP,
        :level => 39,
        :item => :TANGABERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:LEECHSEED, :PROTECT, :SUCKERPUNCH, :GUNKSHOT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SNAPIKE,
        :level => 39,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:EARTHQUAKE, :POISONJAB, :STONEEDGE, :FIREPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BANSCREAM,
        :level => 39,
        :item => :COLBURBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:GHASTLYWAIL, :PSYSHOCK, :VACUUMWAVE, :NASTYPLOT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LISQUID,
        :level => 40,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:LIQUIDATION, :CRUNCH, :ICEBEAM, :SUCKERPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Yvonne", :NURSE, 0],
    :defeat => "Oh, now that just won't do at all.",
    :mons => [
      {
        :species => :BUDCHEEP,
        :level => 11,
        :item => :WACANBERRY,
        :ability => :RATTLED,
        :nature => :MODEST,
        :moves => [:ROUND,:PECK,:HIDDENPOWERGRA,:TOXIC],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
      {
        :species => :MOOSTONE,
        :level => 11,
        :ability => :RIVALRY,
        :nature => :ADAMANT,
        :moves => [:ROCKTHROW,:HEADBUTT,:TRAILBLAZE,:ROCKSMASH],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
      {
        :species => :TWEETOT,
        :level => 11,
        :item => :MAGICALSEED,
        :ability => :OWNTEMPO,
        :nature => :TIMID,
        :moves => [:DISARMINGVOICE,:CONFUSION,:ECHOEDVOICE,:HIDDENPOWERGRO],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
      {
        :species => :RUBBALL,
        :level => 12,
        :item => :EVIOLITE,
        :ability => :BOUNCY,
        :nature => :MODEST,
        :moves => [:SWIFT,:HIDDENPOWERPSY,:PUNISHMENT,:ROCKSMASH],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Claire", :NURSE, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ATOMIX,
        :level => 25,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DEERBIE,
        :level => 25,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Lucilla", :NURSE, 0],
    :defeat => "",
    :mons => [
      {
        :species => :RUBBALL,
        :level => 9,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TWEETOT,
        :level => 9,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Chantal", :NURSE, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ARCTICHARE,
        :level => 48,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Ira", :NURSE, 0],
    :defeat => "",
    :mons => [
      {
        :species => :KAHULA,
        :level => 35,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :KELPULA,
        :level => 35,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Madeline", :NURSERYAIDE, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SNUFFUZZ,
        :level => 12,
        :item => :CHOPLEBERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:HYPERFANG, :BITE, :BABYDOLLEYES, :DEFENSECURL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Aleida", :PARASOLLADY, 0],
    :defeat => "",
    :mons => [
      {
        :species => :FLOWBY,
        :level => 16,
        :item => :WACANBERRY,
        :ability => :WATERBUBBLE,
        :nature => :TIMID,
        :moves => [:BUBBLEBEAM,:SHOCKWAVE,:AIRCUTTER,:ICYWIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :ANGLING,
        :level => 16,
        :item => :MYSTICWATER,
        :ability => :SWIFTSWIM,
        :nature => :MODEST,
        :moves => [:BRINE,:ROUND,:ICYWIND,:HIDDENPOWERGRA],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
      {
        :species => :TADART,
        :level => 16,
        :item => :BLACKSLUDGE,
        :ability => :RAINDISH,
        :nature => :MODEST,
        :moves => [:MEGADRAIN,:SLUDGE,:WATERPULSE,:ROUND],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Jessica", :PkMnBREADER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :AEROMA,
        :level => 24,
        :item => :YACHEBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:GIGADRAIN, :AIRSLASH, :DAZZLINGGLEAM, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FROGOO,
        :level => 24,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SLUDGEBOMB, :BUBBLEBEAM, :SHADOWBALL, :ZENHEADBUTT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Leonardo", :PkMnBREADER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :POOLDOG,
        :level => 25,
        :item => :LEFTOVERS,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:SLACKOFF, :AQUASLAM, :ICEFANG, :CRUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Layla", :PkMnRANGER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :GROILLA,
        :level => 45,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TIKIKI,
        :level => 45,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LAZLOTH,
        :level => 45,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Carla", :PkMnRANGER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :GIRAFLAME,
        :level => 32,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:FLAMECHARGE, :ENERGYBALL, :DAZZLINGGLEAM, :FLAMETHROWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Tamina", :PkMnRANGER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BLITZIGLOW,
        :level => 43,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ECLIPSER,
        :level => 43,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :JEWELTAL,
        :level => 43,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Shandra", :PkMnRANGER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :WEASHOCK,
        :level => 31,
        :item => :LIFEORB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:THUNDERBOLT, :GRASSKNOT, :DAZZLINGGLEAM, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FYANT,
        :level => 31,
        :item => :CHARTIBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:BUGBUZZ, :SLUDGEBOMB, :FLAMETHROWER, :GIGADRAIN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Mae", :PkMnRANGER_Female, 0],
    :defeat => "Mystical...",
    :mons => [
      {
        :species => :BLITZY,
        :level => 15,
        :item => :CHARCOAL,
        :ability => :LEVITATE,
        :nature => :TIMID,
        :moves => [:INCINERATE,:SHOCKWAVE,:ROUND,:WILLOWISP],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :PHOXY,
        :level => 15,
        :item => :BERRYJUICE,
        :ability => :FAIRYAURA,
        :nature => :TIMID,
        :moves => [:DRAININGKISS,:DUSTYDASH,:HIDDENPOWERFIR,:ROUND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :GROILLA,
        :level => 15,
        :item => :EVIOLITE,
        :ability => :OVERGROW,
        :nature => :JOLLY,
        :moves => [:RAZORLEAF,:KARATECHOP,:BULLDOZE,:ROCKTOMB],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
    ]
  },
  {
    :teamid => ["Dalia", :PkMnRANGER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :TOXITOAD,
        :level => 38,
        :item => :LEFTOVERS,
        :ability => "",
        :nature => :BOLD,
        :moves => [:TOXIC, :PROTECT, :VENOSHOCK, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GECKONE,
        :level => 38,
        :item => :EXPERTBELT,
        :ability => "",
        :nature => :TIMID,
        :moves => [:CHARGEBEAM, :PSYSHOCK, :SHADOWBALL, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :KAPPLASH,
        :level => 38,
        :item => :RINDOBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:SURF, :PSYCHIC, :ICEBEAM, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Frances", :PkMnRANGER_Female, 0],
    :defeat => "Not bad!",
    :mons => [
      {
        :species => :LOPHUG,
        :level => 18,
        :item => :PIXIEPLATE,
        :ability => "",
        :nature => :HARDY,
        :moves => [:BRICKBREAK, :DOUBLESLAP, :DOUBLEHIT, :MOONLIGHT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :BRACHIO,
        :level => 18,
        :item => :COBABERRY,
        :ability => :THICKFAT,
        :nature => :QUIET,
        :moves => [:BULLDOZE, :MEGADRAIN, :GEOSPHERE, :SYNTHESIS],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Edie", :PkMnRANGER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :CASSPRING,
        :level => 21,
        :item => :CHARTIBERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:SWORDSDANCE, :XSCISSOR, :GALERUSH, :BRICKBREAK],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Lina", :PkMnRANGER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SIGNILEAF,
        :level => 60,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GHOULLOW,
        :level => 60,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MOSSNAIL,
        :level => 60,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Austin", :PkMnRANGER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :WEREHIDE,
        :level => 32,
        :item => :LIFEORB,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:CRUNCH, :FIREFANG, :ICEFANG, :THUNDERFANG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Luke", :PkMnRANGER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PHOXIVEN,
        :level => 39,
        :item => :KEBIABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:DAZZLINGGLEAM, :THUNDERBOLT, :ENERGYBALL, :MYSTICALFIRE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PIXILILY,
        :level => 39,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:BUGBUZZ, :DAZZLINGGLEAM, :GIGADRAIN, :AIRSLASH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TROLLERK,
        :level => 39,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:PLAYROUGH, :KNOCKOFF, :FIREPUNCH, :THUNDERPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Linus", :PkMnRANGER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ATOMOTRO,
        :level => 43,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GRENATRIC,
        :level => 43,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MOOSTRIKE,
        :level => 43,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Harley", :PkMnRANGER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :TAPIBLAZE,
        :level => 49,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:SLUDGEBOMB, :FIREBLAST, :EARTHPOWER, :GIGADRAIN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LAVENRINA,
        :level => 49,
        :item => :KEBIABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SLEEPPOWDER, :MOONBLAST, :ENERGYBALL, :DUSTYDASH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SASCRUSH,
        :level => 49,
        :item => :CHOPLEBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:CRUNCH, :MEGAPUNCH, :FAKEOUT, :ICEPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Adam", :PkMnRANGER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PARAFUL,
        :level => 31,
        :item => "",
        :ability => "",
        :nature => :JOLLY,
        :moves => [:CRUSHCLAW, :ACROBATICS, :STEELWING, :SHADOWCLAW],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ZEBRITE,
        :level => 31,
        :item => :COLBURBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:MINDBLAST, :ICYWIND, :DAZZLINGGLEAM, :SHADOWBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rudy", :PkMnRANGER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :MOONKY,
        :level => 14,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ANGLING,
        :level => 14,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:WATERPULSE, :AQUAJET, :CHARM, :DRAININGKISS],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Brad", :PkMnRANGER_Male, 0],
    :defeat => "What?",
    :mons => [
      {
        :species => :GECKONE,
        :level => 19,
        :item => :WISEGLASSES,
        :ability => :PROTEAN,
        :nature => :TIMID,
        :moves => [:PSYBEAM, :CHARGEBEAM, :ICYWIND, :SIGNALBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
    ]
  },
  {
    :teamid => ["Phil", :PkMnRANGER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :DINOMITE,
        :level => 18,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["S_G", :PkMnRANGER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :FLEAROE,
        :level => 61,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:HEATWAVE, :EARTHPOWER, :SOLARBEAM, :CRACKLESLAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SIGNILEAF,
        :level => 61,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:DISCHARGE, :ENERGYBALL, :DAZZLINGGLEAM, :WEATHERBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CARBONITRO,
        :level => 61,
        :item => :CHARTIBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:BLIZZARD, :HEATWAVE, :EARTHPOWER, :SCALD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :EQWATER,
        :level => 61,
        :item => :COBABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SCALD, :SOLARBEAM, :ICEBEAM, :WEATHERBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MERSIDON,
        :level => 61,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SCALD, :THUNDERBOLT, :ENERGYBALL, :ICEBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BULKER,
        :level => 61,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:HAMMERARM, :MACHPUNCH, :ICEPUNCH, :THUNDERPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Dazed", :ROUGHNECK, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ELESTOMP,
        :level => 61,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:EARTHQUAKE, :PHANTOMGRIP, :GUNKSHOT, :STONEEDGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PUPLASH,
        :level => 61,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HYDROPUMP, :MOONBLAST, :ICEBEAM, :DUSTYDASH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PUPYRO,
        :level => 61,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:SOLARCLAW, :PLAYROUGH, :EARTHPOWER, :FLAMECHARGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SHRIMPOON,
        :level => 61,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:FIREBLAST, :SCALD, :FLAMECHARGE, :GIGADRAIN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SILVICIOUS,
        :level => 61,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:WAVECRASH, :IRONTAIL, :AQUAJET, :HEADSMASH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :KONGRILLA,
        :level => 61,
        :item => :COBABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:TRAILBLAZE, :DRAINPUNCH, :WOODHAMMER, :ICEPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Mizz", :WAITER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :WORMOLE,
        :level => 61,
        :item => :OCCABERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:EARTHQUAKE, :XSCISSOR, :STONEEDGE, :IRONTAIL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PSYFLOCK,
        :level => 61,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:EXPANDINGFORCE, :SQUALLBLOW, :HEATWAVE, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MOUNTREE,
        :level => 61,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:PETALBLIZZARD, :ROCKSLIDE, :SUPERPOWER, :IRONTAIL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ECLIPSER,
        :level => 61,
        :item => :COLBURBERRY,
        :ability => "",
        :nature => :QUIET,
        :moves => [:EXPANDINGFORCE, :POWERGEM, :TRICKROOM, :OVERHEAT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :HIPPOTONE,
        :level => 61,
        :item => :RINDOBERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:WAVECRASH, :HIGHHORSEPOWER, :GUNKSHOT, :STONEEDGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CASSAND,
        :level => 61,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:BODYPRESS, :MEGAHORN, :DRILLRUN, :STONEEDGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["necro", :WORKER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :FLEAROE,
        :level => 62,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:FIREBLAST, :EARTHPOWER, :FAKEOUT, :CRACKLESLAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GOLOSSUS,
        :level => 62,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:COMETPUNCH, :DRAINPUNCH, :METEORMASH, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CORALTLE,
        :level => 62,
        :item => :RINDOBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:HYDROPUMP, :GEODECANNON, :ICEBEAM, :THUNDERBOLT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DINOPION,
        :level => 62,
        :item => :COBABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:CLOSECOMBAT, :IRONTAIL, :DRAGONRUSH, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SPECSTONE,
        :level => 62,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SHADOWBALL, :GEODECANNON, :EARTHPOWER, :SIGNALBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :COBOLTA,
        :level => 62,
        :item => :LIFEORB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SLUDGEWAVE, :THUNDERBOLT, :AQUATAIL, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["PhantomNavik", :BIRDKEEPER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :CASSPRING,
        :level => 62,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:STICKYWEB, :ATTACKORDER, :GALERUSH, :HIGHJUMPKICK],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MOSLIQUO,
        :level => 62,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:SWORDSDANCE, :PINMISSILE, :WATERSHURIKEN, :BULLETSEED],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PHAROBE,
        :level => 62,
        :item => :COBABERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:ICEPUNCH, :BODYPRESS, :PHANTOMGRIP, :THUNDERPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :WOODAWN,
        :level => 62,
        :item => :YACHEBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:BULLETSEED, :ROCKBLAST, :PINMISSILE, :TRAILBLAZE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PARABOW,
        :level => 62,
        :item => :LIFEORB,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:TAILSLAP, :TALONGASH, :HIDDENPOWER, :HEATWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TERRAVOLT,
        :level => 62,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HURRICANE, :THUNDER, :ENERGYBALL, :HEATWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Icyalex", :BIRDKEEPER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BLIMPOON,
        :level => 62,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SQUALLBLOW, :HEATWAVE, :FLASHCANNON, :AIRCANNON],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BAABREEZE,
        :level => 62,
        :item => :LIFEORB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SQUALLBLOW, :HYPERVOICE, :DAZZLINGGLEAM, :HEATWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CIRRIBUS,
        :level => 62,
        :item => :COVERTCLOAK,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SQUALLBLOW, :BLIZZARD, :THUNDERBOLT, :HEATWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PUFFPEAK,
        :level => 62,
        :item => :OCCABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SQUALLBLOW, :BLIZZARD, :THUNDERBOLT, :FLASHCANNON],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GLYDFIN,
        :level => 62,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HYPERVOICE, :HEATWAVE, :MUDDYWATER, :ICEBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DODONT,
        :level => 62,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:EARTHQUAKE, :BRAVEBIRD, :HEADSMASH, :DOUBLEEDGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["foca", :SWIMMER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :NAWALE,
        :level => 62,
        :item => :EJECTBUTTON,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:AQUATAIL, :GLACIERCRASH, :DRILLRUN, :SACREDSWORD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FLAPINKO,
        :level => 62,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HURRICANE, :HYPERVOICE, :WEATHERBALL, :THUNDERBOLT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SALASLAM,
        :level => 62,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:GUNKSHOT, :AQUATAIL, :ICEPUNCH, :SWORDSDANCE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :WEASHOCK,
        :level => 62,
        :item => :LIFEORB,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:FACADE, :THUNDER, :ENERGYBALL, :IRONTAIL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MONSTRAP,
        :level => 62,
        :item => :COBABERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:SUCKERPUNCH, :POWERWHIP, :EARTHQUAKE, :GUNKSHOT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SMAQUA,
        :level => 62,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:AQUATAIL, :ICEPUNCH, :DRAINPUNCH, :IRONTAIL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Eto", :SWIMMER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :MERSIDON,
        :level => 62,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :TIMID,
        :moves => [:MUDDYWATER, :FOCUSBLAST, :ENERGYBALL, :THUNDER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :AURORAI,
        :level => 62,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:BLIZZARD, :DISCHARGE, :ENERGYBALL, :DUSTYDASH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PINGLADE,
        :level => 62,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:SLASH, :RAZORSHELL, :RAZORBLADE, :CRACKLESLAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :HYDROGON,
        :level => 62,
        :item => :COVERTCLOAK,
        :ability => "",
        :nature => :MODEST,
        :moves => [:HYDROPUMP, :DRAGONPULSE, :ICEBEAM, :THUNDER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :STRIKLOUD,
        :level => 62,
        :item => :FLYINGGEM,
        :ability => "",
        :nature => :TIMID,
        :moves => [:COUNTERCURRENT, :THUNDER, :ENERGYBALL, :WEATHERBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GLOWING,
        :level => 62,
        :item => :LIFEORB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:BUGBUZZ, :THUNDER, :DAZZLINGGLEAM, :FLASHCANNON],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Amro", :GUITARIST_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BLIMPOON,
        :level => 63,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :MODEST,
        :moves => [:FLASHCANNON, :SQUALLBLOW, :HEATWAVE, :CHARGEBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :METEROCK,
        :level => 63,
        :item => :ELECTRICSEED,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:VOLTTACKLE, :STONEEDGE, :GLACIERCRASH, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :AVALDEER,
        :level => 63,
        :item => :ELECTRICSEED,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:SWORDSDANCE, :GLACIERCRASH, :WILDCHARGE, :DOUBLEEDGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TERRAVOLT,
        :level => 63,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:THUNDERBOLT, :SQUALLBLOW, :HEATWAVE, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CHAMELECTRO,
        :level => 63,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:FLAMECHARGE, :THUNDERBOLT, :ENERGYBALL, :FIREBLAST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :RUSHOT,
        :level => 63,
        :item => :ELECTRICSEED,
        :ability => "",
        :nature => :NAUGHTY,
        :moves => [:VOLTTACKLE, :HEATWAVE, :ICEFANG, :IRONTAIL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["mob", :PUNKGUY, 0],
    :defeat => "",
    :mons => [
      {
        :species => :LISQUID,
        :level => 63,
        :item => :COVERTCLOAK,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:SUCKERPUNCH, :CRUNCH, :LIQUIDATION, :ICEBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :WEREHIDE,
        :level => 63,
        :item => :COVERTCLOAK,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:SUCKERPUNCH, :CRUNCH, :ICEFANG, :THUNDERFANG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PHAROBE,
        :level => 63,
        :item => :MIDNIGHTSEED,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:BODYPRESS, :PHANTOMGRIP, :IRONHEAD, :HAMMERARM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :AURORAI,
        :level => 63,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:BLIZZARD, :THUNDERBOLT, :DAZZLINGGLEAM, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PSYTRIC,
        :level => 63,
        :item => :COLBURBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:REFLECT, :LIGHTSCREEN, :PSYCHIC, :THUNDERBOLT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DEERFERNO,
        :level => 63,
        :item => :LIFEORB,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:FLAREBLITZ, :DOUBLEEDGE, :ROCKSLIDE, :HIGHJUMPKICK],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Chun", :PUNKGIRL, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SYPHOON,
        :level => 63,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:DARKPULSE, :SHADOWBALL, :AEROBLAST, :VACUUMWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SPECSTONE,
        :level => 63,
        :item => :POWERHERB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:METEORBEAM, :SHADOWBALL, :EARTHPOWER, :DARKPULSE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SKELEDEEP,
        :level => 63,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:CRUNCH, :MEGALOFANG, :PHANTOMGRIP, :AQUAJET],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GHOULLOW,
        :level => 63,
        :item => :MIDNIGHTSEED,
        :ability => "",
        :nature => :MODEST,
        :moves => [:SHADOWBALL, :BODYPRESS, :MOONBLAST, :SLACKOFF],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GASLIT,
        :level => 63,
        :item => :LIFEORB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:VACUUMWAVE, :SHADOWBALL, :FIREBLAST, :DARKPULSE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SPIRIX,
        :level => 63,
        :item => :LIFEORB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SUCKERPUNCH, :SHADOWBALL, :HYPERVOICE, :DUSTYDASH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["A11", :VETERAN_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :MONSTRAP,
        :level => 63,
        :item => :LIFEORB,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:POWERWHIP, :CRUNCH, :LEAFDARTS, :GUNKSHOT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :AEROMA,
        :level => 63,
        :item => :YACHEBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:GIGADRAIN, :SQUALLBLOW, :CALMMIND, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CIRRIBUS,
        :level => 63,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HURRICANE, :THUNDER, :ICEBEAM, :WEATHERBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :KONGRILLA,
        :level => 63,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:LEAFDARTS, :MACHPUNCH, :STONEEDGE, :CLOSECOMBAT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SALASLAM,
        :level => 63,
        :item => :GRASSYSEED,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:GUNKSHOT, :WAVECRASH, :ICEPUNCH, :IRONTAIL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LOPHUG,
        :level => 63,
        :item => :GRASSYSEED,
        :ability => "",
        :nature => :TIMID,
        :moves => [:CALMMIND, :HYPERVOICE, :THUNDERBOLT, :ICEBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Pyuku", :BIKER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :KINIP,
        :level => 63,
        :item => :REDCARD,
        :ability => "",
        :nature => :BOLD,
        :moves => [:TOXICSPIKES, :FOULPLAY, :SLUDGEWAVE, :HYDROPUMP],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SWAMPHEAP,
        :level => 63,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :BRAVE,
        :moves => [:LEAFDARTS, :POWERWHIP, :STONEEDGE, :DARKPULSE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DOVEHEART,
        :level => 63,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:MOONBLAST, :HEATWAVE, :LOVELYKISS, :SQUALLBLOW],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :NEMBROSLUG,
        :level => 63,
        :item => :GRASSYSEED,
        :ability => "",
        :nature => :MODEST,
        :moves => [:BODYPRESS, :HYDROPUMP, :SLUDGEWAVE, :RECOVER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LUNAPE,
        :level => 63,
        :item => :GRASSYSEED,
        :ability => "",
        :nature => :TIMID,
        :moves => [:CALMMIND, :MOONLIGHT, :PSYCHIC, :MOONBLAST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SNUFFUZZ,
        :level => 63,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:FACADE, :CRACKLESLAM, :IRONHEAD, :KNOCKOFF],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Lazez", :SAFARIRANGER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :FLEAROE,
        :level => 63,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:ROCKSLIDE, :FAKEOUT, :EARTHQUAKE, :CRACKLESLAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TERRAVOLT,
        :level => 63,
        :item => :COVERTCLOAK,
        :ability => "",
        :nature => :TIMID,
        :moves => [:DISCHARGE, :SQUALLBLOW, :HEATWAVE, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CORALTLE,
        :level => 63,
        :item => :RINDOBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:MUDDYWATER, :GEODECANNON, :THUNDER, :ICEBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FLAPINKO,
        :level => 63,
        :item => :LIFEORB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HYPERVOICE, :SQUALLBLOW, :AIRCANNON, :MUDDYWATER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MERSIDON,
        :level => 63,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :TIMID,
        :moves => [:RIPPLEWAVE, :THUNDER, :ICEBEAM, :FOCUSBLAST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SILVICIOUS,
        :level => 63,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:WAVECRASH, :IRONTAIL, :HEADSMASH, :WILDCHARGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Sky", :RICHBOY, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PHANSHEET,
        :level => 63,
        :item => :SHININGSEED,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HYPNOSIS, :SHADOWBALL, :DARKPULSE, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GIRAFLAME,
        :level => 63,
        :item => :SHININGSEED,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:FIREBLAST, :FLAMECHARGE, :EARTHPOWER, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CHEETRIC,
        :level => 63,
        :item => :LIFEORB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:THUNDERBOLT, :DARKPULSE, :HIDDENPOWER, :GRASSKNOT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SIGNILEAF,
        :level => 63,
        :item => :LIFEORB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:ENERGYBALL, :THUNDERBOLT, :NATUREPOWER, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PSYFLOCK,
        :level => 63,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:PSYCHIC, :SQUALLBLOW, :HEATWAVE, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BILLAZE,
        :level => 63,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:FLAREBLITZ, :FACADE, :EARTHQUAKE, :GLACIERCRASH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Aizakku", :ACETRAINER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ORCAIL,
        :level => 64,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:BODYPRESS, :GLACIERCRASH, :LIQUIDATION, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PINGLADE,
        :level => 64,
        :item => :LIFEORB,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:SLASH, :RAZORSHELL, :ICESHARD, :CROSSCHOP],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MYSTABLET,
        :level => 64,
        :item => :OCCABERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:MINDBLAST, :FLASHCANNON, :BLIZZARD, :THUNDERBOLT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :POLARPOW,
        :level => 64,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:FROSTCLAW, :CLOSECOMBAT, :EARTHQUAKE, :THUNDERPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :NEMBROSLUG,
        :level => 64,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:HYDROPUMP, :SLUDGEWAVE, :BLIZZARD, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BLIMPOON,
        :level => 64,
        :item => :OCCABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:FLASHCANNON, :SQUALLBLOW, :HEATWAVE, :AIRCANNON],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["fish_gaming", :FISHERMAN, 0],
    :defeat => "",
    :mons => [
      {
        :species => :TARATERROR,
        :level => 64,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:STICKYWEB, :CRUNCH, :EARTHQUAKE, :PINMISSILE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GIGLOO,
        :level => 64,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :BRAVE,
        :moves => [:ICESHARD, :ICICLESPEAR, :ROCKBLAST, :FIREBLAST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SMAQUA,
        :level => 64,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:LIQUIDATION, :MACHPUNCH, :ICEPUNCH, :CLOSECOMBAT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :KONGRILLA,
        :level => 64,
        :item => :COBABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:LEAFDARTS, :WOODHAMMER, :ICEPUNCH, :HAMMERARM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TAREXITE,
        :level => 64,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:STONEEDGE, :FLAREBLITZ, :EARTHQUAKE, :THUNDERFANG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SHRIMPET,
        :level => 64,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:FIREBLAST, :RIPPLEWAVE, :BUGBUZZ, :RECOVER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Epix", :SWIMMER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :FELOVE,
        :level => 65,
        :item => :COVERTCLOAK,
        :ability => "",
        :nature => :TIMID,
        :moves => [:LIGHTSCREEN, :REFLECT, :MOONBLAST, :PSYCHIC],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BLITZIBOOM,
        :level => 65,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:BOOMBURST, :HEATWAVE, :DAZZLINGGLEAM, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DINOPION,
        :level => 65,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:DRAGONRUSH, :CLOSECOMBAT, :IRONTAIL, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SKELEDEEP,
        :level => 65,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:PHANTOMGRIP, :MEGALOFANG, :CRUNCH, :ICEFANG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DRAGOON,
        :level => 65,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:HORNLEECH, :NATURESFORCE, :ROCKSLIDE, :WILDCHARGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :HORSHUSH,
        :level => 65,
        :item => :LIFEORB,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:FLOWERTRICK, :HIGHJUMPKICK, :LEAFDARTS, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Citrine", :LASS, 0],
    :defeat => "",
    :mons => [
      {
        :species => :FLEAROE,
        :level => 65,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HEATWAVE, :EARTHPOWER, :CRACKLESLAM, :IRONTAIL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MELOTWEET,
        :level => 65,
        :item => :LIFEORB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:EXPANDINGFORCE, :DAZZLINGGLEAM, :HEATWAVE, :THUNDERBOLT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SYPHOON,
        :level => 65,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SQUALLBLOW, :SHADOWBALL, :FREEZEDRY, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TERRAVOLT,
        :level => 65,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SQUALLBLOW, :THUNDERBOLT, :HEATWAVE, :FLASHCANNON],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SPIRIX,
        :level => 65,
        :item => :LIFEORB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HYPERVOICE, :SHADOWBALL, :PSYCHIC, :DARKPULSE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :HUSKOLD,
        :level => 65,
        :item => :OCCABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:CRACKLESLAM, :ICICLECRASH, :IRONTAIL, :CRUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Keira", :PkMnTRAINER_Keira, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SALATAD,
        :level => 7,
        :item => :ORANBERRY,
        :ability => :TORRENT,
        :nature => :QUIRKY,
        :moves => [:ACID,:WATERGUN,:POUND,:GROWL],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Keira", :PkMnTRAINER_Keira,1, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SALATAD,
        :level => 7,
        :item => :ORANBERRY,
        :ability => :TORRENT,
        :nature => :QUIRKY,
        :moves => [:ACID,:WATERGUN,:POUND,:GROWL],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Keira", :PkMnTRAINER_Keira,2, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SALATAD,
        :level => 7,
        :item => :ORANBERRY,
        :ability => :TORRENT,
        :nature => :QUIRKY,
        :moves => [:ACID,:WATERGUN,:POUND,:GROWL],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Keira", :PkMnTRAINER_Keira,3, 0],
    :defeat => "I enjoyed it.",
    :mons => [
      {
        :species => :HYPNOPUFF,
        :level => 15,
        :item => :BLACKSLUDGE,
        :ability => :SHIELDDUST,
        :nature => :MODEST,
        :moves => [:SLUDGE, :CONFUSION, :NIGHTSHADE, :POISONGAS],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
      {
        :species => :CARBONIX,
        :level => 15,
        :item => :CHARTIBERRY,
        :ability => :FLASHFIRE,
        :nature => :TIMID,
        :moves => [:EMBER, :POWDERSNOW, :WATERPULSE, :HIDDENPOWERGRA],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :FAYELY,
        :level => 15,
        :item => :YACHEBERRY,
        :ability => :POISONHEAL,
        :nature => :MODEST,
        :moves => [:FAIRYWIND, :DRAGONBREATH, :ANCIENTPOWER, :HIDDENPOWERGRA],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
      {
        :species => :FIBBIT,
        :level => 15,
        :item => :CHARCOAL,
        :ability => :KLUTZ,
        :nature => :JOLLY,
        :moves => [:FLAMECHARGE, :STOMP, :WILLOWISP, :DOUBLESLAP],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :SHRUBZOR,
        :level => 15,
        :item => :ELEMENTALSEED,
        :ability => :CHLOROPHYLL,
        :nature => :JOLLY,
        :moves => [:HONECLAWS, :METALCLAW, :RAZORLEAF, :ROCKTOMB],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :SALATAD,
        :level => 16,
        :item => :RINDOBERRY,
        :ability => :TORRENT,
        :nature => :TIMID,
        :moves => [:SCALD, :SLUDGE, :HIDDENPOWERGRA, :ICYWIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252],
        :statmults => [1.1,1,1,1.1,1,1]
      },
    ]
  },
  {
    :teamid => ["Keira", :PkMnTRAINER_Keira,4, 0],
    :defeat => "",
    :mons => [
      {
        :species => :HYPNOPUFF,
        :level => 15,
        :item => :BLACKSLUDGE,
        :ability => :SHIELDDUST,
        :nature => :MODEST,
        :moves => [:SLUDGE, :CONFUSION, :NIGHTSHADE, :POISONGAS],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
      {
        :species => :CARBONIX,
        :level => 15,
        :item => :CHARTIBERRY,
        :ability => :HEATPROOF,
        :nature => :TIMID,
        :moves => [:EMBER, :ICYWIND, :WATERPULSE, :HIDDENPOWERGRA],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :FAYELY,
        :level => 15,
        :item => :YACHEBERRY,
        :ability => :POISONHEAL,
        :nature => :MODEST,
        :moves => [:FAIRYWIND, :DRAGONBREATH, :ANCIENTPOWER, :GRASSKNOT],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
      {
        :species => :RABBLAZE,
        :level => 15,
        :item => :CHARCOAL,
        :ability => :KLUTZ,
        :nature => :JOLLY,
        :moves => [:FLAMECHARGE, :STOMP, :WILLOWISP, :DOUBLESLAP],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :SHRUBZOR,
        :level => 15,
        :item => :ELEMENTALSEED,
        :ability => :CHLOROPHYLL,
        :nature => :JOLLY,
        :moves => [:HONECLAWS, :METALCLAW, :RAZORLEAF, :ROCKTOMB],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :SALANIP,
        :level => 16,
        :item => :MYSTICWATER,
        :ability => :TORRENT,
        :nature => :TIMID,
        :moves => [:BUBBLEBEAM, :POISONFANG, :HIDDENPOWERGRA, :ICYWIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
    ]
  },
  {
    :teamid => ["Keira", :PkMnTRAINER_Keira,5, 0],
    :defeat => "",
    :mons => [
      {
        :species => :HYPNOPUFF,
        :level => 15,
        :item => :BLACKSLUDGE,
        :ability => :SHIELDDUST,
        :nature => :MODEST,
        :moves => [:SLUDGE, :CONFUSION, :NIGHTSHADE, :POISONGAS],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
      {
        :species => :CARBONIX,
        :level => 15,
        :item => :CHARTIBERRY,
        :ability => :HEATPROOF,
        :nature => :TIMID,
        :moves => [:EMBER, :ICYWIND, :WATERPULSE, :HIDDENPOWERGRA],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :FAYELY,
        :level => 15,
        :item => :YACHEBERRY,
        :ability => :POISONHEAL,
        :nature => :MODEST,
        :moves => [:FAIRYWIND, :DRAGONBREATH, :ANCIENTPOWER, :GRASSKNOT],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
      {
        :species => :RABBLAZE,
        :level => 15,
        :item => :CHARCOAL,
        :ability => :KLUTZ,
        :nature => :JOLLY,
        :moves => [:FLAMECHARGE, :STOMP, :WILLOWISP, :DOUBLESLAP],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :SHRUBZOR,
        :level => 15,
        :item => :ELEMENTALSEED,
        :ability => :CHLOROPHYLL,
        :nature => :JOLLY,
        :moves => [:HONECLAWS, :METALCLAW, :RAZORLEAF, :ROCKTOMB],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :SALANIP,
        :level => 16,
        :item => :MYSTICWATER,
        :ability => :TORRENT,
        :nature => :TIMID,
        :moves => [:BUBBLEBEAM, :POISONFANG, :HIDDENPOWERGRA, :ICYWIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
    ]
  },
  {
    :teamid => ["Keira", :PkMnTRAINER_Keira,6, 0],
    :defeat => "",
    :mons => [
      {
        :species => :NIMBLOW,
        :level => 27,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:LIGHTNINGSTRIKE, :SQUALLBLOW, :WEATHERBALL, :AIRCANNON],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SNUFFUZZ,
        :level => 27,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:HYPERFANG, :CRUNCH, :BULLDOZE, :ZENHEADBUTT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FAYEGON,
        :level => 27,
        :item => :TOXICORB,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:PLAYROUGH, :DRAGONCLAW, :FACADE, :PROTECT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :RINOLAR,
        :level => 27,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:ICICLECRASH, :DRILLRUN, :ROCKSLIDE, :ICESHARD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PIXILILY,
        :level => 27,
        :item => :CHARTIBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:BUGBOMB, :DAZZLINGGLEAM, :HIDDENPOWER, :PSYSHOCK],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SALANIP,
        :level => 28,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:AQUASLAM, :CROSSPOISON, :RAINDANCE, :ICEPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Keira", :PkMnTRAINER_Keira,7, 0],
    :defeat => "",
    :mons => [
      {
        :species => :NIMBLOW,
        :level => 27,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:LIGHTNINGSTRIKE, :SQUALLBLOW, :WEATHERBALL, :AIRCANNON],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DEERASH,
        :level => 27,
        :item => :LIFEORB,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:TAKEDOWN, :BLAZEKICK, :JUMPKICK, :CRUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FAYEGON,
        :level => 27,
        :item => :TOXICORB,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:PLAYROUGH, :DRAGONCLAW, :FACADE, :PROTECT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :RINOLAR,
        :level => 27,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:ICICLECRASH, :DRILLRUN, :ROCKSLIDE, :ICESHARD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PIXILILY,
        :level => 27,
        :item => :CHARTIBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:BUGBOMB, :DAZZLINGGLEAM, :HIDDENPOWER, :PSYSHOCK],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FORESTONE,
        :level => 28,
        :item => :CHOPLEBERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:SEEDBOMB, :ROCKSLIDE, :BULLDOZE, :ZENHEADBUTT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Keira", :PkMnTRAINER_Keira,8, 0],
    :defeat => "",
    :mons => [
      {
        :species => :NIMBLOW,
        :level => 27,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:LIGHTNINGSTRIKE, :SQUALLBLOW, :WEATHERBALL, :AIRCANNON],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :POOLDOG,
        :level => 27,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:AQUASLAM, :ICEFANG, :ROCKSLIDE, :WILDCHARGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FAYEGON,
        :level => 27,
        :item => :TOXICORB,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:PLAYROUGH, :DRAGONCLAW, :FACADE, :PROTECT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :RINOLAR,
        :level => 27,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:ICICLECRASH, :DRILLRUN, :ROCKSLIDE, :ICESHARD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PIXILILY,
        :level => 27,
        :item => :CHARTIBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:BUGBOMB, :DAZZLINGGLEAM, :HIDDENPOWER, :PSYSHOCK],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PURRYO,
        :level => 28,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:LAVAPLUME, :MUDSHOT, :CRACKLESLAM, :WILLOWISP],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Keira", :PkMnTRAINER_Keira,9, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PIXILILY,
        :level => 29,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:LIGHTBURST, :BUGBOMB, :AIRCANNON, :GIGADRAIN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FAYEGON,
        :level => 29,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:DRAGONCLAW, :PLAYROUGH, :BABYDOLLEYES, :AQUATAIL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :RINOLAR,
        :level => 30,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:ICICLECRASH, :STOMPINGTANTRUM, :ICESHARD, :ROCKTOMB],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Keira", :PkMnTRAINER_Keira,10, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PIXILILY,
        :level => 34,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:BUGBUZZ, :MOONBLAST, :SLEEPPOWDER, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :RUBBUNNY,
        :level => 34,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:RETURN, :EARTHQUAKE, :ZENHEADBUTT, :DRAINPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :RINOLAR,
        :level => 34,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:ICICLECRASH, :EARTHQUAKE, :ROCKSLIDE, :ICESHARD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FAYEGON,
        :level => 34,
        :item => :POWERHERB,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:PLAYROUGH, :DRAGONCLAW, :AQUATAIL, :DIG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :NIMBLOW,
        :level => 34,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:THUNDERBOLT, :SQUALLBLOW, :WEATHERBALL, :AIRCANNON],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SALANIP,
        :level => 35,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:AQUATAIL, :POISONJAB, :RAINDANCE, :DRAINPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Keira", :PkMnTRAINER_Keira,11, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PIXILILY,
        :level => 34,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:BUGBUZZ, :MOONBLAST, :SLEEPPOWDER, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :RUBBUNNY,
        :level => 34,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:RETURN, :EARTHQUAKE, :ZENHEADBUTT, :DRAINPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :RINOLAR,
        :level => 34,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:ICICLECRASH, :EARTHQUAKE, :ROCKSLIDE, :ICESHARD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FAYEGON,
        :level => 34,
        :item => :POWERHERB,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:PLAYROUGH, :DRAGONCLAW, :AQUATAIL, :DIG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DEERASH,
        :level => 34,
        :item => :LIFEORB,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:TAKEDOWN, :GALERUSH, :WILDCHARGE, :BLAZEKICK],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FORESTONE,
        :level => 35,
        :item => :CHOPLEBERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:SEEDBOMB, :ROCKSLIDE, :IRONHEAD, :ZENHEADBUTT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Keira", :PkMnTRAINER_Keira,12, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PIXILILY,
        :level => 34,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:BUGBUZZ, :MOONBLAST, :SLEEPPOWDER, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :RUBBUNNY,
        :level => 34,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:RETURN, :EARTHQUAKE, :ZENHEADBUTT, :DRAINPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :RINOLAR,
        :level => 34,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:ICICLECRASH, :EARTHQUAKE, :ROCKSLIDE, :ICESHARD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FAYEGON,
        :level => 34,
        :item => :POWERHERB,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:PLAYROUGH, :DRAGONCLAW, :AQUATAIL, :DIG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :POOLDOG,
        :level => 34,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:WATERFALL, :CRUNCH, :FACADE, :ICEFANG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PURRYO,
        :level => 35,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:FLAMETHROWER, :EARTHPOWER, :CRACKLESLAM, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Keira", :PkMnTRAINER_Keira,13, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ROOBEOP,
        :level => 43,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:EARTHQUAKE, :HIGHJUMPKICK, :BLAZEKICK, :ICEPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :RINOTIC,
        :level => 43,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:ICESHARD, :GLACIERCRASH, :EARTHQUAKE, :STONEEDGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FAYEGON,
        :level => 43,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:PLAYROUGH, :DRAGONCLAW, :DRAGONDANCE, :RECOVER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GLYDFIN,
        :level => 43,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HYDROPUMP, :ICEBEAM, :HYPERVOICE, :HEATWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DEERFERNO,
        :level => 43,
        :item => :CHARTIBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:BLAZEKICK, :DOUBLEEDGE, :JUMPKICK, :BULLDOZE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SALASLAM,
        :level => 44,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:AQUATAIL, :RAINDANCE, :POISONJAB, :DRAINPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Keira", :PkMnTRAINER_Keira,14, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ROOBEOP,
        :level => 43,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:EARTHQUAKE, :HIGHJUMPKICK, :BLAZEKICK, :ICEPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :RINOTIC,
        :level => 43,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:ICESHARD, :GLACIERCRASH, :EARTHQUAKE, :STONEEDGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FAYEGON,
        :level => 43,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:PLAYROUGH, :DRAGONCLAW, :DRAGONDANCE, :RECOVER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GLYDFIN,
        :level => 43,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HYDROPUMP, :ICEBEAM, :HYPERVOICE, :HEATWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PIXILILY,
        :level => 43,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:BUGBUZZ, :MOONBLAST, :HIDDENPOWER, :QUIVERDANCE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MOUNTREE,
        :level => 44,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:ROCKPOLISH, :PETALBLIZZARD, :STONEEDGE, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Keira", :PkMnTRAINER_Keira,15, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ROOBEOP,
        :level => 43,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:EARTHQUAKE, :HIGHJUMPKICK, :BLAZEKICK, :ICEPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :RINOTIC,
        :level => 43,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:ICESHARD, :GLACIERCRASH, :EARTHQUAKE, :STONEEDGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FAYEGON,
        :level => 43,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:PLAYROUGH, :DRAGONCLAW, :DRAGONDANCE, :RECOVER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GLYDFIN,
        :level => 43,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HYDROPUMP, :ICEBEAM, :HYPERVOICE, :HEATWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :POOLDOG,
        :level => 43,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:AQUAJET, :GLACIERCRASH, :LIQUIDATION, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FLEAROE,
        :level => 44,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:EARTHPOWER, :FLAMETHROWER, :CRACKLESLAM, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Keira", :PkMnTRAINER_Keira,16, 0],
    :defeat => "",
    :mons => [
      {
        :species => :FELOVE,
        :level => 52,
        :item => :LIGHTCLAY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:REFLECT, :LIGHTSCREEN, :MOONBLAST, :PSYCHIC],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GLYDFIN,
        :level => 52,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HYPERVOICE, :MUDDYWATER, :HEATWAVE, :BLIZZARD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SALASLAM,
        :level => 53,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:AQUATAIL, :POISONJAB, :DRAINPUNCH, :ICEPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Keira", :PkMnTRAINER_Keira,17, 0],
    :defeat => "",
    :mons => [
      {
        :species => :FELOVE,
        :level => 52,
        :item => :LIGHTCLAY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:REFLECT, :LIGHTSCREEN, :MOONBLAST, :PSYCHIC],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GLYDFIN,
        :level => 52,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HYPERVOICE, :MUDDYWATER, :HEATWAVE, :BLIZZARD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MOUNTREE,
        :level => 53,
        :item => :LUMBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:LEAFDARTS, :PETALBLIZZARD, :ROCKSLIDE, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Keira", :PkMnTRAINER_Keira,18, 0],
    :defeat => "",
    :mons => [
      {
        :species => :FELOVE,
        :level => 52,
        :item => :LIGHTCLAY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:REFLECT, :LIGHTSCREEN, :MOONBLAST, :PSYCHIC],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GLYDFIN,
        :level => 52,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HYPERVOICE, :MUDDYWATER, :HEATWAVE, :BLIZZARD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FLEAROE,
        :level => 53,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:EARTHPOWER, :HEATWAVE, :CRACKLESLAM, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rick", :PkMnTRAINER_Rick,6, 0],
    :defeat => "",
    :mons => [
      {
        :species => :TROLLGER,
        :level => 52,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:FEYHAMMER, :CRUNCH, :FOULPLAY, :DRAINPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PARABOW,
        :level => 52,
        :item => :LIFEORB,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:TAILSLAP, :TALONGASH, :HIDDENPOWER, :TAILWIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DINOPION,
        :level => 53,
        :item => :ROSELIBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:CLOSECOMBAT, :DRAGONRUSH, :ROCKSLIDE, :IRONTAIL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Keira and Rick", :PKMNTRAINERS,1, 0],
    :defeat => "",
    :mons => [
      {
        :species => :FELOVE,
        :level => 52,
        :item => :LIGHTCLAY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:REFLECT, :LIGHTSCREEN, :MOONBLAST, :PSYCHIC],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TROLLGER,
        :level => 52,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:FEYHAMMER, :CRUNCH, :FOULPLAY, :DRAINPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GLYDFIN,
        :level => 52,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HYPERVOICE, :MUDDYWATER, :HEATWAVE, :BLIZZARD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PARABOW,
        :level => 52,
        :item => :LIFEORB,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:TAILSLAP, :TALONGASH, :HIDDENPOWER, :TAILWIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DINOPION,
        :level => 53,
        :item => :DINOPIONITE,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:CLOSECOMBAT, :DRAGONRUSH, :ROCKSLIDE, :IRONTAIL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MOUNTREE,
        :level => 53,
        :item => :LUMBERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:LEAFDARTS, :PETALBLIZZARD, :ROCKSLIDE, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Keira and Rick", :PKMNTRAINERS,2, 0],
    :defeat => "",
    :mons => [
      {
        :species => :FELOVE,
        :level => 52,
        :item => :LIGHTCLAY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:REFLECT, :LIGHTSCREEN, :MOONBLAST, :PSYCHIC],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TROLLGER,
        :level => 52,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:FEYHAMMER, :CRUNCH, :FOULPLAY, :DRAINPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GLYDFIN,
        :level => 52,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HYPERVOICE, :MUDDYWATER, :HEATWAVE, :BLIZZARD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PARABOW,
        :level => 52,
        :item => :LIFEORB,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:TAILSLAP, :TALONGASH, :HIDDENPOWER, :TAILWIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DINOPION,
        :level => 53,
        :item => :DINOPIONITE,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:CLOSECOMBAT, :DRAGONRUSH, :ROCKSLIDE, :IRONTAIL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FLEAROE,
        :level => 53,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:EARTHPOWER, :HEATWAVE, :CRACKLESLAM, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Keira", :PkMnTRAINER_Keira,19, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BAABLIZZ,
        :level => 54,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:AVALANCHE, :BODYSLAM, :ROCKSLIDE, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ROOBEOP,
        :level => 54,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:EARTHQUAKE, :LOWKICK, :ICEPUNCH, :QUICKATTACK],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BILLAZE,
        :level => 55,
        :item => :CHARCOAL,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FLAMEWHEEL, :BODYSLAM, :BULLDOZE, :BULKUP],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CIRRIBUS,
        :level => 55,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:SQUALLBLOW, :WEATHERBALL, :THUNDERBOLT, :TAILWIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PIXILILY,
        :level => 55,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:MYSTICWAVE, :BUGBUZZ, :QUIVERDANCE, :SLEEPPOWDER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SALASLAM,
        :level => 56,
        :item => :SALASLAMITE,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:AQUASLAM, :POISONJAB, :RAINDANCE, :TOXIC],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Keira", :PkMnTRAINER_Keira,20, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BAABLIZZ,
        :level => 54,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:AVALANCHE, :BODYSLAM, :ROCKSLIDE, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ROOBEOP,
        :level => 54,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:EARTHQUAKE, :LOWKICK, :ICEPUNCH, :QUICKATTACK],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :POOLDOG,
        :level => 55,
        :item => :MYSTICWATER,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:MEGALOFANG, :CRUNCH, :BULKUP, :ICEFANG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CIRRIBUS,
        :level => 55,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:SQUALLBLOW, :WEATHERBALL, :THUNDERBOLT, :TAILWIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PIXILILY,
        :level => 55,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:MYSTICWAVE, :BUGBUZZ, :QUIVERDANCE, :SLEEPPOWDER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MOUNTREE,
        :level => 56,
        :item => :MOUNTREENITE,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:WOODHAMMER, :ROCKSLIDE, :LEECHSEED, :SYNTHESIS],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Keira", :PkMnTRAINER_Keira,21, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BAABLIZZ,
        :level => 54,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:AVALANCHE, :BODYSLAM, :ROCKSLIDE, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ROOBEOP,
        :level => 54,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:EARTHQUAKE, :LOWKICK, :ICEPUNCH, :QUICKATTACK],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :HORSHUSH,
        :level => 55,
        :item => :MIRACLESEED,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:LEAFDARTS, :BOUNCE, :THUNDERWAVE, :SYNTHESIS],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CIRRIBUS,
        :level => 55,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:SQUALLBLOW, :WEATHERBALL, :THUNDERBOLT, :TAILWIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PIXILILY,
        :level => 55,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:MYSTICWAVE, :BUGBUZZ, :QUIVERDANCE, :SLEEPPOWDER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FLEAROE,
        :level => 56,
        :item => :FLEAROENITE,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FLAMETHROWER, :DUSTYDASH, :KNOCKOFF, :WILLOWISP],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Keira", :PkMnTRAINER_Keira,22, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BAABLIZZ,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:BLIZZARD, :EARTHQUAKE, :ROCKSLIDE, :YAWN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PIXILILY,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:BUGBUZZ, :MYSTICWAVE, :SLEEPPOWDER, :QUIVERDANCE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SALASLAM,
        :level => 65,
        :item => :SALASLAMITE,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:WATERFALL, :POISONJAB, :TOXIC, :RAINDANCE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Keira", :PkMnTRAINER_Keira,23, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BAABLIZZ,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:BLIZZARD, :EARTHQUAKE, :ROCKSLIDE, :YAWN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PIXILILY,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:BUGBUZZ, :MYSTICWAVE, :SLEEPPOWDER, :QUIVERDANCE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MOUNTREE,
        :level => 65,
        :item => :MOUNTREENITE,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:WOODHAMMER, :HEADSMASH, :LEECHSEED, :SYNTHESIS],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Keira", :PkMnTRAINER_Keira,24, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BAABLIZZ,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:BLIZZARD, :EARTHQUAKE, :ROCKSLIDE, :YAWN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PIXILILY,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:BUGBUZZ, :MYSTICWAVE, :SLEEPPOWDER, :QUIVERDANCE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FLEAROE,
        :level => 65,
        :item => :FLEAROENITE,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FLAMETHROWER, :EARTHPOWER, :TAUNT, :WILLOWISP],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Keira", :PkMnTRAINER_Keira,25, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BAABLIZZ,
        :level => 80,
        :item => :CHOPLEBERRY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:AVALANCHE, :BLIZZARD, :EARTHQUAKE, :HAIL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ROOBEOP,
        :level => 80,
        :item => :EXPERTBELT,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:EARTHQUAKE, :HIGHJUMPKICK, :BOUNCE, :THUNDERPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PIXILILY,
        :level => 80,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:MYSTICWAVE, :BUGBUZZ, :QUIVERDANCE, :SLEEPPOWDER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CIRRIBUS,
        :level => 80,
        :item => :CHOICESCARF,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:HURRICANE, :WEATHERBALL, :THUNDER, :ICEBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BILLAZE,
        :level => 80,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FLAREBLITZ, :SUPERPOWER, :FLAMECHARGE, :BULKUP],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SALASLAM,
        :level => 80,
        :item => :SALASLAMITE,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:WATERFALL, :POISONJAB, :SUCKERPUNCH, :SWORDSDANCE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Keira", :PkMnTRAINER_Keira,26, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BAABLIZZ,
        :level => 80,
        :item => :CHOPLEBERRY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:AVALANCHE, :BLIZZARD, :EARTHQUAKE, :HAIL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ROOBEOP,
        :level => 80,
        :item => :EXPERTBELT,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:EARTHQUAKE, :HIGHJUMPKICK, :BOUNCE, :THUNDERPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PIXILILY,
        :level => 80,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:MYSTICWAVE, :BUGBUZZ, :QUIVERDANCE, :SLEEPPOWDER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CIRRIBUS,
        :level => 80,
        :item => :CHOICESCARF,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:HURRICANE, :WEATHERBALL, :THUNDER, :ICEBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :POOLDOG,
        :level => 80,
        :item => :CHOICEBAND,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:MEGALOFANG, :CRUNCH, :PLAYROUGH, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MOUNTREE,
        :level => 80,
        :item => :MOUNTREENITE,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:WOODHAMMER, :HEADSMASH, :LEECHSEED, :SYNTHESIS],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Keira", :PkMnTRAINER_Keira,27, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BAABLIZZ,
        :level => 80,
        :item => :CHOPLEBERRY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:AVALANCHE, :BLIZZARD, :EARTHQUAKE, :HAIL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ROOBEOP,
        :level => 80,
        :item => :EXPERTBELT,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:EARTHQUAKE, :HIGHJUMPKICK, :BOUNCE, :THUNDERPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PIXILILY,
        :level => 80,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:MYSTICWAVE, :BUGBUZZ, :QUIVERDANCE, :SLEEPPOWDER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CIRRIBUS,
        :level => 80,
        :item => :CHOICESCARF,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:HURRICANE, :WEATHERBALL, :THUNDER, :ICEBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :HORSHUSH,
        :level => 80,
        :item => :LEFTOVERS,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:GIGADRAIN, :DUSTYDASH, :YAWN, :UTURN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FLEAROE,
        :level => 80,
        :item => :FLEAROENITE,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FLAMETHROWER, :DUSTYDASH, :KNOCKOFF, :WILLOWISP],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rick", :PkMnTRAINER_Rick, 0],
    :defeat => "I'm still better...",
    :mons => [
      {
        :species => :TORON,
        :level => 12,
        :item => :RINDOBERRY,
        :ability => :MOLDBREAKER,
        :nature => :ADAMANT,
        :moves => [:BULLDOZE, :SMACKDOWN, :HORNATTACK, :THUNDERFANG],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
      {
        :species => :STOTOX,
        :level => 12,
        :item => :ORANBERRY,
        :ability => :SOLIDROCK,
        :nature => :ADAMANT,
        :moves => [:SLUDGE, :SMACKDOWN, :ROCKSMASH, :PINMISSILE],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
      {
        :species => :STICKIT,
        :level => 12,
        :item => :TELLURICSEED,
        :ability => :SWARM,
        :nature => :JOLLY,
        :moves => [:BUGBITE, :CHIPAWAY, :ROCKSMASH, :RAZORLEAF],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :TIKIKI,
        :level => 12,
        :item => :WISEGLASSES,
        :ability => :RATTLED,
        :nature => :TIMID,
        :moves => [:EMBER, :MEGADRAIN, :OMINOUSWIND, :CONFUSERAY],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :RAIZID,
        :level => 12,
        :item => :ELECTRICGEM,
        :ability => :SHEERFORCE,
        :nature => :HASTY,
        :moves => [:SPARK, :MUDSHOT, :SNARL, :HIDDENPOWERGRA],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DINOMITE,
        :level => 13,
        :item => :BLACKBELT,
        :ability => :MOXIE,
        :nature => :JOLLY,
        :moves => [:KARATECHOP, :KNOCKOFF, :CHIPAWAY, :FOCUSENERGY],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
    ]
  },
  {
    :teamid => ["Rick", :PkMnTRAINER_Rick,1, 0],
    :defeat => "",
    :mons => [
      {
        :species => :TIKITIK,
        :level => 21,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:INCINERATE, :MAGICALLEAF, :ANCIENTPOWER, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BOULDOX,
        :level => 21,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :BRAVE,
        :moves => [:CROSSPOISON, :ROCKSLIDE, :XSCISSOR, :GYROBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PARAFUL,
        :level => 21,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:FACADE, :WINGATTACK, :STEELWING, :SHADOWCLAW],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :JUMPLE,
        :level => 21,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:PINMISSILE, :BRICKBREAK, :AERIALACE, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DINOMITE,
        :level => 21,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:DRAINPUNCH, :KNOCKOFF, :DUALCHOP, :IRONHEAD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ORITURE,
        :level => 22,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:BULLDOZE, :ROCKSLIDE, :WILDCHARGE, :IRONHEAD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rick", :PkMnTRAINER_Rick,2, 0],
    :defeat => "",
    :mons => [
      {
        :species => :CASSPRING,
        :level => 33,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:STICKYWEB, :GALERUSH, :XSCISSOR, :BRICKBREAK],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :REXITE,
        :level => 33,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:BLAZEKICK, :ROCKSLIDE, :WILDCHARGE, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ORITURE,
        :level => 33,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:EARTHQUAKE, :ROCKSLIDE, :WILDCHARGE, :ICEFANG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PARAFUL,
        :level => 33,
        :item => :LIFEORB,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:DOUBLEHIT, :AERIALACE, :HEATWAVE, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TROLLERK,
        :level => 33,
        :item => :KEBIABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:PLAYROUGH, :CRUNCH, :ROCKSLIDE, :FIREPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DINOPION,
        :level => 34,
        :item => :ROSELIBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:IRONTAIL, :SUBMISSION, :DRAGONCLAW, :ICEPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rick", :PkMnTRAINER_Rick,3, 0],
    :defeat => "",
    :mons => [
      {
        :species => :CASSPRING,
        :level => 33,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:STICKYWEB, :GALERUSH, :XSCISSOR, :BRICKBREAK],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :STEGRON,
        :level => 33,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:FLASHCANNON, :GEODECANNON, :THUNDERBOLT, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ORITURE,
        :level => 33,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:EARTHQUAKE, :ROCKSLIDE, :WILDCHARGE, :ICEFANG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PARAFUL,
        :level => 33,
        :item => :LIFEORB,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:DOUBLEHIT, :AERIALACE, :HEATWAVE, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TROLLERK,
        :level => 33,
        :item => :KEBIABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:PLAYROUGH, :CRUNCH, :ROCKSLIDE, :FIREPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DINOPION,
        :level => 34,
        :item => :ROSELIBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:IRONTAIL, :SUBMISSION, :DRAGONCLAW, :ICEPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rick", :PkMnTRAINER_Rick,4, 0],
    :defeat => "",
    :mons => [
      {
        :species => :TIKITOKO,
        :level => 44,
        :item => :COBABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HEATWAVE, :ENERGYBALL, :THUNDERBOLT, :FOCUSBLAST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CASSPRING,
        :level => 44,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:JUMPKICK, :PINMISSILE, :GALERUSH, :STICKYWEB],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TROLLGER,
        :level => 44,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:FEYHAMMER, :CRUNCH, :FIREPUNCH, :DRAINPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TAREXITE,
        :level => 44,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:ROCKSLIDE, :FLAREBLITZ, :WILDCHARGE, :AQUATAIL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PARABOW,
        :level => 44,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:TALONGASH, :DOUBLEHIT, :HEATWAVE, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DINOPION,
        :level => 45,
        :item => :COBABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:CLOSECOMBAT, :DRAGONIMPACT, :ROCKSLIDE, :IRONHEAD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rick", :PkMnTRAINER_Rick,5, 0],
    :defeat => "",
    :mons => [
      {
        :species => :TIKITOKO,
        :level => 44,
        :item => :COBABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HEATWAVE, :ENERGYBALL, :THUNDERBOLT, :FOCUSBLAST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CASSPRING,
        :level => 44,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:JUMPKICK, :PINMISSILE, :GALERUSH, :STICKYWEB],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :STEGAJOLT,
        :level => 44,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:FLASHCANNON, :GEODECANNON, :THUNDERBOLT, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TROLLGER,
        :level => 44,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:FEYHAMMER, :CRUNCH, :FIREPUNCH, :DRAINPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PARABOW,
        :level => 44,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:TALONGASH, :DOUBLEHIT, :HEATWAVE, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DINOPION,
        :level => 45,
        :item => :COBABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:CLOSECOMBAT, :DRAGONIMPACT, :ROCKSLIDE, :IRONHEAD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rick", :PkMnTRAINER_Rick,7, 0],
    :defeat => "",
    :mons => [
      {
        :species => :MYSTABLET,
        :level => 49,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:MINDBLAST, :FLASHCANNON, :METALBURST, :PAINSPLIT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TOXITOAD,
        :level => 49,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:VENOSHOCK, :SHADOWBALL, :BUBBLEBEAM, :TOXIC],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :STEGAJOLT,
        :level => 50,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FLASHCANNON, :GEODECANNON, :AUTOTOMIZE, :SOLARBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :NATORON,
        :level => 50,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:MAGNITUDE, :DOUBLEEDGE, :WILDCHARGE, :BIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CASSPRING,
        :level => 51,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:ACROBATICS, :UTURN, :JUMPKICK, :SWORDSDANCE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DINOPION,
        :level => 52,
        :item => :EXPERTBELT,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:POWERUPPUNCH, :CLOSECOMBAT, :DRAGONCLAW, :IRONHEAD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rick", :PkMnTRAINER_Rick,8, 0],
    :defeat => "",
    :mons => [
      {
        :species => :TIKITOKO,
        :level => 64,
        :item => :GRASSYSEED,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HEATWAVE, :SOLARBEAM, :EARTHPOWER, :THUNDERBOLT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SCROW,
        :level => 64,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:PETALBLIZZARD, :PHANTOMGRIP, :RAZORBLADE, :STONEEDGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PARABOW,
        :level => 63,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:TALONGASH, :TAILSLAP, :HIDDENPOWER, :SUCKERPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TROLLGER,
        :level => 63,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:FEYHAMMER, :CRUNCH, :ROCKSLIDE, :SUCKERPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CASSPRING,
        :level => 63,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:STICKYWEB, :ATTACKORDER, :GALERUSH, :HIGHJUMPKICK],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DINOPION,
        :level => 66,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:CLOSECOMBAT, :DRAGONRUSH, :IRONTAIL, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rick", :PkMnTRAINER_Rick,9, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PINGLADE,
        :level => 59,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:WATERFALL, :ICICLECRASH, :AQUAJET, :SWORDSDANCE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MYSTABLET,
        :level => 60,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:PAINSPLIT, :FLASHCANNON, :METALBURST, :FUTURESIGHT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PARABOW,
        :level => 60,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:CRUSHCLAW, :TALONGASH, :STEELWING, :TAILWIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :STEGAJOLT,
        :level => 61,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FLASHCANNON, :GEODECANNON, :AUTOTOMIZE, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CASSPRING,
        :level => 61,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:ACROBATICS, :UTURN, :HIGHJUMPKICK, :SWORDSDANCE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DINOPION,
        :level => 62,
        :item => :EXPERTBELT,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:POWERUPPUNCH, :CLOSECOMBAT, :DRAGONCLAW, :IRONHEAD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rick", :PkMnTRAINER_Rick,10, 0],
    :defeat => "",
    :mons => [
      {
        :species => :MYSTABLET,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FLASHCANNON, :FUTURESIGHT, :PAINSPLIT, :FOULPLAY],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :NATORON,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:EARTHQUAKE, :HEADSMASH, :DOUBLEEDGE, :ROAR],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PINGLADE,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:WATERFALL, :GLACIERCRASH, :CRACKLESLAM, :RAINDANCE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TAREXITE,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FIREFANG, :STONEEDGE, :THUNDERFANG, :DRAGONDANCE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CASSPRING,
        :level => 65,
        :item => :FLYINGGEM,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:ACROBATICS, :HIGHJUMPKICK, :POISONJAB, :SWORDSDANCE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DINOPION,
        :level => 65,
        :item => :EXPERTBELT,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:CLOSECOMBAT, :DRAGONCLAW, :IRONTAIL, :DRAGONDANCE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rick", :PkMnTRAINER_Rick,11, 0],
    :defeat => "",
    :mons => [
      {
        :species => :MYSTABLET,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FLASHCANNON, :FUTURESIGHT, :PAINSPLIT, :FOULPLAY],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :NATORON,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:EARTHQUAKE, :HEADSMASH, :DOUBLEEDGE, :ROAR],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PINGLADE,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:WATERFALL, :GLACIERCRASH, :CRACKLESLAM, :RAINDANCE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :STEGAJOLT,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FLASHCANNON, :ANCIENTPOWER, :DAZZLINGGLEAM, :AUTOTOMIZE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CASSPRING,
        :level => 65,
        :item => :FLYINGGEM,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:ACROBATICS, :HIGHJUMPKICK, :POISONJAB, :SWORDSDANCE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DINOPION,
        :level => 65,
        :item => :EXPERTBELT,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:CLOSECOMBAT, :DRAGONCLAW, :IRONTAIL, :DRAGONDANCE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rick", :PkMnTRAINER_Rick,12, 0],
    :defeat => "",
    :mons => [
      {
        :species => :NATORON,
        :level => 80,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:EARTHQUAKE, :STONEEDGE, :GLACIERCRASH, :ROCKPOLISH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TOXITOAD,
        :level => 80,
        :item => :BLACKSLUDGE,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:VENOSHOCK, :TOXIC, :FOCUSBLAST, :NASTYPLOT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PARABOW,
        :level => 80,
        :item => :LIFEORB,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:RETURN, :TALONGASH, :STEELWING, :SWORDSDANCE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CASSPRING,
        :level => 80,
        :item => :FLYINGGEM,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:ACROBATICS, :DIG, :HIGHJUMPKICK, :UTURN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TAREXITE,
        :level => 80,
        :item => :CHOICESCARF,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FIREFANG, :STONEEDGE, :EARTHQUAKE, :THUNDERFANG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DINOPION,
        :level => 80,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:CLOSECOMBAT, :DRAGONCLAW, :FIREPUNCH, :DRAGONDANCE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rick", :PkMnTRAINER_Rick,13, 0],
    :defeat => "",
    :mons => [
      {
        :species => :NATORON,
        :level => 80,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:EARTHQUAKE, :STONEEDGE, :GLACIERCRASH, :ROCKPOLISH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TOXITOAD,
        :level => 80,
        :item => :BLACKSLUDGE,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:VENOSHOCK, :TOXIC, :FOCUSBLAST, :NASTYPLOT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PARABOW,
        :level => 80,
        :item => :LIFEORB,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:RETURN, :TALONGASH, :STEELWING, :SWORDSDANCE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CASSPRING,
        :level => 80,
        :item => :FLYINGGEM,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:ACROBATICS, :DIG, :HIGHJUMPKICK, :UTURN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :STEGAJOLT,
        :level => 80,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FLASHCANNON, :GEODECANNON, :EARTHPOWER, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DINOPION,
        :level => 80,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:CLOSECOMBAT, :DRAGONCLAW, :FIREPUNCH, :DRAGONDANCE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rodney", :RODNEY,0],
    :defeat => "",
    :mons => [
      {
        :species => :PURRLIT,
        :level => 5,
        :ability => :BLAZE,
        :nature => :QUIRKY,
        :moves => [:SCRATCH,:LEER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rodney", :RODNEY,1],
    :defeat => "",
    :mons => [
      {
        :species => :PURRLIT,
        :level => 5,
        :ability => :BLAZE,
        :nature => :QUIRKY,
        :moves => [:SCRATCH,:LEER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rodney", :RODNEY,2],
    :defeat => "",
    :mons => [
      {
        :species => :PURRLIT,
        :level => 5,
        :ability => :BLAZE,
        :nature => :QUIRKY,
        :moves => [:SCRATCH,:LEER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rodney", :RODNEY,3],
    :defeat => "I enjoyed it.",
    :mons => [
      {
        :species => :BAAWOOL,
        :level => 10,
        :item => :ORANBERRY,
        :ability => :SCRAPPY,
        :nature => :ADAMANT,
        :moves => [:TACKLE, :TRAILBLAZE, :YAWN, :NATUREPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
      {
        :species => :BUGRAY,
        :level => 10,
        :item => :OCCABERRY,
        :ability => :SPEEDBOOST,
        :nature => :NAIVE,
        :moves => [:HIDDENPOWERWAT, :BUGBITE, :AERIALACE, :BULLETSEED],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :WEAKID,
        :level => 10,
        :ability => :IRONFIST,
        :nature => :ADAMANT,
        :moves => [:VITALTHROW, :BULKUP, :HEADBUTT, :PURSUIT],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
      {
        :species => :MELEON,
        :level => 10,
        :item => :MUSCLEBAND,
        :ability => :OVERGROW,
        :nature => :JOLLY,
        :moves => [:SMACKDOWN, :VINEWHIP, :DRAGONBREATH, :GROWTH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :PURRLIT,
        :level => 11,
        :item => :CHARCOAL,
        :ability => :BLAZE,
        :nature => :TIMID,
        :moves => [:INCINERATE, :HIDDENPOWERBUG, :DUSTYDASH, :SNARL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
    ]
  },
  {
    :teamid => ["Rodney", :RODNEY,4],
    :defeat => "I enjoyed it.",
    :mons => [
      {
        :species => :BAAWOOL,
        :level => 10,
        :item => :ORANBERRY,
        :ability => :SCRAPPY,
        :nature => :ADAMANT,
        :moves => [:TACKLE, :TRAILBLAZE, :YAWN, :NATUREPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
      {
        :species => :BUGRAY,
        :level => 10,
        :item => :OCCABERRY,
        :ability => :SPEEDBOOST,
        :nature => :NAIVE,
        :moves => [:HIDDENPOWERWAT, :BUGBITE, :AERIALACE, :BULLETSEED],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :WEAKID,
        :level => 10,
        :ability => :IRONFIST,
        :nature => :ADAMANT,
        :moves => [:VITALTHROW, :BULKUP, :HEADBUTT, :PURSUIT],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
      {
        :species => :MELEON,
        :level => 10,
        :item => :MUSCLEBAND,
        :ability => :OVERGROW,
        :nature => :JOLLY,
        :moves => [:SMACKDOWN, :VINEWHIP, :DRAGONBREATH, :GROWTH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :PURRLIT,
        :level => 11,
        :item => :CHARCOAL,
        :ability => :BLAZE,
        :nature => :TIMID,
        :moves => [:INCINERATE, :HIDDENPOWERBUG, :DUSTYDASH, :SNARL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
    ]
  },
  {
    :teamid => ["Rodney", :RODNEY,5],
    :defeat => "I enjoyed it.",
    :mons => [
      {
        :species => :BAAWOOL,
        :level => 10,
        :item => :ORANBERRY,
        :ability => :SCRAPPY,
        :nature => :ADAMANT,
        :moves => [:TACKLE, :TRAILBLAZE, :YAWN, :NATUREPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
      {
        :species => :BUGRAY,
        :level => 10,
        :item => :OCCABERRY,
        :ability => :SPEEDBOOST,
        :nature => :NAIVE,
        :moves => [:HIDDENPOWERWAT, :BUGBITE, :AERIALACE, :BULLETSEED],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :WEAKID,
        :level => 10,
        :ability => :IRONFIST,
        :nature => :ADAMANT,
        :moves => [:VITALTHROW, :BULKUP, :HEADBUTT, :PURSUIT],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
      {
        :species => :MELEON,
        :level => 10,
        :item => :MUSCLEBAND,
        :ability => :OVERGROW,
        :nature => :JOLLY,
        :moves => [:SMACKDOWN, :VINEWHIP, :DRAGONBREATH, :GROWTH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :PURRLIT,
        :level => 11,
        :item => :CHARCOAL,
        :ability => :BLAZE,
        :nature => :TIMID,
        :moves => [:INCINERATE, :HIDDENPOWERBUG, :DUSTYDASH, :SNARL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
    ]
  },
  {
    :teamid => ["Rodney", :Rodney,6, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BAAWOOL,
        :level => 19,
        :item => :LIGHTCLAY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:HYPERVOICE, :HIDDENPOWER, :REFLECT, :LIGHTSCREEN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TERRAZ,
        :level => 19,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SHOCKWAVE, :AIRCUTTER, :HIDDENPOWER, :UTURN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :WEAKID,
        :level => 19,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:DRAINPUNCH, :MACHPUNCH, :ROCKTOMB, :KNOCKOFF],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BUGRAY,
        :level => 19,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:BUGBITE, :STEELWING, :FELLSTINGER, :WINGATTACK],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FEVIRA,
        :level => 19,
        :item => :BLACKGLASSES,
        :ability => "",
        :nature => :TIMID,
        :moves => [:DARKMATTER, :FEVER, :DRAINPUNCH, :CALMMIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PURRYO,
        :level => 20,
        :item => :CHARCOAL,
        :ability => "",
        :nature => :TIMID,
        :moves => [:FLAMEBURST, :DUSTYDASH, :WILLOWISP, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rodney", :Rodney,7, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BAAWOOL,
        :level => 19,
        :item => :LIGHTCLAY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:HYPERVOICE, :HIDDENPOWER, :REFLECT, :LIGHTSCREEN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TERRAZ,
        :level => 19,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SHOCKWAVE, :AIRCUTTER, :HIDDENPOWER, :UTURN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :WEAKID,
        :level => 19,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:DRAINPUNCH, :MACHPUNCH, :ROCKTOMB, :KNOCKOFF],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BUGRAY,
        :level => 19,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:BUGBITE, :STEELWING, :FELLSTINGER, :WINGATTACK],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FEVIRA,
        :level => 19,
        :item => :BLACKGLASSES,
        :ability => "",
        :nature => :TIMID,
        :moves => [:DARKMATTER, :SLUDGE, :DRAINPUNCH, :CALMMIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SALANIP,
        :level => 20,
        :item => :MYSTICWATER,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:AQUASLAM, :BRICKBREAK, :CROSSPOISON, :KNOCKOFF],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rodney", :Rodney,8, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BAAWOOL,
        :level => 19,
        :item => :LIGHTCLAY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:HYPERVOICE, :HIDDENPOWER, :REFLECT, :LIGHTSCREEN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TERRAZ,
        :level => 19,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SHOCKWAVE, :AIRCUTTER, :HIDDENPOWER, :UTURN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :WEAKID,
        :level => 19,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:DRAINPUNCH, :MACHPUNCH, :ROCKTOMB, :KNOCKOFF],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BUGRAY,
        :level => 19,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:BUGBITE, :STEELWING, :FELLSTINGER, :WINGATTACK],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FEVIRA,
        :level => 19,
        :item => :BLACKGLASSES,
        :ability => "",
        :nature => :TIMID,
        :moves => [:DARKMATTER, :SLUDGE, :DRAINPUNCH, :CALMMIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FORESTONE,
        :level => 20,
        :item => :MIRACLESEED,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:RAZORLEAF, :ROCKTOMB, :BULLDOZE, :GROWTH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rodney", :Rodney,9, 0],
    :defeat => "",
    :mons => [
      {
        :species => :VALURE,
        :level => 25,
        :item => :RINDOBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:PSYSHOCK, :SCALD, :SLUDGEBOMB, :SIGNALBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BUDCHERP,
        :level => 25,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HYPERVOICE, :AIRSLASH, :HIDDENPOWER, :ROOST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LUNAPE,
        :level => 25,
        :item => :COLBURBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:PSYBEAM, :LIGHTBURST, :DARKPULSE, :FIREPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GROILLUM,
        :level => 25,
        :item => :COBABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:SEEDBOMB, :AERIALACE, :ROCKSLIDE, :BRICKBREAK],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FEVIRA,
        :level => 25,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :TIMID,
        :moves => [:DARKPULSE, :TOXIC, :VENOSHOCK, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PURRYO,
        :level => 26,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:LAVAPLUME, :DUSTYDASH, :CRACKLESLAM, :WILLOWISP],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rodney", :Rodney,10, 0],
    :defeat => "",
    :mons => [
      {
        :species => :DRAGOON,
        :level => 25,
        :item => :YACHEBERRY,
        :ability => "",
        :nature => :QUIET,
        :moves => [:GIGADRAIN, :DRAGONCLAW, :ROCKSLIDE, :SYNTHESIS],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BUDCHERP,
        :level => 25,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HYPERVOICE, :AIRSLASH, :HIDDENPOWER, :ROOST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LUNAPE,
        :level => 25,
        :item => :COLBURBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:PSYBEAM, :LIGHTBURST, :DARKPULSE, :FIREPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GRIZZLER,
        :level => 25,
        :item => :COBABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:FIREPUNCH, :THUNDERPUNCH, :ROCKSLIDE, :BRICKBREAK],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FEVIRA,
        :level => 25,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :TIMID,
        :moves => [:DARKPULSE, :TOXIC, :VENOSHOCK, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SALANIP,
        :level => 26,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:AQUASLAM, :CROSSPOISON, :ICEPUNCH, :SHADOWCLAW],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rodney", :Rodney,11, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SLITHEAT,
        :level => 25,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:FLAMETHROWER, :VENOSHOCK, :TOXIC, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BUDCHERP,
        :level => 25,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HYPERVOICE, :AIRSLASH, :HIDDENPOWER, :ROOST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LUNAPE,
        :level => 25,
        :item => :TANGABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:PSYBEAM, :LIGHTBURST, :DARKPULSE, :FIREPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :YAYAK,
        :level => 25,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:AQUATAIL, :ZENHEADBUTT, :TAKEDOWN, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FEVIRA,
        :level => 25,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :TIMID,
        :moves => [:DARKPULSE, :TOXIC, :VENOSHOCK, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FORESTONE,
        :level => 26,
        :item => :CHOPLEBERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:SEEDBOMB, :ROCKSLIDE, :ZENHEADBUTT, :BULLDOZE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rodney", :Rodney,12, 0],
    :defeat => "",
    :mons => [
      {
        :species => :LUNAPE,
        :level => 32,
        :item => :LIGHTCLAY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:REFLECT, :LIGHTSCREEN, :PSYSHOCK, :MOONBLAST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BUDSOAR,
        :level => 32,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:FLASHCANNON, :HYPERVOICE, :AIRSLASH, :HEATWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GROILLUM,
        :level => 32,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:SEEDBOMB, :DRAINPUNCH, :THUNDERPUNCH, :LEAFDARTS],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :VALURE,
        :level => 32,
        :item => :RINDOBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:SURF, :PSYCHIC, :ICEBEAM, :GIGADRAIN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FEVIRA,
        :level => 32,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :TIMID,
        :moves => [:DARKPULSE, :SLUDGEBOMB, :HIDDENPOWER, :CALMMIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PURRYO,
        :level => 33,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:FLAMETHROWER, :EARTHPOWER, :CRACKLESLAM, :WILLOWISP],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rodney", :Rodney,13, 0],
    :defeat => "",
    :mons => [
      {
        :species => :LUNAPE,
        :level => 32,
        :item => :LIGHTCLAY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:REFLECT, :LIGHTSCREEN, :PSYSHOCK, :MOONBLAST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BUDSOAR,
        :level => 32,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:FLASHCANNON, :HYPERVOICE, :AIRSLASH, :HEATWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GRIZZLER,
        :level => 32,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:FIREPUNCH, :DRAINPUNCH, :THUNDERPUNCH, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DRAGOON,
        :level => 32,
        :item => :YACHEBERRY,
        :ability => "",
        :nature => :QUIET,
        :moves => [:GIGADRAIN, :DRAGONCLAW, :ROCKSLIDE, :SYNTHESIS],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FEVIRA,
        :level => 32,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :TIMID,
        :moves => [:DARKPULSE, :SLUDGEBOMB, :HIDDENPOWER, :CALMMIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SALANIP,
        :level => 33,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:AQUATAIL, :POISONJAB, :RAINDANCE, :DRAINPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rodney", :Rodney,14, 0],
    :defeat => "",
    :mons => [
      {
        :species => :LUNAPE,
        :level => 32,
        :item => :LIGHTCLAY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:REFLECT, :LIGHTSCREEN, :PSYSHOCK, :MOONBLAST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BUDSOAR,
        :level => 32,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:FLASHCANNON, :HYPERVOICE, :AIRSLASH, :HEATWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :YAYAK,
        :level => 32,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:FACADE, :AQUATAIL, :CRUNCH, :ICEFANG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SLITHEAT,
        :level => 32,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:FLAMETHROWER, :VENOSHOCK, :TOXIC, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FEVIRA,
        :level => 32,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :TIMID,
        :moves => [:DARKPULSE, :SLUDGEBOMB, :HIDDENPOWER, :CALMMIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FORESTONE,
        :level => 33,
        :item => :CHOPLEBERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:SEEDBOMB, :STONEEDGE, :SYNTHESIS, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rodney", :Rodney,15, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BAABREEZE,
        :level => 40,
        :item => :POWERHERB,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:SKYATTACK, :DIG, :HEATWAVE, :BLIZZARD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DRACOFLY,
        :level => 40,
        :item => :CHARTIBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:FIRSTIMPRESSION, :DRAGONRUSH, :PINMISSILE, :UTURN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FEVESTA,
        :level => 40,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:NASTYPLOT, :DARKPULSE, :SLUDGEWAVE, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :VALURE,
        :level => 40,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:RIPPLEWAVE, :PSYSHOCK, :CALMMIND, :RECOVER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LUNAPE,
        :level => 40,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:CALMMIND, :PSYCHIC, :DAZZLINGGLEAM, :MOONLIGHT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FLEAROE,
        :level => 41,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:EARTHPOWER, :FLAMETHROWER, :CRACKLESLAM, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rodney", :Rodney,16, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BAABREEZE,
        :level => 40,
        :item => :POWERHERB,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:SKYATTACK, :DIG, :HEATWAVE, :BLIZZARD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DRACOFLY,
        :level => 40,
        :item => :CHARTIBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:FIRSTIMPRESSION, :DRAGONRUSH, :PINMISSILE, :UTURN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FEVESTA,
        :level => 40,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:NASTYPLOT, :DARKPULSE, :SLUDGEWAVE, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DRAGOON,
        :level => 40,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :QUIET,
        :moves => [:GIGADRAIN, :SYNTHESIS, :DRAGONRUSH, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LUNAPE,
        :level => 40,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:CALMMIND, :PSYCHIC, :DAZZLINGGLEAM, :MOONLIGHT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SALASLAM,
        :level => 41,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:AQUATAIL, :RAINDANCE, :POISONJAB, :DRAINPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rodney", :Rodney,17, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BAABREEZE,
        :level => 40,
        :item => :POWERHERB,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:SKYATTACK, :DIG, :HEATWAVE, :BLIZZARD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DRACOFLY,
        :level => 40,
        :item => :CHARTIBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:FIRSTIMPRESSION, :DRAGONRUSH, :PINMISSILE, :UTURN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FEVESTA,
        :level => 40,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:NASTYPLOT, :DARKPULSE, :SLUDGEWAVE, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SLITHEAT,
        :level => 40,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :TIMID,
        :moves => [:FLAMETHROWER, :SLUDGEWAVE, :EARTHPOWER, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LUNAPE,
        :level => 40,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:CALMMIND, :PSYCHIC, :DAZZLINGGLEAM, :MOONLIGHT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MOUNTREE,
        :level => 41,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:ROCKPOLISH, :PETALBLIZZARD, :STONEEDGE, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rodney", :Rodney,18, 0],
    :defeat => "",
    :mons => [
      {
        :species => :LEONITE,
        :level => 37,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:DIAMONDCLAW, :BITE, :ZENHEADBUTT, :HONECLAWS],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BAAWOOL,
        :level => 38,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:HEADBUTT, :YAWN, :COTTONSPORE, :COTTONGUARD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BULKER,
        :level => 38,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:WAKEUPSLAP, :SMACKDOWN, :ICEPUNCH, :FOCUSENERGY],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TERRAVOLT,
        :level => 39,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:PARABOLICCHARGE, :AIRCUTTER, :ENERGYBALL, :VOLTSWITCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LUNAPE,
        :level => 39,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:PSYBEAM, :LIGHTBURST, :DARKMATTER, :MOONLIGHT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FLEAROE,
        :level => 40,
        :item => :CHARCOAL,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FLAMEBURST, :DUSTYDASH, :FEINTATTACK, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rodney", :Rodney,19, 0],
    :defeat => "",
    :mons => [
      {
        :species => :LEONITE,
        :level => 37,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:DIAMONDCLAW, :BITE, :ZENHEADBUTT, :HONECLAWS],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BAAWOOL,
        :level => 38,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:HEADBUTT, :YAWN, :COTTONSPORE, :COTTONGUARD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BULKER,
        :level => 38,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:WAKEUPSLAP, :SMACKDOWN, :ICEPUNCH, :FOCUSENERGY],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TERRAVOLT,
        :level => 39,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:PARABOLICCHARGE, :AIRCUTTER, :ENERGYBALL, :VOLTSWITCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LUNAPE,
        :level => 39,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:PSYBEAM, :LIGHTBURST, :DARKMATTER, :MOONLIGHT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SALASLAM,
        :level => 40,
        :item => :MYSTICWATER,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:AQUASLAM, :ACIDSPRAY, :BRICKBREAK, :SCREECH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rodney", :Rodney,20, 0],
    :defeat => "",
    :mons => [
      {
        :species => :LEONITE,
        :level => 37,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:DIAMONDCLAW, :BITE, :ZENHEADBUTT, :HONECLAWS],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BAAWOOL,
        :level => 38,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:HEADBUTT, :YAWN, :COTTONSPORE, :COTTONGUARD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BULKER,
        :level => 38,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:WAKEUPSLAP, :SMACKDOWN, :ICEPUNCH, :FOCUSENERGY],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TERRAVOLT,
        :level => 39,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:PARABOLICCHARGE, :AIRCUTTER, :ENERGYBALL, :VOLTSWITCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LUNAPE,
        :level => 39,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:PSYBEAM, :LIGHTBURST, :DARKMATTER, :MOONLIGHT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MOUNTREE,
        :level => 40,
        :item => :MIRACLESEED,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:RAZORLEAF, :ROCKTOMB, :WILDCHARGE, :ROCKPOLISH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rodney", :Rodney,21, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BULKER,
        :level => 46,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:HAMMERARM, :IRONHEAD, :ICEPUNCH, :THUNDERPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LUNAPE,
        :level => 46,
        :item => :KASIBBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:LIGHTSCREEN, :REFLECT, :PSYCHIC, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LEONITE,
        :level => 46,
        :item => :LIFEORB,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:ROCKSLIDE, :CRUNCH, :DRILLRUN, :CRACKLESLAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DRACOFLY,
        :level => 46,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:FIRSTIMPRESSION, :DRAGONRUSH, :POISONJAB, :PINMISSILE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TERRAVOLT,
        :level => 46,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SQUALLBLOW, :THUNDERBOLT, :HEATWAVE, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FLEAROE,
        :level => 47,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:HEATWAVE, :EARTHPOWER, :CRACKLESLAM, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rodney", :Rodney,22, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BULKER,
        :level => 46,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:HAMMERARM, :IRONHEAD, :ICEPUNCH, :THUNDERPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LUNAPE,
        :level => 46,
        :item => :KASIBBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:LIGHTSCREEN, :REFLECT, :PSYCHIC, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LEONITE,
        :level => 46,
        :item => :LIFEORB,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:ROCKSLIDE, :CRUNCH, :DRILLRUN, :CRACKLESLAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DRACOFLY,
        :level => 46,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:FIRSTIMPRESSION, :DRAGONRUSH, :POISONJAB, :PINMISSILE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TERRAVOLT,
        :level => 46,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SQUALLBLOW, :THUNDERBOLT, :HEATWAVE, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SALASLAM,
        :level => 47,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:AQUATAIL, :GUNKSHOT, :ICEPUNCH, :DRAINPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rodney", :Rodney,23, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BULKER,
        :level => 46,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:HAMMERARM, :IRONHEAD, :ICEPUNCH, :THUNDERPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LUNAPE,
        :level => 46,
        :item => :KASIBBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:LIGHTSCREEN, :REFLECT, :PSYCHIC, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LEONITE,
        :level => 46,
        :item => :LIFEORB,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:ROCKSLIDE, :CRUNCH, :DRILLRUN, :CRACKLESLAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DRACOFLY,
        :level => 46,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:FIRSTIMPRESSION, :DRAGONRUSH, :POISONJAB, :PINMISSILE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TERRAVOLT,
        :level => 46,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SQUALLBLOW, :THUNDERBOLT, :HEATWAVE, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MOUNTREE,
        :level => 47,
        :item => :CHOPLEBERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:PETALBLIZZARD, :ROCKSLIDE, :IRONTAIL, :ZENHEADBUTT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rodney", :Rodney,24, 0],
    :defeat => "",
    :mons => [
      {
        :species => :LEONITE,
        :level => 50,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:DIAMONDCLAW, :CRUNCH, :ZENHEADBUTT, :HONECLAWS],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BAABUSH,
        :level => 50,
        :item => :MIRACLESEED,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:GIGADRAIN, :HYPERVOICE, :COTTONGUARD, :LEECHSEED],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TERRAVOLT,
        :level => 51,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:PARABOLICCHARGE, :AIRSLASH, :ENERGYBALL, :VOLTSWITCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LUNAPE,
        :level => 51,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:PSYCHIC, :MOONBLAST, :AMNESIA, :MOONLIGHT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BUDSOAR,
        :level => 51,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:ECHOEDVOICE, :CHATTER, :HEATWAVE, :ROOST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FLEAROE,
        :level => 52,
        :item => :FLEAROENITE,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FLAREBLITZ, :DUSTYDASH, :ANCIENTPOWER, :SNARL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rodney", :Rodney,25, 0],
    :defeat => "",
    :mons => [
      {
        :species => :LEONITE,
        :level => 50,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:DIAMONDCLAW, :CRUNCH, :ZENHEADBUTT, :HONECLAWS],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BAABLAZE,
        :level => 50,
        :item => :CHARCOAL,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FLAMETHROWER, :HYPERVOICE, :EARTHPOWER, :WILLOWISP],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TERRAVOLT,
        :level => 51,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:PARABOLICCHARGE, :AIRSLASH, :ENERGYBALL, :VOLTSWITCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LUNAPE,
        :level => 51,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:PSYCHIC, :MOONBLAST, :AMNESIA, :MOONLIGHT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BUDSOAR,
        :level => 51,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:ECHOEDVOICE, :CHATTER, :HEATWAVE, :ROOST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SALASLAM,
        :level => 52,
        :item => :SALASLAMITE,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:AQUASLAM, :POISONJAB, :BRICKBREAK, :SCREECH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rodney", :Rodney,26, 0],
    :defeat => "",
    :mons => [
      {
        :species => :LEONITE,
        :level => 50,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:DIAMONDCLAW, :CRUNCH, :ZENHEADBUTT, :HONECLAWS],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BAABBLE,
        :level => 50,
        :item => :MYSTICWATER,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:BRINE, :BODYSLAM, :YAWN, :REFLECT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TERRAVOLT,
        :level => 51,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:PARABOLICCHARGE, :AIRSLASH, :ENERGYBALL, :VOLTSWITCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LUNAPE,
        :level => 51,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:PSYCHIC, :MOONBLAST, :AMNESIA, :MOONLIGHT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BUDSOAR,
        :level => 51,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:ECHOEDVOICE, :CHATTER, :HEATWAVE, :ROOST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MOUNTREE,
        :level => 52,
        :item => :MOUNTREENITE,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:WOODHAMMER, :ROCKTOMB, :WILDCHARGE, :ROCKPOLISH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rodney", :Rodney,27, 0],
    :defeat => "",
    :mons => [
      {
        :species => :TUNDRILL,
        :level => 58,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:RAZORBLADE, :ICICLECRASH, :DRILLRUN, :ICESHARD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BAABUSH,
        :level => 58,
        :item => :MIRACLESEED,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:GIGADRAIN, :HYPERVOICE, :COTTONGUARD, :LEECHSEED],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BULKER,
        :level => 59,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:HAMMERARM, :ROCKSLIDE, :ICEPUNCH, :BATTLECRY],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LUNAPE,
        :level => 59,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:PSYCHIC, :MOONBLAST, :AMNESIA, :MOONLIGHT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BUDSOAR,
        :level => 59,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:ECHOEDVOICE, :CHATTER, :HEATWAVE, :ROOST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FLEAROE,
        :level => 60,
        :item => :FLEAROENITE,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FLAREBLITZ, :EARTHPOWER, :ANCIENTPOWER, :SNARL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rodney", :Rodney,28, 0],
    :defeat => "",
    :mons => [
      {
        :species => :TUNDRILL,
        :level => 58,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:RAZORBLADE, :ICICLECRASH, :DRILLRUN, :ICESHARD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BAABLAZE,
        :level => 58,
        :item => :CHARCOAL,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FLAMETHROWER, :EARTHPOWER, :EARTHPOWER, :WILLOWISP],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BULKER,
        :level => 59,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:HAMMERARM, :ROCKSLIDE, :ICEPUNCH, :BATTLECRY],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LUNAPE,
        :level => 59,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:PSYBEAM, :MOONBLAST, :SWIFT, :MOONLIGHT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BUDSOAR,
        :level => 59,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:ECHOEDVOICE, :CHATTER, :HEATWAVE, :ROOST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SALASLAM,
        :level => 60,
        :item => :SALASLAMITE,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:AQUASLAM, :POISONJAB, :BRICKBREAK, :ICEPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rodney", :Rodney,29, 0],
    :defeat => "",
    :mons => [
      {
        :species => :TUNDRILL,
        :level => 58,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:RAZORBLADE, :ICICLECRASH, :DRILLRUN, :ICESHARD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BAABBLE,
        :level => 58,
        :item => :MYSTICWATER,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:BRINE, :BODYSLAM, :YAWN, :REFLECT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BULKER,
        :level => 59,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:HAMMERARM, :ROCKSLIDE, :ICEPUNCH, :BATTLECRY],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LUNAPE,
        :level => 59,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:PSYBEAM, :MOONBLAST, :SWIFT, :MOONLIGHT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BUDSOAR,
        :level => 59,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:ECHOEDVOICE, :CHATTER, :HEATWAVE, :ROOST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MOUNTREE,
        :level => 60,
        :item => :MOUNTREENITE,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:WOODHAMMER, :HEADSMASH, :WILDCHARGE, :ROCKPOLISH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rodney", :Rodney,30, 0],
    :defeat => "",
    :mons => [
      {
        :species => :LUNAPE,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:PSYSHOCK, :MOONBLAST, :DUSTYDASH, :CALMMIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BUDSOAR,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:HYPERVOICE, :CHATTER, :ENERGYBALL, :HEATWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BULKER,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FOCUSPUNCH, :SUBSTITUTE, :DRAINPUNCH, :KNOCKOFF],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BAABUSH,
        :level => 65,
        :item => :MIRACLESEED,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:GIGADRAIN, :HYPERVOICE, :LEECHSEED, :GRASSYTERRAIN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FLEAROE,
        :level => 65,
        :item => :FLEAROENITE,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FIREBLAST, :EARTHPOWER, :HYPERVOICE, :NASTYPLOT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rodney", :Rodney,31, 0],
    :defeat => "",
    :mons => [
      {
        :species => :LUNAPE,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:PSYSHOCK, :MOONBLAST, :DUSTYDASH, :CALMMIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BUDSOAR,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:HYPERVOICE, :CHATTER, :ENERGYBALL, :HEATWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BULKER,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FOCUSPUNCH, :SUBSTITUTE, :DRAINPUNCH, :KNOCKOFF],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BAABLAZE,
        :level => 65,
        :item => :CHARCOAL,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:HYPERVOICE, :FLAMECHARGE, :EARTHPOWER, :FLAREUP],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SALASLAM,
        :level => 65,
        :item => :SALASLAMITE,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:WATERFALL, :GUNKSHOT, :ICEPUNCH, :HONECLAWS],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rodney", :Rodney,32, 0],
    :defeat => "",
    :mons => [
      {
        :species => :LUNAPE,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:PSYSHOCK, :MOONBLAST, :DUSTYDASH, :CALMMIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BUDSOAR,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:HYPERVOICE, :CHATTER, :ENERGYBALL, :HEATWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BULKER,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FOCUSPUNCH, :SUBSTITUTE, :DRAINPUNCH, :KNOCKOFF],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BAABBLE,
        :level => 65,
        :item => :MYSTICWATER,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:SCALD, :HYPERVOICE, :ICEBEAM, :CALMMIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MOUNTREE,
        :level => 65,
        :item => :MOUNTREENITE,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:WOODHAMMER, :HEADSMASH, :WILDCHARGE, :ROCKPOLISH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rodney", :Rodney,33, 0],
    :defeat => "",
    :mons => [
      {
        :species => :TUNDRILL,
        :level => 80,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:RAZORBLADE, :GLACIERCRASH, :DRILLRUN, :FOCUSENERGY],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TERRAVOLT,
        :level => 80,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:HURRICANE, :THUNDERBOLT, :DAZZLINGGLEAM, :VOLTSWITCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BUDSOAR,
        :level => 80,
        :item => :LIFEORB,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:HYPERVOICE, :HEATWAVE, :ENERGYBALL, :UTURN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BULKER,
        :level => 80,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:DRAINPUNCH, :POWERUPPUNCH, :EARTHQUAKE, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BAABUSH,
        :level => 80,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:LEAFSTORM, :HYPERVOICE, :EARTHQUAKE, :SYNTHESIS],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FLEAROE,
        :level => 80,
        :item => :FLEAROENITE,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FIREBLAST, :EARTHPOWER, :ANCIENTPOWER, :CRACKLESLAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rodney", :Rodney,34, 0],
    :defeat => "",
    :mons => [
      {
        :species => :TUNDRILL,
        :level => 80,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:RAZORBLADE, :GLACIERCRASH, :DRILLRUN, :FOCUSENERGY],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TERRAVOLT,
        :level => 80,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:HURRICANE, :THUNDERBOLT, :DAZZLINGGLEAM, :VOLTSWITCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BUDSOAR,
        :level => 80,
        :item => :LIFEORB,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:HYPERVOICE, :HEATWAVE, :ENERGYBALL, :UTURN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BULKER,
        :level => 80,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:DRAINPUNCH, :POWERUPPUNCH, :EARTHQUAKE, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BAABLAZE,
        :level => 80,
        :item => :CHOICESPECS,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FIREBLAST, :HYPERVOICE, :EARTHPOWER, :HYPERBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SALASLAM,
        :level => 80,
        :item => :SALASLAMITE,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:AQUATAIL, :GUNKSHOT, :ICEPUNCH, :SUCKERPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rodney", :Rodney,35, 0],
    :defeat => "",
    :mons => [
      {
        :species => :TUNDRILL,
        :level => 80,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:RAZORBLADE, :GLACIERCRASH, :DRILLRUN, :FOCUSENERGY],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TERRAVOLT,
        :level => 80,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:HURRICANE, :THUNDERBOLT, :DAZZLINGGLEAM, :VOLTSWITCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BUDSOAR,
        :level => 80,
        :item => :LIFEORB,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:HYPERVOICE, :HEATWAVE, :ENERGYBALL, :UTURN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BULKER,
        :level => 80,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:DRAINPUNCH, :POWERUPPUNCH, :EARTHQUAKE, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BAABBLE,
        :level => 80,
        :item => :LEFTOVERS,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:SCALD, :ICYWIND, :AQUARING, :REFLECT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MOUNTREE,
        :level => 80,
        :item => :MOUNTREENITE,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:WOODHAMMER, :HEADSMASH, :ZENHEADBUTT, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Claudia", :POKEFAN_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BUSHOO,
        :level => 19,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:MAGICALLEAF, :HIDDENPOWER, :LEECHSEED, :SYNTHESIS],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SPONY,
        :level => 19,
        :item => "",
        :ability => "",
        :nature => :JOLLY,
        :moves => [:BULLDOZE, :RAZORLEAF, :GROWTH, :STOMP],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CHEEPIP,
        :level => 19,
        :item => "",
        :ability => "",
        :nature => :TIMID,
        :moves => [:AIRSLASH, :MAGICALLEAF, :ROOST, :UTURN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Alanah", :POKEFAN_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ZEBRITE,
        :level => 39,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FLAPINKO,
        :level => 39,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Magarete", :POKEFAN_Female,1, 0],
    :defeat => "",
    :mons => [
      {
        :species => :RUSHOT,
        :level => 37,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PHOXIVEN,
        :level => 37,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:SWIFT, :ENCORE, :DRAININGKISS, :REFLECT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Magarete", :POKEFAN_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ZUPPY,
        :level => 16,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Robert", :POKEFAN_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ZUPPY,
        :level => 19,
        :item => :ELECTRICGEM,
        :ability => "",
        :nature => :TIMID,
        :moves => [:ELECTROBALL, :SIGNALBEAM, :UPROAR, :SHOCKWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ZUPPY,
        :level => 19,
        :item => :ELECTRICGEM,
        :ability => "",
        :nature => :TIMID,
        :moves => [:ELECTROBALL, :SIGNALBEAM, :UPROAR, :SHOCKWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :WEASHOCK,
        :level => 20,
        :item => :WISEGLASSES,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SHOCKWAVE, :FLAMEBURST, :HIDDENPOWER, :FACADE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Jared", :POKEFAN_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BULLSON,
        :level => 39,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CHEETRIC,
        :level => 39,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Wayne", :POKEFAN_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :FLAWK,
        :level => 16,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Wayne", :POKEFAN_Male,1, 0],
    :defeat => "",
    :mons => [
      {
        :species => :LEGENIX,
        :level => 37,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :POOLDOG,
        :level => 37,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Elia", :PRESCHOOLER_Female, 0],
    :defeat => "Oh...",
    :mons => [
      {
        :species => :SPONY,
        :level => 13,
        :item => :MIRACLESEED,
        :ability => :QUICKFEET,
        :nature => :JOLLY,
        :moves => [:RAZORLEAF,:DOUBLEKICK,:BULLDOZE,:STOMP],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :BUDCHEEP,
        :level => 13,
        :ability => :RATTLED,
        :nature => :MODEST,
        :moves => [:ROUND,:AIRCUTTER,:ROOST,:HIDDENPOWERGRO],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Timothy", :PRESCHOOLER_Male, 0],
    :defeat => "Hiking day is ruined.",
    :mons => [
      {
        :species => :SPIDOX,
        :level => 15,
        :item => :TELLURICSEED,
        :ability => :POISONTOUCH,
        :nature => :JOLLY,
        :moves => [:BUGBITE,:POISONFANG,:KNOCKOFF,:HIDDENPOWERGRA],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
    ]
  },
  {
    :teamid => ["Vivien", :PSYCHIC_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :HYPNOSMOG,
        :level => 61,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :KAPPLASH,
        :level => 61,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rayne", :PSYCHIC_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :CYCRILL,
        :level => 48,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:AIRSLASH, :SHADOWBALL, :FREEZEDRY, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GECKONE,
        :level => 48,
        :item => :LIFEORB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:THUNDERBOLT, :PSYCHIC, :ICEBEAM, :SHADOWBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ZEBRITE,
        :level => 48,
        :item => :COLBURBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:PSYSHOCK, :SIGNALBEAM, :SHADOWBALL, :ICEBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Laelia", :PSYCHIC_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :MYSTABLET,
        :level => 53,
        :item => :OCCABERRY,
        :ability => "",
        :nature => :QUIET,
        :moves => [:TRICKROOM, :PSYCHIC, :FLASHCANNON, :ICEBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :HYPNOSMOG,
        :level => 53,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :QUIET,
        :moves => [:SPORE, :PSYSHOCK, :MOONBLAST, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ECLIPSER,
        :level => 53,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :QUIET,
        :moves => [:TRICKROOM, :OVERHEAT, :PSYCHIC, :GEODECANNON],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Padma", :PSYCHIC_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :MYSTABLET,
        :level => 48,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :QUIET,
        :moves => [:TRICKROOM, :FLASHCANNON, :PSYCHIC, :ICEBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Junis", :PSYCHIC_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PSYTRIC,
        :level => 61,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ZEBRITE,
        :level => 61,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Ladislav", :PSYCHIC_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ZEBRITE,
        :level => 53,
        :item => :LIGHTCLAY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:REFLECT, :LIGHTSCREEN, :PSYCHIC, :MOONBLAST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MELOTWEET,
        :level => 53,
        :item => :KEBIABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:PSYCHIC, :DAZZLINGGLEAM, :HEATWAVE, :SQUALLBLOW],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CYCRILL,
        :level => 53,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SHADOWBALL, :SQUALLBLOW, :DARKPULSE, :AIRCANNON],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BLIMPOON,
        :level => 53,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :MODEST,
        :moves => [:FLASHCANNON, :SQUALLBLOW, :HEATWAVE, :AIRCANNON],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Pacey", :PSYCHIC_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :HYPNOPUFF,
        :level => 42,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SNOOZEE,
        :level => 42,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :NAPKID,
        :level => 42,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Randolph", :PSYCHIC_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :LUNAPE,
        :level => 48,
        :item => :LIGHTCLAY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:REFLECT, :LIGHTSCREEN, :PSYCHIC, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PSYTRIC,
        :level => 48,
        :item => :MAGNET,
        :ability => "",
        :nature => :TIMID,
        :moves => [:THUNDERBOLT, :PSYCHIC, :ENERGYBALL, :FOCUSBLAST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :VALURE,
        :level => 48,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:MUDDYWATER, :PSYSHOCK, :ICEBEAM, :SIGNALBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Lyla", :PUNKGIRL, 0],
    :defeat => "",
    :mons => [
      {
        :species => :COBOLTA,
        :level => 39,
        :item => :AIRBALLOON,
        :ability => "",
        :nature => :TIMID,
        :moves => [:THUNDERBOLT, :SLUDGEWAVE, :ENERGYBALL, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :WEREHIDE,
        :level => 39,
        :item => :TANGABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:CRUNCH, :FIREFANG, :ICEFANG, :THUNDERFANG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BOULDOX,
        :level => 39,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:EARTHQUAKE, :CROSSPOISON, :STONEEDGE, :PINMISSILE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Shauna", :PUNKGIRL, 0],
    :defeat => "",
    :mons => [
      {
        :species => :TOXITOAD,
        :level => 38,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :QUIET,
        :moves => [:SLUDGEWAVE, :SURF, :EARTHQUAKE, :DRAINPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :HOLLOWKIN,
        :level => 38,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :IMPISH,
        :moves => [:LEECHSEED, :PHANTOMGRIP, :XSCISSOR, :PROTECT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BANSHREEK,
        :level => 38,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :MODEST,
        :moves => [:SHADOWBALL, :HIDDENPOWER, :PSYCHIC, :SIGNALBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Shirley", :PUNKGIRL, 0],
    :defeat => "You can see in the dark too?",
    :mons => [
      {
        :species => :APEIN,
        :level => 17,
        :item => :BLACKGLASSES,
        :ability => :ANGERPOINT,
        :nature => :JOLLY,
        :moves => [:BRUTALSWING,:FAKEOUT,:HEADBUTT,:BRICKBREAK],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :BEOPUP,
        :level => 17,
        :item => :BERRYJUICE,
        :ability => :STRONGJAW,
        :nature => :JOLLY,
        :moves => [:FEINTATTACK,:THUNDERFANG,:QUICKATTACK,:TRAILBLAZE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :VENNAP,
        :level => 18,
        :item => :EVIOLITE,
        :ability => :INSECTIVORE,
        :nature => :QUIRKY,
        :moves => [:BITE,:RAZORLEAF,:BULLDOZE,:ROCKTOMB],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Hellena", :PUNKGIRL, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BEOPUP,
        :level => 15,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Corey", :PUNKGUY, 0],
    :defeat => "",
    :mons => [
      {
        :species => :VENNAP,
        :level => 17,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:FEINTATTACK, :RAZORLEAF, :SUPERFANG, :INFESTATION],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BEOPUP,
        :level => 17,
        :item => :BLACKGLASSES,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:BITE, :FIREFANG, :ICEFANG, :THUNDERFANG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PARAFOX,
        :level => 17,
        :item => :SPELLTAG,
        :ability => "",
        :nature => :TIMID,
        :moves => [:OMINOUSWIND, :SWIFT, :HIDDENPOWER, :SHADOWSNEAK],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Gregory", :PUNKGUY, 0],
    :defeat => "",
    :mons => [
      {
        :species => :STOTOX,
        :level => 13,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Pius", :PUNKGUY, 0],
    :defeat => "",
    :mons => [
      {
        :species => :HUMBREECH,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:WATERSPOUT, :SCALD, :METALBURST, :REST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CARBONITRO,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:DRYICE, :FLAMETHROWER, :EARTHPOWER, :WILLOWISP],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :RAIZODON,
        :level => 65,
        :item => :RAIZODONITE,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:CRACKLESLAM, :OUTRAGE, :FIREBLAST, :IRONHEAD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Felix", :PUNKGUY, 0],
    :defeat => "",
    :mons => [
      {
        :species => :TROLLERK,
        :level => 38,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:PLAYROUGH, :SUCKERPUNCH, :ROCKSLIDE, :FIREPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FUNGERM,
        :level => 38,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SULFURICSPRAY, :GIGADRAIN, :HIDDENPOWER, :TOXIC],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MONSTRAP,
        :level => 38,
        :item => :OCCABERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:CRUNCH, :SEEDBOMB, :KNOCKOFF, :BULLDOZE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Sean", :PUNKGUY, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SASCRUSH,
        :level => 39,
        :item => :CHOPLEBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:KNOCKOFF, :MEGAPUNCH, :DRAINPUNCH, :THUNDERPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Samuel", :RANCHER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BAABUSH,
        :level => 44,
        :item => :KEEBERRY,
        :ability => "",
        :nature => :BOLD,
        :moves => [:SYNTHESIS, :CALMMIND, :DUSTYDASH, :GIGADRAIN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Jacob", :RANCHER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BUSHAIRY,
        :level => 44,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :BRAVE,
        :moves => [:ENERGYBALL, :TRICKROOM, :EARTHQUAKE, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GIGLOO,
        :level => 44,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :BRAVE,
        :moves => [:ICICLESPEAR, :ROCKBLAST, :FREEZEDRY, :VACUUMWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BARBVIRAL,
        :level => 44,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :BRAVE,
        :moves => [:GYROBALL, :POISONJAB, :EARTHQUAKE, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Brooklyn", :RICHBOY, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PUPOOL,
        :level => 23,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:AQUASLAM, :ICEFANG, :AQUAJET, :PLAYROUGH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LUNAPE,
        :level => 23,
        :item => :COLBURBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:EXTRASENSORY, :LIGHTBURST, :HIDDENPOWER, :SIGNALBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Willi", :RICHBOY, 0],
    :defeat => "",
    :mons => [
      {
        :species => :GECKONE,
        :level => 32,
        :item => :LIFEORB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:EXTRASENSORY, :SIGNALBEAM, :DAZZLINGGLEAM, :AIRCANNON],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PARAFUL,
        :level => 32,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:CRUSHCLAW, :GALERUSH, :STEELWING, :UTURN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :WORMUNE,
        :level => 31,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:DRILLRUN, :UTURN, :ROCKSLIDE, :IRONHEAD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Dwayne", :ROUGHNECK, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BARBALL,
        :level => 33,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:TOXICSPIKES, :DRILLRUN, :POISONJAB, :IRONHEAD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FEVIRA,
        :level => 33,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :TIMID,
        :moves => [:DARKPULSE, :SLUDGEBOMB, :HIDDENPOWER, :VENOSHOCK],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Dirk", :ROUGHNECK, 0],
    :defeat => "",
    :mons => [
      {
        :species => :RAIZODON,
        :level => 33,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:CRACKLESLAM, :EARTHQUAKE, :DRAGONCLAW, :FIREFANG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BLIMPOON,
        :level => 33,
        :item => :LIFEORB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:FLASHCANNON, :SQUALLBLOW, :HEATWAVE, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Chandler", :ROUGHNECK, 0],
    :defeat => "",
    :mons => [
      {
        :species => :IRIMP,
        :level => 33,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:FLASHCANNON, :SQUALLBLOW, :SIGNALBEAM, :ICYWIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :WIDOX,
        :level => 33,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:POISONJAB, :XSCISSOR, :CRUNCH, :THUNDERFANG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Tyson", :RUINMANIAC, 0],
    :defeat => "",
    :mons => [
      {
        :species => :WRAPHRO,
        :level => 26,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :IMPISH,
        :moves => [:NIGHTSHADE, :HYPNOSIS, :DRAINPUNCH, :PAINSPLIT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FIZIRE,
        :level => 26,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:POWERGEM, :LAVAPLUME, :SCALD, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Juan", :RUINMANIAC, 0],
    :defeat => "Wow, I've been defeated!",
    :mons => [
      {
        :species => :DAEOGON,
        :level => 38,
        :item => :ASSAULTVEST,
        :ability => :THICKFAT,
        :nature => :ADAMANT,
        :moves => [:EARTHQUAKE, :DRAGONRUSH, :ROCKSLIDE, :IRONTAIL],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
      {
        :species => :BLIZZIBAT,
        :level => 40,
        :pulse3 => true,
        :item => :FOCUSSASH,
        :ability => :TELEPATHY,
        :nature => :TIMID,
        :moves => [:BOOMBURST, :SLUDGEWAVE, :ENERGYBALL, :FREEZEDRY],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :METEROCK,
        :level => 38,
        :item => :TELLURICSEED,
        :ability => :UNBURDEN,
        :nature => :ADAMANT,
        :moves => [:ROCKSLIDE, :CRACKLESLAM, :ACROBATICS, :GLACIERCRASH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :JEWELTAL,
        :level => 41,
        :pulse3 => true,
        :item => :TELLURICSEED,
        :ability => :MAGICGUARD,
        :nature => :TIMID,
        :moves => [:BUGBUZZ, :POWERGEM, :DAZZLINGGLEAM, :ICEBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252],
        :statmults => [1.2,1,1,1.2,1,1]
      },
      {
        :species => :CORALTLE,
        :level => 38,
        :item => :RINDOBERRY,
        :ability => :WATERABSORB,
        :nature => :MODEST,
        :moves => [:POWERGEM, :MUDDYWATER, :THUNDERBOLT, :ICEBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0,0]
      },
      {
        :species => :SPIRIX,
        :level => 38,
        :item => :LIFEORB,
        :ability => :KEENEYE,
        :nature => :TIMID,
        :moves => [:HYPERVOICE, :SHADOWBALL, :DAZZLINGGLEAM, :DARKPULSE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0,252]
      },
    ]
  },
  {
    :teamid => ["Gerrit", :RUINMANIAC, 0],
    :defeat => "",
    :mons => [
      {
        :species => :STEGRON,
        :level => 27,
        :item => :CHOPLEBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:FLASHCANNON, :GEODECANNON, :THUNDERBOLT, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :REXITE,
        :level => 27,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:FIREFANG, :ROCKSLIDE, :IRONHEAD, :THUNDERFANG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Anton", :RUINMANIAC, 0],
    :defeat => "",
    :mons => [
      {
        :species => :GOLKID,
        :level => 16,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Dorian", :RUINMANIAC, 0],
    :defeat => "",
    :mons => [
      {
        :species => :GOLEMO,
        :level => 20,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:ROCKSLIDE, :DRAINPUNCH, :FIREPUNCH, :BULLDOZE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Beric", :RUINMANIAC, 0],
    :defeat => "",
    :mons => [
      {
        :species => :AVALDEER,
        :level => 54,
        :item => :ENIGMABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:SWORDSDANCE, :ICICLECRASH, :RETURN, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Archie", :RUINMANIAC, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ECLIPSER,
        :level => 45,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:POWERGEM, :OVERHEAT, :PSYSHOCK, :EARTHPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :JEWELTAL,
        :level => 45,
        :item => :CHARTIBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:POWERGEM, :BUGBUZZ, :ROCKPOLISH, :FREEZEDRY],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ATOMOTRO,
        :level => 45,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:FLASHCANNON, :THUNDERBOLT, :ENERGYBALL, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Halvar", :RUINMANIAC, 0],
    :defeat => "",
    :mons => [
      {
        :species => :GIGLOO,
        :level => 54,
        :item => :IAPAPABERRY,
        :ability => "",
        :nature => :BRAVE,
        :moves => [:ICICLESPEAR, :ROCKBLAST, :EARTHQUAKE, :ICESHARD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Helmut", :RUINMANIAC, 0],
    :defeat => "",
    :mons => [
      {
        :species => :METEROCK,
        :level => 45,
        :item => :LIFEORB,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:STONEEDGE, :CRACKLESLAM, :IRONHEAD, :GALERUSH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SNAPIKE,
        :level => 45,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:POISONJAB, :EARTHQUAKE, :STONEEDGE, :DRAINPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ROTTOWEEN,
        :level => 45,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :CAREFUL,
        :moves => [:LEECHSEED, :PROTECT, :PHANTOMGRIP, :XSCISSOR],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Jeffrey", :RUINMANIAC, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SANDSTER,
        :level => 20,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :WRAPHRO,
        :level => 20,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Colin", :RUINMANIAC, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PHAROBE,
        :level => 61,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ECLIPSER,
        :level => 61,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Hugo", :RUINMANIAC, 0],
    :defeat => "",
    :mons => [
      {
        :species => :COUNTULA,
        :level => 61,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :WORMOLE,
        :level => 61,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Daria", :SAFARIRANGER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :GIRAFIRE,
        :level => 38,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :HIPPOND,
        :level => 38,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CHEETRIC,
        :level => 38,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Kiano", :SAFARIRANGER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ROLLIE,
        :level => 38,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :YAYAK,
        :level => 38,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LEONITE,
        :level => 38,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Susie", :SCHOOLKID_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :FAYELY,
        :level => 11,
        :item => :ORANBERRY,
        :ability => :THICKFAT,
        :nature => :BOLD,
        :moves => [:LIGHTBURST, :DRAGONBREATH, :BABYDOLLEYES, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Sharon", :SCHOOLKID_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :LAVENSEED,
        :level => 8,
        :ability => :FRIENDGUARD,
        :nature => :MODEST,
        :moves => [:LEECHSEED, :FAIRYWIND, :CHARM, :ABSORB],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
      {
        :species => :PIXWEE,
        :level => 9,
        :ability => :LEVITATE,
        :nature => :NAIVE,
        :moves => [:FAIRYWIND, :GUST, :STUNSPORE, :BUGBITE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
    ]
  },
  {
    :teamid => ["Concetta", :SCHOOLKID_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :LUNAPE,
        :level => 48,
        :item => :COLBURBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SHADOWBALL, :ENERGYBALL, :DAZZLINGGLEAM, :PSYCHIC],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :WOODAWN,
        :level => 48,
        :item => :YACHEBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:BULLETSEED, :WINGATTACK, :DRILLRUN, :KNOCKOFF],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rayna", :SCHOOLKID_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :STRIKON,
        :level => 11,
        :item => :ORANBERRY,
        :ability => :VOLTABSORB,
        :nature => :TIMID,
        :moves => [:THUNDERWAVE, :THUNDERSHOCK, :DRAGONBREATH, :AIRCUTTER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Kelly", :SCHOOLKID_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PHOXIVEN,
        :level => 31,
        :item => :LIFEORB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:DAZZLINGGLEAM, :MYSTICALFIRE, :EXTRASENSORY, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DOVEHEART,
        :level => 31,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:AIRSLASH, :DAZZLINGGLEAM, :ROOST, :HEATWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Bob", :SCHOOLKID_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SNUFFUZZ,
        :level => 31,
        :item => :CHOPLEBERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:HYPERFANG, :CRUNCH, :CRACKLESLAM, :IRONHEAD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DARTOAD,
        :level => 31,
        :item => :OCCABERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:SLUDGEBOMB, :GIGADRAIN, :SCALD, :ICEBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Toby", :SCHOOLKID_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SERPYRO,
        :level => 11,
        :item => :ORANBERRY,
        :ability => :SHEDSKIN,
        :nature => :ADAMANT,
        :moves => [:FLAMECHARGE, :COIL, :BULLDOZE, :DRAGONTAIL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Filippo", :SCHOOLKID_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :DARTOAD,
        :level => 48,
        :item => :OCCABERRY,
        :ability => "",
        :nature => :QUIET,
        :moves => [:GIGADRAIN, :SLUDGEBOMB, :MUDDYWATER, :LEAFDARTS],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BUDSOAR,
        :level => 48,
        :item => :LIFEORB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HYPERVOICE, :SQUALLBLOW, :ENERGYBALL, :HEATWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Lockey", :SCHOOLKID_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :POOLDOG,
        :level => 42,
        :item => :SPLASHPLATE,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:MEGALOFANG, :AQUAJET, :WILDCHARGE, :GLACIERCRASH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ECLIPSER,
        :level => 42,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:OVERHEAT, :POWERGEM, :PSYSHOCK, :MOONBLAST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SCORPINOVA,
        :level => 42,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:SOLARCLAW, :DRILLRUN, :ROCKSLIDE, :HONECLAWS],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Pauli", :SCHOOLKID_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PINKMEE,
        :level => 11,
        :item => :ORANBERRY,
        :ability => :SHELLARMOR,
        :nature => :TIMID,
        :moves => [:SING, :WATERPULSE, :DRAGONBREATH, :ICYWIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Michael", :SCHOOLKID_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :UGLING,
        :level => 10,
        :ability => :TECHNICIAN,
        :nature => :TIMID,
        :moves => [:BUBBLE, :GUST, :FEATHERDANCE, :HEADBUTT],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Cord", :ARTIST, 0],
    :defeat => "",
    :mons => [
      {
        :species => :TUNDRILL,
        :level => 65,
        :item => :CHOPLEBERRY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:RAZORBLADE, :ICICLECRASH, :DRILLRUN, :FOCUSENERGY],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SWELLEGANT,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:SCALD, :AIRSLASH, :AQUARING, :ROOST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FEVESTA,
        :level => 65,
        :item => :BLACKSLUDGE,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:VENOSHOCK, :TOXIC, :FOULPLAY, :TRICK],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ECLIPSER,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:POWERGEM, :SOLARBEAM, :SUNNYDAY, :MORNINGSUN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Tina", :SKIER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SUBEARO,
        :level => 47,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :APEIN,
        :level => 47,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rita", :SKIER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SWELLEGANT,
        :level => 54,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HURRICANE, :HEATWAVE, :SURF, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PUFFPEAK,
        :level => 54,
        :item => :CHARTIBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:AIRSLASH, :ICEBEAM, :FLASHCANNON, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :IGLOW,
        :level => 54,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :BRAVE,
        :moves => [:ROCKBLAST, :ICICLESPEAR, :BULLDOZE, :FREEZEDRY],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Lindsey", :SKIER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :IGLOW,
        :level => 46,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SASCRUSH,
        :level => 46,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MOLICE,
        :level => 46,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Axel", :SKIER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :CIRRIBUS,
        :level => 53,
        :item => :CHARTIBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HEATWAVE, :SQUALLBLOW, :ICEBEAM, :AIRCANNON],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BAABLIZZ,
        :level => 53,
        :item => :CHOPLEBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:HYPERVOICE, :ICEBEAM, :FREEZEDRY, :DUSTYDASH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BOULDOISE,
        :level => 53,
        :item => :RINDOBERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:EARTHQUAKE, :STONEEDGE, :IRONHEAD, :SUPERPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Fritz", :SKIER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ARCTICHARE,
        :level => 54,
        :item => :BABIRIBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:MOONBLAST, :ICEBEAM, :FREEZEDRY, :DUSTYDASH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ORCAIL,
        :level => 54,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:GLACIERCRASH, :LIQUIDATION, :EARTHQUAKE, :AQUAJET],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Benjamin", :SKIER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :RINOLAR,
        :level => 47,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :APEIN,
        :level => 47,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Herbert", :SNOWBOARDER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ORCAIL,
        :level => 54,
        :item => :LUMBERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:GLACIERCRASH, :EARTHQUAKE, :LIQUIDATION, :AQUAJET],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Tony", :SNOWBOARDER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SNOWRONG,
        :level => 47,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TUNDRILL,
        :level => 47,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Hans", :SNOWBOARDER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :TUNDRILL,
        :level => 54,
        :item => :OCCABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:ICICLECRASH, :IRONHEAD, :BRICKBREAK, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PINGLADE,
        :level => 54,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:AQUAJET, :GLACIERCRASH, :LIQUIDATION, :CROSSCHOP],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :AURORAI,
        :level => 54,
        :item => :AIRBALLOON,
        :ability => "",
        :nature => :MODEST,
        :moves => [:THUNDERBOLT, :ICEBEAM, :DUSTYDASH, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Amadeus", :SNOWBOARDER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SNOWRONG,
        :level => 54,
        :item => :OCCABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:PHANTOMGRIP, :ICEBEAM, :DARKPULSE, :FREEZEDRY],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SUBEARO,
        :level => 54,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:DRAINPUNCH, :ICICLECRASH, :THUNDERPUNCH, :FOULPLAY],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :AURORAI,
        :level => 54,
        :item => :OCCABERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:DISCHARGE, :ICEBEAM, :ENERGYBALL, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Petra", :SOCIALITE, 0],
    :defeat => "",
    :mons => [
      {
        :species => :DOVEHEART,
        :level => 25,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ORITURE,
        :level => 25,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DYNABALL,
        :level => 25,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :AEROMA,
        :level => 25,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :WEREHIDE,
        :level => 25,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Dragana", :SOCIALITE, 0],
    :defeat => "",
    :mons => [
      {
        :species => :FINNDRA,
        :level => 46,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:SURF, :ICEBEAM, :DRAGONPULSE, :THUNDERWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SUBEARO,
        :level => 46,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:ICEPUNCH, :HAMMERARM, :THUNDERPUNCH, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GRIZZLER,
        :level => 46,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:FIREPUNCH, :THUNDERPUNCH, :DRAINPUNCH, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Brite", :SOLAROFFICIER_Bright, 0],
    :defeat => "",
    :mons => [
      {
        :species => :FLAWK,
        :level => 20,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :TIMID,
        :moves => [:FLAMEBURST, :SUNNYDAY, :HIDDENPOWER, :AIRSLASH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DYNABALL,
        :level => 20,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:FLAMECHARGE, :IRONHEAD, :ROCKTOMB, :WILDCHARGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FIZIRE,
        :level => 21,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:ANCIENTPOWER, :LAVAPLUME, :BULLDOZE, :FLAMECHARGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Brite", :SOLAROFFICIER_Bright,1, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PSYFLOCK,
        :level => 35,
        :item => :COLBURBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:REFLECT, :PSYSHOCK, :SQUALLBLOW, :HEATWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SCORPINOVA,
        :level => 35,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :RASH,
        :moves => [:STOMPINGTANTRUM, :ROCKSLIDE, :FLAMETHROWER, :GIGADRAIN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SLITHEAT,
        :level => 35,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SLUDGEBOMB, :HEATWAVE, :SCALD, :EARTHPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :VOLCADON,
        :level => 36,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:POWERGEM, :HEATWAVE, :SCALD, :EARTHPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Gloria", :SOLAROFFICIER_Gloria, 0],
    :defeat => "",
    :mons => [
      {
        :species => :WEASHOCK,
        :level => 35,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:LIGHTSCREEN, :THUNDERBOLT, :ICEFANG, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :HUMMZAP,
        :level => 35,
        :item => :CHARTIBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:CRACKLESLAM, :DRILLPECK, :ENERGYBALL, :DRILLRUN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ATOMOTRO,
        :level => 35,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :TIMID,
        :moves => [:FLASHCANNON, :THUNDERBOLT, :ENERGYBALL, :EARTHPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CHEETRIC,
        :level => 36,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:DARKPULSE, :THUNDERBOLT, :ENERGYBALL, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Gloria", :SOLAROFFICIER_Gloria,1, 0],
    :defeat => "",
    :mons => [
      {
        :species => :STRIKLOUD,
        :level => 45,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :TIMID,
        :moves => [:THUNDERBOLT, :COUNTERCURRENT, :ENERGYBALL, :HEATWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BLITZIBOOM,
        :level => 45,
        :item => :CHARTIBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:THUNDERBOLT, :FIREBLAST, :DAZZLINGGLEAM, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GLOWING,
        :level => 45,
        :item => :CHARTIBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:BUGBUZZ, :THUNDERBOLT, :QUIVERDANCE, :HEATWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :RUSHOT,
        :level => 45,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:VOLTTACKLE, :ENERGYBALL, :HEATWAVE, :IRONTAIL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DEERFERNO,
        :level => 46,
        :item => :LIFEORB,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:FLAREBLITZ, :DOUBLEEDGE, :WILDCHARGE, :CRUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CHEETRIC,
        :level => 46,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :MODEST,
        :moves => [:THUNDER, :DARKPULSE, :IRONTAIL, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Starla", :SOLARLEADER_Starla, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ATOMOTRIX,
        :level => 55,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FLASHCANNON, :THUNDERBOLT, :ENERGYBALL, :METALSOUND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SCORPINOVA,
        :level => 55,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:DIG, :LAVAPLUME, :ROCKSLIDE, :SUCKERPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PSYTRIC,
        :level => 56,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:PSYSHOCK, :SHOCKWAVE, :SHADOWBALL, :FOCUSBLAST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BILLAZE,
        :level => 56,
        :item => :BILLAZENITE,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FLAMEWHEEL, :IRONHEAD, :GLACIERCRASH, :FLAMECHARGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BLITZIBOOM,
        :level => 57,
        :item => :WISEGLASSES,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:DISCHARGE, :FIREWORKS, :DAZZLINGGLEAM, :THUNDERWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Caroline", :SWIMMER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :FLAPINKO,
        :level => 41,
        :item => :LIFEORB,
        :ability => "",
        :nature => :MODEST,
        :moves => [:HURRICANE, :HYPERVOICE, :SURF, :AIRCANNON],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ANGELIGHT,
        :level => 41,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:SURF, :ICEBEAM, :CALMMIND, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SWELLEGANT,
        :level => 41,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HURRICANE, :SURF, :ICEBEAM, :UTURN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Cara", :SWIMMER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :JELLINIP,
        :level => 40,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:SLUDGEBOMB, :RIPPLEWAVE, :ICEBEAM, :SIGNALBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SWELLEGANT,
        :level => 40,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:AIRSLASH, :MUDDYWATER, :DAZZLINGGLEAM, :HEATWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DOFLAP,
        :level => 40,
        :item => :MYSTICWATER,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SURF, :HYPERVOICE, :ICYWIND, :SIGNALBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Korrin", :SWIMMER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :CORALTLE,
        :level => 41,
        :item => :RINDOBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SHELLSMASH, :POWERGEM, :EARTHPOWER, :SURF],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Ilka", :SWIMMER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :JELLINIP,
        :level => 40,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PORFIN,
        :level => 40,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :WHALEY,
        :level => 40,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Liv", :SWIMMER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :JELLIQUEEN,
        :level => 61,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :NEMBROSLUG,
        :level => 61,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Phoebe", :SWIMMER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PUPLASH,
        :level => 44,
        :item => :RINDOBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:SURF, :MOONBLAST, :ICEBEAM, :DUSTYDASH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TIDUDE,
        :level => 44,
        :item => :LIFEORB,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:CLOSECOMBAT, :SURF, :ICEBEAM, :WILDCHARGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SWELLEGANT,
        :level => 44,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HURRICANE, :SCALD, :ICEBEAM, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Jovana", :SWIMMER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SEAGIC,
        :level => 56,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DOFLAP,
        :level => 56,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Aurelia", :SWIMMER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :HUMBREECH,
        :level => 60,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SEAGIC,
        :level => 60,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MARKRUSH,
        :level => 60,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Tara", :SWIMMER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :WEEDSEA,
        :level => 30,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SHRUBSEA,
        :level => 30,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Mireia", :SWIMMER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :MYSTABLET,
        :level => 59,
        :item => :IAPAPABERRY,
        :ability => "",
        :nature => :QUIET,
        :moves => [:TRICKROOM, :TRICKROOM, :MEMENTO, :MEMENTO],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PARADISO,
        :level => 59,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :QUIET,
        :moves => [:TRICKROOM, :ENERGYBALL, :ICEBEAM, :HYDROPUMP],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ROCKSTER,
        :level => 59,
        :item => :LIFEORB,
        :ability => "",
        :nature => :BRAVE,
        :moves => [:JETPUNCH, :DIAMONDCLAW, :ICEPUNCH, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :KAHULA,
        :level => 59,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :QUIET,
        :moves => [:HYDROPUMP, :GIGADRAIN, :ICEBEAM, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SHRIMPOON,
        :level => 59,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :QUIET,
        :moves => [:ERUPTION, :HYDROPUMP, :FIREBLAST, :GIGADRAIN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SEALBERG,
        :level => 59,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :BRAVE,
        :moves => [:MEGALOFANG, :GLACIERCRASH, :EARTHQUAKE, :STONEEDGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Lucy", :SWIMMER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :DOFLAP,
        :level => 40,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:RIPPLEWAVE, :ICEBEAM, :SIGNALBEAM, :CALMMIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PLATYPLASH,
        :level => 40,
        :item => :RINDOBERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:EARTHQUAKE, :AQUATAIL, :ICEPUNCH, :SHADOWCLAW],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :YAKKLE,
        :level => 40,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:DOUBLEEDGE, :AQUATAIL, :EARTHQUAKE, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :VALURE,
        :level => 40,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:SURF, :PSYSHOCK, :ICEBEAM, :GIGADRAIN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Ramona", :SWIMMER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PORFIN,
        :level => 37,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:RIPPLEWAVE, :ICEBEAM, :HIDDENPOWER, :SIGNALBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PORFIN,
        :level => 37,
        :item => :CHOICESPECS,
        :ability => "",
        :nature => :TIMID,
        :moves => [:RIPPLEWAVE, :ICEBEAM, :HIDDENPOWER, :SIGNALBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PORFIN,
        :level => 37,
        :item => :LIFEORB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:RIPPLEWAVE, :ICEBEAM, :HIDDENPOWER, :SIGNALBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Ilona", :SWIMMER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :CRABLUE,
        :level => 31,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PORFIN,
        :level => 31,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Paul", :SWIMMER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :JELLIQUEEN,
        :level => 41,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:SURF, :SLUDGEWAVE, :GIGADRAIN, :RECOVER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Damian", :SWIMMER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SILVICIOUS,
        :level => 44,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:LIQUIDATION, :IRONHEAD, :EARTHQUAKE, :HEADSMASH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SHRIMPOON,
        :level => 44,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:LAVAPLUME, :SCALD, :GIGADRAIN, :EARTHPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :EELECT,
        :level => 44,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:THUNDERBOLT, :SURF, :ICEBEAM, :SLUDGEBOMB],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Aidan", :SWIMMER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ROCKSTER,
        :level => 40,
        :item => :RINDOBERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:AQUATAIL, :ROCKSLIDE, :IRONTAIL, :FROSTCLAW],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :EELECT,
        :level => 40,
        :item => :MAGNET,
        :ability => "",
        :nature => :TIMID,
        :moves => [:THUNDER, :HYDROPUMP, :ICEBEAM, :SLUDGEBOMB],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FINNDRA,
        :level => 40,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:DRAGONPULSE, :RIPPLEWAVE, :FREEZEDRY, :THUNDERWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Jim", :SWIMMER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :MARKRUSH,
        :level => 43,
        :item => :LIFEORB,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:LIQUIDATION, :CRACKLESLAM, :EXTREMESPEED, :SWORDSDANCE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Jasper", :SWIMMER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :LISQUID,
        :level => 45,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:NIGHTSLASH, :LIQUIDATION, :GUNKSHOT, :WILDCHARGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :YAKKLE,
        :level => 45,
        :item => :FLAMEORB,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:FACADE, :LIQUIDATION, :EARTHQUAKE, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BAABBLE,
        :level => 45,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:HYDROPUMP, :ICEBEAM, :DAZZLINGGLEAM, :CALMMIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Seth", :SWIMMER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SHARKO,
        :level => 35,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SHARKO,
        :level => 35,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SHARKO,
        :level => 35,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Emilian", :SWIMMER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SILVICIOUS,
        :level => 60,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GLYDFIN,
        :level => 60,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PINGLADE,
        :level => 60,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Chad", :SWIMMER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :POOLDOG,
        :level => 59,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:AQUATAIL, :PLAYROUGH, :WILDCHARGE, :GLACIERCRASH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PUPLASH,
        :level => 59,
        :item => :DAMPROCK,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SURF, :DAZZLINGGLEAM, :ICEBEAM, :DUSTYDASH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :HIPPOTONE,
        :level => 59,
        :item => :RINDOBERRY,
        :ability => "",
        :nature => :BRAVE,
        :moves => [:MEGALOFANG, :HIGHHORSEPOWER, :GYROBALL, :GUNKSHOT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :HUMBREECH,
        :level => 59,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :TIMID,
        :moves => [:MUDDYWATER, :BLIZZARD, :FLASHCANNON, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :NAWALE,
        :level => 59,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:GLACIERCRASH, :SACREDSWORD, :AQUATAIL, :AQUAJET],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :KELPULA,
        :level => 59,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:PETALBLIZZARD, :AQUAJET, :SUCKERPUNCH, :BRICKBREAK],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Ference", :SWIMMER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SURFIDE,
        :level => 31,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SURFIDE,
        :level => 31,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Ian", :SWIMMER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :CRABLUE,
        :level => 30,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SURFIDE,
        :level => 30,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Till", :SWIMMER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :JELLIKING,
        :level => 61,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SEALBERG,
        :level => 61,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Mitch", :SWIMMER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :MERMARINE,
        :level => 60,
        :item => :LIFEORB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HYPERVOICE, :DAZZLINGGLEAM, :BLIZZARD, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MERSIDON,
        :level => 60,
        :item => :COVERTCLOAK,
        :ability => "",
        :nature => :TIMID,
        :moves => [:RIPPLEWAVE, :THUNDER, :FOCUSBLAST, :ICEBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :EQWATER,
        :level => 60,
        :item => :COBABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HYDROPUMP, :GIGADRAIN, :ICEBEAM, :VACUUMWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ORCAIL,
        :level => 60,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:GLACIERCRASH, :AQUAJET, :BODYPRESS, :LIQUIDATION],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GLYDFIN,
        :level => 60,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:HYPERVOICE, :MUDDYWATER, :SUCKERPUNCH, :ICEBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SEAGIC,
        :level => 60,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :MODEST,
        :moves => [:MOONBLAST, :ICEBEAM, :RIPPLEWAVE, :PSYSHOCK],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Florian", :SWIMMER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SHARKO,
        :level => 37,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:AQUATAIL, :CRACKLESLAM, :AQUAJET, :ICEFANG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ANGELIGHT,
        :level => 37,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:SURF, :ICEBEAM, :DAZZLINGGLEAM, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :JELLITIC,
        :level => 37,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:SURF, :ICEBEAM, :SIGNALBEAM, :SHOCKWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Josh", :TAXIDRIVER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :AQUAD,
        :level => 16,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GECKONE,
        :level => 16,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Jimmy", :TAXIDRIVER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :FLOWBY,
        :level => 16,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LOPHUG,
        :level => 16,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Cam", :TAXIDRIVER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :TADART,
        :level => 17,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Victoria", :TEACHER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :DOVEHEART,
        :level => 10,
        :item => :ORANBERRY,
        :ability => :BIGPECKS,
        :nature => :TIMID,
        :moves => [:FAIRYWIND, :AIRCUTTER, :PLAYFIGHT, :ROUND],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Eugenia", :TEACHER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ELESTOMP,
        :level => 49,
        :item => :LEFTOVERS,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:EARTHQUAKE, :STONEEDGE, :GUNKSHOT, :ZENHEADBUTT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grunt", :TEAMLUNAR_Female,1, 0],
    :defeat => "",
    :mons => [
      {
        :species => :CYCRILL,
        :level => 29,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:AIRCUTTER, :SHADOWBALL, :WILLOWISP, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :HOLLOWKIN,
        :level => 29,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :BRAVE,
        :moves => [:PHANTOMGRIP, :BULLETSEED, :XSCISSOR, :FLAMETHROWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FINNDRA,
        :level => 29,
        :item => :ROSELIBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:DRAGONPULSE, :SCALD, :FREEZEDRY, :THUNDERWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grunt", :TEAMLUNAR_Female,5, 0],
    :defeat => "",
    :mons => [
      {
        :species => :TARATERROR,
        :level => 38,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:CRUNCH, :XSCISSOR, :EARTHQUAKE, :RAZORBLADE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :WIDOX,
        :level => 38,
        :item => :OCCABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:POISONJAB, :XSCISSOR, :RAZORBLADE, :LEAFBLADE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grunt", :TEAMLUNAR_Female, 0],
    :defeat => "Commander Scarlett won't be happy...",
    :mons => [
      {
        :species => :PARASEA,
        :level => 14,
        :item => :TANGABERRY,
        :ability => :FRIENDGUARD,
        :nature => :MODEST,
        :moves => [:MEGADRAIN, :WATERPULSE, :HIDDENPOWERICE, :ANCIENTPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grunt", :TEAMLUNAR_Female,2, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ISEALCLE,
        :level => 29,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:MEGALOFANG, :ICEFANG, :ROCKSLIDE, :IRONHEAD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :APEIN,
        :level => 29,
        :item => :CHOPLEBERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:FAKEOUT, :MEGAPUNCH, :KNOCKOFF, :DRAINPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TROLLERK,
        :level => 29,
        :item => :ROSELIBERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:PLAYROUGH, :CRUNCH, :FIREPUNCH, :ICEPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DRACUBAT,
        :level => 29,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:GIGADRAIN, :NIGHTSLASH, :WINGATTACK, :SHADOWCLAW],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grunt", :TEAMLUNAR_Female,3, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BEOPUP,
        :level => 25,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grunt", :TEAMLUNAR_Male,2, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BOULDOX,
        :level => 29,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:ROCKSLIDE, :CROSSPOISON, :XSCISSOR, :IRONHEAD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MONSTRAP,
        :level => 29,
        :item => :COBABERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:CRUNCH, :SEEDBOMB, :ROCKTOMB, :POISONJAB],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SANDSTER,
        :level => 29,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:DARKPULSE, :EARTHPOWER, :HEATWAVE, :ANCIENTPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grunt", :TEAMLUNAR_Male,1, 0],
    :defeat => "",
    :mons => [
      {
        :species => :WEREHIDE,
        :level => 29,
        :item => :TANGABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:BITE, :FIREFANG, :THUNDERFANG, :ICEFANG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BANSHREEK,
        :level => 28,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:SHADOWBALL, :SIGNALBEAM, :ICYWIND, :AIRCANNON],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :HAMAWL,
        :level => 28,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:AQUATAIL, :IRONHEAD, :WILDCHARGE, :ZENHEADBUTT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :WIDOX,
        :level => 29,
        :item => :POWERHERB,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:XSCISSOR, :POISONJAB, :DIG, :RAZORBLADE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grunt", :TEAMLUNAR_Male, 0],
    :defeat => "Drat!",
    :mons => [
      {
        :species => :STOTOX,
        :level => 14,
        :item => :WEAKNESSPOLICY,
        :ability => :SOLIDROCK,
        :nature => :ADAMANT,
        :moves => [:ROCKSLIDE, :SLUDGE, :HEADBUTT, :KNOCKOFF],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grunt", :TEAMLUNAR_Male,5, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BANSHREEK,
        :level => 38,
        :item => :LIFEORB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:GHASTLYWAIL, :SIGNALBEAM, :AIRCANNON, :HYPERVOICE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CYCRILL,
        :level => 38,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SHADOWBALL, :AIRSLASH, :HIDDENPOWER, :ANCIENTPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grunt", :TEAMLUNAR_Male,3, 0],
    :defeat => "",
    :mons => [
      {
        :species => :VAMBAT,
        :level => 25,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grunt", :TEAMSOLAR_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :RAIZID,
        :level => 20,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:BULLDOZE, :CRACKLESLAM, :DUALCHOP, :FLAMECHARGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grunt", :TEAMSOLAR_Female,6, 0],
    :defeat => "",
    :mons => [
      {
        :species => :RUSHOT,
        :level => 35,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:CRACKLESLAM, :HEATWAVE, :DAZZLINGGLEAM, :IRONTAIL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grunt", :TEAMSOLAR_Female,1, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ZEBRITE,
        :level => 41,
        :item => :LIGHTCLAY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:LIGHTSCREEN, :REFLECT, :PSYSHOCK, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FYANT,
        :level => 41,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:WILLOWISP, :FLAMETHROWER, :BUGBUZZ, :EARTHPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BLITZIGLOW,
        :level => 41,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:THUNDERBOLT, :THUNDERWAVE, :FLAMETHROWER, :VACUUMWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GROILLUM,
        :level => 41,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:DRAINPUNCH, :WOODHAMMER, :THUNDERPUNCH, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TAPIBLAZE,
        :level => 41,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:HEATWAVE, :SLUDGEBOMB, :EARTHPOWER, :SLACKOFF],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BAABLAZE,
        :level => 41,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :MODEST,
        :moves => [:HEATWAVE, :HYPERVOICE, :DUSTYDASH, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grunt", :TEAMSOLAR_Female,5, 0],
    :defeat => "",
    :mons => [
      {
        :species => :FYANT,
        :level => 27,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SNAZAP,
        :level => 27,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grunt", :TEAMSOLAR_Female,3, 0],
    :defeat => "",
    :mons => [
      {
        :species => :TAPIBLAZE,
        :level => 52,
        :item => :AIRBALLOON,
        :ability => "",
        :nature => :MODEST,
        :moves => [:HEATWAVE, :SLUDGEBOMB, :GIGADRAIN, :EARTHPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SHRIMPOON,
        :level => 52,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:MUDDYWATER, :FLAMETHROWER, :GIGADRAIN, :EARTHPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :METEROCK,
        :level => 52,
        :item => :LIFEORB,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:CRACKLESLAM, :ROCKSLIDE, :GALERUSH, :IRONHEAD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grunt", :TEAMSOLAR_Male,3, 0],
    :defeat => "",
    :mons => [
      {
        :species => :GIRAFLAME,
        :level => 52,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HEATWAVE, :DAZZLINGGLEAM, :EARTHPOWER, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GRENATRIC,
        :level => 52,
        :item => :AIRBALLOON,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:FLAREBLITZ, :IRONHEAD, :WILDCHARGE, :FINALGAMBIT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :RAIZODON,
        :level => 52,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:CRACKLESLAM, :HIGHHORSEPOWER, :FIREPUNCH, :ICEPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grunt", :TEAMSOLAR_Male,5, 0],
    :defeat => "",
    :mons => [
      {
        :species => :FYANT,
        :level => 35,
        :item => :CHARTIBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:BUGBUZZ, :FLAMETHROWER, :ENERGYBALL, :EARTHPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FIZIRE,
        :level => 35,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:FLAMETHROWER, :POWERGEM, :SCALD, :EARTHPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grunt", :TEAMSOLAR_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :COSMET,
        :level => 20,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:ROCKSLIDE, :CRACKLESLAM, :IRONHEAD, :FLAMECHARGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grunt", :TEAMSOLAR_Male,6, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BILLAZE,
        :level => 35,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :MODEST,
        :moves => [:HEATWAVE, :EARTHPOWER, :ZENHEADBUTT, :WILDCHARGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ECLIPO,
        :level => 35,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:PSYCHIC, :POWERGEM, :OVERHEAT, :MOONBLAST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grunt", :TEAMSOLAR_Male,1, 0],
    :defeat => "",
    :mons => [
      {
        :species => :COBOLTA,
        :level => 41,
        :item => :AIRBALLOON,
        :ability => "",
        :nature => :TIMID,
        :moves => [:DISCHARGE, :SLUDGEWAVE, :DAZZLINGGLEAM, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DEERASH,
        :level => 41,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:BLAZEKICK, :DOUBLEEDGE, :JUMPKICK, :WILDCHARGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TIKITIK,
        :level => 41,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:FLAMETHROWER, :GIGADRAIN, :EARTHPOWER, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :METEROCK,
        :level => 41,
        :item => :RINDOBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:CRACKLESLAM, :ROCKSLIDE, :IRONHEAD, :GALERUSH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LAVENRINA,
        :level => 41,
        :item => :OCCABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:DAZZLINGGLEAM, :ENERGYBALL, :DUSTYDASH, :PSYSHOCK],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BILLAZE,
        :level => 41,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:WILDCHARGE, :EARTHPOWER, :ZENHEADBUTT, :OVERHEAT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grunt", :TEAMSOLAR_Male,4, 0],
    :defeat => "",
    :mons => [
      {
        :species => :GRIZZLER,
        :level => 26,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:FIREPUNCH, :DRAINPUNCH, :THUNDERPUNCH, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BLITZIGLOW,
        :level => 26,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:LIGHTNINGSTRIKE, :HEATWAVE, :ENERGYBALL, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CHAMELEC,
        :level => 26,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:THUNDERBOLT, :SLUDGEBOMB, :ENERGYBALL, :AQUATAIL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grunt", :TEAMSOLAR_Male,2, 0],
    :defeat => "",
    :mons => [
      {
        :species => :RUSHOT,
        :level => 43,
        :item => :LIFEORB,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:EXTREMESPEED, :WILDCHARGE, :HEATWAVE, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :COBOLTA,
        :level => 43,
        :item => :AIRBALLOON,
        :ability => "",
        :nature => :TIMID,
        :moves => [:THUNDERBOLT, :SLUDGEBOMB, :ENERGYBALL, :SULFURICSPRAY],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DEERASH,
        :level => 43,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:TAKEDOWN, :BLAZEKICK, :JUMPKICK, :CRUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SCORPINOVA,
        :level => 43,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:FIREBLAST, :EARTHPOWER, :SCALD, :GIGADRAIN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Gina", :TUBER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :JELLITOTF,
        :level => 32,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Tialda", :TUBER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :KAHULA,
        :level => 37,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:GIGADRAIN, :SCALD, :ICEBEAM, :INGRAIN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Ryan", :TUBER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :KELPULA,
        :level => 37,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:LEAFBLADE, :AQUATAIL, :XSCISSOR, :AQUAJET],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Shorty", :TUBER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :DARTOAD,
        :level => 37,
        :item => :LEFTOVERS,
        :ability => "",
        :nature => :MODEST,
        :moves => [:GIGADRAIN, :SLUDGEBOMB, :ICEBEAM, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Teri & Judy", :TWINS, 0],
    :defeat => "Twins are the best...",
    :mons => [
      {
        :species => :CHEEPIP,
        :level => 13,
        :item => :MIRACLESEED,
        :ability => :TRIAGE,
        :nature => :MODEST,
        :moves => [:MEGADRAIN,:PLUCK,:RAZORLEAF,:GROWL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :ELECRITTER,
        :level => 12,
        :item => :ELECTRICGEM,
        :ability => :KEENEYE,
        :nature => :TIMID,
        :moves => [:SHOCKWAVE,:MUDSLAP,:FLAMEBURST,:TAILWHIP],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :HAMSTAR,
        :level => 12,
        :item => :ORANBERRY,
        :ability => :IMMUNITY,
        :nature => :ADAMANT,
        :moves => [:HEADBUTT,:BITE,:ROLLOUT,:BABYDOLLEYES],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Emily & Emelia", :TWINS, 0],
    :defeat => "",
    :mons => [
      {
        :species => :HORSHUSH,
        :level => 38,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PHOXIVEN,
        :level => 38,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:SWIFT, :ENCORE, :DRAININGKISS, :REFLECT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Ulla", :VETERAN_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :MYSTABLET,
        :level => 62,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :AVALDEER,
        :level => 62,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SEALBERG,
        :level => 62,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Alma", :VETERAN_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :TIKITOKO,
        :level => 59,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BLIZZIBAT,
        :level => 59,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SYPHOON,
        :level => 59,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CHEETRIC,
        :level => 59,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Matheo", :VETERAN_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :MONSTUNE,
        :level => 59,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BARBVIRAL,
        :level => 59,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MOSLIQUO,
        :level => 59,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :AEROGON,
        :level => 59,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Lasse", :VETERAN_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PHAROBE,
        :level => 62,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MONSTUNE,
        :level => 62,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SCORPINOVA,
        :level => 62,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Stewy", :WAITER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PLATYPLASH,
        :level => 37,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MONSTRAP,
        :level => 37,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Samantha", :WAITRESS, 0],
    :defeat => "",
    :mons => [
      {
        :species => :HUMMZAP,
        :level => 37,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PSYFLOCK,
        :level => 37,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rickard", :WORKER_ICE, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PINGLETT,
        :level => 48,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :NAWALE,
        :level => 48,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SNOWLOW,
        :level => 48,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Brandon", :WORKER_ICE, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PINGLETT,
        :level => 48,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ISEALCLE,
        :level => 48,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SUBEARO,
        :level => 48,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Max", :YOUNGSTER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SNUFFUZZ,
        :level => 24,
        :item => :LEFTOVERS,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:TOXIC, :PROTECT, :BULLDOZE, :AMNESIA],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PLATYPLASH,
        :level => 24,
        :item => :RINDOBERRY,
        :ability => "",
        :nature => :QUIET,
        :moves => [:WATERPULSE, :MUDSHOT, :ICEPUNCH, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Nick", :YOUNGSTER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :STICKUT,
        :level => 32,
        :item => :COBABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:XSCISSOR, :SEEDBOMB, :ROCKSLIDE, :KNOCKOFF],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GLOWING,
        :level => 32,
        :item => :OCCABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:THUNDERBOLT, :BUGBUZZ, :FLASHCANNON, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Colt", :YOUNGSTER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :HAMSTAR,
        :level => 17,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Jerome", :YOUNGSTER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :HAMSTAR,
        :level => 11,
        :ability => :IMMUNITY,
        :nature => :ADAMANT,
        :moves => [:HEADBUTT,:BITE,:ROLLOUT,:SUPERFANG],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
      {
        :species => :STICKIT,
        :level => 11,
        :item => :FOCUSSASH,
        :ability => :SWARM,
        :nature => :ADAMANT,
        :moves => [:RAZORLEAF,:BUGBITE,:CHIPAWAY,:SMACKDOWN],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
      {
        :species => :BUNNIC,
        :level => 11,
        :item => :WISEGLASSES,
        :ability => :THICKFAT,
        :nature => :TIMID,
        :moves => [:ROUND,:LIGHTBURST,:BABYDOLLEYES,:KNOCKOFF],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
    ]
  },
  {
    :teamid => ["Fabian", :YOUNGSTER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SNAPIKE,
        :level => 31,
        :item => :SALACBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:TOXICSPIKES, :POISONJAB, :DRILLRUN, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Mark", :YOUNGSTER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BUDCHEEP,
        :level => 8,
        :ability => :RATTLED,
        :item => :ORANBERRY,
        :nature => :TIMID,
        :moves => [:ECHOEDVOICE,:PECK,:SCREECH,:DEFOG],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
      {
        :species => :HAMSTAR,
        :level => 9,
        :ability => :IMMUNITY,
        :nature => :IMPISH,
        :moves => [:DEFENSECURL,:ROLLOUT,:TACKLE,:BABYDOLLEYES],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 0, 252, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Lacey", :YOUNGSTER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :STOTOX,
        :level => 10,
        :item => :ORANBERRY,
        :ability => :SOLIDROCK,
        :nature => :BRAVE,
        :moves => [:ROCKTOMB, :ACID, :ROCKSMASH, :PAYBACK],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
      {
        :species => :POIPOLE,
        :level => 11,
        :item => :BERRYJUICE,
        :ability => :CORROSION,
        :nature => :TIMID,
        :moves => [:ACIDSPRAY, :BUBBLE, :MUDBOMB, :ROUND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :SPIDOX,
        :level => 11,
        :item => :FOCUSSASH,
        :ability => :SWARM,
        :nature => :JOLLY,
        :moves => [:POISONSTING, :BUGBITE, :BITE, :INFESTATION],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
    ]
  },
  {
    :teamid => ["Jerry", :YOUNGSTER, 0],
    :defeat => "I could have beaten them too!",
    :mons => [
      {
        :species => :GLOCOON,
        :level => 14,
        :item => :BERRYJUICE,
        :ability => :ILLUMINATE,
        :nature => :MODEST,
        :moves => [:SIGNALBEAM, :CHARGEBEAM, :ELECTROWEB, :HIDDENPOWERROC],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
      {
        :species => :MOOFORK,
        :level => 15,
        :item => :EVIOLITE,
        :ability => :SAPSIPPER,
        :nature => :ADAMANT,
        :moves => [:BULLDOZE,:HORNATTACK,:ICESHARD,:DOUBLEKICK],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 252]
      },
    ]
  },
  {
    :teamid => ["Lou", :YOUNGSTER,1, 0],
    :defeat => "",
    :mons => [
      {
        :species => :GRENATRIC,
        :level => 37,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BARBVIRAL,
        :level => 37,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Todd", :YOUNGSTER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PSYFLOCK,
        :level => 42,
        :item => :LIGHTCLAY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:REFLECT, :LIGHTSCREEN, :PSYSHOCK, :AIRSLASH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TERRAVOLT,
        :level => 42,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:THUNDERBOLT, :AIRSLASH, :HEATWAVE, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PARABOW,
        :level => 42,
        :item => :CHARTIBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:TALONGASH, :CRUSHCLAW, :KNOCKOFF, :LASTRESORT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Dion", :YOUNGSTER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SKREECH,
        :level => 20,
        :item => :EVIOLITE,
        :ability => :ANTICIPATION,
        :nature => :MODEST,
        :moves => [:SHADOWBALL, :NIGHTSHADE, :SNARL, :ROUND],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
      {
        :species => :NAPKID,
        :level => 20,
        :item => :EVIOLITE,
        :ability => :ANTICIPATION,
        :nature => :MODEST,
        :moves => [:HEX, :WILLOWISP, :ROUND, :HIDDENPOWERFIG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :BEOPUP,
        :level => 20,
        :item => :LIFEORB,
        :ability => :INSOMNIA,
        :nature => :JOLLY,
        :moves => [:BITE, :THUNDERFANG, :ICEFANG, :FIREFANG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
    ]
  },
  {
    :teamid => ["Kirby", :YOUNGSTER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :UGLING,
        :level => 16,
        :item => :EVIOLITE,
        :ability => :SERENEGRACE,
        :nature => :TIMID,
        :moves => [:WATERPULSE,:BOUNCE,:STEELWING,:HIDDENPOWERGRO],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 252, 0, 0, 0, 252]
      },
      {
        :species => :AQUAD,
        :level => 16,
        :item => :MYSTICWATER,
        :ability => :HUGEPOWER,
        :nature => :JOLLY,
        :moves => [:KARATECHOP,:AQUAJET,:BULKUP,:ROCKTOMB],
        :iv => 31,
        :happiness => 255,
        :ev => [252, 252, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Taylor", :YOUNGSTER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BUDCHERP,
        :level => 20,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HYPERVOICE, :AIRSLASH, :FACADE, :STEELWING],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Lou", :YOUNGSTER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :DYNABALL,
        :level => 30,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:FLAMECHARGE, :WILDCHARGE, :IRONHEAD, :TAKEDOWN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FIZIRE,
        :level => 30,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:POWERGEM, :LAVAPLUME, :EARTHPOWER, :SCALD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GIRAFIRE,
        :level => 30,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :TIMID,
        :moves => [:DAZZLINGGLEAM, :EARTHPOWER, :FLAMEBURST, :OVERHEAT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Wren", :YOUNGSTER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BULLSON,
        :level => 38,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :POOLDOG,
        :level => 38,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rocco", :ELITEFOUR_Rocco, 0],
    :defeat => "",
    :mons => [
      {
        :species => :LEONITE,
        :level => 66,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:STEALTHROCK, :SANDSTORM, :DIAMONDCLAW, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :COCOROCKO,
        :level => 66,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:WOODHAMMER, :ROCKBLAST, :POWERUPPUNCH, :LEECHSEED],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :JEWELTAL,
        :level => 67,
        :item => :ELECTRICGEM,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:SHATTERGEM, :BUGBUZZ, :ICEBEAM, :ROCKPOLISH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BOULDOISE,
        :level => 67,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:STONEEDGE, :EARTHQUAKE, :ROAR, :TOXIC],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :VOLCADON,
        :level => 67,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:ERUPTION, :LAVAPLUME, :ANCIENTPOWER, :EARTHPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GOLOSSUS,
        :level => 68,
        :item => :LEFTOVERS,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:ROCKSLIDE, :REVENGE, :AMNESIA, :RECOVER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rocco", :ELITEFOUR_Rocco,1, 0],
    :defeat => "",
    :mons => [
      {
        :species => :GOLOSSUS,
        :level => 68,
        :item => :LEFTOVERS,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:ROCKSLIDE, :REVENGE, :AMNESIA, :RECOVER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :VOLCADON,
        :level => 67,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:ERUPTION, :LAVAPLUME, :ANCIENTPOWER, :EARTHPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LEONITE,
        :level => 66,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:STEALTHROCK, :SANDSTORM, :DIAMONDCLAW, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rocco", :ELITEFOUR_Rocco,2, 0],
    :defeat => "",
    :mons => [
      {
        :species => :METEROCK,
        :level => 80,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:HEADSMASH, :VOLTTACKLE, :GLACIERCRASH, :STEALTHROCK],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :COCOROCKO,
        :level => 80,
        :item => :CHOPLEBERRY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:WOODHAMMER, :STONEEDGE, :EARTHQUAKE, :DRAINPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :JEWELTAL,
        :level => 80,
        :item => :FIGHTINGGEM,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:SHATTERGEM, :BUGBUZZ, :ICEBEAM, :ROCKPOLISH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ROCKSTER,
        :level => 80,
        :item => :SALACBERRY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:DIAMONDCLAW, :CRABHAMMER, :SUPERPOWER, :ROCKPOLISH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :VOLCADON,
        :level => 80,
        :item => :LEFTOVERS,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:ERUPTION, :LAVAPLUME, :GEODECANNON, :EARTHPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GOLOSSUS,
        :level => 80,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:STONEEDGE, :DRAINPUNCH, :EARTHQUAKE, :POWERUPPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Fayette", :ELITEFOUR_Fayette, 0],
    :defeat => "",
    :mons => [
      {
        :species => :LOPHUG,
        :level => 66,
        :item => :LIGHTCLAY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:PLAYROUGH, :WISH, :MAGICCOAT, :LIGHTSCREEN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MERMARINE,
        :level => 66,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:SCALD, :MYSTICWAVE, :LOVELYKISS, :BATONPASS],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FELOVE,
        :level => 67,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:PSYSHOCK, :LIGHTBURST, :HEARTSTAMP, :THUNDERWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GHOULLOW,
        :level => 67,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:SHADOWBALL, :MOONBLAST, :HYPNOSIS, :DREAMEATER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PHOXIVEN,
        :level => 67,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:HYPERVOICE, :MYSTICALFIRE, :DUSTYDASH, :CALMMIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LAVENRINA,
        :level => 68,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:PETALDANCE, :DAZZLINGGLEAM, :PSYCHIC, :QUIVERDANCE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Fayette", :ELITEFOUR_Fayette,1, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PHOXIVEN,
        :level => 80,
        :item => :LIFEORB,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:HYPERVOICE, :DARKPULSE, :MYSTICALFIRE, :CALMMIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MERMARINE,
        :level => 80,
        :item => :LIGHTCLAY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:SCALD, :REFLECT, :LOVELYKISS, :BATONPASS],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MELOTWEET,
        :level => 80,
        :item => :EXPERTBELT,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:PSYSHOCK, :MYSTICWAVE, :AIRSLASH, :HEATWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GHOULLOW,
        :level => 80,
        :item => :LEFTOVERS,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:SHADOWBALL, :MOONBLAST, :HYPNOSIS, :DREAMEATER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FAYEDRA,
        :level => 80,
        :item => :LUMBERRY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:PLAYROUGH, :OUTRAGE, :EARTHQUAKE, :DRAGONDANCE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LAVENRINA,
        :level => 80,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:PETALDANCE, :DAZZLINGGLEAM, :PSYCHIC, :QUIVERDANCE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Nora", :ELITEFOUR_Nora, 0],
    :defeat => "",
    :mons => [
      {
        :species => :LAZLOTH,
        :level => 66,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:BODYSLAM, :KNOCKOFF, :TOXIC, :REST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MOOSTRIKE,
        :level => 66,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:DOUBLEEDGE, :IRONHEAD, :HEADSMASH, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SASCRUSH,
        :level => 67,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FAKEOUT, :ROCKCLIMB, :KNOCKOFF, :SUCKERPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SPIRIX,
        :level => 67,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:HYPERVOICE, :SHADOWBALL, :DAZZLINGGLEAM, :UTURN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FORMLING,
        :level => 67,
        :item => :EXPERTBELT,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:METRONOME],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BULLSON,
        :level => 68,
        :item => :SALACBERRY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FLAIL, :REVERSAL, :COUNTER, :TAUNT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Nora", :ELITEFOUR_Nora,1, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BAABREEZE,
        :level => 80,
        :item => :LIFEORB,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:SQUALLBLOW, :HYPERVOICE, :TAILWIND, :UTURN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DEERFERNO,
        :level => 80,
        :item => :CHOICEBAND,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:DOUBLEEDGE, :FLAREBLITZ, :WILDCHARGE, :SUPERPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LAZLOTH,
        :level => 80,
        :item => :LEFTOVERS,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:BODYSLAM, :KNOCKOFF, :SLACKOFF, :ENTRAINMENT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SPIRIX,
        :level => 80,
        :item => :REDCARD,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:HYPERVOICE, :SHADOWBALL, :DAZZLINGGLEAM, :UTURN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SASCRUSH,
        :level => 80,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FAKEOUT, :RETURN, :SUCKERPUNCH, :DRAINPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BULLSON,
        :level => 80,
        :item => :LIECHIBERRY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:HEADCHARGE, :EARTHQUAKE, :GLACIERCRASH, :KNOCKOFF],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rex", :ELITEFOUR_Rex, 0],
    :defeat => "",
    :mons => [
      {
        :species => :HYDROGON,
        :level => 66,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:HYDROPUMP, :DRAGONPULSE, :ICYWIND, :THUNDERBOLT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DRACOFLY,
        :level => 66,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:XSCISSOR, :DUALCHOP, :UTURN, :RAZORBLADE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FRUGON,
        :level => 67,
        :item => :YACHEBERRY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:DRAGONICBLOOM, :EARTHQUAKE, :LEECHSEED, :INGRAIN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BLAZILISK,
        :level => 67,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:DRAGONICFLARE, :FLAMECHARGE, :SLUDGEBOMB, :GLARE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :STRIKYON,
        :level => 67,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:DRAGONICSTRIKE, :HEATWAVE, :FLASHCANNON, :TAILWIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :AEROGON,
        :level => 68,
        :item => :FLAMEORB,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:DRAGONIMPACT, :GALERUSH, :DRAGONDANCE, :SHADOWCLAW],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rex", :ELITEFOUR_Rex,1, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BEAUTIFIN,
        :level => 80,
        :item => :SCOPELENS,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:RIPPLEWAVE, :DRACOMETEOR, :THUNDERBOLT, :ICEBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DRACOFLY,
        :level => 80,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:DRAGONCLAW, :XSCISSOR, :RAZORBLADE, :FELLSTINGER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FRUGON,
        :level => 80,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:SOLARBEAM, :DRAGONTAIL, :SOLARCLAW, :SUNNYDAY],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BLAZILISK,
        :level => 80,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:DRAGONICFLARE, :EARTHPOWER, :GUNKSHOT, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :STRIKYON,
        :level => 80,
        :item => :CHOICESCARF,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:DRAGONICSTRIKE, :HEATWAVE, :FLASHCANNON, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :AEROGON,
        :level => 80,
        :item => :WHITEHERB,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:DRAGONIMPACT, :DOUBLEEDGE, :EARTHQUAKE, :CRACKLESLAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Jax", :CHAMPION, 0],
    :defeat => "",
    :mons => [
      {
        :species => :GECKONE,
        :level => 68,
        :item => :GECKONITE,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:PSYCHIC, :SHADOWBALL, :FOCUSBLAST, :ICEBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ELESTOMP,
        :level => 68,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:EARTHQUAKE, :MUDDYWATER, :YAWN, :SLACKOFF],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PHANSHEET,
        :level => 69,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:HEX, :GLARE, :PAINSPLIT, :CURSE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MONSTRAP,
        :level => 69,
        :item => :LEFTOVERS,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:POWERWHIP, :CRUNCH, :TOXIC, :INGRAIN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GRENATRIC,
        :level => 69,
        :item => :LIFEORB,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FLAREBLITZ, :IRONHEAD, :WILDCHARGE, :EXPLOSION],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :AURORAI,
        :level => 70,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FROSTBREATH, :DISCHARGE, :DUSTYDASH, :AGILITY],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Jax", :CHAMPION,1, 0],
    :defeat => "",
    :mons => [
      {
        :species => :GECKONE,
        :level => 68,
        :item => :GECKONITE,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:PSYCHIC, :SHADOWBALL, :FOCUSBLAST, :ICEBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ELESTOMP,
        :level => 68,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:EARTHQUAKE, :MUDDYWATER, :YAWN, :SLACKOFF],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PHANSHEET,
        :level => 69,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:HEX, :GLARE, :PAINSPLIT, :CURSE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TAPIBLAZE,
        :level => 69,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FLAMETHROWER, :SLUDGEBOMB, :MESMERSMOKE, :SLACKOFF],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SWELLEGANT,
        :level => 69,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:SCALD, :AIRSLASH, :TAILWIND, :ROOST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :AURORAI,
        :level => 70,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FROSTBREATH, :DISCHARGE, :DUSTYDASH, :AGILITY],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Jax", :CHAMPION,2, 0],
    :defeat => "",
    :mons => [
      {
        :species => :GECKONE,
        :level => 68,
        :item => :GECKONITE,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:PSYCHIC, :SHADOWBALL, :FOCUSBLAST, :ICEBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ELESTOMP,
        :level => 68,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:EARTHQUAKE, :MUDDYWATER, :YAWN, :SLACKOFF],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PHANSHEET,
        :level => 69,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:HEX, :GLARE, :PAINSPLIT, :CURSE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SILVICIOUS,
        :level => 69,
        :item => :METRONOME,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:HEADSMASH, :IRONHEAD, :AQUATAIL, :WILDCHARGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :KELPULA,
        :level => 69,
        :item => :KEBIABERRY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:POWERWHIP, :WATERFALL, :SUCKERPUNCH, :SWORDSDANCE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :AURORAI,
        :level => 70,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FROSTBREATH, :DISCHARGE, :DUSTYDASH, :AGILITY],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Jax", :CHAMPION,3, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PHANSHEET,
        :level => 85,
        :item => :EJECTBUTTON,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FOULPLAY, :PROTECT, :PAINSPLIT, :PERISHSONG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ELESTOMP,
        :level => 85,
        :item => :LEFTOVERS,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:EARTHQUAKE, :SCALD, :GUNKSHOT, :SLACKOFF],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MONSTRAP,
        :level => 85,
        :item => :TANGABERRY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:POWERWHIP, :SUCKERPUNCH, :SUPERPOWER, :SUPERFANG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GRENATRIC,
        :level => 85,
        :item => :LIFEORB,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FLAREBLITZ, :IRONHEAD, :WILDCHARGE, :EXPLOSION],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GECKONE,
        :level => 85,
        :item => :GECKONITE,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:PSYSHOCK, :KNOCKOFF, :FOCUSBLAST, :SLUDGEWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :AURORAI,
        :level => 85,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FROSTBREATH, :THUNDERBOLT, :DUSTYDASH, :TAILGLOW],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Jax", :CHAMPION,4, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PHANSHEET,
        :level => 85,
        :item => :EJECTBUTTON,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FOULPLAY, :PROTECT, :PAINSPLIT, :PERISHSONG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ELESTOMP,
        :level => 85,
        :item => :LEFTOVERS,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:EARTHQUAKE, :SCALD, :GUNKSHOT, :SLACKOFF],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TAPIBLAZE,
        :level => 85,
        :item => :SALACBERRY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FLAMETHROWER, :SLUDGEWAVE, :MESMERSMOKE, :SLACKOFF],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SWELLEGANT,
        :level => 85,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:SCALD, :AIRSLASH, :TAILWIND, :ROOST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GECKONE,
        :level => 85,
        :item => :GECKONITE,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:PSYSHOCK, :KNOCKOFF, :FOCUSBLAST, :SLUDGEWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :AURORAI,
        :level => 85,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FROSTBREATH, :THUNDERBOLT, :DUSTYDASH, :TAILGLOW],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Jax", :CHAMPION,5, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PHANSHEET,
        :level => 85,
        :item => :EJECTBUTTON,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FOULPLAY, :PROTECT, :PAINSPLIT, :PERISHSONG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ELESTOMP,
        :level => 85,
        :item => :LEFTOVERS,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:EARTHQUAKE, :SCALD, :GUNKSHOT, :SLACKOFF],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SILVICIOUS,
        :level => 85,
        :item => :CHOICEBAND,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:HEADSMASH, :IRONHEAD, :AQUATAIL, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :KELPULA,
        :level => 85,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:POWERWHIP, :WATERFALL, :SUCKERPUNCH, :SWORDSDANCE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GECKONE,
        :level => 85,
        :item => :GECKONITE,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:PSYSHOCK, :KNOCKOFF, :FOCUSBLAST, :SLUDGEWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :AURORAI,
        :level => 85,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FROSTBREATH, :THUNDERBOLT, :DUSTYDASH, :TAILGLOW],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Acton", :ACETRAINER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ATOMOTRIX,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :KAPPLASH,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TAPIBLAZE,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Rahel", :ACETRAINER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :FEVESTA,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CRYSTIWING,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PHAROBE,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Kael", :SWIMMER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :DOFLAP,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GLYDFIN,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LISQUID,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Sabella", :SWIMMER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ANGELIGHT,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :JELLIQUEEN,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SEAGIC,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Babette", :BIRDKEEPER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :AEROMA,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PARABOW,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MELOTWEET,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Vernon", :BIRDKEEPER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PUFFPEAK,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BUDSOAR,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :HUMMZAP,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Raoul", :VETERAN_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :AEROGON,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DOZAND,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :VOLCADON,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Waiola", :VETERAN_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SASCRUSH,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :KAHULA,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ROTTOWEEN,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Felicia", :FAIRYTALEGIRL, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PHOXIVEN,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GHOULLOW,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ARCTICHARE,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Xander", :PUNKGUY, 0],
    :defeat => "",
    :mons => [
      {
        :species => :MONSTRAP,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TROLLGER,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SNAPIKE,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Panthea", :PSYCHIC_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ZEBRITE,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SPIRIX,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MYSTABLET,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Fausto", :BLACKBELT, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SMAQUA,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GOLOSSUS,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BULKER,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Bedelia", :GARDENER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SIGNILEAF,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :HYPNOSMOG,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FELOVE,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Albus", :BACKPACKER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :POLARPOW,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BILLAZE,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SPECSTONE,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Minerva", :BACKPACKER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :GIGLOO,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PHANSHEET,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :KELPULA,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Homer", :HIKER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :MOOSTRIKE,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :NATORON,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BOULDOISE,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Salem", :BUGCATCHER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :MOSSNAIL,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CASSAND,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FYANT,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Percival", :PkMnRANGER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :LAZLOTH,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CARBONITRO,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SMAQUA,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Leanna", :PkMnRANGER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :TIKITOKO,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ANGELIGHT,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MYSTABLET,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Ferdinand", :HIKER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :GOLOSSUS,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :RINOTIC,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MOSSNAIL,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Davis", :RUINMANIAC, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PLATYPLASH,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ECLIPSER,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MAGRIZZLY,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Bedford", :RUINMANIAC, 0],
    :defeat => "",
    :mons => [
      {
        :species => :RAIZODON,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BLIMPOON,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BANSCREAM,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Chai-Tao", :GAMECREATOR_Tao, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BULKER,
        :level => 48,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:BULKUP, :MACHPUNCH, :ICEPUNCH, :WAKEUPSLAP],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ROOBEOP,
        :level => 48,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:JUMPKICK, :EARTHQUAKE, :BLAZEKICK, :TAUNT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DRAGOON,
        :level => 48,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:LEECHSEED, :TOXIC, :SUBSTITUTE, :SEEDBOMB],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :AVALDEER,
        :level => 48,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:AGILITY, :DOUBLEEDGE, :ICICLECRASH, :BULLDOZE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :RUSHOT,
        :level => 50,
        :item => :RUSHOTITE,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:HYPERVOICE, :HEATWAVE, :VOLTSWITCH, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Pseico", :GUITARIST_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :HUMBREECH,
        :level => 50,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:WATERSPOUT, :SCALD, :METALBURST, :REST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SYPHOON,
        :level => 50,
        :item => :COLBURBERRY,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:AEROBLAST, :SHADOWBALL, :FREEZEDRY, :PAINSPLIT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :RAIZODON,
        :level => 50,
        :item => :RAIZODONITE,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:CRACKLESLAM, :EARTHQUAKE, :FLAMETHROWER, :KNOCKOFF],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Auriol", :GAMECREATOR_Auriol, 0],
    :defeat => "",
    :mons => [
      {
        :species => :SKELEDEEP,
        :level => 70,
        :item => :CUSTAPBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:STEALTHROCK, :DESTINYBOND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CRYSTIWING,
        :level => 70,
        :item => :LUMBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:QUIVERDANCE, :FREEZEDRY, :BUGBUZZ, :ROOST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MERSIDON,
        :level => 70,
        :item => :LIFEORB,
        :ability => "",
        :nature => :MODEST,
        :moves => [:RAINDANCE, :HYDROPUMP, :THUNDER, :ICEBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FAYEDRA,
        :level => 70,
        :item => :CHESTOBERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:DRAGONDANCE, :REST, :PLAYROUGH, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :KONGRILLA,
        :level => 70,
        :item => :SALACBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:SWORDSDANCE, :LOWKICK, :SEEDBOMB, :STONEEDGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LEONITE,
        :level => 70,
        :item => :LEONITETITE,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:SWORDSDANCE, :SUCKERPUNCH, :STONEEDGE, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Sola", :GAMECREATOR_Sola, 0],
    :defeat => "",
    :mons => [
      {
        :species => :RUBBUNNY,
        :level => 70,
        :item => :LEFTOVERS,
        :ability => "",
        :nature => :IMPISH,
        :moves => [:SLACKOFF, :THUNDERWAVE, :DRAINPUNCH, :ROCKTOMB],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FLEAROE,
        :level => 70,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:EARTHPOWER, :WILLOWISP, :FLAMETHROWER, :ASSIST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FEVESTA,
        :level => 70,
        :item => :AIRBALLOON,
        :ability => "",
        :nature => :MODEST,
        :moves => [:TOXIC, :DARKPULSE, :SLUDGEWAVE, :ACUPRESSURE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GHOULLOW,
        :level => 70,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:HYPNOSIS, :SLACKOFF, :SHADOWBALL, :MOONBLAST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :HYPNOSMOG,
        :level => 70,
        :item => :BLACKSLUDGE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:SPORE, :SLUDGEBOMB, :PSYSHOCK, :BUGBOMB],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PHOXIVEN,
        :level => 70,
        :item => :LIFEORB,
        :ability => "",
        :nature => :MODEST,
        :moves => [:LOVELYKISS, :DRAININGKISS, :MYSTICALFIRE, :ICEBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Tyrant", :GAMECREATOR_Tyrant, 0],
    :defeat => "",
    :mons => [
      {
        :species => :TERRAVOLT,
        :level => 70,
        :item => :LIFEORB,
        :ability => "",
        :nature => :MODEST,
        :moves => [:TAILWIND, :THUNDERBOLT, :GALERUSH, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :STEGAJOLT,
        :level => 70,
        :item => :AIRBALLOON,
        :ability => "",
        :nature => :MODEST,
        :moves => [:FLASHCANNON, :GEODECANNON, :CALMMIND, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BRACHIODON,
        :level => 70,
        :item => :ROCKYHELMET,
        :ability => "",
        :nature => :CALM,
        :moves => [:GIGADRAIN, :GEOSPHERE, :TOXIC, :SYNTHESIS],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DODONT,
        :level => 70,
        :item => :CHOICESCARF,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:BRAVEBIRD, :WILDCHARGE, :EARTHQUAKE, :DOUBLEEDGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PARADISO,
        :level => 70,
        :item => :LEFTOVERS,
        :ability => "",
        :nature => :BOLD,
        :moves => [:SCALD, :CALMMIND, :GIGADRAIN, :SYNTHESIS],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TAREXITE,
        :level => 70,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:DRAGONDANCE, :FIREFANG, :DRAGONCLAW, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Zerobreaker", :GAMECREATOR_Zerobreaker, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BARBVIRAL,
        :level => 70,
        :item => :ROCKYHELMET,
        :ability => "",
        :nature => :IMPISH,
        :moves => [:GYROBALL, :SPIKES, :TOXICSPIKES, :SPIKYSHIELD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LEGENIX,
        :level => 70,
        :item => :CHOICESCARF,
        :ability => "",
        :nature => :MODEST,
        :moves => [:ERUPTION, :SQUALLBLOW, :AURASPHERE, :UTURN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :KELPULA,
        :level => 70,
        :item => :SALACBERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:WATERFALL, :POWERWHIP, :XSCISSOR, :SWORDSDANCE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CHAMELECTRO,
        :level => 70,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :MODEST,
        :moves => [:THUNDERBOLT, :ENERGYBALL, :DARKPULSE, :FLASHCANNON],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SPIRIX,
        :level => 70,
        :item => :LIFEORB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HYPERVOICE, :SHADOWBALL, :DAZZLINGGLEAM, :UTURN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GIGLOO,
        :level => 70,
        :item => :EXPERTBELT,
        :ability => "",
        :nature => :BRAVE,
        :moves => [:FROSTBREATH, :ROCKBLAST, :EARTHQUAKE, :FOCUSBLAST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Cord", :ARTIST,1, 0],
    :defeat => "",
    :mons => [
      {
        :species => :CRYSTOX,
        :level => 70,
        :item => :LEFTOVERS,
        :ability => "",
        :nature => :BOLD,
        :moves => [:TOXICSPIKES, :STEALTHROCK, :LIGHTSCREEN, :REFLECT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PIXILILY,
        :level => 70,
        :item => :WISEGLASSES,
        :ability => "",
        :nature => :MODEST,
        :moves => [:CALMMIND, :DRAININGKISS, :PSYCHIC, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :COUNTULA,
        :level => 70,
        :item => :FLYINGGEM,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:SWORDSDANCE, :ACROBATICS, :CRUNCH, :ICEFANG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DINOPION,
        :level => 70,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:DRAGONDANCE, :DRAGONCLAW, :CLOSECOMBAT, :SOLARCLAW],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ATOMOTRIX,
        :level => 70,
        :item => :CHESTOBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:CALMMIND, :REST, :DISCHARGE, :FLASHCANNON],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BULKER,
        :level => 70,
        :item => :BULKERITE,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:FIREPUNCH, :ICEPUNCH, :THUNDERPUNCH, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Watertrainer", :GAMECREATOR_WT, 0],
    :defeat => "",
    :mons => [
      {
        :species => :GECKONE,
        :level => 49,
        :item => :GECKONITE,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:PSYCHIC, :SHADOWBALL, :FOCUSBLAST, :ICEBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ELESTOMP,
        :level => 49,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:EARTHQUAKE, :MUDDYWATER, :YAWN, :SLACKOFF],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PHANSHEET,
        :level => 49,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:HEX, :GLARE, :PAINSPLIT, :CURSE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :AURORAI,
        :level => 50,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:FROSTBREATH, :DISCHARGE, :DUSTYDASH, :AGILITY],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Buttjuice", :GAMECREATOR_Buttjuice, 0],
    :defeat => "",
    :mons => [
      {
        :species => :NATORON,
        :level => 70,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:STEALTHROCK, :DOUBLEEDGE, :HEADSMASH, :WILDCHARGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BARBVIRAL,
        :level => 70,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :IMPISH,
        :moves => [:TOXICSPIKES, :SPIKES, :METEORMASH, :SPIKYSHIELD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ECLIPSER,
        :level => 70,
        :item => :LEFTOVERS,
        :ability => "",
        :nature => :BOLD,
        :moves => [:TRICKROOM, :LIGHTSCREEN, :REFLECT, :PSYCHIC],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :RAIZODON,
        :level => 70,
        :item => :CHESTOBERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:CRACKLESLAM, :FIREPUNCH, :IRONHEAD, :REST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :NEMBROSLUG,
        :level => 70,
        :item => :LEFTOVERS,
        :ability => "",
        :nature => :CALM,
        :moves => [:SLUDGEWAVE, :RECOVER, :SURF, :RAINDANCE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :STRIKYON,
        :level => 70,
        :item => :ELECTRICGEM,
        :ability => "",
        :nature => :MODEST,
        :moves => [:DRAGONICSTRIKE, :THUNDER, :ELECTRICTERRAIN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Leonite", :ROGUEPOKEMON, 0],
    :defeat => "",
    :mons => [
      {
        :species => :LEONITE,
        :level => 55,
        :item => :LUMBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:STONEEDGE, :EARTHQUAKE, :GLACIERCRASH, :SWORDSDANCE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Atomotrix", :ROGUEPOKEMON, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ATOMOTRIX,
        :level => 56,
        :item => :SALACBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:FLASHCANNON, :THUNDERBOLT, :ENERGYBALL, :CALMMIND],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grunt", :TEAMLUNAR_Male,100, 0],
    :defeat => "",
    :mons => [
      {
        :species => :CRYSCOON,
        :level => 55,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :MODEST,
        :moves => [:STICKYWEB, :BLIZZARD, :BUGBUZZ, :FLASHCANNON],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BANSCREAM,
        :level => 55,
        :item => :LIFEORB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:GHASTLYWAIL, :VACUUMWAVE, :BOOMBURST, :PSYCHIC],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TROLLERK,
        :level => 55,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:PLAYROUGH, :CRUNCH, :ROCKSLIDE, :FIREPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ORCAIL,
        :level => 55,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :IMPISH,
        :moves => [:BODYPRESS, :GLACIERCRASH, :LIQUIDATION, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grunt", :TEAMLUNAR_Male,101, 0],
    :defeat => "",
    :mons => [
      {
        :species => :KAPPLASH,
        :level => 55,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HYDROPUMP, :PSYCHIC, :ICEBEAM, :FOCUSBLAST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PINGLADE,
        :level => 55,
        :item => :LIFEORB,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:SLASH, :RAZORSHELL, :CROSSCHOP, :SUCKERPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SCROW,
        :level => 55,
        :item => :COLBURBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:LEAFBLADE, :PHANTOMGRIP, :SHADOWSNEAK, :RAZORBLADE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SKELEDEEP,
        :level => 55,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:PHANTOMGRIP, :MEGALOFANG, :ICEFANG, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ARCTICHARE,
        :level => 55,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:MOONBLAST, :BLIZZARD, :CALMMIND, :DUSTYDASH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grunt", :TEAMLUNAR_Female,100, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PHANSHEET,
        :level => 55,
        :item => :COLBURBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SHADOWBALL, :FAKEOUT, :FOULPLAY, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FEVESTA,
        :level => 55,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SLUDGEBOMB, :DARKPULSE, :FOULPLAY, :GRASSKNOT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SNOWRONG,
        :level => 55,
        :item => :LIFEORB,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:PHANTOMGRIP, :BLIZZARD, :FOCUSBLAST, :FREEZEDRY],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grunt", :TEAMSOLAR_Male,100, 0],
    :defeat => "",
    :mons => [
      {
        :species => :AURORAI,
        :level => 55,
        :item => :OCCABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:THUNDER, :BLIZZARD, :DUSTYDASH, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BILLAZE,
        :level => 55,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:FLAREBLITZ, :WILDCHARGE, :ROCKSLIDE, :RAZORBLADE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ATOMOTRIX,
        :level => 55,
        :item => :SALACBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:FLASHCANNON, :THUNDERBOLT, :ENERGYBALL, :FOCUSBLAST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Scarlett", :LUNAROFFICIER_Scarlett,2, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BLIZZIBAT,
        :level => 56,
        :item => :EJECTBUTTON,
        :ability => "",
        :nature => :TIMID,
        :moves => [:BOOMBURST, :ENERGYBALL, :SLUDGEWAVE, :AURORAVEIL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SYPHOON,
        :level => 56,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:AEROBLAST, :SHADOWBALL, :FREEZEDRY, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :HUSKOLD,
        :level => 56,
        :item => :LIFEORB,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:FROSTCLAW, :ICESHARD, :CRACKLESLAM, :IRONTAIL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FEVESTA,
        :level => 57,
        :item => :AIRBALLOON,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SLUDGEWAVE, :DARKPULSE, :NASTYPLOT, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :WEREHIDE,
        :level => 56,
        :item => :TANGABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:CRUNCH, :IRONTAIL, :SUCKERPUNCH, :THUNDERFANG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LISQUID,
        :level => 57,
        :item => :LIFEORB,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:LIQUIDATION, :CRUNCH, :ICEBEAM, :SUCKERPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grunt", :TEAMSOLAR_Female,200, 0],
    :defeat => "",
    :mons => [
      {
        :species => :HUMMZAP,
        :level => 56,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:TAILWIND, :SQUALLBLOW, :ELECTROBALL, :HEATWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :RAIZODON,
        :level => 56,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:EARTHQUAKE, :CRACKLESLAM, :ROCKSLIDE, :FIREPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DINOPION,
        :level => 56,
        :item => :COBABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:DRAGONRUSH, :CLOSECOMBAT, :FIREPUNCH, :IRONTAIL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SHRIMPOON,
        :level => 56,
        :item => :CHARTIBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SCALD, :HEATWAVE, :GIGADRAIN, :EARTHPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FLAPINKO,
        :level => 56,
        :item => :LIFEORB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HYPERVOICE, :SQUALLBLOW, :HEATWAVE, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LAVENRINA,
        :level => 56,
        :item => :COVERTCLOAK,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SLEEPPOWDER, :MOONBLAST, :SOLARBEAM, :DUSTYDASH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grunt", :TEAMSOLAR_Male,200, 0],
    :defeat => "",
    :mons => [
      {
        :species => :HYPNOSMOG,
        :level => 56,
        :item => :REDCARD,
        :ability => "",
        :nature => :QUIET,
        :moves => [:TRICKROOM, :SPORE, :PSYCHIC, :SLUDGEWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ECLIPSER,
        :level => 56,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :QUIET,
        :moves => [:OVERHEAT, :PSYCHIC, :POWERGEM, :EARTHPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SLITHEAT,
        :level => 56,
        :item => :EVIOLITE,
        :ability => "",
        :nature => :TIMID,
        :moves => [:FIREBLAST, :BURNINGVENOM, :SCALD, :NASTYPLOT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MAGRIZZLY,
        :level => 56,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :BRAVE,
        :moves => [:SOLARCLAW, :CLOSECOMBAT, :THUNDERPUNCH, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DRAGOON,
        :level => 56,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :BRAVE,
        :moves => [:HORNLEECH, :NATURESFORCE, :GROWTH, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :WEASHOCK,
        :level => 56,
        :item => :LIFEORB,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:THUNDERBOLT, :FIREPUNCH, :ENERGYBALL, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grunt", :TEAMLUNAR_Female,200, 0],
    :defeat => "",
    :mons => [
      {
        :species => :FUNGERM,
        :level => 56,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SULFURICSPRAY, :TOXICSPIKES, :SPORE, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ROTTOWEEN,
        :level => 56,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :BRAVE,
        :moves => [:PHANTOMGRIP, :XSCISSOR, :GROWTH, :FIREBLAST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FYANT,
        :level => 56,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:BUGBUZZ, :FIREBLAST, :EARTHPOWER, :GIGADRAIN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TAREXITE,
        :level => 56,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:DRAGONDANCE, :SOLARCLAW, :STONEEDGE, :THUNDERFANG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :JEWELTAL,
        :level => 56,
        :item => :WHITEHERB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:BUGBUZZ, :GEODECANNON, :SHELLSMASH, :WEATHERBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GASLIT,
        :level => 56,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:NASTYPLOT, :VACUUMWAVE, :FIREBLAST, :SHADOWBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Brite", :SOLAROFFICIER_Bright,2, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PSYFLOCK,
        :level => 57,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:EXPANDINGFORCE, :DAZZLINGGLEAM, :SQUALLBLOW, :HEATWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LEGENIX,
        :level => 57,
        :item => :CHARTIBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:FIREBLAST, :SOLARBEAM, :TOXIC, :PROTECT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SIGNILEAF,
        :level => 57,
        :item => :LIFEORB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SOLARBEAM, :THUNDERBOLT, :GIGADRAIN, :WEATHERBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BILLAZE,
        :level => 58,
        :item => :CLEARAMULET,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:METEORMASH, :FLAMECHARGE, :FACADE, :HEATCRASH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GRENATRIC,
        :level => 57,
        :item => :AIRBALLOON,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:DOUBLEEDGE, :METEORMASH, :WILDCHARGE, :FLAMECHARGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :VOLCADON,
        :level => 59,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :MODEST,
        :moves => [:GEODECANNON, :FIREBLAST, :HIDDENPOWER, :EARTHPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grunt", :TEAMLUNAR_Female,300, 0],
    :defeat => "",
    :mons => [
      {
        :species => :FUNGERM,
        :level => 56,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SULFURICSPRAY, :TOXICSPIKES, :SPORE, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ROTTOWEEN,
        :level => 56,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :BRAVE,
        :moves => [:PHANTOMGRIP, :XSCISSOR, :GROWTH, :FIREBLAST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FYANT,
        :level => 56,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:BUGBUZZ, :FIREBLAST, :EARTHPOWER, :GIGADRAIN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TAREXITE,
        :level => 56,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:DRAGONDANCE, :SOLARCLAW, :STONEEDGE, :THUNDERFANG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :JEWELTAL,
        :level => 56,
        :item => :WHITEHERB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:BUGBUZZ, :GEODECANNON, :SHELLSMASH, :WEATHERBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GASLIT,
        :level => 56,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:NASTYPLOT, :VACUUMWAVE, :FIREBLAST, :SHADOWBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grunt", :TEAMLUNAR_Male,400, 0],
    :defeat => "",
    :mons => [
      {
        :species => :DARTOAD,
        :level => 57,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :QUIET,
        :moves => [:LEAFDARTS, :MUDDYWATER, :ENERGYBALL, :SLUDGEWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FELOVE,
        :level => 57,
        :item => :LIGHTCLAY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:REFLECT, :LIGHTSCREEN, :DAZZLINGGLEAM, :PSYCHIC],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :HIPPOTONE,
        :level => 57,
        :item => :RINDOBERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:AQUATAIL, :EARTHQUAKE, :GUNKSHOT, :CRUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :NAWALE,
        :level => 57,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:ICICLECRASH, :AQUATAIL, :MEGAHORN, :SACREDSWORD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CIRRIBUS,
        :level => 57,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SQUALLBLOW, :WEATHERBALL, :THUNDER, :AIRCANNON],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :EELECT,
        :level => 57,
        :item => :LIFEORB,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:SURF, :THUNDER, :ENERGYBALL, :AQUAJET],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grunt", :TEAMLUNAR_Female,400, 0],
    :defeat => "",
    :mons => [
      {
        :species => :POOLDOG,
        :level => 57,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:LIQUIDATION, :PLAYROUGH, :GLACIERCRASH, :THUNDERFANG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ANGELIGHT,
        :level => 57,
        :item => :LEFTOVERS,
        :ability => "",
        :nature => :CALM,
        :moves => [:WHIRLPOOL, :PROTECT, :TOXIC, :SOAK],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PUPETAL,
        :level => 57,
        :item => :GRASSYSEED,
        :ability => "",
        :nature => :MODEST,
        :moves => [:MOONBLAST, :GIGADRAIN, :CALMMIND, :DUSTYDASH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PLATYPLASH,
        :level => 57,
        :item => :RINDOBERRY,
        :ability => "",
        :nature => :BRAVE,
        :moves => [:EARTHQUAKE, :HYDROPUMP, :ICEBEAM, :POISONJAB],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CASSPRING,
        :level => 57,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:ATTACKORDER, :GALERUSH, :SWORDSDANCE, :SUPERPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :POLARPOW,
        :level => 57,
        :item => :LIFEORB,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:GLACIERCRASH, :CLOSECOMBAT, :STONEEDGE, :THUNDERPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grunt", :TEAMSOLAR_Female,400, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PIXILILY,
        :level => 57,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:STICKYWEB, :MOONBLAST, :BUGBUZZ, :SLEEPPOWDER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BOULDOISE,
        :level => 57,
        :item => :RINDOBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:SHELLSMASH, :EARTHQUAKE, :STONEEDGE, :AQUATAIL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MELOTWEET,
        :level => 57,
        :item => :LIFEORB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:PSYCHIC, :MOONBLAST, :THUNDERBOLT, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CHAMELECTRO,
        :level => 57,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:THUNDER, :ENERGYBALL, :AQUATAIL, :SUCKERPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ATOMOTRIX,
        :level => 57,
        :item => :POWERHERB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:FLASHCANNON, :THUNDER, :METEORBEAM, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SMAQUA,
        :level => 57,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:AQUATAIL, :DRAINPUNCH, :ICEPUNCH, :AQUAJET],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grunt", :TEAMLUNAR_Female,401, 0],
    :defeat => "",
    :mons => [
      {
        :species => :ZEBRITE,
        :level => 57,
        :item => :COLBURBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:PSYCHIC, :ICEBEAM, :THUNDERBOLT, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TIDUDE,
        :level => 57,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:HYDROPUMP, :CLOSECOMBAT, :ICEBEAM, :SUCKERPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SALASLAM,
        :level => 57,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:GUNKSHOT, :AQUATAIL, :DRAINPUNCH, :IRONTAIL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grunt", :TEAMLUNAR_Male,401, 0],
    :defeat => "",
    :mons => [
      {
        :species => :MERMARINE,
        :level => 57,
        :item => :LIFEORB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HYPERVOICE, :DAZZLINGGLEAM, :ICEBEAM, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :JELLIQUEEN,
        :level => 57,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :MODEST,
        :moves => [:MUDDYWATER, :SLUDGEBOMB, :ICEBEAM, :THUNDERBOLT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MOSLIQUO,
        :level => 57,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:MEGALOFANG, :SIPHONBITE, :RAZORBLADE, :POISONJAB],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Marcus", :LUNAROFFICIER_Marcus,2, 0],
    :defeat => "",
    :mons => [
      {
        :species => :GHOULLOW,
        :level => 59,
        :item => :KASIBBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HYPNOSIS, :DAZZLINGGLEAM, :SHADOWBALL, :PSYSHOCK],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TARATERROR,
        :level => 58,
        :item => :COVERTCLOAK,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:RAZORBLADE, :PINMISSILE, :CRUNCH, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TROLLGER,
        :level => 58,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:CRUNCH, :FEYHAMMER, :ROCKSLIDE, :SUCKERPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SPECSTONE,
        :level => 58,
        :item => :POWERHERB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:METEORBEAM, :SHADOWBALL, :EARTHPOWER, :SIGNALBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :COUNTULA,
        :level => 59,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:TALONGASH, :CRUNCH, :FOCUSBLAST, :SUCKERPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SKELEDEEP,
        :level => 60,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:MEGALOFANG, :BODYPRESS, :PHANTOMGRIP, :ROCKSLIDE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grunt", :TEAMLUNAR_Male,500, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PSYTRIC,
        :level => 58,
        :item => :LIGHTCLAY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:REFLECT, :LIGHTSCREEN, :PSYCHIC, :THUNDERBOLT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BAABLIZZ,
        :level => 58,
        :item => :CHOPLEBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:BLIZZARD, :HYPERVOICE, :DUSTYDASH, :FREEZEDRY],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CRYSTIWING,
        :level => 58,
        :item => :OCCABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:QUIVERDANCE, :CHARGEBEAM, :BUGBUZZ, :BLIZZARD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :AVALDEER,
        :level => 58,
        :item => :ELECTRICSEED,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:DOUBLEEDGE, :GLACIERCRASH, :PLAYROUGH, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :AURORAI,
        :level => 58,
        :item => :ELECTRICSEED,
        :ability => "",
        :nature => :TIMID,
        :moves => [:TAILGLOW, :BLIZZARD, :THUNDERBOLT, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SNOWRONG,
        :level => 58,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:FROSTCLAW, :PHANTOMGRIP, :FOCUSBLAST, :ICESHARD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grunt", :TEAMSOLAR_Male,500, 0],
    :defeat => "",
    :mons => [
      {
        :species => :MELOTWEET,
        :level => 58,
        :item => :LIFEORB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:EXPANDINGFORCE, :DAZZLINGGLEAM, :HEATWAVE, :THUNDERBOLT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GLYDFIN,
        :level => 58,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HYPERVOICE, :MUDDYWATER, :BLIZZARD, :HEATWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PARABOW,
        :level => 58,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:TALONGASH, :TAILSLAP, :STEELWING, :HEATWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PSYFLOCK,
        :level => 58,
        :item => :COLBURBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:EXPANDINGFORCE, :SQUALLBLOW, :HEATWAVE, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :COUNTULA,
        :level => 58,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:TALONGASH, :CRUNCH, :FOCUSBLAST, :BLIZZARD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DODONT,
        :level => 58,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:BRAVEBIRD, :HEADSMASH, :DOUBLEEDGE, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grunt", :TEAMLUNAR_Female,501, 0],
    :defeat => "",
    :mons => [
      {
        :species => :TARATERROR,
        :level => 59,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:CRUNCH, :PINMISSILE, :EARTHQUAKE, :PURSUIT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ROCKSTER,
        :level => 59,
        :item => :RINDOBERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:JETPUNCH, :DIAMONDCLAW, :ICEPUNCH, :DRAINPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PHANSHEET,
        :level => 59,
        :item => :MIDNIGHTSEED,
        :ability => "",
        :nature => :MODEST,
        :moves => [:HYPNOSIS, :NASTYPLOT, :SHADOWBALL, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :HUMBREECH,
        :level => 59,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :MODEST,
        :moves => [:HYDROPUMP, :ICEBEAM, :FLASHCANNON, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :KINIP,
        :level => 59,
        :item => :MIDNIGHTSEED,
        :ability => "",
        :nature => :MODEST,
        :moves => [:CALMMIND, :REST, :RIPPLEWAVE, :SLUDGEWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :WEREHIDE,
        :level => 59,
        :item => :LIFEORB,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:SUCKERPUNCH, :CRUNCH, :ICEFANG, :THUNDERFANG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grunt", :TEAMSOLAR_Female,501, 0],
    :defeat => "",
    :mons => [
      {
        :species => :GRENATRIC,
        :level => 59,
        :item => :CHOICESCARF,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:EXPLOSION, :EXPLOSION, :EXPLOSION, :EXPLOSION],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :HORSHUSH,
        :level => 59,
        :item => :COVERTCLOAK,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:FLOWERTRICK, :ROCKSLIDE, :LEAFDARTS, :HIGHHORSEPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :EQWATER,
        :level => 59,
        :item => :LIFEORB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SCALD, :WEATHERBALL, :ENERGYBALL, :ICEBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grunt", :TEAMSOLAR_Male,501, 0],
    :defeat => "",
    :mons => [
      {
        :species => :GASLIT,
        :level => 59,
        :item => :GRASSYSEED,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HEATWAVE, :SHADOWBALL, :ENERGYBALL, :VACUUMWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PUPYRO,
        :level => 59,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:SOLARCLAW, :PLAYROUGH, :EARTHPOWER, :WILDCHARGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :COCOROCKO,
        :level => 59,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:ROCKSLIDE, :WOODHAMMER, :DRAINPUNCH, :KNOCKOFF],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["THE TOP GRUNT", :TEAMSOLAR_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :CASSAND,
        :level => 59,
        :item => :MENTALHERB,
        :ability => "",
        :nature => :SASSY,
        :moves => [:STEALTHROCK, :SPIKES, :BODYPRESS, :EARTHQUAKE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :NATORON,
        :level => 59,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:EARTHQUAKE, :HEADSMASH, :GLACIERCRASH, :FIREBLAST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LEONITE,
        :level => 59,
        :item => :LIFEORB,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:DIAMONDCLAW, :THUNDERFANG, :FIREFANG, :ICEFANG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :WORMOLE,
        :level => 59,
        :item => :MISTYSEED,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:EARTHQUAKE, :COIL, :STONEEDGE, :RECOVER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MOSSNAIL,
        :level => 59,
        :item => :MISTYSEED,
        :ability => "",
        :nature => :BOLD,
        :moves => [:IRONDEFENSE, :BODYPRESS, :GEODECANNON, :RECOVER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DOZAND,
        :level => 60,
        :item => :CLEARAMULET,
        :ability => "",
        :nature => :IMPISH,
        :moves => [:BULKUP, :AMNESIA, :EARTHQUAKE, :STONEEDGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Derek", :LUNARLEADER_Derek, 0],
    :defeat => "",
    :mons => [
      {
        :species => :TARATERROR,
        :level => 60,
        :item => :EJECTBUTTON,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:STICKYWEB, :CRUNCH, :SIPHONBITE, :PSYCHICFANGS],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PHAROBE,
        :level => 60,
        :item => :MIDNIGHTSEED,
        :ability => "",
        :nature => :IMPISH,
        :moves => [:BODYPRESS, :MOONLIGHT, :KNOCKOFF, :PHANTOMGRIP],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BANSCREAM,
        :level => 60,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:GHASTLYWAIL, :BOOMBURST, :VACUUMWAVE, :DARKPULSE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :NAWALE,
        :level => 60,
        :item => :CLEARAMULET,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:GLACIERCRASH, :SACREDSWORD, :DRILLRUN, :AQUATAIL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SWAMPHEAP,
        :level => 60,
        :item => :LEFTOVERS,
        :ability => "",
        :nature => :SASSY,
        :moves => [:PROTECT, :TOXIC, :SUCKERPUNCH, :KNOCKOFF],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ELESTOMP,
        :level => 61,
        :item => :KASIBBERRY,
        :ability => "",
        :nature => :BRAVE,
        :moves => [:EARTHQUAKE, :LASTRESPECTS, :CRUNCH, :STONEEDGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LUNARO,
        :level => 61,
        :item => :SITRUSBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:LUNATICWAVE, :MOONLIGHT, :SHADOWBALL, :MOONBLAST],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Terradon", :PkMnTRAINER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :FLEAROE,
        :level => 66,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:FAKEOUT, :FIREBLAST, :EARTHPOWER, :CRACKLESLAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :ELESTOMP,
        :level => 65,
        :item => :RINDOBERRY,
        :ability => "",
        :nature => :BRAVE,
        :moves => [:LASTRESPECTS, :EARTHQUAKE, :SLACKOFF, :CRUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DOZAND,
        :level => 66,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:EARTHQUAKE, :PHANTOMGRIP, :STONEEDGE, :DRAINPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MOUNTREE,
        :level => 66,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:HEADSMASH, :WOODHAMMER, :IRONTAIL, :WILDCHARGE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GOLOSSUS,
        :level => 65,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:COMETPUNCH, :DRAINPUNCH, :THUNDERPUNCH, :ICEPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TERRADON,
        :level => 75,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:EARTHQUAKE, :STONEEDGE, :SLACKOFF, :GLACIERCRASH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Tigacore", :PkMnTRAINER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :TIKITOKO,
        :level => 66,
        :item => :COBABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:FIREBLAST, :ENERGYBALL, :THUNDERBOLT, :EARTHPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PUPYRO,
        :level => 65,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:SOLARCLAW, :PLAYROUGH, :EARTHPOWER, :DUSTYDASH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BILLAZE,
        :level => 65,
        :item => :CHOPLEBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:HEATCRASH, :METEORMASH, :GLACIERCRASH, :FACADE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BLAZILISK,
        :level => 66,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:BURNINGVENOM, :FIREBLAST, :EARTHPOWER, :SCALD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TIGACORE,
        :level => 75,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:EARTHQUAKE, :FLAREBLITZ, :FACADE, :CRACKLESLAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :FLAWK,
        :level => 1,
        :item => :SACREDASH,
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:ENDEAVOR, :ENDEAVOR, :ENDEAVOR, :ENDEAVOR],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Searine", :PkMnTRAINER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :HYDROGON,
        :level => 65,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :MODEST,
        :moves => [:HYDROPUMP, :DRAGONPULSE, :ICEBEAM, :THUNDERBOLT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SMAQUA,
        :level => 66,
        :item => :MISTYSEED,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:BULKUP, :AQUAJET, :ICEPUNCH, :DRAINPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BEAUTIFIN,
        :level => 66,
        :item => :MISTYSEED,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SCALEBASH, :RECOVER, :PSYCHIC, :BODYPRESS],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PARADISO,
        :level => 65,
        :item => :COBABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:ENERGYBALL, :RIPPLEWAVE, :ICEBEAM, :EARTHPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MARKRUSH,
        :level => 65,
        :item => :LIFEORB,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:VOLTTACKLE, :WAVECRASH, :EXTREMESPEED, :IRONTAIL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SEARINE,
        :level => 75,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:WATERSPOUT, :MOONBLAST, :THUNDERBOLT, :ICEBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Tornadowl", :PkMnTRAINER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :CIRRIBUS,
        :level => 66,
        :item => :MAGNET,
        :ability => "",
        :nature => :TIMID,
        :moves => [:SQUALLBLOW, :ICEBEAM, :THUNDERBOLT, :HEATWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :WOODAWN,
        :level => 65,
        :item => :YACHEBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:BULLETSEED, :ROCKBLAST, :PINMISSILE, :DRILLRUN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PARABOW,
        :level => 65,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:TALONGASH, :TAILSLAP, :HEATWAVE, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :BLIMPOON,
        :level => 66,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :TIMID,
        :moves => [:FLASHCANNON, :SQUALLBLOW, :HEATWAVE, :AIRCANNON],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :AEROGON,
        :level => 66,
        :item => :YACHEBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:EXTREMESPEED, :FACADE, :EARTHQUAKE, :DRAGONRUSH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TORNADOWL,
        :level => 75,
        :item => :POWERHERB,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:SKYATTACK, :HEATWAVE, :THUNDERBOLT, :ICEBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Aethera", :PkMnTRAINER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BLITZIBOOM,
        :level => 66,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:BOOMBURST, :HEATWAVE, :DAZZLINGGLEAM, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :RAIZODON,
        :level => 65,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:DRAGONRUSH, :CRACKLESLAM, :FIREPUNCH, :ICEPUNCH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :RUSHOT,
        :level => 66,
        :item => :ELECTRICSEED,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:HYPERVOICE, :EXTREMESPEED, :HEATWAVE, :IRONTAIL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :CHAMELECTRO,
        :level => 65,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :NAIVE,
        :moves => [:SUCKERPUNCH, :RISINGVOLTAGE, :FIREBLAST, :SLUDGEBOMB],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :EELECT,
        :level => 65,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:MUDDYWATER, :RISINGVOLTAGE, :ICEBEAM, :ENERGYBALL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :AETHERA,
        :level => 75,
        :item => :LIFEORB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:BOOMBURST, :FOCUSBLAST, :ENERGYBALL, :DAZZLINGGLEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Healthia", :PkMnTRAINER_Male, 0],
    :defeat => "",
    :mons => [
      {
        :species => :PUPETAL,
        :level => 65,
        :item => :GRASSYSEED,
        :ability => "",
        :nature => :TIMID,
        :moves => [:MOONBLAST, :ENERGYBALL, :REFLECT, :LIGHTSCREEN],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PARADISO,
        :level => 65,
        :item => :COBABERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:MUDDYWATER, :ENERGYBALL, :ICEBEAM, :EARTHPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DOVEHEART,
        :level => 65,
        :item => :MISTYSEED,
        :ability => "",
        :nature => :TIMID,
        :moves => [:TAILWIND, :DAZZLINGGLEAM, :SQUALLBLOW, :HEATWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TIKITOKO,
        :level => 65,
        :item => :ASSAULTVEST,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HEATWAVE, :ENERGYBALL, :THUNDERBOLT, :EARTHPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MONSTRAP,
        :level => 65,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:CRUNCH, :POWERWHIP, :SUCKERPUNCH, :GUNKSHOT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :DOFLAP,
        :level => 65,
        :item => :LIFEORB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HYDROPUMP, :ICEBEAM, :FOULPLAY, :SIGNALBEAM],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MOUNTREE,
        :level => 66,
        :item => :CHOPLEBERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:HEADSMASH, :PETALBLIZZARD, :WILDCHARGE, :LEAFDARTS],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :HORSHUSH,
        :level => 66,
        :item => :COBABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:FLOWERTRICK, :HIGHHORSEPOWER, :ROCKSLIDE, :LEAFDARTS],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :EQWATER,
        :level => 65,
        :item => :LIFEORB,
        :ability => "",
        :nature => :TIMID,
        :moves => [:WEATHERBALL, :ENERGYBALL, :ICEBEAM, :SCALD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PIXILILY,
        :level => 65,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :TIMID,
        :moves => [:STICKYWEB, :MOONBLAST, :BUGBUZZ, :FOULPLAY],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :PUPLASH,
        :level => 65,
        :item => :RINDOBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:MUDDYWATER, :MOONBLAST, :ICEBEAM, :DUSTYDASH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :HEALTHIA,
        :level => 75,
        :item => :GRASSYSEED,
        :ability => "",
        :nature => :TIMID,
        :moves => [:DAZZLINGGLEAM, :ENERGYBALL, :DUSTYDASH, :THUNDERBOLT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Grunt", :TEAMLUNAR_Male,600, 0],
    :defeat => "",
    :mons => [
      {
        :species => :BAABREEZE,
        :level => 65,
        :item => :COVERTCLOAK,
        :ability => "",
        :nature => :TIMID,
        :moves => [:TAILWIND, :SQUALLBLOW, :HEATWAVE, :HIDDENPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SCROW,
        :level => 65,
        :item => :FOCUSSASH,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:PHANTOMGRIP, :POWERWHIP, :STONEEDGE, :REVERSAL],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :TARATERROR,
        :level => 65,
        :item => :COBABERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:SIPHONBITE, :CRUNCH, :RAZORBLADE, :ICEFANG],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :SHRIMPOON,
        :level => 65,
        :item => :WACANBERRY,
        :ability => "",
        :nature => :TIMID,
        :moves => [:HEATWAVE, :MUDDYWATER, :GIGADRAIN, :EARTHPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MONSTRAP,
        :level => 65,
        :item => :LIFEORB,
        :ability => "",
        :nature => :BRAVE,
        :moves => [:SUCKERPUNCH, :POWERWHIP, :GUNKSHOT, :SUPERPOWER],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :LISQUID,
        :level => 67,
        :item => :LIFEORB,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:SUCKERPUNCH, :CRUNCH, :LIQUIDATION, :GUNKSHOT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Lex", :CLERK_Male,1, 0],
    :defeat => "",
    :mons => [
      {
        :species => :CRYSTOX,
        :level => 68,
        :item => :SHUCABERRY,
        :ability => "",
        :nature => :BRAVE,
        :moves => [:STONEEDGE, :GUNKSHOT, :EARTHQUAKE, :BODYPRESS],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :STEGAJOLT,
        :level => 65,
        :item => :CHOICESCARF,
        :ability => "",
        :nature => :TIMID,
        :moves => [:STEELBEAM, :GEODECANNON, :EARTHPOWER, :THUNDERBOLT],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GIGLOO,
        :level => 65,
        :item => :WEAKNESSPOLICY,
        :ability => "",
        :nature => :BRAVE,
        :moves => [:ICICLESPEAR, :ROCKBLAST, :FIREBLAST, :ICESHARD],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :RAIZODON,
        :level => 65,
        :item => :LIFEORB,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:CRACKLESLAM, :HIGHHORSEPOWER, :ICEPUNCH, :DRAGONDANCE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :MONSTUNE,
        :level => 65,
        :item => :PASSHOBERRY,
        :ability => "",
        :nature => :MODEST,
        :moves => [:EARTHPOWER, :DUSTYDASH, :DARKPULSE, :HEATWAVE],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GOLKID,
        :level => 1,
        :item => :SHELLBELL,
        :ability => "",
        :nature => :BRAVE,
        :moves => [:ENDEAVOR, :SUCKERPUNCH, :PROTECT, :ENDEAVOR],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Forrest", :HIKER, 0],
    :defeat => "",
    :mons => [
      {
        :species => :GEMMANY,
        :level => 65,
        :item => "",
        :ability => "",
        :nature => :QUIRKY,
        :moves => [:JEWELFLASH, :JEWELFLASH, :JEWELFLASH, :JEWELFLASH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  },
  {
    :teamid => ["Curie", :ACETRAINER_Female, 0],
    :defeat => "",
    :mons => [
      {
        :species => :GEMMANY,
        :level => 65,
        :item => :CHARTIBERRY,
        :ability => "",
        :nature => :ADAMANT,
        :moves => [:FLAMEIMPACT, :LOWKICK, :FLAREBLITZ, :PLASMARUSH],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
      {
        :species => :GEMMANY,
        :level => 65,
        :item => :CHOPLEBERRY,
        :ability => "",
        :nature => :JOLLY,
        :moves => [:FUSIONBITE, :METEORMASH, :CHEMOTHERAPY, :BODYPRESS],
        :iv => 31,
        :happiness => 255,
        :ev => [0, 0, 0, 0, 0, 0]
      },
    ]
  }
]
