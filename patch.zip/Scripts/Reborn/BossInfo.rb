BOSSINFOHASH = {
  ##############################
  # Boss Template
  ##############################

  :GODKILLER => {
    :name => "God Killer", # nickname
    :shieldCount => 1, # number of shields
    :barGraphic => "", # what kind of hp bar graphic should be pulled
    :immunities => { # any immunities to things
      :moves => [],
      :fieldEffectDamage => []
    },
    :capturable => true, # can you catch this boss after shields are removed?
    :entryText => "Heaven-shaking Godkiller appeared.", # dialogue upon enterring battle as a wild pokemon
    :moninfo => { # bosspokemon details
      :species => :GARCHOMP,
      :level => 5,
      :form => 0,
      :item => :LEFTOVERS,
      :moves => [:DARKPULSE, :PSYSHOCK, :MOONLIGHT, :MOONBLAST],
      :ability => :RKSSYSTEM,
      :gender => "F",
      :nature => :MODEST,
      :iv => 31,
      :happiness => 255,
      :ev => [252, 0, 4, 0, 252, 0]
    },
    :sosDetails => { # sospokemon details
      :activationRequirement => "@battle.battlers[battlerIndex].shieldCount == 0",
      :continuous => true,
      :totalMonCount => 3,
      :moninfos => {
        1 => {
          :species => :GARCHOMP,
          :level => 5,
          :form => 0,
          :item => :LEFTOVERS,
          :moves => [:DARKPULSE, :PSYSHOCK, :MOONLIGHT, :MOONBLAST],
          :ability => :RKSSYSTEM,
          :gender => "F",
          :nature => :MODEST,
          :iv => 31,
          :happiness => 255,
          :ev => [252, 0, 4, 0, 252, 0]
        },
        2 => {
          :species => :GYARADOS,
          :level => 5,
          :form => 0,
          :item => :LEFTOVERS,
          :moves => [:DARKPULSE, :PSYSHOCK, :MOONLIGHT, :MOONBLAST],
          :ability => :RKSSYSTEM,
          :gender => "F",
          :nature => :MODEST,
          :iv => 31,
          :happiness => 255,
          :ev => [252, 0, 4, 0, 252, 0]
        },
      },
    },
    :onEntryEffects => { # effects applied on entry, use same attributes/syntax as onbreakeffects
      :fieldChange => :PSYTERRAIN,
      :fieldChangeMessage => "Gothitelle laughs at how dumb your face looks. So mean!"
    },
    :onBreakEffects => { # in order of shield count, with the highest value being the first shield broken and the lowest the last
      1 => {
        :threshold => 0, # if desired, shield can be broken at higher hp% than 0
        :message => "", # message that plays when shield is broken
        :bossEffect => :MagicCoat, # effect that applies on the boss when breaking shield
        :bossEffectduration => true, # duration of the effect(some effects are booleans, double check)
        :bossEffectMessage => "{1} shrouded itself with Magic Coat!", # message that plays for the effect
        :bossEffectanimation => :MAGICCOAT, # effect animation
        :weatherChange => :RAINDANCE, # weather to apply
        :formchange => 0, # formchanges
        :abilitychange => :DOWNLOAD, # ability to change to upon shieldbreaker
        :fieldChange => :SWAMP, # field changes
        :fieldChangeMessage => "", # message that plays when the field is changes
        :weatherCount => 5, # weather turncount
        :weatherChangeMessage => "Rain began to fall!", # weather message
        :weatherChangeAnimation => "Rain", # string of "Rain", "Sunny","Hail","Sandstorm"
        :typeChange => [:FIRE, :ROCK], # any given type changes
        :movesetUpdate => [:EARTHQUAKE, :OUTRAGE, :ROCKSLIDE, :FIREBLAST], # any given moveset changes
        :speciesUpdate => :FLYGON,
        :statusCure => true, # if status is cured when shield is broken
        :effectClear => true, # if effects are cleared when shield is broken
        :bossSideStatusChanges => [:PARALYSIS, "Paralysis"], # what status gets inflicted on a boss/player pokemon when shield is broken. array has 2 elements, first the status symbol, then a string for the animation
        :playerSideStatusChanges => [:PARALYSIS, "Paralysis"], # what status gets inflicted on a boss/player pokemon when shield is broken. array has 2 elements, first the status symbol, then a string for the animation
        :statDropCure => true, # if statdrops are negated when shield is broken
        :playerEffects => :Curse, # effects applied upon enemies on breaking shield
        :playerEffectsduration => true, # enemy effect durration
        :playerEffectsAnimation => :CURSE, # enemyeffect animation
        :playerEffectsMessage => "A curse was inflicted on the opposing side!", # enemy effect message
        :stateChanges => :TrickRoom, # handles state changes found in the Battle_Global class(in Battle_ActiveSide file + Trick Room
        :stateChangeAnimation => :TRICKROOM, # state change animation
        :stateChangeCount => 5, # state change turncount
        :stateChangeMessage => "The dimensions were changed!", # statechange messages
        :playersideChanges => :ToxicSpikes, # handles side changes found in the Battle_Side class(in Battle_ActiveSide file)
        :playersideChangeAnimation => :TOXICSPIKES, # side change animation
        :playersideChangeCount => 1, # side change turncount
        :playersideChangeMessage => "Toxic Spikes was set up!", # statechange messages
        :bosssideChanges => :ToxicSpikes, # handles side changes found in the Battle_Side class(in Battle_ActiveSide file)
        :bosssideChangeAnimation => :TOXICSPIKES, # side change animation
        :bosssideChangeCount => 1, # side change turncount
        :bosssideChangeMessage => "Toxic Spikes was set up!", # statechange messages
        :itemchange => :LEFTOVERS, # item that is given upon breaking shield
        :bgmChange => "Battle - Final Endeavor",
        :bossStatChanges => { # any statboosts that are given
          PBStats::SPATK => 1,
        },
        :playerSideStatChanges => { # any statchanges applied to the players side
          PBStats::SPATK => -1,
        }
      },
    },
  },

  ##############################
  # Normal Bosses
  ##############################

}
