#!/usr/bin/env ruby
# Converts old encounter text files to new Ruby hash format
# Merges HeadbuttLow + HeadbuttHigh into a single Headbutt section

def balance_rates(entries)
  return {} if entries.empty?
  count = entries.size
  rates = Array.new(count, 5)   # start all at 5
  total = rates.sum
  rates[-1] += (100 - total)    # adjust last to reach 100
  balanced = {}
  entries.each_with_index do |entry, i|
    species, min, max = entry
    balanced[species.to_sym] ||= []
    balanced[species.to_sym] << [rates[i], min, max]
  end
  balanced
end

def convert_file(filename)
  lines = File.readlines(filename, chomp: true)

  output = {}
  i = 0
  while i < lines.size
    line = lines[i]
    if line =~ /^#-+$/   # divider
      header = lines[i+1]
      id, name = header.split("#").map(&:strip)
      map_id = id.to_i
      map_name = name
      rates = lines[i+2].split(",").map(&:to_i)
      landrate, caverate, waterrate = rates

      section_data = {
        :landrate => landrate,
        :caverate => caverate,
        :waterrate => waterrate
      }

      i += 3
      current_section = nil
      temp_entries = []
      headbutt_entries = []  # <-- collect both low + high here

      while i < lines.size && lines[i] !~ /^#-+$/
        line = lines[i].strip
        if line.empty?
          i += 1
          next
        end

        if /^[A-Za-z]+/.match?(line) && !line.include?(",")
          # New section name
          # Save previous section first
          if current_section && !temp_entries.empty?
            if current_section =~ /^Headbutt/
              headbutt_entries.concat(temp_entries)
            else
              section_data[current_section.to_sym] = balance_rates(temp_entries)
            end
            temp_entries = []
          end
          current_section = line
        else
          # Encounter line
          parts = line.split(",")
          species = parts[0]
          min = parts[1].to_i
          max = parts[2] ? parts[2].to_i : min
          temp_entries << [species, min, max]
        end
        i += 1
      end

      # save last section
      if current_section && !temp_entries.empty?
        if current_section =~ /^Headbutt/
          headbutt_entries.concat(temp_entries)
        else
          section_data[current_section.to_sym] = balance_rates(temp_entries)
        end
      end

      # merge headbutt
      unless headbutt_entries.empty?
        section_data[:Headbutt] = balance_rates(headbutt_entries)
      end

      output[map_id] = { :"# #{map_name}" => section_data }
    else
      i += 1
    end
  end

  output
end

# --- Run example ---
if __FILE__ == $0
  file = ARGV[0] || "input.txt"
  data = convert_file(file)

  data.each do |id, content|
    comment = content.keys.find { |k| k.to_s.start_with?("#") }
    section = content[comment]

    puts "  #{id} => { #{comment}"
    section.each do |key, val|
      if key.is_a?(Symbol) && !val.is_a?(Hash)
        puts "    :#{key} => #{val},"
      else
        puts "    :#{key} => {"
        val.each do |species, arrs|
          arrs_str = arrs.map { |a| "[#{a.join(', ')}]" }.join(", ")
          puts "      :#{species} => [#{arrs_str}],"
        end
        puts "    },"
      end
    end
    puts "  },"
  end
end