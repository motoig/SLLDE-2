CONSUMABLEITEMS = [[:ORANBERRY,:PECHABERRY,:CHESTOBERRY,:CHERIBERRY],[],[],[],[]]
NONCONSUMABLEITEMS = [[:BINDINGBAND,:WIDELENS,:GRIPCLAW],[],[],[],[]]



#-------------------------------------------------------------------------------
#  This class performs menu screen processing.
#===============================================================================
class Scene_OnlineShop
  #-----------------------------------------------------------------------------
  # * Object Initialization
  #     menu_index : command cursor's initial position
  #-----------------------------------------------------------------------------
  def initialize(menu_index = 0, fromPokeGear = true)
    @menu_index = menu_index
    @fromPokeGear = fromPokeGear
  end

  #-----------------------------------------------------------------------------
  # * Main Processing
  #-----------------------------------------------------------------------------
  def main
    # Makes the text window
    @sprites = {}
    @viewport = Viewport.new(0, 0, Graphics.width, Graphics.height)
    @viewport.z = 99999
    @sprites["background"] = IconSprite.new(0, 0)
    @sprites["background"].setBitmap("Graphics/Pictures/Pokegear/pokegearbg2")
    @sprites["background"].z = 255
    files = ["Consumable Items","Non-Consumable Items","Special Items"]
    @choices = files
    @sprites["header"] = Window_UnformattedTextPokemon.newWithSize(_INTL("Online Shopping"), 2, -18, 128, 264, @viewport)
    @sprites["header"].baseColor = Color.new(248, 248, 248)
    @sprites["header"].shadowColor = Color.new(0, 0, 0)
    @sprites["header"].windowskin = nil
    @sprites["command_window"] = Window_ShopCommand.new(@choices, 324)
    @sprites["command_window"].windowskin = nil
    @sprites["command_window"].index = @menu_index
    @sprites["command_window"].setHW_XYZ(224, 324, 94, 92, 256)
    # Execute transition
    Graphics.transition
    # Main loop
    loop do
      # Update game screen
      Graphics.update
      # Update input information
      Input.update
      # Frame update
      update
      # Abort loop if screen is changed
      if $scene != self
        break
      end
    end
    # Prepares for transition
    Graphics.freeze
    # Disposes the windows
    pbDisposeSpriteHash(@sprites)
    @viewport.dispose
  end

  #-----------------------------------------------------------------------------
  # * Frame Update
  #-----------------------------------------------------------------------------
  def update
    # Update windows
    pbUpdateSpriteHash(@sprites)
    updateCustom
    return
  end

  #-----------------------------------------------------------------------------
  # * Frame Update (when command window is active)
  #-----------------------------------------------------------------------------
  def updateCustom
    if Input.trigger?(Input::B)
      pbPlayCancelSE()
      if @fromPokeGear
        $scene = Scene_Pokegear.new(:shop)
      else
        $scene = Scene_Map.new
      end
      return
    end
    if Input.trigger?(Input::C)
        if @sprites["command_window"].index==0 #consumable
            items=[]
            case $game_variables[2499] #sticker stamps
            when 0
                items.push(:ORANBERRY,:PECHABERRY,:CHESTOBERRY,:CHERIBERRY,:BERRYJUICE)
            when 1
                items.push(:ORANBERRY,:PECHABERRY,:CHESTOBERRY,:CHERIBERRY,:BERRYJUICE,:SITRUSBERRY)
            #when 1 etc
            end
            pbPlayDecisionSE()
            scene = PokemonOnlineMartScene.new
            screen = PokemonOnlineMartScreen.new(scene, items)
            screen.pbBuyScreen
        end
        if @sprites["command_window"].index==1 #nonconsumable
            items=[]
            case $game_variables[2499] #sticker stamps
            when 0
                items.push(:GRIPCLAW,:BINDINGBAND,:WIDELENS)
            when 1
                items.push(:GRIPCLAW,:BINDINGBAND,:WIDELENS,:FLAMEFRAGMENT,:SPLASHFRAGMENT,:ZAPFRAGMENT,:MEADOWFRAGMENT,:ICICLEFRAGMENT,
                :FISTFRAGMENT,:TOXICFRAGMENT,:EARTHFRAGMENT,:SKYFRAGMENT,:MINDFRAGMENT,:INSECTFRAGMENT,:STONEFRAGMENT,:SPOOKYFRAGMENT,
                :DRACOFRAGMENT,:DREADFRAGMENT,:IRONFRAGMENT,:PIXIEFRAGMENT)
            #when 1 etc
            end
            pbPlayDecisionSE()
            scene = PokemonOnlineMartScene.new
            screen = PokemonOnlineMartScreen.new(scene, items)
            screen.pbBuyScreen
        end
        if @sprites["command_window"].index==2 #special
            items=[]
            case $game_variables[2499] #sticker stamps
            when 0
                items.push(:ODDKEY)
            when 1 
                items.push(:ODDKEY)
            #when 1 etc
            end
            pbPlayDecisionSE()
            scene = PokemonOnlineMartScene.new
            screen = PokemonOnlineMartScreen.new(scene, items)
            screen.pbBuyScreen
        end
      @sprites["command_window"].refresh
    end
  end

  def update_command # Almost certainly redundant now.
    # If B button was pressed
    if Input.trigger?(Input::B)
      pbPlayCancelSE()
      # Switch to map screen
      if @fromPokeGear == true
        $scene = Scene_Pokegear.new(:shop)
      else
        $scene = Scene_Map.new
      end
      return
    end
  end
end

class Window_ShopCommand < Window_CommandPokemon
  def drawItem(index, count, rect)
    pbSetSystemFont(self.contents) if @starting
    rect = drawCursor(index, rect)
    pbDrawShadowText(self.contents, rect.x, rect.y, rect.width, rect.height, @commands[index], self.baseColor, self.shadowColor)
  end
end
