CONSUMABLEITEMS = [[:ORANBERRY,:PECHABERRY,:CHESTOBERRY,:CHERIBERRY],[],[],[],[]]
NONCONSUMABLEITEMS = [[:BINDINGBAND,:WIDELENS,:GRIPCLAW],[],[],[],[]]



#-------------------------------------------------------------------------------
#  This class performs menu screen processing.
#===============================================================================
class Scene_OnlineShop
  #-----------------------------------------------------------------------------
  # * Object Initialization
  #     menu_index : command cursor's initial position
  #-----------------------------------------------------------------------------
  def initialize(menu_index = 0, fromPokeGear = true)
    @menu_index = menu_index
    @fromPokeGear = fromPokeGear
  end

  #-----------------------------------------------------------------------------
  # * Main Processing
  #-----------------------------------------------------------------------------
  def main
    # Makes the text window
    @sprites = {}
    @viewport = Viewport.new(0, 0, Graphics.width, Graphics.height)
    @viewport.z = 99999
    @sprites["background"] = IconSprite.new(0, 0)
    @sprites["background"].setBitmap("Graphics/Pictures/Pokegear/pokegearbg2")
    @sprites["background"].z = 255
    files = ["Consumable Items","Non-Consumable Items","Special Items"]
    @choices = files
    @sprites["header"] = Window_UnformattedTextPokemon.newWithSize(_INTL("Online Shopping"), 2, -18, 128, 264, @viewport)
    @sprites["header"].baseColor = Color.new(248, 248, 248)
    @sprites["header"].shadowColor = Color.new(0, 0, 0)
    @sprites["header"].windowskin = nil
    @sprites["command_window"] = Window_ShopCommand.new(@choices, 324)
    @sprites["command_window"].windowskin = nil
    @sprites["command_window"].index = @menu_index
    @sprites["command_window"].setHW_XYZ(224, 324, 94, 92, 256)
    # Execute transition
    Graphics.transition
    # Main loop
    loop do
      # Update game screen
      Graphics.update
      # Update input information
      Input.update
      # Frame update
      update
      # Abort loop if screen is changed
      if $scene != self
        break
      end
    end
    # Prepares for transition
    Graphics.freeze
    # Disposes the windows
    pbDisposeSpriteHash(@sprites)
    @viewport.dispose
  end

  #-----------------------------------------------------------------------------
  # * Frame Update
  #-----------------------------------------------------------------------------
  def update
    # Update windows
    pbUpdateSpriteHash(@sprites)
    updateCustom
    return
  end

  #-----------------------------------------------------------------------------
  # * Frame Update (when command window is active)
  #-----------------------------------------------------------------------------
  def updateCustom
    if Input.trigger?(Input::B)
      pbPlayCancelSE()
      if @fromPokeGear
        $scene = Scene_Pokegear.new(:shop)
      else
        $scene = Scene_Map.new
      end
      return
    end
    if Input.trigger?(Input::C)
        if @sprites["command_window"].index==0 #consumable
          floorchoices=[]
          stickers=$game_variables[2499]+1
          floorchoices.push(_INTL("1- Berries I; Rare Candies")) if stickers>0
          floorchoices.push(_INTL("2- Niche Items I")) if stickers>1
          floorchoices.push(_INTL("3- Gems")) if stickers>2
          floorchoices.push(_INTL("4- Consumable Items; Utility Items I")) if stickers>3
          floorchoices.push(_INTL("5- Natural Gift Ammunition")) if stickers>4
          floorchoices.push(_INTL("6- Type Gems")) if stickers>5
          floorchoices.push(_INTL("7-  Evolution Stones; Utility Items II")) if stickers>6
          floorchoices.push(_INTL("8- Vitamins; Special Evo Items I")) if stickers>7
          floorchoices.push(_INTL("9- Type Resist Berries")) if stickers>8 && $game_switches[581]
          floorchoices.push(_INTL("10- Top-tier General Needs; Rare Berries")) if stickers>9 && $game_switches[581]
          floorchoices.push(_INTL("11- Utility Items III; Special Evo Items II")) if stickers>10
          floorchoices.push(_INTL("Penthouse- Exclusive rest and relaxation")) if stickers>11		
          floorchoices.push(_INTL("Cancel"))
          stickers+=1
          choiceFloor = Kernel.pbMessage("Buy goods from which floor?",floorchoices,stickers)
          stickers-=1
          case choiceFloor
          when stickers
          when 0
            items=[]
            items.push(:RARECANDY,:ORANBERRY,:PECHABERRY,:CHESTOBERRY,:CHERIBERRY,:BERRYJUICE,:SITRUSBERRY)
            pbPlayDecisionSE()
            scene = PokemonOnlineMartScene.new
            screen = PokemonOnlineMartScreen.new(scene, items)
            screen.pbBuyScreen
          when 1
            items=[]
            items.push(:WHITEHERB,:MENTALHERB,:ABSORBBULB,:SNOWBALL,:CELLBATTERY)
            pbPlayDecisionSE()
            scene = PokemonOnlineMartScene.new
            screen = PokemonOnlineMartScreen.new(scene, items)
            screen.pbBuyScreen
          when 2
            items=[]
            items.push(:NORMALGEM,:FIREGEM,:FIGHTINGGEM,:WATERGEM,:FLYINGGEM,:GRASSGEM,:POISONGEM,:ELECTRICGEM,:GROUNDGEM,:PSYCHICGEM,:ROCKGEM,:ICEGEM,:BUGGEM,:DRAGONGEM,:GHOSTGEM,:DARKGEM,:STEELGEM,:FAIRYGEM)
            pbPlayDecisionSE()
            scene = PokemonOnlineMartScene.new
            screen = PokemonOnlineMartScreen.new(scene, items)
            screen.pbBuyScreen
          end
        end
        if @sprites["command_window"].index==1 #nonconsumable
          floorchoices=[]
          stickers=$game_variables[2499]+1
          floorchoices.push(_INTL("1- Utility Items I")) if stickers>0
          floorchoices.push(_INTL("2- Type Boosting Items I")) if stickers>1
          floorchoices.push(_INTL("3- Type Boosting Items II")) if stickers>2
          floorchoices.push(_INTL("4- Consumable Items; Utility Items I")) if stickers>3
          floorchoices.push(_INTL("5- Natural Gift Ammunition")) if stickers>4
          floorchoices.push(_INTL("6- Type Gems")) if stickers>5
          floorchoices.push(_INTL("7-  Evolution Stones; Utility Items II")) if stickers>6
          floorchoices.push(_INTL("8- Vitamins; Special Evo Items I")) if stickers>7
          floorchoices.push(_INTL("9- Type Resist Berries")) if stickers>8 && $game_switches[581]
          floorchoices.push(_INTL("10- Top-tier General Needs; Rare Berries")) if stickers>9 && $game_switches[581]
          floorchoices.push(_INTL("11- Utility Items III; Special Evo Items II")) if stickers>10
          floorchoices.push(_INTL("Penthouse- Exclusive rest and relaxation")) if stickers>11		
          floorchoices.push(_INTL("Cancel"))
          stickers+=1
          choiceFloor = Kernel.pbMessage("Buy goods from which floor?",floorchoices,stickers)
          stickers-=1
          case choiceFloor
          when stickers
          when 0
            items=[]
            items.push(:GRIPCLAW,:BINDINGBAND,:WIDELENS,:EVERSTONE,:DESTINYKNOT)
            pbPlayDecisionSE()
            scene = PokemonOnlineMartScene.new
            screen = PokemonOnlineMartScreen.new(scene, items)
            screen.pbBuyScreen
          when 1
            items=[]
            items.push(:FLAMEFRAGMENT,:SPLASHFRAGMENT,:ZAPFRAGMENT,:MEADOWFRAGMENT,:ICICLEFRAGMENT,
            :FISTFRAGMENT,:TOXICFRAGMENT,:EARTHFRAGMENT,:SKYFRAGMENT,:MINDFRAGMENT,:INSECTFRAGMENT,:STONEFRAGMENT,:SPOOKYFRAGMENT,
            :DRACOFRAGMENT,:DREADFRAGMENT,:IRONFRAGMENT,:PIXIEFRAGMENT)
            pbPlayDecisionSE()
            scene = PokemonOnlineMartScene.new
            screen = PokemonOnlineMartScreen.new(scene, items)
            screen.pbBuyScreen
          when 2
            items=[]
            items.push(:MUSCLEBAND,:WISEGLASSES,:SILKSCARF,:CHARCOAL,:MYSTICWATER,:MAGNET,:MIRACLESEED,:NEVERMELTICE,:BLACKBELT,:POISONBARB,:SOFTSAND,:SHARPBEAK,:TWISTEDSPOON,:SILVERPOWDER,:HARDSTONE,:SPELLTAG,:DRAGONFANG,:BLACKGLASSES,:METALCOAT,:FAIRYFEATHER)
            pbPlayDecisionSE()
            scene = PokemonOnlineMartScene.new
            screen = PokemonOnlineMartScreen.new(scene, items)
            screen.pbBuyScreen
          end
        end

      #  if @sprites["command_window"].index==2 #special

      #  end
      @sprites["command_window"].refresh
    end
  end

  def update_command # Almost certainly redundant now.
    # If B button was pressed
    if Input.trigger?(Input::B)
      pbPlayCancelSE()
      # Switch to map screen
      if @fromPokeGear == true
        $scene = Scene_Pokegear.new(:shop)
      else
        $scene = Scene_Map.new
      end
      return
    end
  end
end

class Window_ShopCommand < Window_CommandPokemon
  def drawItem(index, count, rect)
    pbSetSystemFont(self.contents) if @starting
    rect = drawCursor(index, rect)
    pbDrawShadowText(self.contents, rect.x, rect.y, rect.width, rect.height, @commands[index], self.baseColor, self.shadowColor)
  end
end
