def pbGetTutorableMoves(onlybought: false)
  tutormoveslist = []
  if !$Trainer.tutorlist
    $Trainer.tutorlist = []
  end
#  if $Trainer.tutorlist.any? { |i| i.is_a?(Integer) }
#    for i in 0...$Trainer.tutorlist.length
#      next if !$Trainer.tutorlist[i].is_a?(Integer)
#
 #     for j in $cache.moves.keys
 #       if $cache.moves[j].checkFlag?(:ID) == $Trainer.tutorlist[i]
 #         $Trainer.tutorlist[i] = $cache.moves[j].move
 #       end
 #     end
 #   end
 # end
 # $Trainer.tutorlist.each { |i| tutormoveslist.push(i) }
 for i in $Trainer.tutorlist
  if $Trainer.tutorspurchased.include?(i[0])
    tutormoveslist.push(i[0])
  end
 end
  unless onlybought
    $Trainer.buyablelist = [] if !$Trainer.buyablelist
    $Trainer.buyablelist.each { |i| tutormoveslist.push(i) unless tutormoveslist.include?(i[0]) }
  end
  return tutormoveslist | [] # remove duplicates
end

################################################################################
# Scene class for handling appearance of the screen
################################################################################
class MoveTutorScene
  VISIBLEMOVES = 4

  def pbDisplay(msg, brief = false)
    UIHelper.pbDisplay(@sprites["msgwindow"], msg, brief) { pbUpdate }
  end

  def pbConfirm(msg)
    UIHelper.pbConfirm(@sprites["msgwindow"], msg) { pbUpdate }
  end

  # Update the scene here, this is called once each frame
  def pbUpdate
    pbUpdateSpriteHash(@sprites)
  end

  def pbStartScene(moves)
    @moves=[]
    for i in moves
      @moves.push(i[0])
    end
    @prices=moves
    moveCommands = []
    moves.each { |i| moveCommands.push(getMoveShortName(i[0])) }
    # Create sprite hash
    @viewport = Viewport.new(0, 0, Graphics.width, Graphics.height)
    @viewport.z = 99999
    @sprites = {}
    addBackgroundPlane(@sprites, "bg", "tutorbg", @viewport)
    @sprites["background"] = IconSprite.new(0, 0, @viewport)
    @sprites["background"].setBitmap("Graphics/Pictures/reminderSel")
    @sprites["background"].y = 78
    @sprites["background"].src_rect = Rect.new(0, 72, 258, 72)
    @sprites["overlay"] = BitmapSprite.new(Graphics.width, Graphics.height, @viewport)
    @sprites["overlay"].z = 9999999
    #@sprites["icon"] = IconSprite.new( 80, 82, @viewport)
    pbSetSystemFont(@sprites["overlay"].bitmap)
    @sprites["commands"] = Window_CommandPokemon.new(moveCommands, 32)
    @sprites["commands"].x = Graphics.width
    @sprites["commands"].height = 32 * (VISIBLEMOVES + 1)
    @sprites["msgwindow"] = Window_AdvancedTextPokemon.new("")
    @sprites["msgwindow"].visible = false
    @sprites["msgwindow"].viewport = @viewport
    pbDeactivateWindows(@sprites)
    # Fade in all sprites

    pbFadeInAndShow(@sprites) { pbUpdate }
    pbTMSprites
    pbDrawMoveList
  end

  def pbTMSprites
    xvalues = [300, 410, 300, 410, 300, 410]
    yvalues = [60, 78, 140, 164, 220, 244]
    for i in 0...$Trainer.party.length
      if !@sprites["pokemon#{i}"]
        @sprites["pokemon#{i}"] = IconSprite.new(0, 0, @viewport)
        @sprites["pokemon#{i}"].bitmap = pbPokemonIconBitmap($Trainer.party[i], $Trainer.party[i].isEgg?)
        @sprites["pokemon#{i}"].src_rect = Rect.new(0, 0, 64, 64)
        @sprites["pokemon#{i}"].x = xvalues[i]
        @sprites["pokemon#{i}"].y = yvalues[i]
        @sprites["pokemon#{i}"].visible = false
      else
        @sprites["pokemon#{i}"].bitmap = pbPokemonIconBitmap($Trainer.party[i], $Trainer.party[i].isEgg?)
        @sprites["pokemon#{i}"].src_rect = Rect.new(0, 0, 64, 64)
      end
      unless @sprites["possiblelearn#{i}"]
        @sprites["possiblelearn#{i}"] = IconSprite.new(0, 0, @viewport)
        @sprites["possiblelearn#{i}"].x = xvalues[i] + 32
        @sprites["possiblelearn#{i}"].y = yvalues[i] + 32
        @sprites["possiblelearn#{i}"].visible = false
      end
    end
  end

  def pbDrawMoveList
    overlay = @sprites["overlay"].bitmap
    overlay.clear
    textpos = []
    imagepos = []
    type1rect = Rect.new(0, 0, 64, 28)
    type2rect = Rect.new(0, 0, 64, 28)
    thing = Rect.new(0, 0, 64, 50)
    textpos = [
      [_INTL("Teach which move?"), 16, 8, 0, Color.new(88, 88, 80), Color.new(168, 184, 184)]
    ]
    yPos = 82
    for i in 0...VISIBLEMOVES
      moveobject = @moves[@sprites["commands"].top_item + i]
      if moveobject
        movedata = $cache.moves[moveobject]
        costdata = $cache.moves[moveobject].cost
        if movedata
          typeimage = AnimatedBitmap.new(sprintf("Graphics/Icons/type%s", movedata.type))
          overlay.blt(12, yPos + 2, typeimage.bitmap, type1rect)
          filename = pbItemIconFile(costdata[0])
          costimage = AnimatedBitmap.new(filename)
          if !($Trainer.tutorspurchased.include?(movedata.move))
            overlay.blt(164, yPos + 22, costimage.bitmap, thing)
            textpos.push([_ISPRINTF("x{1:d}", costdata[1]), 230, yPos + 32, 1, Color.new(64, 64, 64), Color.new(176, 176, 176)])
          end
          textpos.push([getMoveShortName(moveobject), 80, yPos, 0, Color.new(248, 248, 248), Color.new(0, 0, 0)])
        else
          textpos.push(["-", 80, yPos, 0, Color.new(64, 64, 64), Color.new(176, 176, 176)])
          textpos.push(["--", 228, yPos + 32, 1, Color.new(64, 64, 64), Color.new(176, 176, 176)])
        end
      end
      yPos += 64
    end
    selmovedata = $cache.moves[@moves[@sprites["commands"].index]]
    if selmovedata
      canlearnmove = PokemonBag.pbPartyCanLearnThisMove?(selmovedata.move)
      for i in 0...$Trainer.party.length
        @sprites["pokemon#{i}"].visible = true
        @sprites["possiblelearn#{i}"].visible = true
        case canlearnmove[i]
          when 0 # unable
            @sprites["possiblelearn#{i}"].setBitmap(sprintf("Graphics/Pictures/Bag/tmnope")) rescue nil
          when 1 # able
            @sprites["possiblelearn#{i}"].setBitmap(sprintf("Graphics/Pictures/Bag/tmcheck")) rescue nil
          when 2 # learned
            @sprites["possiblelearn#{i}"].setBitmap(sprintf("Graphics/Pictures/Bag/tmdash")) rescue nil
          else
            @sprites["possiblelearn#{i}"].setBitmap(nil)
        end
      end
    else
      for i in 0...$Trainer.party.length
        @sprites["pokemon#{i}"].visible = false
        @sprites["possiblelearn#{i}"].visible = false
      end
    end
    imagepos.push(["Graphics/Pictures/reminderSel", 0, 78 + (@sprites["commands"].index - @sprites["commands"].top_item) * 64, 0, 0, 258, 72])
    pbDrawTextPositions(overlay, textpos)
    if @sprites["commands"].index < @moves.length - 1
      imagepos.push(["Graphics/Pictures/reminderButtons", 48, 350, 0, 0, 76, 32])
    end
    if @sprites["commands"].index > 0
      imagepos.push(["Graphics/Pictures/reminderButtons", 134, 350, 76, 0, 76, 32])
    end
    pbDrawImagePositions(overlay, imagepos)
  end

  # Processes the scene
  def pbChooseMove
    oldcmd = -1
    pbActivateWindow(@sprites, "commands") {
      loop do
        oldcmd = @sprites["commands"].index
        Graphics.update
        Input.update
        pbUpdate
        if @sprites["commands"].index != oldcmd
          @sprites["background"].x = 0
          @sprites["background"].y = 78 + (@sprites["commands"].index - @sprites["commands"].top_item) * 64
          pbDrawMoveList
        end
        if Input.trigger?(Input::B)
          return false
        end
        if Input.trigger?(Input::C)
          return @sprites["commands"].index
        end
      end
    }
  end

  # End the scene here
  def pbEndScene
    if @sprites
      #pbFadeOutAndHide(@sprites) { pbUpdate } # Fade out all sprites
      pbDisposeSpriteHash(@sprites) # Dispose all sprites
      @viewport.dispose # Dispose the viewport
    end
  end
end

# Screen class for handling game logic
class MoveTutorScreen
  def initialize(scene)
    @scene = scene
  end

  def pbStartScreen
    if $game_variables[:E4_Tracker] > 0
      Kernel.pbMessage(_INTL("Cannot use the Move Tutor app here."))
      return false
    end
    moves = $Trainer.tutorlist
    if moves == []
      Kernel.pbMessage(_INTL("You don't have any registered moves."))
      return false
    end
    @scene.pbStartScene(moves)
    loop do
      move = @scene.pbChooseMove
      if !move.is_a?(Integer)
          @scene.pbEndScene
          return false
      else
        item=$cache.moves[moves[move][0]].cost[0]
        qty=$cache.moves[moves[move][0]].cost[1]
        if !($Trainer.tutorspurchased.include?($cache.moves[moves[move][0]].move)) && @scene.pbConfirm(_INTL("Purchase {1} for {2} {3}s?", getMoveName(moves[move][0]), qty, getItemName(item)))
          if $PokemonBag.pbHasItem?(item) && $PokemonBag.pbQuantity(item) >= qty
            $PokemonBag.pbDeleteItem(item,qty)
            $Trainer.tutorspurchased.push($cache.moves[moves[move][0]].move)
            pbMoveTutorChoose(moves[move][0], false, false, true)
            @scene.pbDrawMoveList
          else
            Kernel.pbMessage(_INTL("You cannot afford {1}.", getMoveName(moves[move][0])))
          end
        elsif $Trainer.tutorspurchased.include?($cache.moves[moves[move][0]].move) && @scene.pbConfirm(_INTL("Teach {1}?", getMoveName(moves[move][0])))
          @scene.pbDrawMoveList if pbMoveTutorChoose(moves[move][0], false, false, true)
        end
      end
    end
  end
end

def pbRelearnMoveTutorScreen
  retval = true
  pbFadeOutIn(99999) {
    scene = MoveTutorScene.new
    screen = MoveTutorScreen.new(scene)
    retval = screen.pbStartScreen
  }
  return retval
end
