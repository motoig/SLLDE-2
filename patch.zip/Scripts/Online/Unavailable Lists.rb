def unavailableMoveList(move)
=begin   if move == :EARTHQUAKE ||
      move == :SWORDSDANCE ||
      move == :FIREBLAST ||
      move == :BLIZZARD ||
      move == :THUNDER ||
      move == :SLUDGEBOMB ||
      move == :ENERGYBALL ||
      move == :PSYSHOCK ||
      move == :UTURN ||
      move == :VOLTSWITCH ||
      move == :ICEBEAM ||
      move == :DRAGONCLAW ||
      move == :SECRETSWORD ||
      move == :RELICSONG ||
      move == :DRAGONASCENT
      return true
=end    else
  return false
  #  end
end

def unavailableMonList(pokemon)
=begin  if pokemon.species==:ARTICUNO ||
     pokemon.species==:MOLTRES ||
     pokemon.species==:ZAPDOS ||
     pokemon.species==:MEWTWO ||
     pokemon.species==:MEW ||
     pokemon.species==:RAIKOU ||
     pokemon.species==:ENTEI ||
     pokemon.species==:SUICUNE ||
     pokemon.species==:LUGIA ||
     pokemon.species==:HOOH ||
     pokemon.species==:CELEBI ||
     pokemon.species==:REGIROCK ||
     pokemon.species==:REGICE ||
     pokemon.species==:REGISTEEL ||
     pokemon.species==:LATIAS ||
     pokemon.species==:LATIOS ||
     pokemon.species==:KYOGRE ||
     pokemon.species==:GROUDON ||
     pokemon.species==:RAYQUAZA ||
     pokemon.species==:JIRACHI ||
     pokemon.species==:DEOXYS ||
     pokemon.species==:UXIE ||
     pokemon.species==:MESPRIT ||
     pokemon.species==:AZELF ||
     pokemon.species==:DIALGA ||
     pokemon.species==:PALKIA ||
     pokemon.species==:HEATRAN ||
     pokemon.species==:REGIGIGAS ||
     pokemon.species==:GIRATINA ||
     pokemon.species==:CRESSELIA ||
     pokemon.species==:MANAPHY ||
     pokemon.species==:DARKRAI ||
     pokemon.species==:SHAYMIN ||
     pokemon.species==:ARCEUS ||
     pokemon.species==:VICTINI ||
     pokemon.species==:COBALION ||
     pokemon.species==:TERRAKION ||
     pokemon.species==:VIRIZION ||
     pokemon.species==:TORNADUS ||
     pokemon.species==:THUNDURUS ||
     pokemon.species==:RESHIRAM ||
     pokemon.species==:ZEKROM ||
     pokemon.species==:LANDORUS ||
     pokemon.species==:KYUREM ||
     pokemon.species==:KELDEO ||
     pokemon.species==:MELOETTA ||
     pokemon.species==:GENESECT ||
     pokemon.species==:XERNEAS ||
     pokemon.species==:YVELTAL ||
     pokemon.species==:ZYGARDE ||
     pokemon.species==:TAPUKOKO ||
     pokemon.species==:TAPULELE ||
     pokemon.species==:TAPUBULU ||
     pokemon.species==:TAPUFINI ||
     pokemon.species==:COSMOG ||
     pokemon.species==:COSMOEM ||
     pokemon.species==:SOLGALEO ||
     pokemon.species==:LUNALA ||
     pokemon.species==:NIHILEGO ||
     pokemon.species==:BUZZWOLE ||
     pokemon.species==:PHEROMOSA ||
     pokemon.species==:XURKITREE ||
     pokemon.species==:CELESTEELA ||
     pokemon.species==:KARTANA ||
     pokemon.species==:GUZZLORD ||
     pokemon.species==:NECROZMA ||
     pokemon.species==:MAGEARNA ||
     pokemon.species==:MARSHADOW ||
     pokemon.species==:STAKATAKA ||
     pokemon.species==:BLACEPHALON ||
     pokemon.species==:ZERAORA
     return true
=end   else
  return false
  #   end
end
