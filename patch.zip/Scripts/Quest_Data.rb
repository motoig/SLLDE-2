module QuestModule
  #East Gearen HC
  Chapter1 = {
    :ID => "1",
    :Name => "Chapter 1 | Crossroads of Destiny",
    :Type => "Main Story",
    :Expiration => "Chapter 2",
    :QuestDescription => "I was about to be captured by that woman with purple hair, but Tesla saved me at the last moment... Now it's up to me to make my way to Gearen Laboratory and hopefully get a Pokémon myself so that I can travel the region safely.",
    :QuestVar => "210",
    :CompletionSwitch => "929",
    :QuestGiver => "???",
    :Stage1 => "Get a partner Pokémon.",
    :Location1 => "Gearen Laboratory",
    :Stage2 => "Find Melia.",
    :Location2 => "East Gearen City",
    :Stage3 => "Bring back a Pecha Berry.",
    :Location3 => "Berry Emporium",
    :Stage4 => "Return to the girl.",
    :Location4 => "East Gearen City",
    :Stage5 => "Meet up with Venam.",
    :Location5 => "Abandoned Sewers",
    :Stage6 => "Find Melia.",
    :Location6 => "Abandoned Sewers",
    :Stage7 => "Battle Venam!",
    :Location7 => "East Gearen Gym",
    :Stage8 => "Meet up with Melia!",
    :Location8 => "Route 1",
    :Stage9 => "Explore Goldenwood Forest!",
    :Location9 => "Goldenwood Forest",
    :Stage10 => "Explore the Silent Grove.",
    :Location10 => "The Silent Grove",
    :Stage11 => "Return to the Lab.",
    :Location11 => "East Gearen City",
    :Stage12 => "Escape Team Xen!",
    :Location12 => "Goldenwood Forest",
    :Stage13 => "Return to the Lab.",
    :Location13 => "East Gearen City",
  }

  CenterBreak = {
  :ID => "1",
  :Name => "Center Investigation",
  :QuestDescription => "Help Password Pat investigate the PokeCenter.",
  :QuestVar => "2501",
  :CompletionSwitch => "2501",
  :QuestGiver => "Password Pat",
  :Stage1 => "Sneak in the back of the PokeCenter.",
  :Location1 => "Serpentine City",
  :Stage2 => "Return to Password Pat.",
  :Location2 => "Serpentine City",
  }

  Route19Clearing = {
  :ID => "2",
  :Name => "Dangerous Wild Pokemon",
  :QuestDescription => "Help defeat dangerous wild Pokemon at Route 19.",
  :QuestVar => "2502",
  :CompletionSwitch => "2502",
  :QuestGiver => "Worker Dan",
  :Stage1 => "Head to Route 19 with Dan.",
  :Location1 => "Serpentine PokeCenter",
  :Stage3 => "Find and defeat wild Pokemon.",
  :Location3 => "Route 19",
  }


  LoveLetter = {
  :ID => "3",
  :Name => "Love Letter",
  :QuestDescription => "Deliver the love letter to the girl on Route 1.",
  :QuestVar => "2504",
  :CompletionSwitch => "2504",
  :QuestGiver => "Youngster Billy",
  :Stage1 => "Give the letter to the girl on Route 1.",
  :Location1 => "Route 1",
  :Stage4 => "Return to Youngster Billy.",
  :Location4 => "Mossy Town",
  }
  end 