class PBMove
  attr_reader(:move)     # Gets the symbol of the move
  attr_accessor(:pp)     # Gets the number of PP remaining for this move.
  attr_accessor(:ppup)   # Gets the number of PP Ups used for this move.

  def initialize(move = nil)
    @move = move
    @ppup = 0
    @pp = totalpp
  end

  def totalpp
    return (maxpp * (1 + 0.2 * @ppup)).floor
  end

  # yanking these from PB_Move. might be unnecessary!
  def function
    return $cache.moves[@move].function
  end

  def type
    return $cache.moves[@move].type
  end

  def category
    return $cache.moves[@move].category
  end

  def basedamage
    return $cache.moves[@move].basedamage
  end

  def accuracy
    return $cache.moves[@move].accuracy
  end

  def maxpp
    return $cache.moves[@move].maxpp
  end

  def target
    return $cache.moves[@move].target
  end

  def desc
    return $cache.moves[@move].desc
  end

  def pbMoveSummaryType(movedata, pokemon)
  if movedata.is_a?(MoveData)
    movedata = PBMove.new(movedata.move)
  end

  type = movedata.summaryType(pokemon)
  type = pbAbilityMoveTypeChange(movedata.move, pokemon.ability, type)
  type = pbCrestMoveTypeChange(pokemon.species, pokemon.form, pokemon.item, type)
  return type
  end

def pbMoveSummaryPower(movedata, pokemon)
  if movedata.is_a?(MoveData)
    movedata = PBMove.new(movedata.move)
  end

  if pokemon.species == :LUVDISC && pokemon.item == :LUVCREST && move.basedamage != 0
    return [250 - pokemon.happiness, 1].max if move.function == 0x08A # Frustration
    return [pokemon.happiness, 250].min
  end

  return movedata.summaryBaseDamage(pokemon)
end

end
