module PBDebug
  def PBDebug.logonerr
    begin
      yield
    rescue
      PBDebug.log("**Exception: #{$!.message}")
      PBDebug.log("#{$!.backtrace.inspect}")
      #      if $INTERNAL
      pbPrintException($!)
      #      end
      PBDebug.flush
    end
  end

  @@log = []
  @@foldername = RTP.getSaveFolder + "Battle Logs/"
  @@filename = "Data/debuglog.txt"
  @@maxlogs = 5

  def PBDebug.flush
    # if $DEBUG && $INTERNAL && @@log.length>0
    if $INTERNAL && @@log.length > 0
      File.open(@@filename, "a+b") { |f|
        f.write("#{@@log}")
      }
    end
    @@log.clear
  end

  def PBDebug.writeField1

    path = File.join(__dir__, "Field_Effect_Manual.txt")

    text = <<~TEXT

    #--------------------------- 49. Rose Garden [RG] --------------------------------#
    "Every rose has its thorn..."
    ############################################################################################
    (The following moves are affected by this field.):
    *   Poison-type moves increase in base power x1.5
    *   Grass-type moves increase in base power x1.3
    *   Stabbing moves increase in base power x1.3
    *   These moves increase in base power x1.2 and apply additional Poison type damage:
          Vine Whip		Razor Leaf	Power Whip	Flower Trick    Leaf Darts
          Frenzy Plant		Leaf Blade	Magical Leaf	Leaf Tornado
    *   These moves increase in base power x1.5:
          Needle Arm      Spike Cannon 
    *   The stat changing affects of these moves is increased:
          Flower Shield		Growth		
    *   Spicy Extract additionally Poisons the target and raises their Speed by 1 stage.	
    *   Ingrain deals damage to opposing Pokemon on contact, unless they are Poison-type.
    *   Secret Power has a chance to Poison
    *   Nature Power turns into Leaf Tornado
    *   Camouflage changes the user's type to Poison
    *   Terrain Pulse becomes Poison-type
    *   Shelter halves damage from Poison Moves
    ############################################################################################
    (The following abilities are affected by this field):
    *   Iron Barbs damage is doubled
    *   Immunity and Natural Cure increase the user's Special Defense on switchin
    *   Flower Gift and Leaf Guard increase the user's Defense on switchin
    *   Flower Veil grants immunity to Poison-type moves
    *   Pokemon with Poison Point always Poison targets with contact moves, and when hit by contact moves
    *   Merciless is activated
    *   Marvel Scale is activated
    *   Toxic Boost grants immunity to Poison and is activated
    *   Mimicry changes the user's type to Poison.
    *   Klutz Poisons the enemy when triggered.
    ############################################################################################
    (The following items are affected by this field):
    *   Synthetic Seed boosts Special Defense and applies Ingrain to the user
    TEXT

    # Append to the file
    File.open(path, "a") do |file|
    file.puts text if !File.readlines("Field_Effect_Manual.txt").any?{ |l| l['[RG]'] }
    end
  end

  def PBDebug.log(msg)
    # DEBUG LOGS AUTOMATIC FOR TESTING ONLY, switch which of the next two are commented to change what is being done
    # if $DEBUG && $INTERNAL
    Dir.mkdir(@@foldername) unless (File.exist?(@@foldername))
    begin
      if File.exist?(@@filename) && File.size(@@filename) > 10_000_000
        File.delete(@@filename)
      end
      if $INTERNAL
        File.open(@@filename, "a+b") { |f|
          f.write("#{msg}\r\n")
        } if @@filename != ""
      end
    rescue
      $INTERNAL = false
    end
  end

  def PBDebug.dump(msg)
    if $INTERNAL
      begin
        File.open(@@filename, "a+b") { |f|
          f.write("#{msg}\r\n")
        }
      rescue
        $INTERNAL = false
      end
    end
  end

  def PBDebug.setFileName(name)
    Dir.mkdir(@@foldername) unless (File.exist?(@@foldername))
    @@filename = (name == "") ? "" : @@foldername + "#{name}.txt"
    i = 1
    Dir.glob("#{@@foldername.gsub('\\', '/')}battlelog - *.txt").sort { |a, b|
      File.mtime(b) <=> File.mtime(a)
    }.each do |file|
      i += 1
      File.delete(file) if i > @@maxlogs
    end
  end
end
